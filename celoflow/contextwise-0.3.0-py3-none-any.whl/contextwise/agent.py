"""Unified Agent class for Contextwise v0.3.0.

This module provides the core Agent class with an agno-inspired simple interface
while preserving all advanced capabilities through optional parameters.
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional, Union, TYPE_CHECKING

# TEE import (lazy — only TEEConfig is imported at module level)
try:
    from .lib.tee.config import TEEConfig
except ImportError:
    TEEConfig = None  # type: ignore[assignment,misc]

from agents import Agent as SDKAgent, Runner, RunConfig, OpenAIProvider
from agents.memory import Session
from agents.stream_events import RunItemStreamEvent, StreamEvent

from .lib.base import AgentPlugin, PluginManager
from .lib.context import AgentContext
from .lib.session.inmemory_plugin import InMemorySession
from .lib.session import SessionManager, SessionMetadata, SessionExport, MessageValidator
from .lib.whatsmeow.utils import normalize_whatsapp_jid

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from .models import Model
    from .lib.storage import Storage


@dataclass
class Agent:
    """Unified Agent class with all core features.

    Supports multiple initialization patterns:
        # Minimal (3 lines)
        agent = Agent("gpt-4o-mini", "You are helpful")
        response = agent.chat("Hello!")

        # With features
        agent = Agent(
            model="gpt-4o-mini",
            instructions="You are helpful",
            tools=[my_tool],
            voice=VoiceConfig(...),
            channels=[WhatsAppChannel()],
        )

    Attributes:
        model: Model ID string or Model instance
        instructions: System instructions for the agent
        name: Agent display name
        description: Agent description
        locale: Default locale (e.g., "en", "es")
        tools: List of tools/functions the agent can use
        knowledge: Optional knowledge base
        storage: Optional storage backend for sessions
        channels: List of channel strings or ChannelPlugin instances
        voice: Optional voice configuration (VoiceConfig or True)
        mcp: List of MCP server configurations
        codemode: Optional CodeMode configuration for safe code execution
        memory: Optional HMLR memory configuration
        plugins: List of custom AgentPlugin instances
        response_model: Optional Pydantic model for structured output
        markdown: Whether to format output as markdown
        show_tool_calls: Whether to show tool calls in output
        user_id: Default user ID for sessions
        session_id: Default session ID
    """

    # Required - model can be string ID or Model instance
    model: Union[str, "Model"]
    instructions: str = "You are a helpful assistant."

    # Identity
    name: str = "Assistant"
    description: str = ""
    locale: str = "en"

    # Capabilities
    tools: List[Any] = field(default_factory=list)
    knowledge: Optional[Any] = None  # KnowledgeBase
    storage: Optional["Storage"] = None

    # Channels (core feature)
    channels: List[Union[str, Any]] = field(default_factory=lambda: ["api"])

    # Voice (core feature) - SEPARATE from text config
    voice: Optional[Union[bool, Any]] = None  # VoiceConfig

    # MCP integration (core feature)
    mcp: List[Any] = field(default_factory=list)  # MCPServer

    # CodeMode (core feature) - safe code execution
    codemode: Optional[Union[bool, Any]] = None  # CodeMode

    # Memory (core feature)
    memory: Optional[Union[bool, Any]] = None  # HMLRMemory

    # Scheduler (core feature) - job scheduling
    scheduler: Optional[Union[bool, Any]] = None  # APSchedulerBackendPlugin

    # TEE (Trusted Execution Environment)
    tee: Optional[Any] = None  # TEEConfig

    # Workspace for markdown behavior (auto-activates)
    workspace: Optional[Path] = None

    # Extensions
    plugins: List[AgentPlugin] = field(default_factory=list)

    # Behavior
    response_model: Optional[type] = None
    markdown: bool = True
    show_tool_calls: bool = False

    # Session
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    chat_history_db_url: Optional[str] = None  # PostgreSQL URL for persistent chat history

    # Internal state
    _sdk_agent: Optional[SDKAgent] = field(default=None, repr=False, init=False)
    _plugin_manager: Optional[PluginManager] = field(default=None, repr=False, init=False)
    _voice_agent: Optional[Any] = field(default=None, repr=False, init=False)
    _run_config: Optional[RunConfig] = field(default=None, repr=False, init=False)
    _codemode: Optional[Any] = field(default=None, repr=False, init=False)  # CodeMode instance
    _codemode_plugin: Optional[Any] = field(default=None, repr=False, init=False)  # CodeModePlugin instance
    _memory: Optional[Any] = field(default=None, repr=False, init=False)  # HMLRMemoryPlugin instance
    _memory_plugin: Optional[Any] = field(default=None, repr=False, init=False)  # HMLRMemoryPlugin instance
    _scheduler: Optional[Any] = field(default=None, repr=False, init=False)  # Scheduler instance
    _scheduler_plugin: Optional[Any] = field(default=None, repr=False, init=False)  # SchedulerPlugin instance
    _chat_history_plugin: Optional[Any] = field(default=None, repr=False, init=False)  # ChatHistoryPlugin instance
    # TEE internal state
    _tee_manager: Optional[Any] = field(default=None, repr=False, init=False)  # TEEManager instance
    _tee_identity: Optional[Any] = field(default=None, repr=False, init=False)  # TEEIdentity instance
    _audit_log: Optional[Any] = field(default=None, repr=False, init=False)  # AuditLog instance

    _in_memory_sessions: Dict[str, Session] = field(default_factory=dict, repr=False, init=False)
    _session_manager: Optional[SessionManager] = field(default=None, repr=False, init=False)
    _message_validator: Optional[MessageValidator] = field(default=None, repr=False, init=False)

    def __post_init__(self):
        """Initialize the agent with all configured features."""
        self._session_manager = SessionManager(storage=self.storage)
        self._message_validator = MessageValidator(strict_mode=False)

        # Auto-activate markdown behavior if workspace is set
        if self.workspace is not None:
            from .lib.markdown_behavior import MarkdownBehaviorPlugin

            markdown_plugin = MarkdownBehaviorPlugin(
                workspace_dir=self.workspace,
                fallback_to_instructions=True,
            )
            self.plugins.insert(0, markdown_plugin)
            logger.info(f"Markdown behavior auto-activated for workspace: {self.workspace}")

        self._build()

    def _has_codemode_enabled(self) -> bool:
        if self._codemode_plugin is not None:
            return True
        for plugin in getattr(self, "plugins", []) or []:
            if getattr(plugin, "id", None) == "codemode":
                return True
        return False

    def _build(self) -> None:
        """Build the underlying SDK agent and plugins."""
        # Handle TEE configuration (before everything else)
        if self.tee is not None and getattr(self.tee, 'enabled', False):
            self._initialize_tee()

        # Handle voice configuration
        if self.voice is True:
            try:
                from .voice import VoiceConfig
                self.voice = VoiceConfig()
            except ImportError:
                pass  # Voice not available

        # Handle CodeMode configuration - create CodeModeCorePlugin for plugin-based integration
        if self.codemode is True:
            from .lib.codemode import CodeModeCorePlugin, CodeModeConfig
            self._codemode_plugin = CodeModeCorePlugin(config=CodeModeConfig())
            self._codemode = self._codemode_plugin.config
        elif self.codemode is not None:
            from .lib.codemode import create_codemode_plugin_from_legacy
            self._codemode_plugin = create_codemode_plugin_from_legacy(self.codemode)
            self._codemode = self.codemode

        # Handle Memory configuration
        # AgentFS is now the default memory backend when memory=True
        if self.memory is True:
            from .lib.agentfs_memory import AgentFSMemoryConfig, AgentFSMemoryPlugin
            self._memory = AgentFSMemoryPlugin(config=AgentFSMemoryConfig())
            self._memory_plugin = self._memory
        elif self.memory is False or self.memory is None:
            pass
        else:
            # Support both AgentFS (recommended) and HMLR (deprecated)
            from .lib.agentfs_memory import AgentFSMemoryConfig, AgentFSMemoryPlugin
            from .lib.hmlrmem import HMLRMemoryConfig, HMLRMemoryPlugin

            if isinstance(self.memory, AgentFSMemoryPlugin):
                self._memory = self.memory
                self._memory_plugin = self.memory
            elif isinstance(self.memory, AgentFSMemoryConfig):
                self._memory = AgentFSMemoryPlugin(config=self.memory)
                self._memory_plugin = self._memory
            elif isinstance(self.memory, HMLRMemoryPlugin):
                import warnings
                warnings.warn(
                    "HMLRMemoryPlugin is deprecated. Use AgentFSMemoryPlugin instead.",
                    DeprecationWarning,
                    stacklevel=2
                )
                self._memory = self.memory
                self._memory_plugin = self.memory
            elif isinstance(self.memory, HMLRMemoryConfig):
                import warnings
                warnings.warn(
                    "HMLRMemoryConfig is deprecated. Use AgentFSMemoryConfig instead.",
                    DeprecationWarning,
                    stacklevel=2
                )
                self._memory = HMLRMemoryPlugin(config=self.memory)
                self._memory_plugin = self._memory
            else:
                raise TypeError(
                    "Agent.memory must be True, AgentFSMemoryConfig, AgentFSMemoryPlugin, "
                    "or deprecated HMLR types (HMLRMemoryConfig, HMLRMemoryPlugin)"
                )

        # Handle Scheduler configuration
        if self.scheduler is True:
            from .lib.scheduler import APSchedulerBackendPlugin
            # Create with defaults: agent_factory=True means use this agent
            self._scheduler = APSchedulerBackendPlugin(
                agent_factory=True,
                max_concurrent_jobs=3,
                auto_start=True
            )
            self._scheduler_plugin = self._scheduler
            # Set reference to this agent for agent_factory=True
            self._scheduler._agent_instance = self
        elif self.scheduler is not None:
            # User provided scheduler instance
            self._scheduler = self.scheduler
            self._scheduler_plugin = self._scheduler
            # If agent_factory=True, set reference to this agent
            if hasattr(self._scheduler, 'agent_factory') and self._scheduler.agent_factory is True:
                self._scheduler._agent_instance = self
            # Auto-start if configured (now using auto_start field directly - no method conflict)
            if getattr(self._scheduler, 'auto_start', False):
                self._scheduler.start()

        # Handle Chat History configuration
        if self.chat_history_db_url:
            from .lib.session.chat_history_plugin import ChatHistoryPlugin
            self._chat_history_plugin = ChatHistoryPlugin(db_url=self.chat_history_db_url)
        else:
            self._chat_history_plugin = None

        # Collect all tools
        all_tools = list(self.tools)

        # Add plugin tools
        for plugin in self.plugins:
            if hasattr(plugin, 'get_tools'):
                all_tools.extend(plugin.get_tools())

        # Add knowledge tools
        if self.knowledge:
            if hasattr(self.knowledge, 'get_tools'):
                all_tools.extend(self.knowledge.get_tools())

        # Resolve model ID
        model_id = self._resolve_model_id()

        # Collect SDK MCP servers (defer connection to runtime)
        # The SDK handles MCP server lifecycle properly with async context managers
        sdk_mcp_servers = []
        if self.mcp:
            for mcp_server in self.mcp:
                # Get or create the underlying SDK server without connecting
                sdk_server = mcp_server.get_or_create_sdk_server()
                if sdk_server:
                    sdk_mcp_servers.append(sdk_server)

        # CodeMode is now integrated via PluginManager (not special-cased here)
        # Pre-register MCP tools for best-effort early access
        enhanced_instructions = self.instructions
        if self._codemode_plugin:
            # Register MCP tools synchronously for best-effort early access
            # The authoritative registration happens in server.py after MCP servers connect
            if self.mcp:
                self._codemode_plugin.register_mcp_tools_sync(self.mcp)

        # Resolve model for SDK agent
        # For GeminiModel with use_native_sdk=True, we pass the model ID string
        # and configure the model provider separately in _build_run_config
        sdk_model = self._resolve_sdk_model()
        
        # Create SDK agent
        self._sdk_agent = SDKAgent(
            name=self.name,
            instructions=enhanced_instructions,
            model=sdk_model,
            tools=all_tools,
            mcp_servers=sdk_mcp_servers,  # Pass MCP servers to SDK
        )

        # Build plugin manager with all plugins including codemode, memory, scheduler, and chat history
        all_plugins = list(self.plugins)
        if self._codemode_plugin:
            all_plugins.insert(0, self._codemode_plugin)  # Prepend so CodeMode runs first
        if self._memory_plugin:
            all_plugins.append(self._memory_plugin)
        if self._scheduler_plugin:
            all_plugins.append(self._scheduler_plugin)
        if self._chat_history_plugin:
            all_plugins.append(self._chat_history_plugin)

        self._plugin_manager = PluginManager(
            base_agent=self._sdk_agent,
            plugins=all_plugins,
        )
        self._sdk_agent = self._plugin_manager.build_agent()

        # Inject Contextwise Agent reference into plugins that need it
        # This enables plugins like WebhookPlugin to call chat_async()
        for plugin in all_plugins:
            if hasattr(plugin, 'set_contextwise_agent'):
                plugin.set_contextwise_agent(self)

        # Build RunConfig with appropriate model provider
        self._run_config = self._build_run_config()

        # Build voice agent if configured
        if self.voice and not isinstance(self.voice, bool):
            self._build_voice_agent()

    def _build_run_config(self) -> RunConfig:
        """Build RunConfig with appropriate model provider.

        Creates an OpenAIProvider with custom base_url for non-OpenAI providers
        like Groq, Anthropic, Gemini, etc.

        For Gemini models with use_native_sdk=True, uses native GenAI SDK provider
        which handles thought_signature automatically for Gemini 3+ models.

        Returns:
            RunConfig configured for the model provider
        """
        # Check if model has provider-specific configuration
        if hasattr(self.model, 'provider') and hasattr(self.model, 'base_url'):
            provider = getattr(self.model, 'provider', 'openai')
            base_url = getattr(self.model, 'base_url', None)
            api_key = getattr(self.model, 'api_key', None)
            use_native_sdk = getattr(self.model, 'use_native_sdk', False)

            # Get API key from environment if not provided
            if not api_key:
                env_key_map = {
                    'groq': 'GROQ_API_KEY',
                    'anthropic': 'ANTHROPIC_API_KEY',
                    'gemini': 'GEMINI_API_KEY',
                    'openai': 'OPENAI_API_KEY',
                }
                env_var = env_key_map.get(provider, f'{provider.upper()}_API_KEY')
                api_key = os.getenv(env_var)

            # For Gemini with use_native_sdk=True, use native GenAI SDK provider
            # This handles thought_signature automatically for Gemini 3+ models
            if provider == 'gemini' and use_native_sdk:
                try:
                    from .lib.models.gemini_native_model import GeminiNativeModelProvider
                    logger.info(f"Using native GenAI SDK for Gemini model: {self._resolve_model_id()}")
                    model_provider = GeminiNativeModelProvider(
                        api_key=api_key,
                        temperature=getattr(self.model, 'temperature', None),
                        max_tokens=getattr(self.model, 'max_tokens', None),
                    )
                    return RunConfig(model_provider=model_provider)
                except ImportError as e:
                    logger.warning(f"Native GenAI SDK not available, falling back to OpenAI-compatible: {e}")

            # Create custom OpenAIProvider with the appropriate base_url
            # For non-OpenAI providers, use_responses=False forces Chat Completions API
            # instead of OpenAI's Responses API (which most providers don't support)
            if provider != 'openai' and base_url:
                model_provider = OpenAIProvider(
                    api_key=api_key,
                    base_url=base_url,
                    use_responses=False,  # Use Chat Completions API for compatibility
                )
                return RunConfig(model_provider=model_provider)

        # Default RunConfig for OpenAI models
        return RunConfig()

    def _resolve_model_id(self) -> str:
        """Get model ID string from model parameter.

        Returns:
            Model ID string suitable for the SDK
        """
        if isinstance(self.model, str):
            return self.model
        # Model instance - get the ID
        if hasattr(self.model, 'id'):
            return self.model.id
        return str(self.model)
    
    def _resolve_sdk_model(self) -> Any:
        """Resolve model for SDK agent.
        
        For contextwise models (GeminiModel, GroqModel, etc.), we need to check
        if they should be passed as-is or as a string ID. The agents SDK expects
        either a string or an agents.models.interface.Model instance.
        
        For GeminiModel with use_native_sdk=True, we return a GeminiNativeModel
        instance that properly implements the SDK Model interface and handles
        conversation history correctly.
        
        Returns:
            Model suitable for SDK agent (string ID or compatible Model instance)
        """
        if isinstance(self.model, str):
            return self.model
        
        # Check for GeminiModel with use_native_sdk=True
        # In this case, we need to return a GeminiNativeModel that implements
        # the SDK Model interface and properly handles conversation history
        try:
            from .lib.models.gemini import GeminiModel
            from .lib.models.gemini_native_model import GeminiNativeModel
            
            if isinstance(self.model, GeminiModel) and getattr(self.model, 'use_native_sdk', False):
                logger.info(f"Using GeminiNativeModel for native SDK mode with model: {self.model.id}")
                # Create a GeminiNativeModel that implements SDK Model interface
                native_model = GeminiNativeModel(
                    model_id=self.model.id,
                    api_key=self.model.api_key,
                    temperature=self.model.temperature,
                    max_tokens=self.model.max_tokens,
                )
                return native_model
        except ImportError as e:
            logger.warning(f"Could not import GeminiNativeModel: {e}")
        
        # For other contextwise models, pass the model ID string
        # The SDK will use its default model provider
        if hasattr(self.model, 'id'):
            return self.model.id
        
        # Default: try to pass the model instance, fall back to ID
        try:
            # Check if model is SDK-compatible
            from agents.models.interface import Model as SDKModel
            if isinstance(self.model, SDKModel):
                return self.model
        except ImportError:
            pass
        
        # Fall back to model ID string
        return self._resolve_model_id()

    def _build_voice_agent(self) -> None:
        """Build the voice agent with separate configuration."""
        try:
            from .voice import VoiceAgentPlugin
            voice_plugin = VoiceAgentPlugin(config=self.voice)
            voice_plugin.configure_agent(self)
            self._voice_agent = voice_plugin
        except ImportError:
            pass  # Voice not available

    @property
    def secrets_backend(self):
        """Proxy to secrets_backend attached by SecretsPlugin.

        Returns:
            SecretsBackend instance if SecretsPlugin is configured, None otherwise
        """
        if self._sdk_agent and hasattr(self._sdk_agent, 'secrets_backend'):
            return self._sdk_agent.secrets_backend
        return None

    def _get_session(self, user_id: str, session_id: Optional[str] = None) -> Optional[Session]:
        """Get or create session for user.

        Args:
            user_id: User identifier

        Returns:
            Session instance or None
        """
        resolved_user_id = user_id or "default"
        resolved_session_id = session_id or self.session_id or f"{resolved_user_id}_session"

        if self.storage:
            return self.storage.get_session(resolved_user_id, resolved_session_id)

        # Fallback: keep an in-memory Session per session_id so the underlying
        # provider receives full conversation history within a single process.
        session = self._in_memory_sessions.get(resolved_session_id)
        if session is None:
            session = InMemorySession(session_id=resolved_session_id)
            self._in_memory_sessions[resolved_session_id] = session
        return session

    def chat(
        self,
        message: str,
        user_id: Optional[str] = None,
        channel: str = "api",
        images: Optional[List[Any]] = None,  # Image
        audio: Optional[List[Any]] = None,   # Audio
        *,
        session_id: Optional[str] = None,
    ) -> str:
        """Send a message and get a response.

        Args:
            message: User message text
            user_id: User identifier for session tracking
            channel: Communication channel (api, whatsapp, voice, etc.)
            images: Optional images for multimodal
            audio: Optional audio for multimodal

        Returns:
            Agent response text
        """
        # Create context
        resolved_user_id = user_id or self.user_id or "default"
        resolved_session_id = session_id or self.session_id or resolved_user_id

        context = AgentContext(
            user_id=resolved_user_id,
            channel=channel,
            locale=self.locale,
            session_id=resolved_session_id,
        )

        # Get session
        session = self._get_session(context.user_id, context.session_id)

        # Run before hooks
        if self._plugin_manager:
            self._plugin_manager.before_run(context, message)

        # Run agent with run_config for custom providers
        result = Runner.run_sync(
            starting_agent=self._sdk_agent,
            input=message,
            context=context,
            session=session,
            run_config=self._run_config,
        )

        # Run after hooks
        if self._plugin_manager:
            self._plugin_manager.after_run(context, result)

        return result.final_output or ""

    async def chat_async(
        self,
        message: str,
        user_id: Optional[str] = None,
        channel: str = "api",
        **kwargs,
    ) -> str:
        """Async version of chat.

        Args:
            message: User message text
            user_id: User identifier for session tracking
            channel: Communication channel
            **kwargs: Additional arguments

        Returns:
            Agent response text
        """
        resolved_user_id = await normalize_whatsapp_jid(user_id or self.user_id or "default")
        resolved_session_id = await normalize_whatsapp_jid(
            kwargs.get("session_id") or self.session_id or resolved_user_id
        )

        context = AgentContext(
            user_id=resolved_user_id,
            channel=channel,
            locale=self.locale,
            session_id=resolved_session_id,
        )

        # Get session
        session = self._get_session(context.user_id, context.session_id)

        # Run async before hooks
        if self._plugin_manager:
            await self._plugin_manager.before_run_async(context, message)

        max_turns = kwargs.get("max_turns")
        if max_turns is None and self._has_codemode_enabled():
            max_turns = 25
        if max_turns is None:
            max_turns = 10

        # Check if dynamic instructions were injected by plugins (e.g., DynamicPromptInjectionPlugin)
        # If so, clone the agent with the new instructions for this run
        agent_to_run = self._sdk_agent
        dynamic_instructions = context.metadata.get("dynamic_instructions")
        if dynamic_instructions and dynamic_instructions != self._sdk_agent.instructions:
            agent_to_run = self._sdk_agent.clone(instructions=dynamic_instructions)
            logger.debug(f"Using dynamic instructions ({len(dynamic_instructions)} chars)")

        # Run agent with run_config for custom providers
        result = await Runner.run(
            starting_agent=agent_to_run,
            input=message,
            context=context,
            session=session,
            max_turns=max_turns,
            run_config=self._run_config,
        )

        # Run async after hooks
        if self._plugin_manager:
            await self._plugin_manager.after_run_async(context, result)

        return result.final_output or ""

    async def chat_streamed(
        self,
        message: str,
        user_id: Optional[str] = None,
        channel: str = "api",
        **kwargs,
    ) -> AsyncIterator[StreamEvent]:
        """Streaming version of chat that yields SDK events.

        This method uses Runner.run_streamed() to get streaming events
        including tool calls as they happen.

        Args:
            message: User message text
            user_id: User identifier for session tracking
            channel: Communication channel
            **kwargs: Additional arguments

        Yields:
            StreamEvent instances (RunItemStreamEvent, RawResponsesStreamEvent, etc.)
        """
        resolved_user_id = user_id or self.user_id or "default"
        resolved_session_id = kwargs.get("session_id") or self.session_id or resolved_user_id

        context = AgentContext(
            user_id=resolved_user_id,
            channel=channel,
            locale=self.locale,
            session_id=resolved_session_id,
        )

        # Get session
        session = self._get_session(context.user_id, context.session_id)

        # Run async before hooks
        if self._plugin_manager:
            await self._plugin_manager.before_run_async(context, message)

        max_turns = kwargs.get("max_turns")
        if max_turns is None and self._has_codemode_enabled():
            max_turns = 25
        if max_turns is None:
            max_turns = 10

        # Check if dynamic instructions were injected by plugins (e.g., DynamicPromptInjectionPlugin)
        agent_to_run = self._sdk_agent
        dynamic_instructions = context.metadata.get("dynamic_instructions")
        if dynamic_instructions and dynamic_instructions != self._sdk_agent.instructions:
            agent_to_run = self._sdk_agent.clone(instructions=dynamic_instructions)
            logger.debug(f"Using dynamic instructions ({len(dynamic_instructions)} chars)")

        # Run agent in streaming mode
        result = Runner.run_streamed(
            starting_agent=agent_to_run,
            input=message,
            context=context,
            session=session,
            max_turns=max_turns,
            run_config=self._run_config,
        )

        # Yield stream events
        async for event in result.stream_events():
            yield event

        # Run async after hooks with final result
        if self._plugin_manager:
            await self._plugin_manager.after_run_async(context, result)

    def print_response(
        self,
        message: str,
        stream: bool = True,
    ) -> None:
        """Print response with optional streaming (agno compatibility).

        Args:
            message: User message
            stream: Whether to stream (currently ignored)
        """
        response = self.chat(message)
        print(response)

    # Voice session methods
    async def start_voice_session(self, room_name: str) -> Any:
        """Start a voice session in a LiveKit room.

        Args:
            room_name: LiveKit room name

        Returns:
            LiveKit AgentSession

        Raises:
            ValueError: If voice not configured
        """
        if not self._voice_agent:
            raise ValueError("Voice not configured for this agent")

        return await self._voice_agent.start_voice_session(room_name)

    def get_voice_instructions(self) -> str:
        """Get voice-specific instructions.

        Returns voice.instructions if configured, else falls back
        to text instructions.

        Returns:
            Voice instructions string
        """
        if self.voice and not isinstance(self.voice, bool):
            if hasattr(self.voice, 'instructions') and self.voice.instructions:
                return self.voice.instructions
        return self.instructions

    # Server methods
    def serve(
        self,
        port: int = 8000,
        channels: Optional[List[str]] = None,
        debug: Optional[bool] = None,
    ):
        """Start server for this agent.

        Auto-mounts webhook routers for configured channels.

        Args:
            port: Server port
            channels: Optional channel filter
            debug: Enable DEBUG logging mode (optional, resolves from env if None)
                When enabled:
                - Sets logging level to DEBUG for contextwise namespace
                - Logs HTTP request/response details (sanitized)
                - Enables detailed exception tracebacks
        """
        from .server import serve
        serve(self, port=port, debug=debug)

    def create_router(self):
        """Create FastAPI router for this agent.

        Returns:
            FastAPI APIRouter
        """
        from .server import create_router
        return create_router(self)

    def clone(
        self,
        *,
        name: Optional[str] = None,
        instructions: Optional[str] = None,
        tools: Optional[List[Any]] = None,
        model: Optional[Union[str, "Model"]] = None,
        **kwargs,
    ) -> "Agent":
        """Create a copy of this agent with optional overrides.

        This method is required by plugins that need to extend the agent
        with additional tools, guardrails, or hooks.

        Args:
            name: Override agent name
            instructions: Override instructions
            tools: Override or extend tools list
            model: Override model
            **kwargs: Additional overrides

        Returns:
            New Agent instance with overrides applied
        """
        from copy import copy
        
        # Create shallow copy
        new_agent = copy(self)
        
        # Apply explicit overrides
        if name is not None:
            new_agent.name = name
        if instructions is not None:
            new_agent.instructions = instructions
        if model is not None:
            new_agent.model = model
        
        # Handle tools - typically plugins extend the tools list
        if tools is not None:
            # If tools provided, use them (could be extended list)
            new_agent.tools = list(tools)
        else:
            # Keep existing tools
            new_agent.tools = list(self.tools)
        
        # Apply any additional kwargs
        for key, value in kwargs.items():
            if hasattr(new_agent, key):
                setattr(new_agent, key, value)
        
        # Important: preserve plugin references but don't rebuild
        # The plugin manager handles rebuilding
        new_agent._sdk_agent = None
        new_agent._plugin_manager = None
        
        # Rebuild the agent with new configuration
        new_agent._build()
        
        # Preserve plugin index if it was attached
        if hasattr(self, 'plugins') and hasattr(self, 'plugin_index'):
            new_agent.plugins = self.plugins
            new_agent.plugin_index = self.plugin_index
        
        return new_agent

    async def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session metadata and information.
        
        Args:
            session_id: Session identifier
            
        Returns:
            Dictionary with session metadata or None if not found
        """
        if not self._session_manager:
            return None
        
        meta = await self._session_manager.get_session_metadata(session_id)
        if meta:
            return meta.to_dict()
        return None
    
    async def clear_session(self, session_id: str) -> bool:
        """Clear a session's conversation history.
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if session was cleared, False if not found
        """
        session = self._in_memory_sessions.get(session_id)
        if session:
            await session.clear_session()
            logger.info(f"Cleared session {session_id}")
            return True
        
        if self.storage:
            try:
                session = self.storage.get_session("unknown", session_id)
                if session:
                    await session.clear_session()
                    logger.info(f"Cleared persistent session {session_id}")
                    return True
            except Exception as e:
                logger.error(f"Failed to clear session {session_id}: {e}")
        
        return False
    
    async def export_session(self, session_id: str) -> Optional[str]:
        """Export session data as JSON string.
        
        Args:
            session_id: Session identifier
            
        Returns:
            JSON string with session data or None if not found
        """
        if not self._session_manager:
            return None
        
        session = self._in_memory_sessions.get(session_id)
        if not session:
            if self.storage:
                session = self.storage.get_session("unknown", session_id)
        
        if session:
            items = await session.get_items()
            export = await self._session_manager.export_session(session_id, items)
            if export:
                return export.to_json()
        
        return None
    
    async def import_session(self, json_data: str) -> bool:
        """Import session data from JSON string.
        
        Args:
            json_data: JSON string with session export data
            
        Returns:
            True if import successful, False otherwise
        """
        if not self._session_manager:
            return False
        
        try:
            export = SessionExport.from_json(json_data)
            await self._session_manager.import_session(export)
            
            session_id = export.metadata.session_id
            session = self._in_memory_sessions.get(session_id)
            if not session:
                session = InMemorySession(session_id=session_id)
                self._in_memory_sessions[session_id] = session
            
            await session.add_items(export.items)
            logger.info(f"Imported session {session_id} with {len(export.items)} items")
            return True
        except Exception as e:
            logger.error(f"Failed to import session: {e}")
            return False
    
    async def list_sessions(
        self,
        user_id: Optional[str] = None,
        channel: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List sessions with optional filtering.
        
        Args:
            user_id: Filter by user ID
            channel: Filter by channel
            
        Returns:
            List of session metadata dictionaries
        """
        if not self._session_manager:
            return []
        
        sessions = await self._session_manager.list_sessions(user_id, channel)
        return [s.to_dict() for s in sessions]
    
    async def prune_sessions(self) -> int:
        """Prune old or inactive sessions.
        
        Returns:
            Number of sessions pruned
        """
        if not self._session_manager:
            return 0
        
        return await self._session_manager.prune_sessions()

    # ----- TEE Methods -----

    def _initialize_tee(self) -> None:
        """Initialize TEE components from TEEConfig.

        Called from _build() when self.tee.enabled is True.
        Sets up TEEManager, derives identity, configures audit log,
        network restrictions, and auto-attaches TEE-native plugins.
        """
        from .lib.tee import TEEManager, TEENetworkRestrictor, AuditLog
        from .lib.tee.plugins import TEEAuthPlugin, TEEMemoryPlugin

        # Validate config
        self.tee.validate()

        # Core TEE manager
        self._tee_manager = TEEManager(self.tee)
        self._tee_identity = self._tee_manager.derive_identity()
        logger.info(f"TEE identity: {self._tee_identity.address}")

        # Audit log
        if self.tee.enable_audit_logging:
            self._audit_log = AuditLog(agent_id=self._tee_identity.address)
            self._audit_log.log(
                event_type="agent.lifecycle",
                action="tee_initialized",
                details={
                    "domain": self.tee.domain,
                    "mock": self._tee_manager.is_mock,
                },
            )

        # Network restrictions
        if self.tee.allowed_domains:
            self._tee_network = TEENetworkRestrictor(
                allowed_domains=self.tee.allowed_domains,
                egress_proxy=self.tee.egress_proxy,
            )
            logger.info(
                f"TEE network restrictions: {len(self.tee.allowed_domains)} domains"
            )

        # Auto-attach TEE plugins
        auth_plugin = TEEAuthPlugin(self._tee_manager)
        self.plugins.append(auth_plugin)

        if self.tee.encrypt_memory:
            memory_plugin = TEEMemoryPlugin(self._tee_manager)
            self.plugins.append(memory_plugin)

    def get_attestation(
        self, application_data: Optional[bytes] = None,
    ) -> Dict[str, Any]:
        """Generate TEE attestation quote.

        Args:
            application_data: Optional data to include (max 64 bytes).

        Returns:
            Dict with attestation quote, event_log, and agent_address.
        """
        if not self.tee or not getattr(self.tee, 'enabled', False):
            return {"error": "TEE not enabled"}
        if not self._tee_manager:
            return {"error": "TEE manager not initialized"}

        data = application_data or b""
        result = self._tee_manager.get_attestation(data)

        if self._audit_log:
            self._audit_log.log(
                event_type="tee.attestation",
                action="generated",
                details={"mock": self._tee_manager.is_mock},
            )

        return result

    def audit_log(
        self,
        event_type: str,
        action: str,
        details: Dict[str, Any],
        user_id: Optional[str] = None,
    ) -> None:
        """Log an auditable event.

        No-op if audit logging is not enabled.

        Args:
            event_type: Event category (e.g., "agent.action").
            action: Human-readable action description.
            details: Arbitrary structured data.
            user_id: Optional user identifier.
        """
        if self._audit_log:
            self._audit_log.log(event_type, action, details, user_id)

    async def prewarm_tools(self) -> None:
        """Prewarm MCP tool caches to eliminate first-message latency.
        
        This method creates a minimal context and calls get_all_tools() on the underlying
        SDK agent to trigger MCP server tool enumeration and caching during agent initialization.
        """
        import time
        start_time = time.time()
        
        try:
            # Create minimal context for prewarming
            dummy_context = AgentContext(
                user_id="prewarm",
                session_id="prewarm",
                channel=None,
                metadata={"prewarm": True},
            )
            
            # Import RunContextWrapper from agents SDK
            from agents.run_context import RunContextWrapper
            from agents import RunConfig
            
            context_wrapper = RunContextWrapper(
                context=dummy_context,
            )
            
            # This will cache MCP tools by calling server.list_tools() on the SDK agent
            await self._sdk_agent.get_all_tools(context_wrapper)
            
            duration = time.time() - start_time
            logger.info(f"Agent '{self.name}' prewarmed tools successfully in {duration:.2f}s")
            
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Tool prewarming failed after {duration:.2f}s: {e}")
            # Continue - agent still works, just slower on first message
