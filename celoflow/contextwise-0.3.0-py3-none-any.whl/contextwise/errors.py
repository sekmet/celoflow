"""Contextwise Error Codes and Exception Handling.

This module defines domain-specific error codes for the Contextwise framework
using apiexception's standardized error handling patterns.

Example:
    from contextwise.errors import ContextwiseExceptionCode
    from apiexception import APIException

    # Raise a structured error
    raise APIException(error_code=ContextwiseExceptionCode.INVALID_REQUEST)

    # With custom message
    raise APIException(
        error_code=ContextwiseExceptionCode.AGENT_EXECUTION_ERROR,
        message="Custom error message",
    )
"""

from __future__ import annotations

from enum import Enum
from typing import Optional, Tuple

try:
    from apiexception import BaseExceptionCode
except ImportError:
    try:
        from api_exception import BaseExceptionCode
    except ImportError:
        BaseExceptionCode = Enum


class ContextwiseExceptionCode(BaseExceptionCode):
    """Domain-specific error codes for Contextwise API.

    Each code maps to: (error_code, message, description, rfc7807_type, rfc7807_instance)

    Error Code Conventions:
        - CW-4XX: Client errors (invalid requests, missing data)
        - CW-5XX: Server errors (execution failures, internal errors)
        - CW-MCP-XXX: MCP-related errors
        - CW-SESSION-XXX: Session management errors
        - CW-STORAGE-XXX: Storage backend errors
    """

    # ==========================================================================
    # Client Errors (4XX)
    # ==========================================================================

    INVALID_REQUEST = (
        "CW-400",
        "Invalid Request",
        "The request payload is malformed or contains invalid data.",
        "https://contextwise.io/errors/invalid-request",
        None,
    )

    MISSING_MESSAGE = (
        "CW-401",
        "Missing Message",
        "No user message found in the request. A 'message' field is required.",
        "https://contextwise.io/errors/missing-message",
        None,
    )

    INVALID_MODEL = (
        "CW-402",
        "Invalid Model",
        "The specified model could not be resolved or is not available.",
        "https://contextwise.io/errors/invalid-model",
        None,
    )

    INVALID_PAYLOAD = (
        "CW-403",
        "Invalid Payload",
        "The request body could not be parsed or validated.",
        "https://contextwise.io/errors/invalid-payload",
        None,
    )

    MISSING_USER_ID = (
        "CW-404",
        "Missing User ID",
        "A user_id is required for this operation.",
        "https://contextwise.io/errors/missing-user-id",
        None,
    )

    # ==========================================================================
    # Session Errors
    # ==========================================================================

    SESSION_NOT_FOUND = (
        "CW-SESSION-404",
        "Session Not Found",
        "The requested session or conversation ID does not exist.",
        "https://contextwise.io/errors/session-not-found",
        None,
    )

    SESSION_CREATE_ERROR = (
        "CW-SESSION-500",
        "Session Creation Error",
        "Failed to create a new session.",
        "https://contextwise.io/errors/session-create-error",
        None,
    )

    SESSION_INVALID = (
        "CW-SESSION-400",
        "Invalid Session",
        "The session ID provided is invalid or expired.",
        "https://contextwise.io/errors/session-invalid",
        None,
    )

    # ==========================================================================
    # Agent Execution Errors
    # ==========================================================================

    AGENT_EXECUTION_ERROR = (
        "CW-500",
        "Agent Execution Error",
        "An error occurred during agent execution.",
        "https://contextwise.io/errors/agent-execution",
        None,
    )

    AGENT_NOT_FOUND = (
        "CW-501",
        "Agent Not Found",
        "The requested agent is not registered or available.",
        "https://contextwise.io/errors/agent-not-found",
        None,
    )

    AGENT_TIMEOUT = (
        "CW-502",
        "Agent Timeout",
        "The agent execution exceeded the allowed time limit.",
        "https://contextwise.io/errors/agent-timeout",
        None,
    )

    # ==========================================================================
    # MCP Errors
    # ==========================================================================

    MCP_ERROR = (
        "CW-MCP-500",
        "MCP Error",
        "An error occurred while communicating with an MCP server.",
        "https://contextwise.io/errors/mcp-error",
        None,
    )

    MCP_CONNECTION_ERROR = (
        "CW-MCP-501",
        "MCP Connection Error",
        "Failed to connect to the MCP server.",
        "https://contextwise.io/errors/mcp-connection",
        None,
    )

    MCP_TOOL_ERROR = (
        "CW-MCP-502",
        "MCP Tool Error",
        "An error occurred while invoking an MCP tool.",
        "https://contextwise.io/errors/mcp-tool",
        None,
    )

    # ==========================================================================
    # Storage Errors
    # ==========================================================================

    STORAGE_ERROR = (
        "CW-STORAGE-500",
        "Storage Error",
        "An error occurred with the storage backend.",
        "https://contextwise.io/errors/storage-error",
        None,
    )

    STORAGE_CONNECTION_ERROR = (
        "CW-STORAGE-501",
        "Storage Connection Error",
        "Failed to connect to the storage backend.",
        "https://contextwise.io/errors/storage-connection",
        None,
    )

    STORAGE_READ_ERROR = (
        "CW-STORAGE-502",
        "Storage Read Error",
        "Failed to read data from storage.",
        "https://contextwise.io/errors/storage-read",
        None,
    )

    STORAGE_WRITE_ERROR = (
        "CW-STORAGE-503",
        "Storage Write Error",
        "Failed to write data to storage.",
        "https://contextwise.io/errors/storage-write",
        None,
    )

    # ==========================================================================
    # Channel Errors
    # ==========================================================================

    CHANNEL_ERROR = (
        "CW-CHANNEL-500",
        "Channel Error",
        "An error occurred with a communication channel.",
        "https://contextwise.io/errors/channel-error",
        None,
    )

    CHANNEL_NOT_FOUND = (
        "CW-CHANNEL-404",
        "Channel Not Found",
        "The requested channel is not configured.",
        "https://contextwise.io/errors/channel-not-found",
        None,
    )

    # ==========================================================================
    # Voice Errors
    # ==========================================================================

    VOICE_ERROR = (
        "CW-VOICE-500",
        "Voice Error",
        "An error occurred with voice processing.",
        "https://contextwise.io/errors/voice-error",
        None,
    )

    VOICE_NOT_CONFIGURED = (
        "CW-VOICE-404",
        "Voice Not Configured",
        "Voice features are not configured for this agent.",
        "https://contextwise.io/errors/voice-not-configured",
        None,
    )

    # ==========================================================================
    # CodeMode Errors
    # ==========================================================================

    CODEMODE_ERROR = (
        "CW-CODEMODE-500",
        "CodeMode Error",
        "An error occurred during code execution.",
        "https://contextwise.io/errors/codemode-error",
        None,
    )

    CODEMODE_TIMEOUT = (
        "CW-CODEMODE-502",
        "CodeMode Timeout",
        "Code execution exceeded the allowed time limit.",
        "https://contextwise.io/errors/codemode-timeout",
        None,
    )

    # ==========================================================================
    # Acontext Errors
    # ==========================================================================

    ACONTEXT_ERROR = (
        "CW-ACONTEXT-500",
        "Acontext Error",
        "An error occurred with Acontext integration.",
        "https://contextwise.io/errors/acontext-error",
        None,
    )

    ACONTEXT_NOT_CONFIGURED = (
        "CW-ACONTEXT-404",
        "Acontext Not Configured",
        "Acontext integration is not configured.",
        "https://contextwise.io/errors/acontext-not-configured",
        None,
    )

    ACONTEXT_LEARNING_ERROR = (
        "CW-ACONTEXT-501",
        "Learning Error",
        "An error occurred during skill learning.",
        "https://contextwise.io/errors/acontext-learning",
        None,
    )

    ACONTEXT_EXPERIENCE_NOT_FOUND = (
        "CW-ACONTEXT-405",
        "Experience Not Found",
        "The requested experience was not found.",
        "https://contextwise.io/errors/acontext-experience-not-found",
        None,
    )

    # ==========================================================================
    # Internal Errors
    # ==========================================================================

    INTERNAL_ERROR = (
        "CW-ISE-500",
        "Internal Server Error",
        "An unexpected internal error occurred.",
        "https://contextwise.io/errors/internal-error",
        None,
    )

    PLUGIN_ERROR = (
        "CW-PLUGIN-500",
        "Plugin Error",
        "An error occurred in a plugin.",
        "https://contextwise.io/errors/plugin-error",
        None,
    )

    CONFIGURATION_ERROR = (
        "CW-CONFIG-500",
        "Configuration Error",
        "Invalid or missing configuration.",
        "https://contextwise.io/errors/config-error",
        None,
    )


# Default internal server error code for fallback middleware
DEFAULT_ISE_CODE = ContextwiseExceptionCode.INTERNAL_ERROR
