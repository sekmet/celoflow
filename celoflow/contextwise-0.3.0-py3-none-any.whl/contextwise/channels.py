"""Channel plugins for Contextwise v0.3.0.

This module provides channel implementations for different communication platforms
like WhatsApp, API, Voice, etc.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Dict, Optional, Any, TYPE_CHECKING, List

from .lib.base import AgentPlugin
from .lib.context import AgentContext

if TYPE_CHECKING:
    from fastapi import APIRouter


@dataclass
class ChannelPlugin(AgentPlugin[AgentContext]):
    """Base class for channel plugins.

    All channel implementations should extend this class.
    """

    channel_id: str = ""

    def configure_agent(self, agent: Any) -> Any:
        """Configure the agent with this channel.

        Default implementation does nothing - channels typically don't modify the agent itself.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        return agent

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a message to a user on this channel.

        Args:
            user_id: User identifier
            text: Message text
            metadata: Optional metadata

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    def create_webhook_router(self) -> Optional["APIRouter"]:
        """Create FastAPI router for webhook handling.

        Returns:
            FastAPI APIRouter or None if not applicable

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        raise NotImplementedError

    @property
    def is_voice_enabled(self) -> bool:
        """Check if this channel supports voice.

        Returns:
            True if voice is supported
        """
        return False


@dataclass
class APIChannel(ChannelPlugin):
    """REST API channel.

    This is the default channel for direct API interactions.
    """

    channel_id: str = "api"
    id: str = "api-channel"
    name: str = "API Channel"
    version: str = "0.2.0"

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send message via API (usually returned directly).

        Args:
            user_id: User identifier
            text: Message text
            metadata: Optional metadata
        """
        # For API channel, messages are typically returned directly
        # No async notification needed
        pass

    def create_webhook_router(self) -> Optional["APIRouter"]:
        """API channel doesn't need webhooks.

        Returns:
            None
        """
        return None


@dataclass
class WhatsAppChannel(ChannelPlugin):
    """WhatsApp Business API channel.

    Attributes:
        access_token: WhatsApp API access token
        phone_number_id: WhatsApp phone number ID
        verify_token: Webhook verification token
        business_account_id: Business account ID
        voice_enabled: Whether voice messages are supported
    """

    channel_id: str = "whatsapp"
    id: str = "whatsapp-channel"
    name: str = "WhatsApp Channel"
    version: str = "0.2.0"

    access_token: Optional[str] = None
    phone_number_id: Optional[str] = None
    verify_token: Optional[str] = None
    business_account_id: Optional[str] = None
    voice_enabled: bool = False
    
    # Internal reference to the agent (set via configure_agent)
    _agent: Optional[Any] = None

    def __post_init__(self):
        """Initialize WhatsApp channel with environment variables."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None
        # Load from environment if not provided
        if not self.access_token:
            self.access_token = os.getenv("WHATSAPP_ACCESS_TOKEN", "")
        if not self.phone_number_id:
            self.phone_number_id = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
        if not self.verify_token:
            self.verify_token = os.getenv("WHATSAPP_VERIFY_TOKEN", "")
        if not self.business_account_id:
            self.business_account_id = os.getenv("WHATSAPP_BUSINESS_ACCOUNT_ID", "")

    def configure_agent(self, agent: Any) -> Any:
        """Store agent reference for message processing.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        self._agent = agent
        return agent

    @property
    def is_voice_enabled(self) -> bool:
        """Check if voice is enabled for WhatsApp.

        Returns:
            True if voice_enabled is True
        """
        return self.voice_enabled

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a WhatsApp message to user.

        Args:
            user_id: WhatsApp phone number
            text: Message text
            metadata: Optional metadata
        """
        from .lib.whatsapp import send_text_message

        if not self.access_token or not self.phone_number_id:
            raise ValueError("WhatsApp credentials not configured")

        send_text_message(
            access_token=self.access_token,
            phone_number_id=self.phone_number_id,
            to=user_id,
            message=text,
        )

    def validate_webhook(
        self,
        mode: Optional[str],
        token: Optional[str],
        challenge: Optional[str],
    ) -> Optional[str]:
        """Validate WhatsApp webhook verification request.

        Args:
            mode: The hub.mode query parameter (should be "subscribe").
            token: The hub.verify_token query parameter.
            challenge: The hub.challenge query parameter to echo back.

        Returns:
            The challenge string if validation succeeds, None otherwise.
        """
        if mode == "subscribe" and token == self.verify_token:
            return challenge
        return None

    def parse_webhook_message(self, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse incoming webhook payload to extract message data.

        Args:
            body: The webhook payload from WhatsApp.

        Returns:
            Parsed message dict with keys: type, content, from, id.
            None if no valid message found.
        """
        if body.get("object") != "whatsapp_business_account":
            return None

        for entry in body.get("entry", []):
            for change in entry.get("changes", []):
                messages = change.get("value", {}).get("messages", [])
                if not messages:
                    continue

                message = messages[0]
                msg_type = message.get("type")
                msg_id = message.get("id")
                msg_from = message.get("from")

                # Extract content based on type
                content = None
                if msg_type == "text":
                    content = message.get("text", {}).get("body")
                elif msg_type == "image":
                    content = message.get("image", {}).get("caption", "Image received")
                elif msg_type == "video":
                    content = message.get("video", {}).get("caption", "Video received")
                elif msg_type == "audio":
                    content = "Audio received"
                elif msg_type == "document":
                    content = "Document received"

                if content is not None:
                    return {
                        "type": msg_type,
                        "content": content,
                        "from": msg_from,
                        "id": msg_id,
                        "raw": message,
                    }

        return None

    def parse_webhook_call(self, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse incoming webhook payload to extract call data.

        Args:
            body: The webhook payload from WhatsApp.

        Returns:
            Parsed call dict with keys: id, from, to, event, sdp, etc.
            None if no valid call found.
        """
        if body.get("object") != "whatsapp_business_account":
            return None

        for entry in body.get("entry", []):
            for change in entry.get("changes", []):
                # Check if this is a calls webhook (not messages)
                if change.get("field") != "calls":
                    continue

                calls = change.get("value", {}).get("calls", [])
                if not calls:
                    continue

                call = calls[0]
                return {
                    "id": call.get("id"),
                    "from": call.get("from"),
                    "to": call.get("to"),
                    "event": call.get("event"),  # connect, terminate, etc.
                    "direction": call.get("direction"),
                    "timestamp": call.get("timestamp"),
                    "status": call.get("status"),
                    "session": call.get("session", {}),  # Contains SDP for WebRTC
                    "raw": call,
                }

        return None

    def create_webhook_router(self) -> "APIRouter":
        """Create FastAPI router for WhatsApp webhooks.

        Returns:
            FastAPI APIRouter with webhook endpoints
        """
        from .lib.whatsapp import create_whatsapp_router

        # Create message handler if agent is available
        message_handler = None
        call_handler = None
        if self._agent is not None:
            message_handler = self._create_message_handler()
            # Only create call handler if voice is enabled
            if self.voice_enabled:
                call_handler = self._create_call_handler()

        # Create router with proper configuration
        return create_whatsapp_router(
            api_plugin=self,
            async_message_handler=message_handler,
            call_handler=call_handler,
        )

    def _create_message_handler(self):
        """Create an async message handler that processes messages through the agent.

        Returns:
            Async message handler function.
        """
        import logging
        from .lib.whatsapp.utils import send_text_message_async

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(message: Dict[str, Any]) -> None:
            phone_number = message.get("from", "")
            content = message.get("content", "")

            try:
                # Process through agent
                response = await agent.chat_async(
                    message=content,
                    user_id=phone_number,
                    channel="whatsapp",
                )

                # Send response via WhatsApp API
                if response:
                    error = await send_text_message_async(phone_number, str(response))
                    if error:
                        logger.error(f"Failed to send WhatsApp message: {error}")

            except Exception as e:
                logger.exception(f"Error processing WhatsApp message: {e}")
                # Send error message
                try:
                    await send_text_message_async(
                        phone_number,
                        "Sorry, there was an error processing your message.",
                    )
                except Exception:
                    logger.exception("Failed to send error message")

        return handler

    def _create_call_handler(self):
        """Create an async call handler for WhatsApp voice calls.

        This handler processes incoming WhatsApp voice calls and connects
        them to a voice agent via LiveKit using the WhatsAppVoiceBridge.

        Returns:
            Async call handler function.
        """
        import logging
        import os

        from .lib.whatsapp.voice_bridge import WhatsAppVoiceBridge

        logger = logging.getLogger(__name__)

        # Get voice configuration from agent if available
        voice_config = {}
        if self._agent and hasattr(self._agent, "voice") and self._agent.voice:
            voice = self._agent.voice
            voice_config = {
                "instructions": getattr(voice, "instructions", None),
                "model": getattr(voice, "model", None),
                "stt": getattr(voice, "stt", "groq/whisper-large-v3-turbo"),
                "stt_language": getattr(voice, "stt_language", "en"),
                "tts": getattr(voice, "tts", "inworld/lupita"),
                "tts_voice": getattr(voice, "tts_voice", None),
            }
            logger.info(f"Voice config: stt={voice_config.get('stt')}, tts={voice_config.get('tts')}")

        # Create voice bridge instance with full configuration
        voice_bridge = WhatsAppVoiceBridge(
            agent=self._agent,
            phone_number_id=self.phone_number_id,
            access_token=self.access_token,
            livekit_url=os.getenv("LIVEKIT_URL", ""),
            livekit_api_key=os.getenv("LIVEKIT_API_KEY", ""),
            livekit_api_secret=os.getenv("LIVEKIT_API_SECRET", ""),
            bridge_url=os.getenv("WHATSAPP_BRIDGE_URL", ""),
            voice_config=voice_config,
        )

        async def handler(call_data: Dict[str, Any]) -> None:
            call_id = call_data.get("id", "")
            caller = call_data.get("from", "")
            event = call_data.get("event", "")

            logger.info(
                f"WhatsApp call handler: event={event}, from={caller}, call_id={call_id}"
            )

            if event == "connect":
                # Check if voice is properly configured
                livekit_url = os.getenv("LIVEKIT_URL", "")
                bridge_url = os.getenv("WHATSAPP_BRIDGE_URL", "")

                if not livekit_url and not bridge_url:
                    logger.warning(
                        f"Neither LIVEKIT_URL nor WHATSAPP_BRIDGE_URL configured. "
                        f"Cannot answer call {call_id}."
                    )
                    return

                # Handle call connection via voice bridge
                result = await voice_bridge.handle_call_connect(call_data)

                if "error" in result:
                    logger.error(f"Failed to connect call {call_id}: {result['error']}")
                else:
                    logger.info(
                        f"Call {call_id} connected successfully. "
                        f"Status: {result.get('status')}"
                    )

            elif event == "terminate":
                status = call_data.get("status", "")
                logger.info(f"Call {call_id} terminated with status: {status}")

                # Handle call termination via voice bridge
                await voice_bridge.handle_call_terminate(call_id)

            else:
                logger.debug(f"Unhandled call event: {event}")

        return handler


@dataclass
class FacebookChannel(ChannelPlugin):
    """Facebook Messenger channel.

    This channel enables Facebook Page messaging via Meta Graph API.

    Attributes:
        access_token: Facebook/Meta access token
        page_id: Facebook Page ID
        verify_token: Webhook verification token
        app_secret: App secret for signature verification
    """

    channel_id: str = "facebook"
    id: str = "facebook-channel"
    name: str = "Facebook Channel"
    version: str = "0.2.0"

    access_token: Optional[str] = None
    page_id: Optional[str] = None
    verify_token: Optional[str] = None
    app_secret: Optional[str] = None

    # Internal reference to the agent (set via configure_agent)
    _agent: Optional[Any] = None

    def __post_init__(self):
        """Initialize Facebook channel with environment variables."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None
        # Load from environment if not provided
        if not self.access_token:
            self.access_token = os.getenv("FACEBOOK_ACCESS_TOKEN", "")
        if not self.page_id:
            self.page_id = os.getenv("FACEBOOK_PAGE_ID", "")
        if not self.verify_token:
            self.verify_token = os.getenv("FACEBOOK_VERIFY_TOKEN", "")
        if not self.app_secret:
            self.app_secret = os.getenv("FACEBOOK_APP_SECRET", "")

    def configure_agent(self, agent: Any) -> Any:
        """Store agent reference for message processing.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        self._agent = agent
        return agent

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a Facebook message to user.

        Args:
            user_id: Facebook user PSID
            text: Message text
            metadata: Optional metadata
        """
        from .lib.facebook import send_facebook_message

        if not self.access_token:
            raise ValueError("Facebook access token not configured")

        send_facebook_message(
            recipient_id=user_id,
            text=text,
            access_token=self.access_token,
        )

    def validate_webhook(
        self,
        mode: Optional[str],
        token: Optional[str],
        challenge: Optional[str],
    ) -> Optional[str]:
        """Validate Facebook webhook verification request.

        Args:
            mode: The hub.mode query parameter (should be "subscribe").
            token: The hub.verify_token query parameter.
            challenge: The hub.challenge query parameter to echo back.

        Returns:
            The challenge string if validation succeeds, None otherwise.
        """
        if mode == "subscribe" and token == self.verify_token:
            return challenge
        return None

    def create_webhook_router(self) -> "APIRouter":
        """Create FastAPI router for Facebook webhooks.

        Returns:
            FastAPI APIRouter with webhook endpoints
        """
        from .lib.facebook import create_facebook_router

        # Create message handler if agent is available
        message_handler = None
        if self._agent is not None:
            message_handler = self._create_message_handler()

        return create_facebook_router(
            api_plugin=self,
            async_message_handler=message_handler,
        )

    def _create_message_handler(self):
        """Create an async message handler that processes messages through the agent.

        Returns:
            Async message handler function.
        """
        import logging
        from .lib.facebook.utils import send_facebook_message_async

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(message: Dict[str, Any]) -> None:
            user_id = message.get("from", "")
            content = message.get("content", "")

            try:
                # Process through agent
                response = await agent.chat_async(
                    message=content,
                    user_id=user_id,
                    channel="facebook",
                )

                # Send response via Facebook API
                if response:
                    error = await send_facebook_message_async(user_id, str(response))
                    if error:
                        logger.error(f"Failed to send Facebook message: {error}")

            except Exception as e:
                logger.exception(f"Error processing Facebook message: {e}")
                # Send error message
                try:
                    await send_facebook_message_async(
                        user_id,
                        "Sorry, there was an error processing your message.",
                    )
                except Exception:
                    logger.exception("Failed to send error message")

        return handler


@dataclass
class TikTokChannel(ChannelPlugin):
    """TikTok channel.

    This channel enables TikTok comment and mention interactions via TikTok API.
    Note: DM support depends on API permissions.

    Attributes:
        access_token: TikTok access token
        client_key: TikTok client key
        client_secret: TikTok client secret for signature verification
        verify_token: Webhook verification token
    """

    channel_id: str = "tiktok"
    id: str = "tiktok-channel"
    name: str = "TikTok Channel"
    version: str = "0.2.0"

    access_token: Optional[str] = None
    client_key: Optional[str] = None
    client_secret: Optional[str] = None
    verify_token: Optional[str] = None

    # Internal reference to the agent (set via configure_agent)
    _agent: Optional[Any] = None

    def __post_init__(self):
        """Initialize TikTok channel with environment variables."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None
        # Load from environment if not provided
        if not self.access_token:
            self.access_token = os.getenv("TIKTOK_ACCESS_TOKEN", "")
        if not self.client_key:
            self.client_key = os.getenv("TIKTOK_CLIENT_KEY", "")
        if not self.client_secret:
            self.client_secret = os.getenv("TIKTOK_CLIENT_SECRET", "")
        if not self.verify_token:
            self.verify_token = os.getenv("TIKTOK_VERIFY_TOKEN", "")

    def configure_agent(self, agent: Any) -> Any:
        """Store agent reference for message processing.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        self._agent = agent
        return agent

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a TikTok comment reply.

        Args:
            user_id: Not used for TikTok (comments are video-scoped)
            text: Comment text
            metadata: Must contain 'video_id' and optionally 'comment_id'
        """
        from .lib.tiktok import send_tiktok_comment

        if not self.access_token:
            raise ValueError("TikTok access token not configured")

        if not metadata or 'video_id' not in metadata:
            raise ValueError("TikTok send_message requires 'video_id' in metadata")

        send_tiktok_comment(
            video_id=metadata['video_id'],
            text=text,
            access_token=self.access_token,
            comment_id=metadata.get('comment_id'),
        )

    def create_webhook_router(self) -> "APIRouter":
        """Create FastAPI router for TikTok webhooks.

        Returns:
            FastAPI APIRouter with webhook endpoints
        """
        from .lib.tiktok import create_tiktok_router

        # Create message handler if agent is available
        message_handler = None
        if self._agent is not None:
            message_handler = self._create_message_handler()

        return create_tiktok_router(
            api_plugin=self,
            async_message_handler=message_handler,
        )

    def _create_message_handler(self):
        """Create an async message handler that processes messages through the agent.

        Returns:
            Async message handler function.
        """
        import logging
        from .lib.tiktok.utils import send_tiktok_comment_async

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(message: Dict[str, Any]) -> None:
            user_id = message.get("from", "")
            content = message.get("content", "")
            metadata = message.get("metadata", {})

            try:
                # Process through agent
                response = await agent.chat_async(
                    message=content,
                    user_id=user_id,
                    channel="tiktok",
                )

                # Send response via TikTok API (if video_id available)
                if response and metadata.get('video_id'):
                    error = await send_tiktok_comment_async(
                        video_id=metadata['video_id'],
                        text=str(response),
                        comment_id=metadata.get('comment_id'),
                    )
                    if error:
                        logger.error(f"Failed to post TikTok comment: {error}")
                else:
                    logger.warning(
                        f"Cannot reply to TikTok message: no video_id in metadata"
                    )

            except Exception as e:
                logger.exception(f"Error processing TikTok message: {e}")
                # TikTok doesn't support reliable error messaging
                # Just log the error

        return handler


@dataclass
class DiscordChannel(ChannelPlugin):
    """Discord channel plugin for slash commands and interactions.

    This channel enables Discord integration via webhook-based interactions
    (slash commands, message components, modals) following the Discord
    Interactions API pattern.

    Attributes:
        bot_token: Discord bot token for API calls
        application_id: Discord application ID
        public_key: Discord application public key for signature verification
        default_guild_id: Default guild ID for guild-specific commands
        default_channel_id: Default channel ID for proactive messages
    """

    channel_id: str = "discord"
    id: str = "discord-channel"
    name: str = "Discord Channel"
    version: str = "0.2.0"

    bot_token: Optional[str] = None
    application_id: Optional[str] = None
    public_key: Optional[str] = None
    default_guild_id: Optional[str] = None
    default_channel_id: Optional[str] = None

    # Internal reference to the agent (set via configure_agent)
    _agent: Optional[Any] = None

    def __post_init__(self):
        """Initialize Discord channel with environment variables."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None
        # Load from environment if not provided
        if not self.bot_token:
            self.bot_token = os.getenv("DISCORD_BOT_TOKEN", "")
        if not self.application_id:
            self.application_id = os.getenv("DISCORD_APPLICATION_ID", "")
        if not self.public_key:
            self.public_key = os.getenv("DISCORD_PUBLIC_KEY", "")
        if not self.default_guild_id:
            self.default_guild_id = os.getenv("DISCORD_DEFAULT_GUILD_ID", "")
        if not self.default_channel_id:
            self.default_channel_id = os.getenv("DISCORD_DEFAULT_CHANNEL_ID", "")

    def configure_agent(self, agent: Any) -> Any:
        """Store agent reference for message processing.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        self._agent = agent
        return agent

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a Discord message to a user or channel.

        If metadata contains 'channel_id', sends to that channel.
        Otherwise, sends a direct message to the user.

        Args:
            user_id: Discord user ID (snowflake) for DMs
            text: Message text
            metadata: Optional metadata with channel_id for channel messages
        """
        from .lib.discord import send_discord_message

        if not self.bot_token:
            raise ValueError("Discord bot token not configured")

        channel_id = None
        if metadata:
            channel_id = metadata.get("channel_id") or metadata.get("discord_channel_id")

        if channel_id:
            # Send to specific channel
            send_discord_message(
                channel_id=channel_id,
                content=text,
                bot_token=self.bot_token,
            )
        else:
            # Send DM - need to create DM channel first (sync version)
            import httpx

            headers = {
                "Authorization": f"Bot {self.bot_token}",
                "Content-Type": "application/json",
            }

            with httpx.Client() as client:
                # Create DM channel
                dm_response = client.post(
                    "https://discord.com/api/v10/users/@me/channels",
                    headers=headers,
                    json={"recipient_id": user_id}
                )
                dm_response.raise_for_status()
                dm_channel_id = dm_response.json()["id"]

                # Send message
                send_discord_message(
                    channel_id=dm_channel_id,
                    content=text,
                    bot_token=self.bot_token,
                )

    def create_webhook_router(self) -> "APIRouter":
        """Create FastAPI router for Discord webhook.

        Returns:
            FastAPI APIRouter with /webhook endpoint
        """
        from .lib.discord import create_discord_router

        # Create message handler if agent is available
        message_handler = None
        command_handler = None
        if self._agent is not None:
            message_handler = self._create_message_handler()
            command_handler = self._create_command_handler()

        return create_discord_router(
            api_plugin=self,
            async_message_handler=message_handler,
            command_handler=command_handler,
        )

    def _create_message_handler(self):
        """Create an async message handler for Discord interactions.

        This handler processes interactions through the agent and
        sends followup responses via the Discord API.

        Returns:
            Async message handler function.
        """
        import logging
        import httpx

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(message: Dict[str, Any]) -> None:
            user_id = message.get("from", "")
            content = message.get("content", "")
            interaction_token = message.get("interaction_token", "")
            interaction_id = message.get("interaction_id", "")

            # Determine channel context
            channel_id = message.get("channel_id", "")
            guild_id = message.get("guild_id", "")

            try:
                # Process through agent
                response = await agent.chat_async(
                    message=content,
                    user_id=user_id,
                    channel="discord",
                )

                # Send followup message via Discord API
                if response and interaction_token:
                    followup_url = (
                        f"https://discord.com/api/v10/webhooks/"
                        f"{self.application_id}/{interaction_token}"
                    )
                    headers = {
                        "Authorization": f"Bot {self.bot_token}",
                        "Content-Type": "application/json",
                    }

                    async with httpx.AsyncClient() as client:
                        await client.post(
                            followup_url,
                            headers=headers,
                            json={"content": str(response)},
                        )

            except Exception as e:
                logger.exception(f"Error processing Discord message: {e}")
                # Try to send error response
                if interaction_token:
                    try:
                        followup_url = (
                            f"https://discord.com/api/v10/webhooks/"
                            f"{self.application_id}/{interaction_token}"
                        )
                        headers = {
                            "Authorization": f"Bot {self.bot_token}",
                            "Content-Type": "application/json",
                        }
                        async with httpx.AsyncClient() as client:
                            await client.post(
                                followup_url,
                                headers=headers,
                                json={"content": "Sorry, there was an error processing your message."},
                            )
                    except Exception:
                        logger.exception("Failed to send error message")

        return handler

    def _create_command_handler(self):
        """Create an async command handler for immediate Discord responses.

        This handler processes slash commands through the agent and
        returns the response directly (for immediate responses without deferred).

        Returns:
            Async command handler function that returns response text.
        """
        import logging

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(interaction: Dict[str, Any]) -> str:
            user_id = interaction.get("user_id", "")
            command_name = interaction.get("command_name", "")
            options = interaction.get("options", {})

            # Construct message from command
            if options:
                # Use the first option value as the main message if it's a "message" or "query" option
                message_keys = ["message", "query", "prompt", "text", "input"]
                content = None
                for key in message_keys:
                    if key in options:
                        content = str(options[key])
                        break

                if not content:
                    # Fall back to stringifying all options
                    content = f"/{command_name} " + " ".join(
                        f"{k}={v}" for k, v in options.items()
                    )
            else:
                content = f"/{command_name}"

            try:
                # Process through agent
                response = await agent.chat_async(
                    message=content,
                    user_id=user_id,
                    channel="discord",
                )
                return str(response) if response else "I couldn't generate a response."

            except Exception as e:
                logger.exception(f"Error processing Discord command: {e}")
                return "Sorry, there was an error processing your command."

        return handler

    def parse_webhook_interaction(self, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse incoming Discord interaction payload.

        Args:
            body: The webhook payload from Discord.

        Returns:
            Parsed interaction dict with normalized fields.
            None if no valid interaction found.
        """
        from .lib.discord.utils import parse_discord_interaction
        return parse_discord_interaction(body)


@dataclass
class SlackChannel(ChannelPlugin):
    """Slack channel plugin for Slack workspace integration.

    This channel enables Slack integration via Events API webhooks,
    supporting app_mention events and direct messages.

    Attributes:
        bot_token: Slack bot token (xoxb-...) for API calls
        signing_secret: Slack app signing secret for request verification
        app_id: Slack application ID
        default_channel: Default channel ID for proactive messages
    """

    channel_id: str = "slack"
    id: str = "slack-channel"
    name: str = "Slack Channel"
    version: str = "0.2.0"

    bot_token: Optional[str] = None
    signing_secret: Optional[str] = None
    app_id: Optional[str] = None
    default_channel: Optional[str] = None

    # Internal reference to the agent (set via configure_agent)
    _agent: Optional[Any] = None

    def __post_init__(self):
        """Initialize Slack channel with environment variables."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None
        # Load from environment if not provided
        if not self.bot_token:
            self.bot_token = os.getenv("SLACK_BOT_TOKEN", "")
        if not self.signing_secret:
            self.signing_secret = os.getenv("SLACK_SIGNING_SECRET", "")
        if not self.app_id:
            self.app_id = os.getenv("SLACK_APP_ID", "")
        if not self.default_channel:
            self.default_channel = os.getenv("SLACK_DEFAULT_CHANNEL", "")

    def configure_agent(self, agent: Any) -> Any:
        """Store agent reference for message processing.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        self._agent = agent
        return agent

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a Slack message to a user or channel.

        If metadata contains 'channel_id', sends to that channel.
        Otherwise, opens a DM with the user and sends there.

        Args:
            user_id: Slack user ID for DMs
            text: Message text
            metadata: Optional metadata with channel_id, thread_ts
        """
        from .lib.slack import send_slack_message

        if not self.bot_token:
            raise ValueError("Slack bot token not configured")

        channel_id = None
        thread_ts = None
        if metadata:
            channel_id = metadata.get("channel_id") or metadata.get("slack_channel")
            thread_ts = metadata.get("thread_ts") or metadata.get("slack_thread_ts")

        if channel_id:
            # Send to specific channel
            send_slack_message(
                channel_id=channel_id,
                text=text,
                bot_token=self.bot_token,
                thread_ts=thread_ts,
            )
        else:
            # Open DM channel and send message
            import httpx

            headers = {
                "Authorization": f"Bearer {self.bot_token}",
                "Content-Type": "application/json; charset=utf-8",
            }

            with httpx.Client() as client:
                # Open DM channel
                dm_response = client.post(
                    "https://slack.com/api/conversations.open",
                    headers=headers,
                    json={"users": user_id}
                )
                dm_response.raise_for_status()
                dm_data = dm_response.json()
                
                if not dm_data.get("ok"):
                    raise ValueError(f"Failed to open DM: {dm_data.get('error')}")
                
                dm_channel_id = dm_data["channel"]["id"]

                # Send message
                send_slack_message(
                    channel_id=dm_channel_id,
                    text=text,
                    bot_token=self.bot_token,
                    thread_ts=thread_ts,
                )

    def create_webhook_router(self) -> "APIRouter":
        """Create FastAPI router for Slack events webhook.

        Returns:
            FastAPI APIRouter with /events endpoint
        """
        from .lib.slack import create_slack_router

        # Create message handler if agent is available
        message_handler = None
        if self._agent is not None:
            message_handler = self._create_message_handler()

        return create_slack_router(
            api_plugin=self,
            async_message_handler=message_handler,
        )

    def _create_message_handler(self):
        """Create an async message handler for Slack events.

        This handler processes events through the agent and
        sends responses back to Slack.

        Returns:
            Async message handler function.
        """
        import logging
        from .lib.slack import send_slack_message_async

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(message: Dict[str, Any]) -> None:
            user_id = message.get("user_id", "")
            text = message.get("text", "")
            channel_id = message.get("channel_id", "")
            thread_ts = message.get("thread_ts", "")

            try:
                # Process through agent
                response = await agent.chat_async(
                    message=text,
                    user_id=user_id,
                    channel="slack",
                )

                # Send response back to Slack
                if response:
                    await send_slack_message_async(
                        channel_id=channel_id,
                        text=str(response),
                        bot_token=self.bot_token,
                        thread_ts=thread_ts,
                    )

            except Exception as e:
                logger.exception(f"Error processing Slack message: {e}")
                # Try to send error response
                try:
                    await send_slack_message_async(
                        channel_id=channel_id,
                        text="Sorry, there was an error processing your message.",
                        bot_token=self.bot_token,
                        thread_ts=thread_ts,
                    )
                except Exception:
                    logger.exception("Failed to send error message")

        return handler

    def parse_webhook_event(self, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse incoming Slack event payload.

        Args:
            body: The webhook payload from Slack.

        Returns:
            Parsed event dict with normalized fields.
            None if no valid event found.
        """
        from .lib.slack.utils import parse_slack_event
        return parse_slack_event(body)


@dataclass
class TelegramChannel(ChannelPlugin):
    """Telegram Bot API channel.

    This channel enables Telegram direct and group messaging via webhook updates.

    Attributes:
        bot_token: Telegram bot token from BotFather
        token_file: Optional file path containing the bot token
        dm_policy: Direct message policy (open, allowlist, disabled)
        allow_from: Allowed user IDs when allowlist policies are enabled
        group_policy: Group policy (open, allowlist, disabled)
        groups: Group-specific configuration map keyed by chat ID
        webhook_url: Optional webhook URL (for deployment scripts)
        webhook_secret: Optional webhook secret header value
        max_message_length: Max message length for chunking (Telegram hard limit 4096)
        chunking_strategy: Chunking strategy (paragraph, sentence, length)
    """

    channel_id: str = "telegram"
    id: str = "telegram-channel"
    name: str = "Telegram Channel"
    version: str = "0.3.0"

    # Authentication
    bot_token: Optional[str] = None
    token_file: Optional[str] = None

    # Access control
    dm_policy: str = "open"
    allow_from: List[str] = field(default_factory=list)
    group_policy: str = "allowlist"
    groups: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # Feature flags
    enable_reactions: bool = True
    enable_threads: bool = True
    enable_streaming: bool = True
    enable_media: bool = True

    # Behavior
    reply_to_mode: str = "first"  # first, all, off
    mention_patterns: List[str] = field(default_factory=list)

    # Technical settings
    webhook_url: Optional[str] = None
    webhook_secret: Optional[str] = None
    max_message_length: int = 4096
    chunking_strategy: str = "paragraph"  # paragraph, sentence, length

    # Internal state
    _agent: Optional[Any] = None
    _bot_username: Optional[str] = None

    def __post_init__(self):
        """Initialize Telegram channel with environment fallback values."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None

        self._resolve_token()

        if not self.webhook_url:
            self.webhook_url = os.getenv("TELEGRAM_WEBHOOK_URL", "")
        if not self.webhook_secret:
            self.webhook_secret = os.getenv("TELEGRAM_WEBHOOK_SECRET", "")

        # Normalize allowlist/group keys to strings for predictable comparisons
        self.allow_from = [str(value) for value in self.allow_from]
        self.groups = {
            str(chat_id): dict(config)
            for chat_id, config in (self.groups or {}).items()
        }

    def _resolve_token(self) -> None:
        """Resolve bot token from constructor, file, or environment."""
        if self.bot_token:
            return

        if self.token_file:
            try:
                with open(self.token_file, "r", encoding="utf-8") as token_file:
                    self.bot_token = token_file.read().strip()
            except OSError as exc:
                import logging
                logging.getLogger(__name__).error(
                    f"Failed to load Telegram token from file '{self.token_file}': {exc}"
                )

        if not self.bot_token:
            self.bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")

    def configure_agent(self, agent: Any) -> Any:
        """Store agent reference for message processing.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        self._agent = agent
        return agent

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a Telegram message synchronously.

        Args:
            user_id: Telegram chat ID
            text: Message text
            metadata: Optional metadata (reply_to_message_id, thread_id, parse_mode)
        """
        import asyncio

        if not self.bot_token:
            raise ValueError("Telegram bot token not configured")

        metadata = metadata or {}
        reply_to_message_id = metadata.get("reply_to_message_id")
        thread_id = metadata.get("thread_id") or metadata.get("message_thread_id")
        parse_mode = metadata.get("parse_mode", "HTML")

        coroutine = self.send_message_async(
            chat_id=user_id,
            text=text,
            reply_to_message_id=reply_to_message_id,
            thread_id=thread_id,
            parse_mode=parse_mode,
        )

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            loop.create_task(coroutine)
        else:
            asyncio.run(coroutine)

    async def send_message_async(
        self,
        chat_id: str,
        text: str,
        reply_to_message_id: Optional[int] = None,
        thread_id: Optional[int] = None,
        parse_mode: str = "HTML",
    ) -> bool:
        """Send a Telegram message asynchronously with chunking.

        Args:
            chat_id: Telegram chat ID
            text: Message text
            reply_to_message_id: Optional message ID to reply to
            thread_id: Optional topic/thread ID for forum chats
            parse_mode: Telegram parse mode

        Returns:
            True when all chunks are sent successfully
        """
        import asyncio
        from .lib.telegram import send_telegram_message_async

        if not self.bot_token:
            raise ValueError("Telegram bot token not configured")

        chunks = self._chunk_message(text)
        for index, chunk in enumerate(chunks):
            if self.reply_to_mode == "off":
                reply_to = None
            elif self.reply_to_mode == "all":
                reply_to = reply_to_message_id
            else:
                reply_to = reply_to_message_id if index == 0 else None

            await send_telegram_message_async(
                chat_id=str(chat_id),
                text=chunk,
                bot_token=self.bot_token,
                reply_to_message_id=reply_to,
                message_thread_id=thread_id,
                parse_mode=parse_mode,
            )

            if index < len(chunks) - 1:
                await asyncio.sleep(0.3)

        return True

    def _chunk_message(self, text: str) -> List[str]:
        """Chunk a message according to configured strategy.

        Args:
            text: Full message text

        Returns:
            List of message chunks
        """
        max_length = self.max_message_length
        if len(text) <= max_length:
            return [text]

        if self.chunking_strategy == "paragraph":
            return self._chunk_by_paragraph(text, max_length)
        if self.chunking_strategy == "sentence":
            return self._chunk_by_sentence(text, max_length)
        return self._chunk_by_length(text, max_length)

    def _chunk_by_paragraph(self, text: str, max_length: int) -> List[str]:
        """Chunk text at paragraph boundaries when possible."""
        paragraphs = text.split("\n\n")
        chunks: List[str] = []
        current = ""

        for paragraph in paragraphs:
            candidate = paragraph if not current else f"{current}\n\n{paragraph}"
            if len(candidate) <= max_length:
                current = candidate
                continue

            if current:
                chunks.append(current)

            if len(paragraph) > max_length:
                chunks.extend(self._chunk_by_sentence(paragraph, max_length))
                current = ""
            else:
                current = paragraph

        if current:
            chunks.append(current)

        return chunks

    def _chunk_by_sentence(self, text: str, max_length: int) -> List[str]:
        """Chunk text at sentence boundaries when possible."""
        import re

        parts = re.split(r"([.!?]+\s+)", text)
        chunks: List[str] = []
        current = ""

        for index in range(0, len(parts), 2):
            sentence = parts[index]
            delimiter = parts[index + 1] if index + 1 < len(parts) else ""
            full_sentence = sentence + delimiter

            if len(current) + len(full_sentence) <= max_length:
                current += full_sentence
                continue

            if current:
                chunks.append(current.strip())

            if len(full_sentence) > max_length:
                chunks.extend(self._chunk_by_length(full_sentence, max_length))
                current = ""
            else:
                current = full_sentence

        if current:
            chunks.append(current.strip())

        return chunks

    def _chunk_by_length(self, text: str, max_length: int) -> List[str]:
        """Chunk text by fixed character length."""
        return [text[index:index + max_length] for index in range(0, len(text), max_length)]

    def _is_authorized_dm(self, user_id: str) -> bool:
        """Check if user is authorized for direct messages."""
        if self.dm_policy == "disabled":
            return False
        if self.dm_policy == "open":
            return True
        return str(user_id) in self.allow_from

    def _is_authorized_group(self, chat_id: str, user_id: str) -> bool:
        """Check if user is authorized for group interactions."""
        if self.group_policy == "disabled":
            return False

        group_config = self.groups.get(str(chat_id))
        if not group_config:
            if self.group_policy == "open":
                return True
            if self.group_policy == "allowlist":
                return str(user_id) in self.allow_from
            return False

        if not group_config.get("enabled", True):
            return False

        group_allowlist = [str(value) for value in group_config.get("allow_from", [])]
        if group_allowlist:
            return str(user_id) in group_allowlist

        if self.group_policy == "open":
            return True

        if self.allow_from:
            return str(user_id) in self.allow_from

        return self.group_policy != "allowlist"

    async def _ensure_bot_username(self) -> None:
        """Load and cache bot username for mention checks."""
        if self._bot_username or not self.bot_token:
            return

        import logging
        from .lib.telegram import get_telegram_me_async

        logger = logging.getLogger(__name__)
        try:
            profile = await get_telegram_me_async(self.bot_token)
            username = profile.get("username")
            if username:
                self._bot_username = username
        except Exception as exc:
            logger.debug(f"Could not resolve Telegram bot username: {exc}")

    def _check_mention_requirement(self, message: Dict[str, Any]) -> bool:
        """Check if mention requirements are satisfied for group messages.

        Checks (in order):
        1. Telegram ``mention`` entities (``@botname``)
        2. Telegram ``text_mention`` entities (users without usernames)
        3. Telegram ``bot_command`` entities (``/help@botname``)
        4. Plain-text ``@bot_username`` fallback
        5. Reply to the bot's own message
        6. Configured custom mention patterns
        """
        chat_id = str(message.get("chat_id", ""))
        group_config = self.groups.get(chat_id)

        if not group_config:
            return True

        if not group_config.get("require_mention", True):
            return True

        content = message.get("content", "")
        if not content:
            return False

        bot_username_lower = self._bot_username.lower() if self._bot_username else ""

        # --- Entity-based detection ---
        entities = message.get("entities", []) or []
        for entity in entities:
            entity_type = entity.get("type", "")

            # @username mention entity
            if entity_type == "mention" and bot_username_lower:
                offset = entity.get("offset", 0)
                length = entity.get("length", 0)
                mention_text = content[offset:offset + length]
                if mention_text.lower() == f"@{bot_username_lower}":
                    return True

            # text_mention entity (user without public username)
            if entity_type == "text_mention":
                mentioned_user = entity.get("user", {}) or {}
                if mentioned_user.get("is_bot") and bot_username_lower:
                    if mentioned_user.get("username", "").lower() == bot_username_lower:
                        return True

            # bot_command entity (e.g. /help@botname)
            if entity_type == "bot_command" and bot_username_lower:
                offset = entity.get("offset", 0)
                length = entity.get("length", 0)
                cmd_text = content[offset:offset + length]
                if f"@{bot_username_lower}" in cmd_text.lower():
                    return True

        # --- Plain-text @bot_username fallback ---
        if bot_username_lower:
            expected = f"@{bot_username_lower}"
            if expected in content.lower():
                return True

        # --- Reply to the bot's own message ---
        raw_message = message.get("raw", {}) or {}
        reply_to = raw_message.get("reply_to_message", {}) or {}
        reply_from = reply_to.get("from", {}) or {}
        if reply_from.get("is_bot") and bot_username_lower:
            if reply_from.get("username", "").lower() == bot_username_lower:
                return True

        # --- Configured custom mention patterns ---
        patterns = group_config.get("mention_patterns", []) or self.mention_patterns
        lowered = content.lower()
        for pattern in patterns:
            if pattern.lower() in lowered:
                return True

        return False

    async def _handle_unauthorized_dm(self, chat_id: str) -> None:
        """Send default message for unauthorized direct messages."""
        from .lib.telegram import send_telegram_message_async

        await send_telegram_message_async(
            chat_id=str(chat_id),
            text=(
                "Sorry, this bot is not configured to accept direct messages "
                "from all users. Please contact the administrator for access."
            ),
            bot_token=self.bot_token,
        )

    def _build_session_id(
        self,
        user_id: str,
        chat_id: str,
        thread_id: Optional[int],
    ) -> str:
        """Build session identifier for Telegram interactions.

        Args:
            user_id: Telegram user ID
            chat_id: Telegram chat ID
            thread_id: Optional topic/thread ID

        Returns:
            Session identifier string
        """
        if thread_id and self.enable_threads:
            group_config = self.groups.get(str(chat_id), {})
            if group_config.get("thread_mode", "separate") == "separate":
                return f"telegram_{chat_id}_{thread_id}"
        return f"telegram_{chat_id}"

    def parse_webhook_message(self, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse incoming Telegram webhook payload.

        Args:
            body: Telegram update payload

        Returns:
            Normalized message dictionary or None
        """
        from .lib.telegram import parse_telegram_update
        return parse_telegram_update(body)

    def create_webhook_router(self) -> "APIRouter":
        """Create FastAPI router for Telegram webhook handling.

        Returns:
            FastAPI APIRouter with Telegram endpoints
        """
        from .lib.telegram import create_telegram_router

        message_handler = None
        if self._agent is not None:
            message_handler = self._create_message_handler()

        return create_telegram_router(
            api_plugin=self,
            async_message_handler=message_handler,
        )

    def _create_message_handler(self):
        """Create async Telegram message handler closure.

        Returns:
            Async handler function
        """
        import logging

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(message: Dict[str, Any]) -> None:
            chat_id = str(message.get("chat_id", ""))
            content = message.get("content", "")
            chat_type = message.get("chat_type", "private")
            user_id = str(message.get("from") or chat_id)
            message_id = message.get("id")
            thread_id = message.get("message_thread_id")

            if not chat_id or not content:
                return

            if chat_type == "private":
                if not self._is_authorized_dm(user_id):
                    await self._handle_unauthorized_dm(chat_id)
                    return
            else:
                if not self._is_authorized_group(chat_id, user_id):
                    return

                await self._ensure_bot_username()
                if not self._check_mention_requirement(message):
                    return

            try:
                # Show typing indicator before processing
                try:
                    from .lib.telegram import send_telegram_chat_action_async
                    await send_telegram_chat_action_async(chat_id=chat_id, action="typing")
                except Exception as e:
                    logger.debug(f"Failed to send typing indicator: {e}")

                session_id = self._build_session_id(user_id, chat_id, thread_id)

                response = await agent.chat_async(
                    message=content,
                    user_id=user_id,
                    channel="telegram",
                    session_id=session_id,
                    metadata={
                        "chat_id": chat_id,
                        "message_id": message_id,
                        "message_thread_id": thread_id,
                        "chat_type": chat_type,
                        "username": message.get("username"),
                        "language_code": message.get("language_code"),
                    },
                )

                if response:
                    reply_to = None
                    try:
                        reply_to = int(message_id) if message_id else None
                    except (TypeError, ValueError):
                        reply_to = None

                    await self.send_message_async(
                        chat_id=chat_id,
                        text=str(response),
                        reply_to_message_id=reply_to,
                        thread_id=thread_id,
                    )

            except Exception as exc:
                logger.exception(f"Error processing Telegram message: {exc}")
                try:
                    await self.send_message_async(
                        chat_id=chat_id,
                        text="Sorry, there was an error processing your message.",
                        reply_to_message_id=int(message_id) if message_id else None,
                        thread_id=thread_id,
                    )
                except Exception:
                    logger.exception("Failed to send Telegram error message")

        return handler


@dataclass
class VoiceChannel(ChannelPlugin):
    """LiveKit voice channel.

    This channel enables real-time voice interactions via LiveKit.

    Attributes:
        livekit_url: LiveKit server URL
        livekit_api_key: LiveKit API key
        livekit_api_secret: LiveKit API secret
    """

    channel_id: str = "voice"
    id: str = "voice-channel"
    name: str = "Voice Channel"
    version: str = "0.2.0"

    livekit_url: Optional[str] = None
    livekit_api_key: Optional[str] = None
    livekit_api_secret: Optional[str] = None

    def __post_init__(self):
        """Initialize Voice channel with environment variables."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None
        # Load from environment if not provided
        if not self.livekit_url:
            self.livekit_url = os.getenv("LIVEKIT_URL", "")
        if not self.livekit_api_key:
            self.livekit_api_key = os.getenv("LIVEKIT_API_KEY", "")
        if not self.livekit_api_secret:
            self.livekit_api_secret = os.getenv("LIVEKIT_API_SECRET", "")

    @property
    def is_voice_enabled(self) -> bool:
        """Voice channel always supports voice.

        Returns:
            True
        """
        return True

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Voice channel uses real-time streaming, not message sending.

        Args:
            user_id: User identifier
            text: Message text (not used)
            metadata: Optional metadata

        Raises:
            NotImplementedError: Voice uses streaming, not message sending
        """
        raise NotImplementedError(
            "Voice channel uses real-time streaming, not message sending"
        )

    def create_webhook_router(self) -> Optional["APIRouter"]:
        """Voice channel doesn't use webhooks.

        Returns:
            None
        """
        return None


@dataclass
class InstagramChannel(ChannelPlugin):
    """Instagram Business API channel.

    This channel enables Instagram DM and comment interactions via Meta Graph API.

    Attributes:
        access_token: Instagram/Meta access token
        page_id: Instagram page/business account ID
        verify_token: Webhook verification token
        app_secret: App secret for signature verification
    """

    channel_id: str = "instagram"
    id: str = "instagram-channel"
    name: str = "Instagram Channel"
    version: str = "0.2.0"

    access_token: Optional[str] = None
    page_id: Optional[str] = None
    verify_token: Optional[str] = None
    app_secret: Optional[str] = None

    # Internal reference to the agent (set via configure_agent)
    _agent: Optional[Any] = None

    def __post_init__(self):
        """Initialize Instagram channel with environment variables."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None
        # Load from environment if not provided
        if not self.access_token:
            self.access_token = os.getenv("INSTAGRAM_ACCESS_TOKEN", "")
        if not self.page_id:
            self.page_id = os.getenv("INSTAGRAM_PAGE_ID", "")
        if not self.verify_token:
            self.verify_token = os.getenv("INSTAGRAM_VERIFY_TOKEN", "")
        if not self.app_secret:
            self.app_secret = os.getenv("INSTAGRAM_APP_SECRET", "")

    def configure_agent(self, agent: Any) -> Any:
        """Store agent reference for message processing.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        self._agent = agent
        return agent

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send an Instagram message to user.

        Args:
            user_id: Instagram user ID (IGSID)
            text: Message text
            metadata: Optional metadata
        """
        from .lib.instagram import send_instagram_message

        if not self.access_token or not self.page_id:
            raise ValueError("Instagram credentials not configured")

        send_instagram_message(
            recipient_id=user_id,
            text=text,
            access_token=self.access_token,
            page_id=self.page_id,
        )

    def validate_webhook(
        self,
        mode: Optional[str],
        token: Optional[str],
        challenge: Optional[str],
    ) -> Optional[str]:
        """Validate Instagram webhook verification request.

        Args:
            mode: The hub.mode query parameter (should be "subscribe").
            token: The hub.verify_token query parameter.
            challenge: The hub.challenge query parameter to echo back.

        Returns:
            The challenge string if validation succeeds, None otherwise.
        """
        if mode == "subscribe" and token == self.verify_token:
            return challenge
        return None

    def create_webhook_router(self) -> "APIRouter":
        """Create FastAPI router for Instagram webhooks.

        Returns:
            FastAPI APIRouter with webhook endpoints
        """
        from .lib.instagram import create_instagram_router

        # Create message handler if agent is available
        message_handler = None
        if self._agent is not None:
            message_handler = self._create_message_handler()

        return create_instagram_router(
            api_plugin=self,
            async_message_handler=message_handler,
        )

    def _create_message_handler(self):
        """Create an async message handler that processes messages through the agent.

        Returns:
            Async message handler function.
        """
        import logging
        from .lib.instagram.utils import send_instagram_message_async

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(message: Dict[str, Any]) -> None:
            user_id = message.get("from", "")
            content = message.get("content", "")

            try:
                # Process through agent
                response = await agent.chat_async(
                    message=content,
                    user_id=user_id,
                    channel="instagram",
                )

                # Send response via Instagram API
                if response:
                    error = await send_instagram_message_async(user_id, str(response))
                    if error:
                        logger.error(f"Failed to send Instagram message: {error}")

            except Exception as e:
                logger.exception(f"Error processing Instagram message: {e}")
                # Send error message
                try:
                    await send_instagram_message_async(
                        user_id,
                        "Sorry, there was an error processing your message.",
                    )
                except Exception:
                    logger.exception("Failed to send error message")

        return handler


@dataclass
class WhatsmeowChannel(ChannelPlugin):
    """WhatsMeow channel for WhatsApp messaging via local Go bridge.

    This channel integrates with the WhatsMeow Go server to provide
    WhatsApp messaging capabilities without requiring Meta Graph API.
    It uses JIDs (e.g., 5511999999999@s.whatsapp.net) for identification.

    Note: This channel does NOT support voice calls (unlike WhatsAppChannel).

    Attributes:
        base_url: WhatsMeow server base URL (default: http://localhost:8080/api)
        api_key: API key for WhatsMeow server authentication
        verify_token: Webhook verification token
        webhook_secret: Secret for HMAC signature validation
    """

    channel_id: str = "whatsmeow"
    id: str = "whatsmeow-channel"
    name: str = "WhatsMeow Channel"
    version: str = "0.2.0"

    base_url: Optional[str] = None
    api_key: Optional[str] = None
    verify_token: Optional[str] = None
    webhook_secret: Optional[str] = None

    # Internal reference to the agent (set via configure_agent)
    _agent: Optional[Any] = None

    def __post_init__(self):
        """Initialize WhatsMeow channel with environment variables."""
        super().__post_init__() if hasattr(super(), '__post_init__') else None
        # Load from environment if not provided
        if not self.base_url:
            self.base_url = os.getenv("WHATSMEOW_BASE_URL", "http://localhost:8080/api")
        if not self.api_key:
            self.api_key = os.getenv("WHATSMEOW_API_KEY", "")
        if not self.verify_token:
            self.verify_token = os.getenv("WHATSMEOW_VERIFY_TOKEN", "")
        if not self.webhook_secret:
            self.webhook_secret = os.getenv("WHATSMEOW_WEBHOOK_SECRET", "")
            if not self.webhook_secret:
                self.webhook_secret = os.getenv("WEBHOOK_SECRET", "")

    def configure_agent(self, agent: Any) -> Any:
        """Store agent reference for message processing.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        self._agent = agent
        return agent

    def send_message(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a WhatsMeow message to user.

        Args:
            user_id: WhatsApp JID (e.g., "5511999999999@s.whatsapp.net")
            text: Message text
            metadata: Optional metadata (e.g., media_path)
        """
        from .lib.whatsmeow import send_text_message

        media_path = None
        if metadata:
            media_path = metadata.get("media_path")

        error = send_text_message(user_id, text, media_path=media_path)
        if error:
            raise RuntimeError(f"Failed to send WhatsMeow message: {error}")

    async def send_message_async(
        self,
        user_id: str,
        text: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Send a WhatsMeow message to user (async).

        Args:
            user_id: WhatsApp JID (e.g., "5511999999999@s.whatsapp.net")
            text: Message text
            metadata: Optional metadata (e.g., media_path, italics)
        """
        from .lib.whatsmeow import send_text_message_async

        media_path = None
        italics = False
        if metadata:
            media_path = metadata.get("media_path")
            italics = metadata.get("italics", False)

        error = await send_text_message_async(
            user_id, text, media_path=media_path, italics=italics
        )
        if error:
            raise RuntimeError(f"Failed to send WhatsMeow message: {error}")

    def validate_webhook(
        self,
        mode: Optional[str],
        token: Optional[str],
        challenge: Optional[str],
    ) -> Optional[str]:
        """Validate WhatsMeow webhook verification request.

        Args:
            mode: The hub.mode query parameter (should be "subscribe").
            token: The hub.verify_token query parameter.
            challenge: The hub.challenge query parameter to echo back.

        Returns:
            The challenge string if validation succeeds, None otherwise.
        """
        if mode == "subscribe" and token == self.verify_token:
            return challenge
        return None

    def parse_webhook_message(self, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse incoming WhatsMeow webhook payload to extract message data.

        WhatsMeow uses a flattened CloudAPI-like payload format:
        - id: Message ID
        - sender_jid: Sender's JID
        - recipient_jid: Recipient's JID
        - content: Message text content
        - media_type: Type of media (text, image/jpeg, etc.)
        - is_group: Whether the message is from a group
        - timestamp: Message timestamp

        Args:
            body: The webhook payload from WhatsMeow.

        Returns:
            Parsed message dict with keys: type, content, from, id, chat_jid.
            None if no valid message found.
        """
        message_id = body.get("id")
        sender_jid = body.get("sender_jid")
        recipient_jid = body.get("recipient_jid")

        if not message_id or not sender_jid:
            return None

        # Determine chat JID for responses
        is_from_me = body.get("is_from_me", False)
        chat_jid = recipient_jid if not is_from_me else sender_jid

        content = body.get("content", "")
        media_type = body.get("media_type", "text")

        # Map media_type to simplified type
        if media_type in ("text", None):
            msg_type = "text"
        elif media_type.startswith("image/"):
            msg_type = "image"
        elif media_type.startswith("video/"):
            msg_type = "video"
        elif media_type.startswith("audio/"):
            msg_type = "audio"
        elif media_type.startswith("application/"):
            msg_type = "document"
        else:
            msg_type = media_type

        return {
            "type": msg_type,
            "content": content,
            "from": sender_jid,
            "id": message_id,
            "chat_jid": chat_jid,
            "is_group": body.get("is_group", False),
            "media_type": media_type,
            "timestamp": body.get("timestamp"),
            "raw": body,
        }

    def create_webhook_router(self) -> "APIRouter":
        """Create FastAPI router for WhatsMeow webhooks.

        Returns:
            FastAPI APIRouter with webhook endpoints
        """
        from .lib.whatsmeow import create_whatsmeow_router

        # Create message handler if agent is available
        message_handler = None
        if self._agent is not None:
            message_handler = self._create_message_handler()

        return create_whatsmeow_router(
            channel=self,
            async_message_handler=message_handler,
        )

    def _create_message_handler(self):
        """Create an async message handler that processes messages through the agent.

        Returns:
            Async message handler function.
        """
        import logging
        from .lib.whatsmeow.utils import send_text_message_async, typing_indicator_async, normalize_whatsapp_jid

        logger = logging.getLogger(__name__)
        agent = self._agent

        async def handler(message: Dict[str, Any]) -> None:
            sender_jid = await normalize_whatsapp_jid(message.get("from", ""))
            chat_jid = await normalize_whatsapp_jid(message.get("chat_jid", sender_jid))
            content = message.get("content", "")

            try:
                # Show typing indicator
                try:
                    await typing_indicator_async(chat_jid, typing=True)
                except Exception as e:
                    logger.warning(f"Typing indicator failed: {e}")

                # Process through agent
                response = await agent.chat_async(
                    message=content,
                    user_id=sender_jid,
                    channel="whatsmeow",
                    metadata={
                        "chat_jid": chat_jid,
                        "message_id": message.get("id"),
                        "is_group": message.get("is_group", False),
                        "media_type": message.get("media_type"),
                    },
                )

                # Send response via WhatsMeow API
                if response:
                    error = await send_text_message_async(chat_jid, str(response))
                    if error:
                        logger.error(f"Failed to send WhatsMeow message: {error}")

            except Exception as e:
                logger.exception(f"Error processing WhatsMeow message: {e}")
                # Send error message
                try:
                    await send_text_message_async(
                        chat_jid,
                        "Sorry, there was an error processing your message.",
                    )
                except Exception:
                    logger.exception("Failed to send error message")

        return handler
