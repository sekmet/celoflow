"""Base infrastructure abstractions for deployment backends.

This module defines the core protocols and interfaces for infrastructure resources
following System Thinking Level 2 principles with clean separation of concerns.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Protocol, TypeVar


class ResourceStatus(str, Enum):
    """Status of an infrastructure resource."""

    PENDING = "pending"
    CREATING = "creating"
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"
    DELETING = "deleting"
    DELETED = "deleted"


class ResourceType(str, Enum):
    """Type of infrastructure resource."""

    NETWORK = "network"
    IMAGE = "image"
    VOLUME = "volume"
    CONTAINER = "container"
    SERVICE = "service"


@dataclass
class ResourceMetadata:
    """Metadata for an infrastructure resource."""

    id: str
    name: str
    type: ResourceType
    status: ResourceStatus = ResourceStatus.PENDING
    tags: Dict[str, str] = field(default_factory=dict)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class InfraResource(Protocol):
    """Protocol for infrastructure resources.

    All infrastructure resources (network, image, volume, container) must implement
    this protocol to enable consistent orchestration and lifecycle management.
    """

    @property
    def metadata(self) -> ResourceMetadata:
        """Return resource metadata."""
        ...

    @property
    def depends_on(self) -> List[str]:
        """Return list of resource IDs this resource depends on."""
        ...

    @property
    def skip_if_exists(self) -> bool:
        """Whether to skip creation if resource already exists."""
        ...

    @property
    def use_cache(self) -> bool:
        """Whether to use cached state for this resource."""
        ...

    def create(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Create the resource.

        Args:
            dry_run: If True, only simulate the operation
            force: If True, force creation even if resource exists

        Returns:
            Dictionary with creation result details

        Raises:
            ResourceCreationError: If creation fails
        """
        ...

    def read(self) -> Dict[str, Any]:
        """Read current state of the resource.

        Returns:
            Dictionary with resource state details

        Raises:
            ResourceNotFoundError: If resource doesn't exist
        """
        ...

    def update(self, **kwargs: Any) -> Dict[str, Any]:
        """Update the resource with new configuration.

        Args:
            **kwargs: Resource-specific update parameters

        Returns:
            Dictionary with update result details

        Raises:
            ResourceUpdateError: If update fails
        """
        ...

    def delete(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Delete the resource.

        Args:
            dry_run: If True, only simulate the operation
            force: If True, force deletion even if dependencies exist

        Returns:
            Dictionary with deletion result details

        Raises:
            ResourceDeletionError: If deletion fails
        """
        ...

    def exists(self) -> bool:
        """Check if the resource exists.

        Returns:
            True if resource exists, False otherwise
        """
        ...

    def get_status(self) -> ResourceStatus:
        """Get current status of the resource.

        Returns:
            Current ResourceStatus
        """
        ...


TResource = TypeVar("TResource", bound=InfraResource)


class InfraBackend(ABC):
    """Abstract base for infrastructure backends.

    Backends (Docker, Kubernetes, etc.) implement this interface to provide
    consistent deployment capabilities across different platforms.
    """

    @property
    @abstractmethod
    def backend_type(self) -> str:
        """Return the backend type identifier (e.g., 'docker', 'k8s')."""
        ...

    @abstractmethod
    def validate_config(self, config: Dict[str, Any]) -> bool:
        """Validate backend configuration.

        Args:
            config: Backend-specific configuration

        Returns:
            True if configuration is valid

        Raises:
            ConfigurationError: If configuration is invalid
        """
        ...

    @abstractmethod
    def create_resources(
        self,
        resources: List[InfraResource],
        *,
        dry_run: bool = False,
        auto_confirm: bool = False,
        force: bool = False,
        group_filter: Optional[str] = None,
        name_filter: Optional[str] = None,
        type_filter: Optional[ResourceType] = None,
    ) -> Dict[str, Any]:
        """Create multiple resources with dependency resolution.

        Args:
            resources: List of resources to create
            dry_run: If True, only simulate operations
            auto_confirm: If True, skip confirmation prompts
            force: If True, force creation
            group_filter: Optional group filter
            name_filter: Optional name filter
            type_filter: Optional resource type filter

        Returns:
            Dictionary with creation results per resource

        Raises:
            OrchestrationError: If orchestration fails
        """
        ...

    @abstractmethod
    def delete_resources(
        self,
        resources: List[InfraResource],
        *,
        dry_run: bool = False,
        auto_confirm: bool = False,
        force: bool = False,
    ) -> Dict[str, Any]:
        """Delete multiple resources in reverse dependency order.

        Args:
            resources: List of resources to delete
            dry_run: If True, only simulate operations
            auto_confirm: If True, skip confirmation prompts
            force: If True, force deletion

        Returns:
            Dictionary with deletion results per resource

        Raises:
            OrchestrationError: If orchestration fails
        """
        ...

    @abstractmethod
    def get_health(self) -> Dict[str, Any]:
        """Get backend health status.

        Returns:
            Dictionary with health metrics
        """
        ...


# ============================================================================
# Exceptions
# ============================================================================


class InfraError(Exception):
    """Base exception for infrastructure errors."""

    pass


class ResourceCreationError(InfraError):
    """Raised when resource creation fails."""

    pass


class ResourceNotFoundError(InfraError):
    """Raised when resource is not found."""

    pass


class ResourceUpdateError(InfraError):
    """Raised when resource update fails."""

    pass


class ResourceDeletionError(InfraError):
    """Raised when resource deletion fails."""

    pass


class ConfigurationError(InfraError):
    """Raised when configuration is invalid."""

    pass


class OrchestrationError(InfraError):
    """Raised when resource orchestration fails."""

    pass


class DependencyError(InfraError):
    """Raised when dependency resolution fails."""

    pass
