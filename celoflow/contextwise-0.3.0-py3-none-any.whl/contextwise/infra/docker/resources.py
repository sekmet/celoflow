"""Docker resources orchestrator with dependency graph resolution.

This module provides orchestration capabilities for Docker resources:
- Dependency graph sorting
- Deterministic ordering (Network → Image → Volume → Container)
- Resource deduplication
- Dry-run support
- Filtering by group, name, and type
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

import docker

from ..base import (
    DependencyError,
    InfraBackend,
    InfraResource,
    OrchestrationError,
    ResourceType,
)
from .resource_types import INSTALL_ORDER_WEIGHTS

logger = logging.getLogger(__name__)


# ============================================================================
# Dependency Graph Utilities
# ============================================================================


def topological_sort(
    resources: List[InfraResource],
) -> List[InfraResource]:
    """Sort resources using topological sort based on dependencies.

    Args:
        resources: List of resources to sort

    Returns:
        Topologically sorted list of resources

    Raises:
        DependencyError: If circular dependencies are detected
    """
    # Build dependency graph
    resource_map = {r.metadata.id: r for r in resources}
    in_degree = {r.metadata.id: 0 for r in resources}
    adjacency = {r.metadata.id: [] for r in resources}

    for resource in resources:
        for dep_id in resource.depends_on:
            if dep_id not in resource_map:
                raise DependencyError(
                    f"Resource {resource.metadata.name} depends on unknown resource {dep_id}"
                )
            adjacency[dep_id].append(resource.metadata.id)
            in_degree[resource.metadata.id] += 1

    # Kahn's algorithm for topological sort
    queue = [rid for rid, degree in in_degree.items() if degree == 0]
    sorted_ids = []

    while queue:
        # Sort by install order weight and name for deterministic ordering
        queue.sort(
            key=lambda rid: (
                INSTALL_ORDER_WEIGHTS.get(resource_map[rid].metadata.type, 999),
                resource_map[rid].metadata.name,
            )
        )

        current_id = queue.pop(0)
        sorted_ids.append(current_id)

        for neighbor_id in adjacency[current_id]:
            in_degree[neighbor_id] -= 1
            if in_degree[neighbor_id] == 0:
                queue.append(neighbor_id)

    if len(sorted_ids) != len(resources):
        raise DependencyError("Circular dependency detected in resource graph")

    return [resource_map[rid] for rid in sorted_ids]


def deduplicate_resources(
    resources: List[InfraResource],
) -> List[InfraResource]:
    """Deduplicate resources by ID, keeping the first occurrence.

    Args:
        resources: List of resources to deduplicate

    Returns:
        Deduplicated list of resources
    """
    seen: Set[str] = set()
    unique_resources = []

    for resource in resources:
        if resource.metadata.id not in seen:
            seen.add(resource.metadata.id)
            unique_resources.append(resource)
        else:
            logger.warning(
                f"Duplicate resource {resource.metadata.id} found, keeping first occurrence"
            )

    return unique_resources


# ============================================================================
# DockerResources Orchestrator
# ============================================================================


@dataclass
class DockerResources:
    """Orchestrator for Docker resource deployment with dependency resolution.

    This class manages the lifecycle of multiple Docker resources (networks,
    images, volumes, containers) with proper dependency ordering and filtering.
    """

    resources: List[InfraResource] = field(default_factory=list)
    _client: Optional[docker.DockerClient] = field(default=None, repr=False, init=False)

    def __post_init__(self):
        """Initialize Docker client."""
        if self._client is None:
            self._client = docker.from_env()

    def add_resource(self, resource: InfraResource) -> None:
        """Add a resource to the orchestrator.

        Args:
            resource: Resource to add
        """
        self.resources.append(resource)

    def add_resources(self, resources: List[InfraResource]) -> None:
        """Add multiple resources to the orchestrator.

        Args:
            resources: List of resources to add
        """
        self.resources.extend(resources)

    def filter_resources(
        self,
        group_filter: Optional[str] = None,
        name_filter: Optional[str] = None,
        type_filter: Optional[ResourceType] = None,
    ) -> List[InfraResource]:
        """Filter resources by group, name, or type.

        Args:
            group_filter: Optional group filter (matches against tags)
            name_filter: Optional name filter (substring match)
            type_filter: Optional resource type filter

        Returns:
            Filtered list of resources
        """
        filtered = self.resources

        if group_filter:
            filtered = [
                r
                for r in filtered
                if group_filter in r.metadata.tags.get("group", "")
            ]

        if name_filter:
            filtered = [r for r in filtered if name_filter in r.metadata.name]

        if type_filter:
            filtered = [r for r in filtered if r.metadata.type == type_filter]

        return filtered

    def create_resources(
        self,
        *,
        dry_run: bool = False,
        auto_confirm: bool = False,
        force: bool = False,
        pull: bool = False,
        group_filter: Optional[str] = None,
        name_filter: Optional[str] = None,
        type_filter: Optional[ResourceType] = None,
    ) -> Dict[str, Any]:
        """Create resources with dependency resolution.

        Args:
            dry_run: If True, only simulate operations
            auto_confirm: If True, skip confirmation prompts
            force: If True, force creation even if resources exist
            pull: If True, pull images even if they exist (Docker images only)
            group_filter: Optional group filter
            name_filter: Optional name filter
            type_filter: Optional resource type filter

        Returns:
            Dictionary with creation results per resource

        Raises:
            OrchestrationError: If orchestration fails
        """
        try:
            # Filter resources
            resources = self.filter_resources(group_filter, name_filter, type_filter)

            if not resources:
                logger.warning("No resources to create after filtering")
                return {"status": "no_resources", "results": {}}

            # Deduplicate
            resources = deduplicate_resources(resources)

            # Sort by dependencies
            sorted_resources = topological_sort(resources)

            logger.info(
                f"Creating {len(sorted_resources)} resources in dependency order"
            )

            # Display plan
            if not auto_confirm and not dry_run:
                self._display_plan(sorted_resources, "create")

            # Execute creation
            results = {}
            for resource in sorted_resources:
                resource_id = resource.metadata.id
                resource_name = resource.metadata.name

                try:
                    logger.info(f"Creating resource: {resource_name} ({resource_id})")
                    result = resource.create(dry_run=dry_run, force=force)
                    results[resource_id] = result

                    if not dry_run:
                        logger.info(
                            f"✓ Created {resource_name}: {result.get('status')}"
                        )

                except Exception as e:
                    logger.error(f"✗ Failed to create {resource_name}: {e}")
                    results[resource_id] = {
                        "action": "create",
                        "resource": resource.metadata.type.value,
                        "name": resource_name,
                        "status": "failed",
                        "error": str(e),
                    }

                    # Stop on first failure unless force=True
                    if not force:
                        raise OrchestrationError(
                            f"Failed to create {resource_name}: {e}"
                        )

            return {"status": "success", "results": results}

        except DependencyError as e:
            logger.error(f"Dependency error: {e}")
            raise OrchestrationError(f"Dependency resolution failed: {e}")
        except Exception as e:
            logger.error(f"Orchestration error: {e}")
            raise OrchestrationError(f"Failed to create resources: {e}")

    def delete_resources(
        self,
        *,
        dry_run: bool = False,
        auto_confirm: bool = False,
        force: bool = False,
        group_filter: Optional[str] = None,
        name_filter: Optional[str] = None,
        type_filter: Optional[ResourceType] = None,
    ) -> Dict[str, Any]:
        """Delete resources in reverse dependency order.

        Args:
            dry_run: If True, only simulate operations
            auto_confirm: If True, skip confirmation prompts
            force: If True, force deletion even if dependencies exist
            group_filter: Optional group filter
            name_filter: Optional name filter
            type_filter: Optional resource type filter

        Returns:
            Dictionary with deletion results per resource

        Raises:
            OrchestrationError: If orchestration fails
        """
        try:
            # Filter resources
            resources = self.filter_resources(group_filter, name_filter, type_filter)

            if not resources:
                logger.warning("No resources to delete after filtering")
                return {"status": "no_resources", "results": {}}

            # Deduplicate
            resources = deduplicate_resources(resources)

            # Sort by dependencies (reverse for deletion)
            sorted_resources = topological_sort(resources)
            sorted_resources.reverse()

            logger.info(
                f"Deleting {len(sorted_resources)} resources in reverse dependency order"
            )

            # Display plan
            if not auto_confirm and not dry_run:
                self._display_plan(sorted_resources, "delete")

            # Execute deletion
            results = {}
            for resource in sorted_resources:
                resource_id = resource.metadata.id
                resource_name = resource.metadata.name

                try:
                    logger.info(f"Deleting resource: {resource_name} ({resource_id})")
                    result = resource.delete(dry_run=dry_run, force=force)
                    results[resource_id] = result

                    if not dry_run:
                        logger.info(
                            f"✓ Deleted {resource_name}: {result.get('status')}"
                        )

                except Exception as e:
                    logger.error(f"✗ Failed to delete {resource_name}: {e}")
                    results[resource_id] = {
                        "action": "delete",
                        "resource": resource.metadata.type.value,
                        "name": resource_name,
                        "status": "failed",
                        "error": str(e),
                    }

                    # Stop on first failure unless force=True
                    if not force:
                        raise OrchestrationError(
                            f"Failed to delete {resource_name}: {e}"
                        )

            return {"status": "success", "results": results}

        except DependencyError as e:
            logger.error(f"Dependency error: {e}")
            raise OrchestrationError(f"Dependency resolution failed: {e}")
        except Exception as e:
            logger.error(f"Orchestration error: {e}")
            raise OrchestrationError(f"Failed to delete resources: {e}")

    def get_resource_graph(self) -> Dict[str, Any]:
        """Get resource dependency graph for visualization.

        Returns:
            Dictionary representing the resource graph
        """
        nodes = []
        edges = []

        for resource in self.resources:
            nodes.append(
                {
                    "id": resource.metadata.id,
                    "name": resource.metadata.name,
                    "type": resource.metadata.type.value,
                    "status": resource.get_status().value,
                }
            )

            for dep_id in resource.depends_on:
                edges.append({"from": dep_id, "to": resource.metadata.id})

        return {"nodes": nodes, "edges": edges}

    def _display_plan(self, resources: List[InfraResource], action: str) -> None:
        """Display execution plan to user.

        Args:
            resources: Resources to be affected
            action: Action to perform (create/delete)
        """
        logger.info(f"\n{'='*60}")
        logger.info(f"Plan: {action.upper()} {len(resources)} resources")
        logger.info(f"{'='*60}\n")

        for i, resource in enumerate(resources, 1):
            logger.info(
                f"{i}. {resource.metadata.type.value.upper()}: {resource.metadata.name}"
            )

        logger.info(f"\n{'='*60}\n")


# ============================================================================
# DockerBackend
# ============================================================================


@dataclass
class DockerBackend(InfraBackend):
    """Docker infrastructure backend implementation."""

    config: Dict[str, Any] = field(default_factory=dict)
    _client: Optional[docker.DockerClient] = field(default=None, repr=False, init=False)

    def __post_init__(self):
        """Initialize Docker client."""
        if self._client is None:
            self._client = docker.from_env()

    @property
    def backend_type(self) -> str:
        """Return the backend type identifier."""
        return "docker"

    def validate_config(self, config: Dict[str, Any]) -> bool:
        """Validate backend configuration.

        Args:
            config: Backend-specific configuration

        Returns:
            True if configuration is valid

        Raises:
            ConfigurationError: If configuration is invalid
        """
        # Minimal validation for now
        return True

    def create_resources(
        self,
        resources: List[InfraResource],
        *,
        dry_run: bool = False,
        auto_confirm: bool = False,
        force: bool = False,
        group_filter: Optional[str] = None,
        name_filter: Optional[str] = None,
        type_filter: Optional[ResourceType] = None,
    ) -> Dict[str, Any]:
        """Create multiple resources with dependency resolution."""
        orchestrator = DockerResources(resources=list(resources))
        return orchestrator.create_resources(
            dry_run=dry_run,
            auto_confirm=auto_confirm,
            force=force,
            group_filter=group_filter,
            name_filter=name_filter,
            type_filter=type_filter,
        )

    def delete_resources(
        self,
        resources: List[InfraResource],
        *,
        dry_run: bool = False,
        auto_confirm: bool = False,
        force: bool = False,
    ) -> Dict[str, Any]:
        """Delete multiple resources in reverse dependency order."""
        orchestrator = DockerResources(resources=list(resources))
        return orchestrator.delete_resources(
            dry_run=dry_run,
            auto_confirm=auto_confirm,
            force=force,
        )

    def get_health(self) -> Dict[str, Any]:
        """Get backend health status.

        Returns:
            Dictionary with health metrics
        """
        try:
            # Ping Docker daemon
            self._client.ping()

            # Get Docker info
            info = self._client.info()

            return {
                "status": "healthy",
                "backend": "docker",
                "version": self._client.version().get("Version"),
                "containers": {
                    "total": info.get("Containers", 0),
                    "running": info.get("ContainersRunning", 0),
                    "paused": info.get("ContainersPaused", 0),
                    "stopped": info.get("ContainersStopped", 0),
                },
                "images": info.get("Images", 0),
            }

        except Exception as e:
            logger.error(f"Docker health check failed: {e}")
            return {
                "status": "unhealthy",
                "backend": "docker",
                "error": str(e),
            }
