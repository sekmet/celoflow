"""Docker resource type implementations.

This module provides concrete implementations for Docker resources:
- DockerNetwork: Network creation and management
- DockerImage: Image build/pull with buildx support
- DockerVolume: Named volume management
- DockerContainer: Container lifecycle management
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import docker
from docker.models.containers import Container
from docker.models.images import Image
from docker.models.networks import Network
from docker.models.volumes import Volume

from ..base import (
    InfraResource,
    ResourceCreationError,
    ResourceDeletionError,
    ResourceMetadata,
    ResourceNotFoundError,
    ResourceStatus,
    ResourceType,
    ResourceUpdateError,
)

logger = logging.getLogger(__name__)


# ============================================================================
# Install Order Weights (for dependency sorting)
# ============================================================================

INSTALL_ORDER_WEIGHTS = {
    ResourceType.NETWORK: 1,
    ResourceType.IMAGE: 2,
    ResourceType.VOLUME: 3,
    ResourceType.CONTAINER: 4,
}


# ============================================================================
# DockerNetwork
# ============================================================================


@dataclass
class DockerNetwork:
    """Docker network resource."""

    name: str
    driver: str = "bridge"
    internal: bool = False
    enable_ipv6: bool = False
    labels: Dict[str, str] = field(default_factory=dict)
    options: Dict[str, Any] = field(default_factory=dict)
    ipam_config: Optional[Dict[str, Any]] = None

    # Resource protocol fields
    resource_id: Optional[str] = None
    skip_if_exists: bool = True
    use_cache: bool = True
    depends_on_resources: List[str] = field(default_factory=list)

    _client: Optional[docker.DockerClient] = field(default=None, repr=False, init=False)

    def __post_init__(self):
        """Initialize Docker client."""
        if self._client is None:
            self._client = docker.from_env()

    @property
    def metadata(self) -> ResourceMetadata:
        """Return resource metadata."""
        return ResourceMetadata(
            id=self.resource_id or f"network_{self.name}",
            name=self.name,
            type=ResourceType.NETWORK,
            status=self.get_status(),
            tags=self.labels,
        )

    @property
    def depends_on(self) -> List[str]:
        """Return list of resource IDs this resource depends on."""
        return self.depends_on_resources

    def create(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Create the network.

        Args:
            dry_run: If True, only simulate the operation
            force: If True, force creation even if network exists

        Returns:
            Dictionary with creation result details
        """
        if dry_run:
            return {
                "action": "create",
                "resource": "network",
                "name": self.name,
                "dry_run": True,
                "status": "would_create",
            }

        try:
            # Check if network exists
            if self.exists() and not force:
                if self.skip_if_exists:
                    logger.info(f"Network {self.name} already exists, skipping")
                    return {
                        "action": "create",
                        "resource": "network",
                        "name": self.name,
                        "status": "skipped",
                        "reason": "already_exists",
                    }
                else:
                    raise ResourceCreationError(
                        f"Network {self.name} already exists and skip_if_exists=False"
                    )

            # Create network
            logger.info(f"Creating network: {self.name}")
            network: Network = self._client.networks.create(
                name=self.name,
                driver=self.driver,
                internal=self.internal,
                enable_ipv6=self.enable_ipv6,
                labels=self.labels,
                options=self.options,
                ipam=self.ipam_config,
            )

            self.resource_id = network.id

            return {
                "action": "create",
                "resource": "network",
                "name": self.name,
                "id": network.id,
                "status": "created",
            }

        except Exception as e:
            logger.error(f"Failed to create network {self.name}: {e}")
            raise ResourceCreationError(f"Failed to create network {self.name}: {e}")

    def read(self) -> Dict[str, Any]:
        """Read current state of the network."""
        try:
            networks = self._client.networks.list(names=[self.name])
            if not networks:
                raise ResourceNotFoundError(f"Network {self.name} not found")

            network = networks[0]
            return {
                "id": network.id,
                "name": network.name,
                "driver": network.attrs.get("Driver"),
                "scope": network.attrs.get("Scope"),
                "internal": network.attrs.get("Internal"),
                "labels": network.attrs.get("Labels", {}),
            }
        except docker.errors.NotFound:
            raise ResourceNotFoundError(f"Network {self.name} not found")
        except Exception as e:
            logger.error(f"Failed to read network {self.name}: {e}")
            raise

    def update(self, **kwargs: Any) -> Dict[str, Any]:
        """Update the network (limited support in Docker API)."""
        raise ResourceUpdateError("Docker networks do not support direct updates")

    def delete(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Delete the network."""
        if dry_run:
            return {
                "action": "delete",
                "resource": "network",
                "name": self.name,
                "dry_run": True,
                "status": "would_delete",
            }

        try:
            networks = self._client.networks.list(names=[self.name])
            if not networks:
                return {
                    "action": "delete",
                    "resource": "network",
                    "name": self.name,
                    "status": "not_found",
                }

            network = networks[0]
            logger.info(f"Deleting network: {self.name}")
            network.remove()

            return {
                "action": "delete",
                "resource": "network",
                "name": self.name,
                "status": "deleted",
            }

        except Exception as e:
            logger.error(f"Failed to delete network {self.name}: {e}")
            raise ResourceDeletionError(f"Failed to delete network {self.name}: {e}")

    def exists(self) -> bool:
        """Check if the network exists."""
        try:
            networks = self._client.networks.list(names=[self.name])
            return len(networks) > 0
        except Exception:
            return False

    def get_status(self) -> ResourceStatus:
        """Get current status of the network."""
        if self.exists():
            return ResourceStatus.RUNNING
        return ResourceStatus.PENDING


# ============================================================================
# DockerImage
# ============================================================================


@dataclass
class DockerImage:
    """Docker image resource with build/pull support."""

    name: str
    tag: str = "latest"
    build_context: Optional[Path] = None
    dockerfile: Optional[Path] = None
    build_args: Dict[str, str] = field(default_factory=dict)
    pull: bool = True
    platform: Optional[str] = None
    labels: Dict[str, str] = field(default_factory=dict)

    # Resource protocol fields
    resource_id: Optional[str] = None
    skip_if_exists: bool = True
    use_cache: bool = True
    depends_on_resources: List[str] = field(default_factory=list)

    _client: Optional[docker.DockerClient] = field(default=None, repr=False, init=False)

    def __post_init__(self):
        """Initialize Docker client."""
        if self._client is None:
            self._client = docker.from_env()

    @property
    def full_name(self) -> str:
        """Return full image name with tag."""
        return f"{self.name}:{self.tag}"

    @property
    def metadata(self) -> ResourceMetadata:
        """Return resource metadata."""
        return ResourceMetadata(
            id=self.resource_id or f"image_{self.name.replace('/', '_')}_{self.tag}",
            name=self.full_name,
            type=ResourceType.IMAGE,
            status=self.get_status(),
            tags=self.labels,
        )

    @property
    def depends_on(self) -> List[str]:
        """Return list of resource IDs this resource depends on."""
        return self.depends_on_resources

    def create(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Build or pull the image."""
        if dry_run:
            action = "build" if self.build_context else "pull"
            return {
                "action": action,
                "resource": "image",
                "name": self.full_name,
                "dry_run": True,
                "status": f"would_{action}",
            }

        try:
            # Check if image exists
            if self.exists() and not force:
                if self.skip_if_exists:
                    logger.info(f"Image {self.full_name} already exists, skipping")
                    return {
                        "action": "create",
                        "resource": "image",
                        "name": self.full_name,
                        "status": "skipped",
                        "reason": "already_exists",
                    }

            # Build or pull
            if self.build_context:
                return self._build_image()
            else:
                return self._pull_image(force)

        except Exception as e:
            logger.error(f"Failed to create image {self.full_name}: {e}")
            raise ResourceCreationError(f"Failed to create image {self.full_name}: {e}")

    def _build_image(self) -> Dict[str, Any]:
        """Build image from Dockerfile."""
        logger.info(f"Building image: {self.full_name}")

        dockerfile_path = self.dockerfile or "Dockerfile"

        image, build_logs = self._client.images.build(
            path=str(self.build_context),
            dockerfile=str(dockerfile_path),
            tag=self.full_name,
            buildargs=self.build_args,
            labels=self.labels,
            platform=self.platform,
            rm=True,
        )

        self.resource_id = image.id

        return {
            "action": "build",
            "resource": "image",
            "name": self.full_name,
            "id": image.id,
            "status": "built",
        }

    def _pull_image(self, force: bool = False) -> Dict[str, Any]:
        """Pull image from registry."""
        logger.info(f"Pulling image: {self.full_name}")

        image: Image = self._client.images.pull(
            self.name,
            tag=self.tag,
            platform=self.platform,
        )

        self.resource_id = image.id

        return {
            "action": "pull",
            "resource": "image",
            "name": self.full_name,
            "id": image.id,
            "status": "pulled",
        }

    def read(self) -> Dict[str, Any]:
        """Read current state of the image."""
        try:
            image: Image = self._client.images.get(self.full_name)
            return {
                "id": image.id,
                "tags": image.tags,
                "labels": image.labels or {},
                "size": image.attrs.get("Size"),
                "created": image.attrs.get("Created"),
            }
        except docker.errors.ImageNotFound:
            raise ResourceNotFoundError(f"Image {self.full_name} not found")
        except Exception as e:
            logger.error(f"Failed to read image {self.full_name}: {e}")
            raise

    def update(self, **kwargs: Any) -> Dict[str, Any]:
        """Update the image (rebuild or re-pull)."""
        return self.create(force=True)

    def delete(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Delete the image."""
        if dry_run:
            return {
                "action": "delete",
                "resource": "image",
                "name": self.full_name,
                "dry_run": True,
                "status": "would_delete",
            }

        try:
            if not self.exists():
                return {
                    "action": "delete",
                    "resource": "image",
                    "name": self.full_name,
                    "status": "not_found",
                }

            logger.info(f"Deleting image: {self.full_name}")
            self._client.images.remove(self.full_name, force=force)

            return {
                "action": "delete",
                "resource": "image",
                "name": self.full_name,
                "status": "deleted",
            }

        except Exception as e:
            logger.error(f"Failed to delete image {self.full_name}: {e}")
            raise ResourceDeletionError(f"Failed to delete image {self.full_name}: {e}")

    def exists(self) -> bool:
        """Check if the image exists."""
        try:
            self._client.images.get(self.full_name)
            return True
        except docker.errors.ImageNotFound:
            return False
        except Exception:
            return False

    def get_status(self) -> ResourceStatus:
        """Get current status of the image."""
        if self.exists():
            return ResourceStatus.RUNNING
        return ResourceStatus.PENDING


# ============================================================================
# DockerVolume
# ============================================================================


@dataclass
class DockerVolume:
    """Docker volume resource."""

    name: str
    driver: str = "local"
    driver_opts: Dict[str, str] = field(default_factory=dict)
    labels: Dict[str, str] = field(default_factory=dict)

    # Resource protocol fields
    resource_id: Optional[str] = None
    skip_if_exists: bool = True
    use_cache: bool = True
    depends_on_resources: List[str] = field(default_factory=list)

    _client: Optional[docker.DockerClient] = field(default=None, repr=False, init=False)

    def __post_init__(self):
        """Initialize Docker client."""
        if self._client is None:
            self._client = docker.from_env()

    @property
    def metadata(self) -> ResourceMetadata:
        """Return resource metadata."""
        return ResourceMetadata(
            id=self.resource_id or f"volume_{self.name}",
            name=self.name,
            type=ResourceType.VOLUME,
            status=self.get_status(),
            tags=self.labels,
        )

    @property
    def depends_on(self) -> List[str]:
        """Return list of resource IDs this resource depends on."""
        return self.depends_on_resources

    def create(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Create the volume."""
        if dry_run:
            return {
                "action": "create",
                "resource": "volume",
                "name": self.name,
                "dry_run": True,
                "status": "would_create",
            }

        try:
            # Check if volume exists
            if self.exists() and not force:
                if self.skip_if_exists:
                    logger.info(f"Volume {self.name} already exists, skipping")
                    return {
                        "action": "create",
                        "resource": "volume",
                        "name": self.name,
                        "status": "skipped",
                        "reason": "already_exists",
                    }

            # Create volume
            logger.info(f"Creating volume: {self.name}")
            volume: Volume = self._client.volumes.create(
                name=self.name,
                driver=self.driver,
                driver_opts=self.driver_opts,
                labels=self.labels,
            )

            self.resource_id = volume.id

            return {
                "action": "create",
                "resource": "volume",
                "name": self.name,
                "id": volume.id,
                "status": "created",
            }

        except Exception as e:
            logger.error(f"Failed to create volume {self.name}: {e}")
            raise ResourceCreationError(f"Failed to create volume {self.name}: {e}")

    def read(self) -> Dict[str, Any]:
        """Read current state of the volume."""
        try:
            volume: Volume = self._client.volumes.get(self.name)
            return {
                "name": volume.name,
                "driver": volume.attrs.get("Driver"),
                "mountpoint": volume.attrs.get("Mountpoint"),
                "labels": volume.attrs.get("Labels", {}),
                "scope": volume.attrs.get("Scope"),
            }
        except docker.errors.NotFound:
            raise ResourceNotFoundError(f"Volume {self.name} not found")
        except Exception as e:
            logger.error(f"Failed to read volume {self.name}: {e}")
            raise

    def update(self, **kwargs: Any) -> Dict[str, Any]:
        """Update the volume (limited support in Docker API)."""
        raise ResourceUpdateError("Docker volumes do not support direct updates")

    def delete(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Delete the volume."""
        if dry_run:
            return {
                "action": "delete",
                "resource": "volume",
                "name": self.name,
                "dry_run": True,
                "status": "would_delete",
            }

        try:
            if not self.exists():
                return {
                    "action": "delete",
                    "resource": "volume",
                    "name": self.name,
                    "status": "not_found",
                }

            logger.info(f"Deleting volume: {self.name}")
            volume: Volume = self._client.volumes.get(self.name)
            volume.remove(force=force)

            return {
                "action": "delete",
                "resource": "volume",
                "name": self.name,
                "status": "deleted",
            }

        except Exception as e:
            logger.error(f"Failed to delete volume {self.name}: {e}")
            raise ResourceDeletionError(f"Failed to delete volume {self.name}: {e}")

    def exists(self) -> bool:
        """Check if the volume exists."""
        try:
            self._client.volumes.get(self.name)
            return True
        except docker.errors.NotFound:
            return False
        except Exception:
            return False

    def get_status(self) -> ResourceStatus:
        """Get current status of the volume."""
        if self.exists():
            return ResourceStatus.RUNNING
        return ResourceStatus.PENDING


# ============================================================================
# DockerContainer
# ============================================================================


@dataclass
class DockerContainer:
    """Docker container resource."""

    name: str
    image: str
    command: Optional[str] = None
    entrypoint: Optional[List[str]] = None
    environment: Dict[str, str] = field(default_factory=dict)
    ports: Dict[str, int] = field(default_factory=dict)
    volumes: Dict[str, Dict[str, str]] = field(default_factory=dict)
    network: Optional[str] = None
    restart_policy: Dict[str, Any] = field(default_factory=lambda: {"Name": "unless-stopped"})
    labels: Dict[str, str] = field(default_factory=dict)
    healthcheck: Optional[Dict[str, Any]] = None
    working_dir: Optional[str] = None
    user: Optional[str] = None
    detach: bool = True

    # Resource protocol fields
    resource_id: Optional[str] = None
    skip_if_exists: bool = True
    use_cache: bool = True
    depends_on_resources: List[str] = field(default_factory=list)

    _client: Optional[docker.DockerClient] = field(default=None, repr=False, init=False)

    def __post_init__(self):
        """Initialize Docker client."""
        if self._client is None:
            self._client = docker.from_env()

    @property
    def metadata(self) -> ResourceMetadata:
        """Return resource metadata."""
        return ResourceMetadata(
            id=self.resource_id or f"container_{self.name}",
            name=self.name,
            type=ResourceType.CONTAINER,
            status=self.get_status(),
            tags=self.labels,
        )

    @property
    def depends_on(self) -> List[str]:
        """Return list of resource IDs this resource depends on."""
        return self.depends_on_resources

    def create(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Create and start the container."""
        if dry_run:
            return {
                "action": "create",
                "resource": "container",
                "name": self.name,
                "image": self.image,
                "dry_run": True,
                "status": "would_create",
            }

        try:
            # Check if container exists
            if self.exists() and not force:
                if self.skip_if_exists:
                    logger.info(f"Container {self.name} already exists, skipping")
                    return {
                        "action": "create",
                        "resource": "container",
                        "name": self.name,
                        "status": "skipped",
                        "reason": "already_exists",
                    }

            # Create container
            logger.info(f"Creating container: {self.name}")
            container: Container = self._client.containers.run(
                image=self.image,
                name=self.name,
                command=self.command,
                entrypoint=self.entrypoint,
                environment=self.environment,
                ports=self.ports,
                volumes=self.volumes,
                network=self.network,
                restart_policy=self.restart_policy,
                labels=self.labels,
                healthcheck=self.healthcheck,
                working_dir=self.working_dir,
                user=self.user,
                detach=self.detach,
            )

            self.resource_id = container.id

            return {
                "action": "create",
                "resource": "container",
                "name": self.name,
                "id": container.id,
                "status": "created",
            }

        except Exception as e:
            logger.error(f"Failed to create container {self.name}: {e}")
            raise ResourceCreationError(f"Failed to create container {self.name}: {e}")

    def read(self) -> Dict[str, Any]:
        """Read current state of the container."""
        try:
            container: Container = self._client.containers.get(self.name)
            container.reload()
            return {
                "id": container.id,
                "name": container.name,
                "status": container.status,
                "image": container.image.tags[0] if container.image.tags else None,
                "labels": container.labels,
                "ports": container.ports,
            }
        except docker.errors.NotFound:
            raise ResourceNotFoundError(f"Container {self.name} not found")
        except Exception as e:
            logger.error(f"Failed to read container {self.name}: {e}")
            raise

    def update(self, **kwargs: Any) -> Dict[str, Any]:
        """Update the container (restart with new config)."""
        # Docker containers are typically replaced rather than updated
        self.delete()
        return self.create()

    def delete(self, dry_run: bool = False, force: bool = False) -> Dict[str, Any]:
        """Stop and delete the container."""
        if dry_run:
            return {
                "action": "delete",
                "resource": "container",
                "name": self.name,
                "dry_run": True,
                "status": "would_delete",
            }

        try:
            if not self.exists():
                return {
                    "action": "delete",
                    "resource": "container",
                    "name": self.name,
                    "status": "not_found",
                }

            logger.info(f"Deleting container: {self.name}")
            container: Container = self._client.containers.get(self.name)
            container.stop(timeout=10)
            container.remove(force=force)

            return {
                "action": "delete",
                "resource": "container",
                "name": self.name,
                "status": "deleted",
            }

        except Exception as e:
            logger.error(f"Failed to delete container {self.name}: {e}")
            raise ResourceDeletionError(f"Failed to delete container {self.name}: {e}")

    def exists(self) -> bool:
        """Check if the container exists."""
        try:
            self._client.containers.get(self.name)
            return True
        except docker.errors.NotFound:
            return False
        except Exception:
            return False

    def get_status(self) -> ResourceStatus:
        """Get current status of the container."""
        try:
            container: Container = self._client.containers.get(self.name)
            container.reload()
            status_map = {
                "running": ResourceStatus.RUNNING,
                "exited": ResourceStatus.STOPPED,
                "created": ResourceStatus.PENDING,
                "paused": ResourceStatus.STOPPED,
                "restarting": ResourceStatus.CREATING,
                "removing": ResourceStatus.DELETING,
                "dead": ResourceStatus.FAILED,
            }
            return status_map.get(container.status, ResourceStatus.PENDING)
        except docker.errors.NotFound:
            return ResourceStatus.PENDING
        except Exception:
            return ResourceStatus.FAILED
