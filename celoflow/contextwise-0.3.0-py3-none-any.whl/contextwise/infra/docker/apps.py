"""Docker application templates for agent deployment.

This module provides pre-configured Docker application templates:
- DockerApp: Base class for all Docker applications
- AgentApiApp: FastAPI/uvicorn service for Agent server
- PlatformApiApp: Platform REST API with artifact volume, auth, SSE support
- PostgresApp: PostgreSQL database (optional dependency)
- RedisApp: Redis cache (optional dependency)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .resource_types import DockerContainer, DockerImage, DockerNetwork, DockerVolume


@dataclass
class DockerApp:
    """Base class for Docker application templates.

    Provides common functionality for creating containerized services with
    standard volume mounts, environment configuration, and networking.
    """

    name: str
    image_name: str
    image_tag: str = "latest"
    command: Optional[str] = None
    entrypoint: Optional[List[str]] = None
    ports: Dict[str, int] = field(default_factory=dict)
    environment: Dict[str, str] = field(default_factory=dict)
    labels: Dict[str, str] = field(default_factory=dict)

    # Volume configuration
    workspace_mount: Optional[Path] = None
    named_volumes: List[str] = field(default_factory=list)
    volume_mounts: Dict[str, Dict[str, str]] = field(default_factory=dict)

    # Network configuration
    network_name: Optional[str] = None

    # Resource policies
    restart_policy: Dict[str, Any] = field(
        default_factory=lambda: {"Name": "unless-stopped"}
    )
    healthcheck: Optional[Dict[str, Any]] = None
    working_dir: Optional[str] = None
    user: Optional[str] = None

    def get_container_name(self) -> str:
        """Get container name for DNS resolution."""
        return self.name.replace("_", "-")

    def get_container_env(self) -> Dict[str, str]:
        """Build container environment variables.

        Combines base environment with app-specific overrides.

        Returns:
            Dictionary of environment variables
        """
        env = {}

        # Add base environment
        env.update(self.environment)

        return env

    def get_container_volumes(self) -> Dict[str, Dict[str, str]]:
        """Build container volume mounts.

        Returns:
            Dictionary of volume mount configurations
        """
        volumes = {}

        # Add workspace mount if configured
        if self.workspace_mount:
            volumes[str(self.workspace_mount)] = {
                "bind": "/workspace",
                "mode": "rw",
            }

        # Add named volumes
        for vol_name in self.named_volumes:
            volumes[vol_name] = {"bind": f"/data/{vol_name}", "mode": "rw"}

        # Add custom volume mounts
        volumes.update(self.volume_mounts)

        return volumes

    def get_container_ports(self) -> Dict[str, int]:
        """Build container port mappings.

        Returns:
            Dictionary of port mappings
        """
        return self.ports

    def to_resources(
        self,
        *,
        create_network: bool = True,
        create_volumes: bool = True,
        build_image: bool = False,
        build_context: Optional[Path] = None,
        dockerfile: Optional[Path] = None,
    ) -> List[Any]:
        """Convert app configuration to infrastructure resources.

        Args:
            create_network: Whether to create a dedicated network
            create_volumes: Whether to create named volumes
            build_image: Whether to build the image from source
            build_context: Build context path (required if build_image=True)
            dockerfile: Dockerfile path (optional)

        Returns:
            List of InfraResource objects
        """
        resources = []

        # Network resource
        if create_network and self.network_name:
            network = DockerNetwork(
                name=self.network_name,
                labels={"app": self.name, **self.labels},
            )
            resources.append(network)

        # Image resource
        if build_image:
            if not build_context:
                raise ValueError("build_context required when build_image=True")

            image = DockerImage(
                name=self.image_name,
                tag=self.image_tag,
                build_context=build_context,
                dockerfile=dockerfile,
                labels={"app": self.name, **self.labels},
            )
        else:
            image = DockerImage(
                name=self.image_name,
                tag=self.image_tag,
                pull=True,
                labels={"app": self.name, **self.labels},
            )
        resources.append(image)

        # Volume resources
        if create_volumes:
            for vol_name in self.named_volumes:
                volume = DockerVolume(
                    name=vol_name,
                    labels={"app": self.name, **self.labels},
                )
                resources.append(volume)

        # Container resource
        container = DockerContainer(
            name=self.get_container_name(),
            image=f"{self.image_name}:{self.image_tag}",
            command=self.command,
            entrypoint=self.entrypoint,
            environment=self.get_container_env(),
            ports=self.get_container_ports(),
            volumes=self.get_container_volumes(),
            network=self.network_name,
            restart_policy=self.restart_policy,
            labels={"app": self.name, **self.labels},
            healthcheck=self.healthcheck,
            working_dir=self.working_dir,
            user=self.user,
        )

        # Set dependencies
        deps = [f"image_{self.image_name.replace('/', '_')}_{self.image_tag}"]
        if create_network and self.network_name:
            deps.append(f"network_{self.network_name}")
        for vol_name in self.named_volumes:
            if create_volumes:
                deps.append(f"volume_{vol_name}")
        container.depends_on_resources = deps

        resources.append(container)

        return resources


# ============================================================================
# AgentApiApp
# ============================================================================


@dataclass
class AgentApiApp(DockerApp):
    """FastAPI/uvicorn service for Contextwise Agent server.

    This app template provides a production-ready Agent API server with:
    - Uvicorn ASGI server
    - Agent configuration loading
    - Storage backend support
    - Optional plugin dependencies
    """

    # Override defaults for agent API
    image_name: str = "contextwise-agent"
    image_tag: str = "latest"
    command: str = "uvicorn contextwise.server:app --host 0.0.0.0 --port 8000"
    working_dir: str = "/app"

    # Agent-specific configuration
    agent_config_path: Optional[Path] = None
    storage_backend: str = "sqlite"
    storage_path: Optional[Path] = None

    def __post_init__(self):
        """Initialize agent API app with defaults."""
        # Set default ports
        if not self.ports:
            self.ports = {"8000/tcp": 8000}

        # Set default named volumes
        if not self.named_volumes:
            self.named_volumes = ["agent-data"]

        # Set default labels
        if not self.labels:
            self.labels = {"service": "agent-api"}

        # Set default healthcheck
        if not self.healthcheck:
            self.healthcheck = {
                "test": ["CMD", "curl", "-f", "http://localhost:8000/health"],
                "interval": 30000000000,  # 30s in nanoseconds
                "timeout": 10000000000,  # 10s in nanoseconds
                "retries": 3,
                "start_period": 40000000000,  # 40s in nanoseconds
            }

    def get_container_env(self) -> Dict[str, str]:
        """Build container environment for agent API."""
        env = super().get_container_env()

        # Add agent-specific env vars
        env.update(
            {
                "STORAGE_BACKEND": self.storage_backend,
                "PYTHONUNBUFFERED": "1",
            }
        )

        if self.storage_path:
            env["STORAGE_PATH"] = str(self.storage_path)

        return env


# ============================================================================
# PlatformApiApp
# ============================================================================


@dataclass
class PlatformApiApp(DockerApp):
    """Platform REST API with artifact volume, auth, SSE support.

    This app template provides the updated Agent Platform API with:
    - Multi-agent management
    - Task/run execution
    - Memory management
    - Artifact upload/download
    - SSE streaming
    - Optional authentication
    """

    # Override defaults for platform API
    image_name: str = "contextwise-platform"
    image_tag: str = "latest"
    command: str = "uvicorn contextwise.lib.agent_api:app --host 0.0.0.0 --port 8001"
    working_dir: str = "/app"

    # Platform-specific configuration
    auth_enabled: bool = False
    auth_token: Optional[str] = None
    artifacts_dir: str = "./agent_api_artifacts"
    cors_allow_origins: str = "*"

    def __post_init__(self):
        """Initialize platform API app with defaults."""
        # Set default ports
        if not self.ports:
            self.ports = {"8001/tcp": 8001}

        # Set default named volumes (for artifact persistence)
        if not self.named_volumes:
            self.named_volumes = ["platform-artifacts"]

        # Set default volume mounts (artifacts directory)
        if not self.volume_mounts:
            self.volume_mounts = {
                "platform-artifacts": {
                    "bind": "/app/agent_api_artifacts",
                    "mode": "rw",
                }
            }

        # Set default labels
        if not self.labels:
            self.labels = {"service": "platform-api"}

        # Set default healthcheck
        if not self.healthcheck:
            self.healthcheck = {
                "test": ["CMD", "curl", "-f", "http://localhost:8001/health"],
                "interval": 30000000000,  # 30s in nanoseconds
                "timeout": 10000000000,  # 10s in nanoseconds
                "retries": 3,
                "start_period": 40000000000,  # 40s in nanoseconds
            }

    def get_container_env(self) -> Dict[str, str]:
        """Build container environment for platform API."""
        env = super().get_container_env()

        # Add platform-specific env vars
        env.update(
            {
                "AGENT_API_AUTH_ENABLED": str(self.auth_enabled).lower(),
                "CORS_ALLOW_ORIGINS": self.cors_allow_origins,
                "PYTHONUNBUFFERED": "1",
            }
        )

        if self.auth_enabled and self.auth_token:
            env["AGENT_API_AUTH_TOKEN"] = self.auth_token

        return env


# ============================================================================
# Optional Dependency Services
# ============================================================================


@dataclass
class PostgresApp(DockerApp):
    """PostgreSQL database service.

    Optional dependency for storage backend or memory persistence.
    """

    # Override defaults for PostgreSQL
    image_name: str = "postgres"
    image_tag: str = "16-alpine"
    working_dir: str = "/var/lib/postgresql/data"

    # PostgreSQL-specific configuration
    postgres_db: str = "contextwise"
    postgres_user: str = "contextwise"
    postgres_password: str = "contextwise"

    def __post_init__(self):
        """Initialize PostgreSQL app with defaults."""
        # Set default ports
        if not self.ports:
            self.ports = {"5432/tcp": 5432}

        # Set default named volumes
        if not self.named_volumes:
            self.named_volumes = ["postgres-data"]

        # Set default volume mounts
        if not self.volume_mounts:
            self.volume_mounts = {
                "postgres-data": {
                    "bind": "/var/lib/postgresql/data",
                    "mode": "rw",
                }
            }

        # Set default labels
        if not self.labels:
            self.labels = {"service": "postgres"}

        # Set default healthcheck
        if not self.healthcheck:
            self.healthcheck = {
                "test": ["CMD-SHELL", "pg_isready -U contextwise"],
                "interval": 10000000000,  # 10s in nanoseconds
                "timeout": 5000000000,  # 5s in nanoseconds
                "retries": 5,
            }

    def get_container_env(self) -> Dict[str, str]:
        """Build container environment for PostgreSQL."""
        env = super().get_container_env()

        # Add PostgreSQL env vars
        env.update(
            {
                "POSTGRES_DB": self.postgres_db,
                "POSTGRES_USER": self.postgres_user,
                "POSTGRES_PASSWORD": self.postgres_password,
            }
        )

        return env


@dataclass
class RedisApp(DockerApp):
    """Redis cache service.

    Optional dependency for fast session storage or caching.
    """

    # Override defaults for Redis
    image_name: str = "redis"
    image_tag: str = "7-alpine"
    command: str = "redis-server --appendonly yes"

    # Redis-specific configuration
    redis_password: Optional[str] = None

    def __post_init__(self):
        """Initialize Redis app with defaults."""
        # Set default ports
        if not self.ports:
            self.ports = {"6379/tcp": 6379}

        # Set default named volumes
        if not self.named_volumes:
            self.named_volumes = ["redis-data"]

        # Set default volume mounts
        if not self.volume_mounts:
            self.volume_mounts = {
                "redis-data": {
                    "bind": "/data",
                    "mode": "rw",
                }
            }

        # Set default labels
        if not self.labels:
            self.labels = {"service": "redis"}

        # Set default healthcheck
        if not self.healthcheck:
            self.healthcheck = {
                "test": ["CMD", "redis-cli", "ping"],
                "interval": 10000000000,  # 10s in nanoseconds
                "timeout": 5000000000,  # 5s in nanoseconds
                "retries": 5,
            }

        # Add password to command if configured
        if self.redis_password:
            self.command = f"redis-server --appendonly yes --requirepass {self.redis_password}"

    def get_container_env(self) -> Dict[str, str]:
        """Build container environment for Redis."""
        env = super().get_container_env()

        if self.redis_password:
            env["REDIS_PASSWORD"] = self.redis_password

        return env


# ============================================================================
# QdrantApp
# ============================================================================


@dataclass
class QdrantApp(DockerApp):
    """Qdrant vector database for embeddings and similarity search.

    This app template provides Qdrant vector storage with:
    - Vector similarity search
    - Collections management
    - gRPC and HTTP APIs
    - Persistent storage
    """

    # Override defaults for Qdrant
    image_name: str = "qdrant/qdrant"
    image_tag: str = "latest"
    working_dir: str = "/qdrant"

    # Qdrant-specific configuration
    qdrant_api_key: Optional[str] = None
    qdrant_collection: str = "contextwise"

    def __post_init__(self):
        """Initialize Qdrant app with defaults."""
        # Set default ports (HTTP and gRPC)
        if not self.ports:
            self.ports = {
                "6333/tcp": 6333,  # HTTP API
                "6334/tcp": 6334,  # gRPC API
            }

        # Set default named volumes
        if not self.named_volumes:
            self.named_volumes = ["qdrant-storage"]

        # Set default volume mounts
        if not self.volume_mounts:
            self.volume_mounts = {
                "qdrant-storage": {
                    "bind": "/qdrant/storage",
                    "mode": "rw",
                }
            }

        # Set default labels
        if not self.labels:
            self.labels = {"service": "qdrant"}

        # Set default healthcheck
        if not self.healthcheck:
            self.healthcheck = {
                "test": ["CMD", "curl", "-f", "http://localhost:6333/"],
                "interval": 10000000000,  # 10s in nanoseconds
                "timeout": 5000000000,  # 5s in nanoseconds
                "retries": 5,
            }

    def get_container_env(self) -> Dict[str, str]:
        """Build container environment for Qdrant."""
        env = super().get_container_env()

        if self.qdrant_api_key:
            env["QDRANT__SERVICE__API_KEY"] = self.qdrant_api_key

        return env


# ============================================================================
# LiveKitWorkerApp
# ============================================================================


@dataclass
class LiveKitWorkerApp(DockerApp):
    """LiveKit voice agent worker for real-time voice interactions.

    This app template provides a LiveKit worker that connects to a LiveKit
    server and handles voice sessions with STT/LLM/TTS pipeline.
    """

    # Override defaults for LiveKit worker
    image_name: str = "contextwise-platform"  # Use platform image
    image_tag: str = "latest"
    command: str = "python -m contextwise.livekit_worker start"
    working_dir: str = "/app"

    # LiveKit worker-specific configuration
    livekit_url: Optional[str] = None
    livekit_api_key: Optional[str] = None
    livekit_api_secret: Optional[str] = None
    stt_provider: str = "groq"
    stt_model: str = "whisper-large-v3-turbo"
    tts_provider: str = "inworld"
    tts_voice: str = "lupita"
    inworld_api_key: Optional[str] = None

    def __post_init__(self):
        """Initialize LiveKit worker app with defaults."""
        # No ports exposed (connects to LiveKit server)
        if not self.ports:
            self.ports = {}

        # Set default labels
        if not self.labels:
            self.labels = {"service": "livekit-worker"}

        # No health check (worker process)
        if not self.healthcheck:
            self.healthcheck = None

    def get_container_env(self) -> Dict[str, str]:
        """Build container environment for LiveKit worker."""
        env = super().get_container_env()

        # LiveKit configuration
        if self.livekit_url:
            env["LIVEKIT_URL"] = self.livekit_url
        if self.livekit_api_key:
            env["LIVEKIT_API_KEY"] = self.livekit_api_key
        if self.livekit_api_secret:
            env["LIVEKIT_API_SECRET"] = self.livekit_api_secret

        # Inworld TTS API key
        if self.inworld_api_key:
            env["INWORLD_API_KEY"] = self.inworld_api_key

        # Worker configuration
        import json
        worker_config = {
            "voice_config": {
                "stt": f"{self.stt_provider}/{self.stt_model}",
                "tts": f"{self.tts_provider}/{self.tts_voice}",
            }
        }
        env["CONTEXTWISE_WORKER_CONFIG"] = json.dumps(worker_config)

        env["PYTHONUNBUFFERED"] = "1"

        return env


# ============================================================================
# LiveKitServerApp
# ============================================================================


@dataclass
class LiveKitServerApp(DockerApp):
    """LiveKit server for real-time voice communications.

    This app template provides a LiveKit server instance for hosting
    voice sessions. Optional component - can also use external LiveKit SaaS.
    """

    # Override defaults for LiveKit server
    image_name: str = "livekit/livekit-server"
    image_tag: str = "latest"
    command: str = "--config /etc/livekit.yaml"
    working_dir: str = "/"

    # LiveKit server-specific configuration
    livekit_api_key: Optional[str] = None
    livekit_api_secret: Optional[str] = None

    def __post_init__(self):
        """Initialize LiveKit server app with defaults."""
        # Set default ports
        if not self.ports:
            self.ports = {
                "7880/tcp": 7880,  # HTTP
                "7881/tcp": 7881,  # WebSocket
                "7882/tcp": 7882,  # TURN/UDP relay
            }

        # Set default named volumes for recordings/logs
        if not self.named_volumes:
            self.named_volumes = ["livekit-data"]

        # Set default volume mounts
        if not self.volume_mounts:
            self.volume_mounts = {
                "livekit-data": {
                    "bind": "/livekit",
                    "mode": "rw",
                }
            }

        # Set default labels
        if not self.labels:
            self.labels = {"service": "livekit-server"}

        # Set default healthcheck
        if not self.healthcheck:
            self.healthcheck = {
                "test": ["CMD", "curl", "-f", "http://localhost:7880/"],
                "interval": 10000000000,  # 10s
                "timeout": 5000000000,  # 5s
                "retries": 5,
                "start_period": 10000000000,  # 10s
            }

    def get_container_env(self) -> Dict[str, str]:
        """Build container environment for LiveKit server."""
        env = super().get_container_env()

        # LiveKit keys
        if self.livekit_api_key:
            env["LIVEKIT_API_KEY"] = self.livekit_api_key
        if self.livekit_api_secret:
            env["LIVEKIT_API_SECRET"] = self.livekit_api_secret

        return env
