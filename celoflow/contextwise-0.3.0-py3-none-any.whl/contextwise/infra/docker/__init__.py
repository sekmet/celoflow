"""Docker infrastructure backend for Contextwise v0.3.0.

This module provides Docker-specific implementations of infrastructure resources
and orchestration capabilities with support for:
- Agent and Platform APIs
- Voice/LiveKit integration
- Vector stores (Qdrant)
- Storage backends (Postgres, Redis)
- Channel integrations
- MCP servers
- CodeMode execution
- A2A protocol
"""

from .apps import (
    DockerApp,
    AgentApiApp,
    PlatformApiApp,
    PostgresApp,
    RedisApp,
    QdrantApp,
    LiveKitWorkerApp,
    LiveKitServerApp,
)
from .config import (
    DockerDeploymentConfig,
    PlatformApiConfig,
    NetworkConfig,
    ImageConfig,
    StorageConfig,
    VoiceConfig,
    MCPConfig,
    ChannelsConfig,
    CodeModeConfig,
    A2AConfig,
    VectorConfig,
    SchedulerConfig,
    HMLRMemoryConfig,
    DependencyServicesConfig,
)
from .resource_types import DockerNetwork, DockerImage, DockerVolume, DockerContainer
from .resources import DockerResources, DockerBackend

__all__ = [
    # App templates
    "DockerApp",
    "AgentApiApp",
    "PlatformApiApp",
    "PostgresApp",
    "RedisApp",
    "QdrantApp",
    "LiveKitWorkerApp",
    "LiveKitServerApp",
    # Configuration classes
    "DockerDeploymentConfig",
    "PlatformApiConfig",
    "NetworkConfig",
    "ImageConfig",
    "StorageConfig",
    "VoiceConfig",
    "MCPConfig",
    "ChannelsConfig",
    "CodeModeConfig",
    "A2AConfig",
    "VectorConfig",
    "SchedulerConfig",
    "HMLRMemoryConfig",
    "DependencyServicesConfig",
    # Resource types
    "DockerNetwork",
    "DockerImage",
    "DockerVolume",
    "DockerContainer",
    # Orchestration
    "DockerResources",
    "DockerBackend",
]
