"""Docker deployment configuration with validation.

This module provides configuration management for Docker deployments:
- DockerDeploymentConfig: Main deployment configuration
- Environment layering with precedence (explicit → secrets → env-file → defaults)
- Integration with SecretsConfig for runtime secret fetching
- Validation following v0.2 patterns
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from ...lib.secrets.config import SecretsConfig


@dataclass
class PlatformApiConfig:
    """Configuration for Platform REST API deployment."""

    enabled: bool = True
    port: int = 8001
    require_auth: bool = False
    auth_token: Optional[str] = None
    artifacts_dir: str = "./agent_api_artifacts"
    cors_allow_origins: str = "*"
    workers: int = 1  # Default to 1 worker (in-memory runtime constraint)

    def validate(self) -> List[str]:
        """Validate platform API configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        if self.port < 1 or self.port > 65535:
            errors.append(f"Invalid port: {self.port} (must be 1-65535)")

        if self.require_auth and not self.auth_token:
            errors.append("auth_token required when require_auth=True")

        if self.workers < 1:
            errors.append(f"Invalid workers: {self.workers} (must be >= 1)")

        if self.workers > 1:
            errors.append(
                "WARNING: workers > 1 not recommended (in-memory runtime splits state). "
                "Consider externalizing runtime state before scaling horizontally."
            )

        return errors

    def validate_or_raise(self) -> None:
        """Validate configuration and raise on errors."""
        errors = self.validate()
        if errors:
            raise ValueError(f"Invalid PlatformApiConfig:\n" + "\n".join(errors))


@dataclass
class NetworkConfig:
    """Configuration for Docker network."""

    name: str = "contextwise-network"
    driver: str = "bridge"
    internal: bool = False
    enable_ipv6: bool = False

    def validate(self) -> List[str]:
        """Validate network configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        if not self.name:
            errors.append("Network name cannot be empty")

        if self.driver not in ["bridge", "overlay", "host", "none", "macvlan"]:
            errors.append(
                f"Invalid network driver: {self.driver} "
                f"(must be one of: bridge, overlay, host, none, macvlan)"
            )

        return errors


@dataclass
class ImageConfig:
    """Configuration for Docker image."""

    name: str = "contextwise-agent"
    tag: str = "latest"
    build_from_source: bool = False
    build_context: Optional[Path] = None
    dockerfile: Optional[Path] = None
    pull_policy: str = "if-not-present"  # always, if-not-present, never

    def validate(self) -> List[str]:
        """Validate image configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        if not self.name:
            errors.append("Image name cannot be empty")

        if self.build_from_source and not self.build_context:
            errors.append("build_context required when build_from_source=True")

        if self.pull_policy not in ["always", "if-not-present", "never"]:
            errors.append(
                f"Invalid pull_policy: {self.pull_policy} "
                f"(must be one of: always, if-not-present, never)"
            )

        return errors


@dataclass
class StorageConfig:
    """Configuration for storage backend."""

    backend: str = "sqlite"
    path: Optional[Path] = None
    postgres_url: Optional[str] = None
    redis_url: Optional[str] = None

    def validate(self) -> List[str]:
        """Validate storage configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        valid_backends = ["sqlite", "postgres", "redis", "inmemory"]
        if self.backend not in valid_backends:
            errors.append(
                f"Invalid backend: {self.backend} (must be one of: {', '.join(valid_backends)})"
            )

        if self.backend == "postgres" and not self.postgres_url:
            errors.append("postgres_url required when backend=postgres")

        if self.backend == "redis" and not self.redis_url:
            errors.append("redis_url required when backend=redis")

        return errors


@dataclass
class VoiceConfig:
    """Configuration for LiveKit voice integration."""

    enabled: bool = False
    livekit_url: Optional[str] = None
    livekit_api_key: Optional[str] = None
    livekit_api_secret: Optional[str] = None
    worker_enabled: bool = False  # Whether to run LiveKit worker
    stt_provider: str = "groq"  # Speech-to-text provider
    stt_model: str = "whisper-large-v3-turbo"
    tts_provider: str = "inworld"  # Text-to-speech provider
    tts_voice: str = "lupita"
    inworld_api_key: Optional[str] = None

    def validate(self) -> List[str]:
        """Validate voice configuration."""
        errors = []

        if self.enabled:
            if not self.livekit_url:
                errors.append("livekit_url required when voice.enabled=True")
            if not self.livekit_api_key:
                errors.append("livekit_api_key required when voice.enabled=True")
            if not self.livekit_api_secret:
                errors.append("livekit_api_secret required when voice.enabled=True")

            if self.tts_provider == "inworld" and not self.inworld_api_key:
                errors.append("inworld_api_key required when tts_provider=inworld")

        return errors


@dataclass
class MCPConfig:
    """Configuration for MCP (Model Context Protocol) servers."""

    enabled: bool = False
    servers: List[Dict[str, Any]] = field(default_factory=list)

    def validate(self) -> List[str]:
        """Validate MCP configuration."""
        errors = []

        for idx, server in enumerate(self.servers):
            if "name" not in server:
                errors.append(f"MCP server {idx}: 'name' is required")
            if "transport" not in server:
                errors.append(f"MCP server {idx}: 'transport' is required")

            transport = server.get("transport")
            if transport == "stdio" and "command" not in server:
                errors.append(f"MCP server {idx}: 'command' required for stdio transport")
            elif transport in ["sse", "streamable-http"] and "url" not in server:
                errors.append(f"MCP server {idx}: 'url' required for {transport} transport")

        return errors


@dataclass
class ChannelsConfig:
    """Configuration for channel integrations."""

    whatsapp_enabled: bool = False
    whatsapp_access_token: Optional[str] = None
    whatsapp_phone_number_id: Optional[str] = None
    whatsapp_verify_token: Optional[str] = None
    whatsapp_voice_enabled: bool = False

    facebook_enabled: bool = False
    facebook_access_token: Optional[str] = None
    facebook_page_id: Optional[str] = None

    discord_enabled: bool = False
    discord_bot_token: Optional[str] = None
    discord_application_id: Optional[str] = None
    discord_public_key: Optional[str] = None

    slack_enabled: bool = False
    slack_bot_token: Optional[str] = None
    slack_signing_secret: Optional[str] = None

    def validate(self) -> List[str]:
        """Validate channels configuration."""
        errors = []

        if self.whatsapp_enabled:
            if not self.whatsapp_access_token:
                errors.append("whatsapp_access_token required when whatsapp_enabled=True")
            if not self.whatsapp_phone_number_id:
                errors.append("whatsapp_phone_number_id required when whatsapp_enabled=True")

        if self.facebook_enabled and not self.facebook_access_token:
            errors.append("facebook_access_token required when facebook_enabled=True")

        if self.discord_enabled and not self.discord_bot_token:
            errors.append("discord_bot_token required when discord_enabled=True")

        if self.slack_enabled and not self.slack_bot_token:
            errors.append("slack_bot_token required when slack_enabled=True")

        return errors


@dataclass
class CodeModeConfig:
    """Configuration for CodeMode safe execution."""

    enabled: bool = False
    sandbox_backend: str = "docker"  # docker, subprocess, llm-sandbox, codejail, none
    timeout: int = 60
    memory_limit: str = "512m"
    enable_network: bool = False

    def validate(self) -> List[str]:
        """Validate CodeMode configuration."""
        errors = []

        valid_backends = ["docker", "subprocess", "llm-sandbox", "codejail", "none"]
        if self.sandbox_backend not in valid_backends:
            errors.append(
                f"Invalid sandbox_backend: {self.sandbox_backend} "
                f"(must be one of: {', '.join(valid_backends)})"
            )

        if self.timeout < 1:
            errors.append("timeout must be positive")

        return errors


@dataclass
class A2AConfig:
    """Configuration for A2A (Agent-to-Agent) protocol."""

    enabled: bool = False
    url: Optional[str] = None
    auth_token: Optional[str] = None
    skills: List[Dict[str, Any]] = field(default_factory=list)

    def validate(self) -> List[str]:
        """Validate A2A configuration."""
        errors = []

        if self.enabled and not self.url:
            errors.append("url required when a2a.enabled=True")

        return errors


@dataclass
class VectorConfig:
    """Configuration for vector stores."""

    enabled: bool = False
    backend: str = "qdrant"  # qdrant, pgvector, inmemory
    qdrant_url: Optional[str] = None
    qdrant_api_key: Optional[str] = None
    qdrant_collection: str = "contextwise"
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    def validate(self) -> List[str]:
        """Validate vector configuration."""
        errors = []

        valid_backends = ["qdrant", "pgvector", "inmemory"]
        if self.backend not in valid_backends:
            errors.append(
                f"Invalid backend: {self.backend} "
                f"(must be one of: {', '.join(valid_backends)})"
            )

        if self.enabled and self.backend == "qdrant" and not self.qdrant_url:
            errors.append("qdrant_url required when backend=qdrant")

        return errors


@dataclass
class SchedulerConfig:
    """Configuration for task scheduler."""

    enabled: bool = False
    backend: str = "apscheduler"  # apscheduler
    job_store_url: Optional[str] = None  # For persistent job storage

    def validate(self) -> List[str]:
        """Validate scheduler configuration."""
        errors = []

        if self.backend not in ["apscheduler"]:
            errors.append(f"Invalid backend: {self.backend} (only apscheduler supported)")

        return errors


@dataclass
class HMLRMemoryConfig:
    """Configuration for HMLR advanced memory system."""

    enabled: bool = False
    chunk_size: int = 512
    overlap: int = 50
    compression_enabled: bool = True
    eviction_strategy: str = "lru"  # lru, lfu, adaptive

    def validate(self) -> List[str]:
        """Validate HMLR memory configuration."""
        errors = []

        if self.chunk_size < 1:
            errors.append("chunk_size must be positive")
        if self.overlap < 0:
            errors.append("overlap cannot be negative")
        if self.overlap >= self.chunk_size:
            errors.append("overlap must be less than chunk_size")

        valid_strategies = ["lru", "lfu", "adaptive"]
        if self.eviction_strategy not in valid_strategies:
            errors.append(
                f"Invalid eviction_strategy: {self.eviction_strategy} "
                f"(must be one of: {', '.join(valid_strategies)})"
            )

        return errors


@dataclass
class DependencyServicesConfig:
    """Configuration for optional dependency services."""

    postgres_enabled: bool = False
    postgres_db: str = "contextwise"
    postgres_user: str = "contextwise"
    postgres_password: str = "contextwise"
    postgres_port: int = 5432

    redis_enabled: bool = False
    redis_password: Optional[str] = None
    redis_port: int = 6379

    qdrant_enabled: bool = False
    qdrant_port: int = 6333
    qdrant_grpc_port: int = 6334

    livekit_enabled: bool = False
    livekit_port: int = 7880
    livekit_ws_port: int = 7881

    def validate(self) -> List[str]:
        """Validate dependency services configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        if self.postgres_port < 1 or self.postgres_port > 65535:
            errors.append(
                f"Invalid postgres_port: {self.postgres_port} (must be 1-65535)"
            )

        if self.redis_port < 1 or self.redis_port > 65535:
            errors.append(f"Invalid redis_port: {self.redis_port} (must be 1-65535)")

        if self.qdrant_port < 1 or self.qdrant_port > 65535:
            errors.append(f"Invalid qdrant_port: {self.qdrant_port} (must be 1-65535)")

        if self.livekit_port < 1 or self.livekit_port > 65535:
            errors.append(f"Invalid livekit_port: {self.livekit_port} (must be 1-65535)")

        return errors


@dataclass
class DockerDeploymentConfig:
    """Main Docker deployment configuration.

    Provides comprehensive configuration for deploying Contextwise agents with:
    - Environment layering (explicit → secrets → env-file → defaults)
    - Secrets backend integration
    - Platform API configuration
    - Network and image configuration
    - Storage backend configuration
    - Voice/LiveKit integration
    - MCP server support
    - Channel integrations (WhatsApp, Discord, Slack, etc.)
    - CodeMode safe execution
    - A2A protocol
    - Vector stores
    - Scheduler
    - HMLR advanced memory
    - Optional dependency services
    """

    # Core configuration
    project_name: str = "contextwise"
    environment: str = "development"

    # Component configurations
    platform_api: PlatformApiConfig = field(default_factory=PlatformApiConfig)
    network: NetworkConfig = field(default_factory=NetworkConfig)
    image: ImageConfig = field(default_factory=ImageConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    dependencies: DependencyServicesConfig = field(
        default_factory=DependencyServicesConfig
    )

    # Extended component configurations
    voice: VoiceConfig = field(default_factory=VoiceConfig)
    mcp: MCPConfig = field(default_factory=MCPConfig)
    channels: ChannelsConfig = field(default_factory=ChannelsConfig)
    codemode: CodeModeConfig = field(default_factory=CodeModeConfig)
    a2a: A2AConfig = field(default_factory=A2AConfig)
    vector: VectorConfig = field(default_factory=VectorConfig)
    scheduler: SchedulerConfig = field(default_factory=SchedulerConfig)
    hmlr_memory: HMLRMemoryConfig = field(default_factory=HMLRMemoryConfig)

    # Secrets configuration (runtime fetching)
    secrets: Optional[SecretsConfig] = None

    # Environment layering
    env_file: Optional[Path] = None
    explicit_env: Dict[str, str] = field(default_factory=dict)

    # Docker-specific options
    compose_file: Optional[Path] = None
    build_args: Dict[str, str] = field(default_factory=dict)
    labels: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        """Initialize configuration with defaults from environment."""
        # Load from environment if not explicitly set
        if not self.explicit_env:
            self.explicit_env = {}

        # Set default labels
        if not self.labels:
            self.labels = {
                "project": self.project_name,
                "environment": self.environment,
            }

    def get_layered_env(self) -> Dict[str, str]:
        """Build environment with proper precedence layering.

        Precedence (highest to lowest):
        1. explicit_env (highest)
        2. env_file values
        3. os.environ defaults (lowest)

        Note: Secrets are fetched at runtime by SecretsBackend, not included here.

        Returns:
            Merged environment dictionary
        """
        env = {}

        # Layer 1: OS environment (base defaults)
        env.update(os.environ)

        # Layer 2: env-file values
        if self.env_file and self.env_file.exists():
            env.update(self._load_env_file(self.env_file))

        # Layer 3: explicit overrides
        env.update(self.explicit_env)

        return env

    def _load_env_file(self, path: Path) -> Dict[str, str]:
        """Load environment variables from file.

        Args:
            path: Path to .env file

        Returns:
            Dictionary of environment variables
        """
        env = {}
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    if "=" in line:
                        key, value = line.split("=", 1)
                        env[key.strip()] = value.strip()
        return env

    def validate(self) -> List[str]:
        """Validate deployment configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        # Validate project name
        if not self.project_name:
            errors.append("project_name cannot be empty")

        # Validate component configurations
        errors.extend(self.platform_api.validate())
        errors.extend(self.network.validate())
        errors.extend(self.image.validate())
        errors.extend(self.storage.validate())
        errors.extend(self.dependencies.validate())

        # Validate extended components
        errors.extend(self.voice.validate())
        errors.extend(self.mcp.validate())
        errors.extend(self.channels.validate())
        errors.extend(self.codemode.validate())
        errors.extend(self.a2a.validate())
        errors.extend(self.vector.validate())
        errors.extend(self.scheduler.validate())
        errors.extend(self.hmlr_memory.validate())

        # Validate secrets configuration if present
        if self.secrets:
            secrets_errors = self.secrets.validate()
            errors.extend(secrets_errors)

        # Validate consistency
        if self.storage.backend == "postgres" and not self.dependencies.postgres_enabled:
            errors.append(
                "WARNING: storage.backend=postgres but dependencies.postgres_enabled=False. "
                "Either enable postgres service or provide external postgres_url."
            )

        if self.storage.backend == "redis" and not self.dependencies.redis_enabled:
            errors.append(
                "WARNING: storage.backend=redis but dependencies.redis_enabled=False. "
                "Either enable redis service or provide external redis_url."
            )

        if self.vector.enabled and self.vector.backend == "qdrant" and not self.dependencies.qdrant_enabled:
            errors.append(
                "WARNING: vector.backend=qdrant but dependencies.qdrant_enabled=False. "
                "Either enable qdrant service or provide external qdrant_url."
            )

        if self.voice.enabled and not self.dependencies.livekit_enabled:
            errors.append(
                "WARNING: voice.enabled=True but dependencies.livekit_enabled=False. "
                "Consider enabling LiveKit service or providing external LiveKit URL."
            )

        if self.channels.whatsapp_voice_enabled and not self.voice.enabled:
            errors.append(
                "WARNING: whatsapp_voice_enabled=True but voice.enabled=False. "
                "WhatsApp voice requires LiveKit voice configuration."
            )

        return errors

    def validate_or_raise(self) -> None:
        """Validate configuration and raise on errors.

        Raises:
            ValueError: If configuration is invalid
        """
        errors = self.validate()
        if errors:
            raise ValueError(
                f"Invalid DockerDeploymentConfig:\n" + "\n".join(f"  - {e}" for e in errors)
            )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> DockerDeploymentConfig:
        """Create configuration from dictionary.

        Args:
            data: Configuration dictionary

        Returns:
            DockerDeploymentConfig instance
        """
        # Extract nested configs
        data = data.copy()  # Don't modify original
        platform_api_data = data.pop("platform_api", {})
        network_data = data.pop("network", {})
        image_data = data.pop("image", {})
        storage_data = data.pop("storage", {})
        dependencies_data = data.pop("dependencies", {})
        voice_data = data.pop("voice", {})
        mcp_data = data.pop("mcp", {})
        channels_data = data.pop("channels", {})
        codemode_data = data.pop("codemode", {})
        a2a_data = data.pop("a2a", {})
        vector_data = data.pop("vector", {})
        scheduler_data = data.pop("scheduler", {})
        hmlr_memory_data = data.pop("hmlr_memory", {})
        secrets_data = data.pop("secrets", None)

        return cls(
            platform_api=PlatformApiConfig(**platform_api_data),
            network=NetworkConfig(**network_data),
            image=ImageConfig(**image_data),
            storage=StorageConfig(**storage_data),
            dependencies=DependencyServicesConfig(**dependencies_data),
            voice=VoiceConfig(**voice_data),
            mcp=MCPConfig(**mcp_data),
            channels=ChannelsConfig(**channels_data),
            codemode=CodeModeConfig(**codemode_data),
            a2a=A2AConfig(**a2a_data),
            vector=VectorConfig(**vector_data),
            scheduler=SchedulerConfig(**scheduler_data),
            hmlr_memory=HMLRMemoryConfig(**hmlr_memory_data),
            secrets=SecretsConfig.from_dict(secrets_data) if secrets_data else None,
            **data,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary.

        Returns:
            Configuration as dictionary
        """
        return {
            "project_name": self.project_name,
            "environment": self.environment,
            "platform_api": {
                "enabled": self.platform_api.enabled,
                "port": self.platform_api.port,
                "require_auth": self.platform_api.require_auth,
                "artifacts_dir": self.platform_api.artifacts_dir,
                "cors_allow_origins": self.platform_api.cors_allow_origins,
                "workers": self.platform_api.workers,
            },
            "network": {
                "name": self.network.name,
                "driver": self.network.driver,
                "internal": self.network.internal,
                "enable_ipv6": self.network.enable_ipv6,
            },
            "image": {
                "name": self.image.name,
                "tag": self.image.tag,
                "build_from_source": self.image.build_from_source,
                "pull_policy": self.image.pull_policy,
            },
            "storage": {
                "backend": self.storage.backend,
                "path": str(self.storage.path) if self.storage.path else None,
            },
            "dependencies": {
                "postgres_enabled": self.dependencies.postgres_enabled,
                "postgres_db": self.dependencies.postgres_db,
                "postgres_user": self.dependencies.postgres_user,
                "postgres_port": self.dependencies.postgres_port,
                "redis_enabled": self.dependencies.redis_enabled,
                "redis_port": self.dependencies.redis_port,
                "qdrant_enabled": self.dependencies.qdrant_enabled,
                "qdrant_port": self.dependencies.qdrant_port,
                "livekit_enabled": self.dependencies.livekit_enabled,
                "livekit_port": self.dependencies.livekit_port,
            },
            "voice": {
                "enabled": self.voice.enabled,
                "livekit_url": self.voice.livekit_url,
                "worker_enabled": self.voice.worker_enabled,
                "stt_provider": self.voice.stt_provider,
                "stt_model": self.voice.stt_model,
                "tts_provider": self.voice.tts_provider,
                "tts_voice": self.voice.tts_voice,
            },
            "mcp": {
                "enabled": self.mcp.enabled,
                "servers": self.mcp.servers,
            },
            "channels": {
                "whatsapp_enabled": self.channels.whatsapp_enabled,
                "whatsapp_voice_enabled": self.channels.whatsapp_voice_enabled,
                "facebook_enabled": self.channels.facebook_enabled,
                "discord_enabled": self.channels.discord_enabled,
                "slack_enabled": self.channels.slack_enabled,
            },
            "codemode": {
                "enabled": self.codemode.enabled,
                "sandbox_backend": self.codemode.sandbox_backend,
                "timeout": self.codemode.timeout,
                "memory_limit": self.codemode.memory_limit,
                "enable_network": self.codemode.enable_network,
            },
            "a2a": {
                "enabled": self.a2a.enabled,
                "url": self.a2a.url,
                "skills": self.a2a.skills,
            },
            "vector": {
                "enabled": self.vector.enabled,
                "backend": self.vector.backend,
                "qdrant_url": self.vector.qdrant_url,
                "qdrant_collection": self.vector.qdrant_collection,
                "embedding_model": self.vector.embedding_model,
            },
            "scheduler": {
                "enabled": self.scheduler.enabled,
                "backend": self.scheduler.backend,
                "job_store_url": self.scheduler.job_store_url,
            },
            "hmlr_memory": {
                "enabled": self.hmlr_memory.enabled,
                "chunk_size": self.hmlr_memory.chunk_size,
                "overlap": self.hmlr_memory.overlap,
                "compression_enabled": self.hmlr_memory.compression_enabled,
                "eviction_strategy": self.hmlr_memory.eviction_strategy,
            },
            "secrets": self.secrets.to_dict() if self.secrets else None,
        }
