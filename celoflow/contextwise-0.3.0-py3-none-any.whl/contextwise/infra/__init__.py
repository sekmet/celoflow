"""Infrastructure layer for Contextwise v0.3.0.

This module provides infrastructure abstractions for deploying agents:
- Docker deployment patterns
- Kubernetes deployment (future)
- Resource orchestration
- Configuration management
"""

from .base import InfraBackend, InfraResource, ResourceStatus

__all__ = [
    "InfraBackend",
    "InfraResource",
    "ResourceStatus",
]
