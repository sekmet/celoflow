"""CLI commands for Docker deployment management.

This module provides command-line interface for deploying and managing
Contextwise agents using Docker infrastructure.
"""

import argparse
import logging
import sys
from pathlib import Path
from typing import Optional

from .docker import (
    DockerBackend,
    DockerDeploymentConfig,
    DockerResources,
    PlatformApiApp,
    PostgresApp,
    RedisApp,
)

logger = logging.getLogger(__name__)


def setup_logging(verbose: bool = False):
    """Setup logging configuration.

    Args:
        verbose: Enable verbose logging
    """
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
    )


def cmd_deploy_up(args: argparse.Namespace) -> int:
    """Deploy Docker stack.

    Args:
        args: Command arguments

    Returns:
        Exit code (0 for success)
    """
    logger.info("Deploying Contextwise Docker stack...")

    try:
        # Load configuration
        config = DockerDeploymentConfig.from_dict({})  # TODO: Load from file

        # Create applications
        orchestrator = DockerResources()

        # Platform API
        platform_app = PlatformApiApp(
            name="contextwise-platform",
            network_name="contextwise-network",
        )
        orchestrator.add_resources(
            platform_app.to_resources(
                create_network=True,
                create_volumes=True,
                build_image=args.build,
            )
        )

        # Optional: PostgreSQL
        if args.with_postgres:
            logger.info("Adding PostgreSQL service...")
            postgres_app = PostgresApp(
                name="contextwise-postgres",
                network_name="contextwise-network",
            )
            orchestrator.add_resources(
                postgres_app.to_resources(create_network=False, create_volumes=True)
            )

        # Optional: Redis
        if args.with_redis:
            logger.info("Adding Redis service...")
            redis_app = RedisApp(
                name="contextwise-redis",
                network_name="contextwise-network",
            )
            orchestrator.add_resources(
                redis_app.to_resources(create_network=False, create_volumes=True)
            )

        # Deploy
        result = orchestrator.create_resources(
            dry_run=args.dry_run,
            auto_confirm=not args.interactive,
            force=args.force,
        )

        if result["status"] == "success":
            logger.info("\n✓ Deployment successful!")
            if not args.dry_run:
                logger.info("\nServices available at:")
                logger.info("  - Platform API: http://localhost:8001")
                logger.info("  - API Docs: http://localhost:8001/docs")
            return 0
        else:
            logger.error("\n✗ Deployment failed")
            return 1

    except Exception as e:
        logger.error(f"Deployment error: {e}", exc_info=args.verbose)
        return 1


def cmd_deploy_down(args: argparse.Namespace) -> int:
    """Stop and remove Docker stack.

    Args:
        args: Command arguments

    Returns:
        Exit code (0 for success)
    """
    logger.info("Stopping Contextwise Docker stack...")

    try:
        # TODO: Implement resource discovery and deletion
        logger.warning("Command not yet implemented")
        return 1

    except Exception as e:
        logger.error(f"Shutdown error: {e}", exc_info=args.verbose)
        return 1


def cmd_deploy_logs(args: argparse.Namespace) -> int:
    """View logs from Docker containers.

    Args:
        args: Command arguments

    Returns:
        Exit code (0 for success)
    """
    logger.info("Viewing Contextwise Docker logs...")

    try:
        # TODO: Implement log viewing
        logger.warning("Command not yet implemented")
        return 1

    except Exception as e:
        logger.error(f"Logs error: {e}", exc_info=args.verbose)
        return 1


def cmd_deploy_status(args: argparse.Namespace) -> int:
    """Check health status of deployed services.

    Args:
        args: Command arguments

    Returns:
        Exit code (0 for success)
    """
    logger.info("Checking Contextwise Docker stack status...")

    try:
        backend = DockerBackend()
        health = backend.get_health()

        if health["status"] == "healthy":
            logger.info("✓ Docker backend healthy")
            logger.info(f"  Version: {health['version']}")
            logger.info(
                f"  Containers: {health['containers']['running']}/{health['containers']['total']} running"
            )
            logger.info(f"  Images: {health['images']}")
            return 0
        else:
            logger.error(f"✗ Docker backend unhealthy: {health.get('error')}")
            return 1

    except Exception as e:
        logger.error(f"Status error: {e}", exc_info=args.verbose)
        return 1


def create_parser() -> argparse.ArgumentParser:
    """Create CLI argument parser.

    Returns:
        ArgumentParser instance
    """
    parser = argparse.ArgumentParser(
        prog="contextwise-deploy",
        description="Contextwise Docker Deployment CLI",
    )

    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # =========================================================================
    # deploy up
    # =========================================================================
    parser_up = subparsers.add_parser("up", help="Deploy Docker stack")
    parser_up.add_argument(
        "--agent-config",
        type=Path,
        help="Path to agent configuration file",
    )
    parser_up.add_argument(
        "--with-postgres",
        action="store_true",
        help="Deploy with PostgreSQL database",
    )
    parser_up.add_argument(
        "--with-redis",
        action="store_true",
        help="Deploy with Redis cache",
    )
    parser_up.add_argument(
        "--build",
        action="store_true",
        help="Build images from source",
    )
    parser_up.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate deployment without creating resources",
    )
    parser_up.add_argument(
        "--force",
        action="store_true",
        help="Force creation even if resources exist",
    )
    parser_up.add_argument(
        "--interactive",
        action="store_true",
        help="Prompt for confirmation before deploying",
    )
    parser_up.set_defaults(func=cmd_deploy_up)

    # =========================================================================
    # deploy down
    # =========================================================================
    parser_down = subparsers.add_parser("down", help="Stop and remove Docker stack")
    parser_down.add_argument(
        "--force",
        action="store_true",
        help="Force removal",
    )
    parser_down.set_defaults(func=cmd_deploy_down)

    # =========================================================================
    # deploy logs
    # =========================================================================
    parser_logs = subparsers.add_parser("logs", help="View container logs")
    parser_logs.add_argument(
        "--follow",
        "-f",
        action="store_true",
        help="Follow log output",
    )
    parser_logs.add_argument(
        "--tail",
        type=int,
        default=100,
        help="Number of lines to show from end",
    )
    parser_logs.set_defaults(func=cmd_deploy_logs)

    # =========================================================================
    # deploy status
    # =========================================================================
    parser_status = subparsers.add_parser("status", help="Check deployment status")
    parser_status.set_defaults(func=cmd_deploy_status)

    return parser


def main(argv: Optional[list[str]] = None) -> int:
    """Main CLI entry point.

    Args:
        argv: Command-line arguments (defaults to sys.argv[1:])

    Returns:
        Exit code (0 for success)
    """
    parser = create_parser()
    args = parser.parse_args(argv)

    setup_logging(args.verbose)

    if not hasattr(args, "func"):
        parser.print_help()
        return 1

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
