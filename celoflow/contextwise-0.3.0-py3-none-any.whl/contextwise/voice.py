"""Voice integration for Contextwise v0.3.0.

This module provides voice capabilities via LiveKit integration.
Voice configuration is separate from text configuration, allowing
different instructions and models for voice interactions.
"""

from __future__ import annotations

import logging
import os
import importlib.util
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Any, TYPE_CHECKING

from .lib.base import AgentPlugin
from .lib.context import AgentContext

if TYPE_CHECKING:
    from .agent import Agent

logger = logging.getLogger(__name__)


@dataclass
class VoiceConfig:
    """Voice configuration - SEPARATE from text instructions.

    Attributes:
        instructions: Voice-specific instructions (overrides text instructions for voice)
        model: Voice-specific model (can differ from text model)
        stt: Speech-to-text model (format: "provider/model")
        stt_language: STT language code
        tts: Text-to-speech provider/voice (format: "provider/voice")
        tts_voice: Optional TTS voice name override
        tts_model: Optional provider-specific TTS model (None = use provider default)
        tts_encoding: Audio encoding format (MP3, OGG_OPUS, LINEAR16)
        tts_speaking_rate: TTS speaking rate multiplier
        enable_vad: Enable voice activity detection
        enable_turn_detection: Enable turn detection
        enable_noise_cancellation: Enable noise cancellation
        livekit_url: LiveKit server URL
        livekit_api_key: LiveKit API key
        livekit_api_secret: LiveKit API secret

    Examples:
        >>> # Basic voice config
        >>> voice = VoiceConfig()

        >>> # Custom voice config
        >>> voice = VoiceConfig(
        ...     instructions="Be brief. Max 2 sentences.",
        ...     model="groq/llama-3.3-70b-versatile",
        ...     stt="groq/whisper-large-v3-turbo",
        ...     tts="inworld/lupita",
        ... )
    """

    # Voice-specific instructions (overrides text for voice)
    instructions: Optional[str] = None

    # Voice-specific model (can differ from text model)
    model: Optional[str] = None

    # STT configuration
    stt: str = "groq/whisper-large-v3-turbo"
    stt_language: str = "es"

    # TTS configuration
    tts: str = "inworld/lupita"
    tts_voice: Optional[str] = None
    tts_model: Optional[str] = None  # Provider-specific model (None = use provider default)
    tts_encoding: str = "MP3"
    tts_speaking_rate: float = 1.2
    tts_language: str = "en"
    # Advanced controls (primarily for ElevenLabs robustness in LiveKit 1.3.x)
    tts_use_stream_adapter: bool = True
    tts_inactivity_timeout: Optional[int] = None

    # Pipeline settings
    enable_vad: bool = True
    enable_turn_detection: bool = True
    enable_noise_cancellation: bool = True

    # LiveKit settings (loaded from env if not provided)
    livekit_url: Optional[str] = None
    livekit_api_key: Optional[str] = None
    livekit_api_secret: Optional[str] = None

    def __post_init__(self):
        """Load LiveKit credentials from environment if not provided."""
        if not self.livekit_url:
            self.livekit_url = os.getenv("LIVEKIT_URL", "")
        if not self.livekit_api_key:
            self.livekit_api_key = os.getenv("LIVEKIT_API_KEY", "")
        if not self.livekit_api_secret:
            self.livekit_api_secret = os.getenv("LIVEKIT_API_SECRET", "")

    def get_combined_instructions(self, workspace: Optional[Path] = None) -> str:
        """Get combined instructions from VoiceConfig + VOICE.md.

        Merges the base VoiceConfig.instructions with VOICE.md content
        from the workspace directory. VOICE.md frontmatter is stripped.

        Args:
            workspace: Workspace path to load VOICE.md from

        Returns:
            Combined instructions string
        """
        instructions = self.instructions or ""

        if workspace:
            voice_md_path = workspace / "VOICE.md"
            if voice_md_path.exists():
                try:
                    voice_md_content = voice_md_path.read_text(encoding="utf-8")
                    # Strip frontmatter if present
                    if voice_md_content.strip().startswith("---"):
                        parts = voice_md_content.strip().split("---", 2)
                        if len(parts) >= 3:
                            voice_md_content = parts[2].strip()

                    instructions = f"{instructions}\n\n{voice_md_content}".strip()
                    logger.info(f"Merged VOICE.md ({len(voice_md_content)} chars) with VoiceConfig.instructions")
                except Exception as e:
                    logger.warning(f"Failed to load VOICE.md from {voice_md_path}: {e}")

        return instructions

    def validate(self) -> bool:
        """Validate that required LiveKit credentials are present.

        Returns:
            True if valid, False otherwise
        """
        return bool(
            self.livekit_url
            and self.livekit_api_key
            and self.livekit_api_secret
        )

    def validate_or_raise(self) -> None:
        """Validate or raise detailed error.

        Raises:
            ValueError: If configuration is invalid
        """
        if not self.validate():
            missing = []
            if not self.livekit_url:
                missing.append("livekit_url or LIVEKIT_URL env var")
            if not self.livekit_api_key:
                missing.append("livekit_api_key or LIVEKIT_API_KEY env var")
            if not self.livekit_api_secret:
                missing.append("livekit_api_secret or LIVEKIT_API_SECRET env var")
            raise ValueError(
                f"Voice configuration incomplete. Missing: {', '.join(missing)}"
            )


@dataclass
class VoiceAgentPlugin(AgentPlugin[AgentContext]):
    """Plugin for adding voice capabilities to an agent.

    This plugin integrates LiveKit voice capabilities with the agent,
    using separate configuration from text interactions.
    """

    id: str = "voice-agent-plugin"
    name: str = "Voice Agent Plugin"
    version: str = "0.2.0"

    config: VoiceConfig = field(default_factory=VoiceConfig)

    def configure_agent(self, agent: "Agent") -> "Agent":
        """Configure the agent for voice (no modifications needed).

        Voice configuration is handled separately via VoiceConfig.

        Args:
            agent: Agent instance

        Returns:
            Unmodified agent
        """
        return agent

    async def start_voice_session(self, room_name: str) -> Any:
        """Start a voice session in a LiveKit room.

        Args:
            room_name: LiveKit room name

        Returns:
            LiveKit AgentSession

        Raises:
            ValueError: If configuration is invalid
            ImportError: If LiveKit SDK not installed
        """
        # Validate configuration
        self.config.validate_or_raise()

        if importlib.util.find_spec("livekit.agents") is None:
            raise ImportError(
                "LiveKit SDK not installed. Install with: pip install livekit-agents"
            )

        # TODO: Implement LiveKit session creation
        # This is a placeholder - actual implementation would create and return
        # a LiveKit session
        raise NotImplementedError(
            "Voice session creation not yet implemented. "
            "This is a placeholder for LiveKit integration."
        )

    def get_voice_instructions(self) -> Optional[str]:
        """Get voice-specific instructions.

        Returns:
            Voice instructions if configured, None otherwise
        """
        return self.config.instructions

    def get_voice_model(self) -> Optional[str]:
        """Get voice-specific model.

        Returns:
            Voice model if configured, None otherwise
        """
        return self.config.model


def parse_stt_config(stt: str) -> tuple[str, str]:
    """Parse STT configuration string.

    Args:
        stt: STT config in format "provider/model"

    Returns:
        Tuple of (provider, model)

    Examples:
        >>> parse_stt_config("groq/whisper-large-v3-turbo")
        ('groq', 'whisper-large-v3-turbo')
    """
    if "/" in stt:
        provider, model = stt.split("/", 1)
        return provider, model
    return "groq", stt  # Default to Groq


def parse_tts_config(tts: str) -> tuple[str, str]:
    """Parse TTS configuration string.

    Args:
        tts: TTS config in format "provider/model"

    Returns:
        Tuple of (provider, model)

    Examples:
        >>> parse_tts_config("inworld/lupita")
        ('inworld', 'lupita')
    """
    if "/" in tts:
        provider, model = tts.split("/", 1)
        return provider, model
    return "inworld", tts  # Default to Inworld
