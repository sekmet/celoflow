"""MCP (Model Context Protocol) integration for Contextwise v0.3.0.

This module provides integration with MCP servers for extending agent capabilities
with external tools and context.
"""

from __future__ import annotations

import asyncio
import logging
import subprocess
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Literal, List, Callable

logger = logging.getLogger(__name__)


@dataclass
class MCPTool:
    """Represents an MCP tool.
    
    Attributes:
        name: Tool name
        description: Tool description
        input_schema: JSON schema for tool inputs
        server: Reference to parent MCP server
    """
    name: str
    description: str
    input_schema: Dict[str, Any]
    server: "MCPServer" = field(repr=False)
    
    async def __call__(self, **kwargs) -> Any:
        """Call the tool with given arguments."""
        return await self.server.call_tool(self.name, kwargs)
    
    def as_function_tool(self) -> Callable:
        """Convert to a function tool for the agent."""
        async def tool_fn(**kwargs) -> str:
            result = await self(**kwargs)
            return str(result)
        
        tool_fn.__name__ = self.name
        tool_fn.__doc__ = self.description
        return tool_fn


@dataclass
class MCPServer:
    """MCP server configuration.

    Supports both stdio and HTTP-based MCP servers.

    Attributes:
        command: Command to run for stdio transport
        url: URL for SSE or streamable-HTTP transport
        transport: Transport type
        env: Environment variables for the server process
        timeout_seconds: Request timeout
        name: Server name for identification
        cache_tools_list: Whether to cache the tools list from the server

    Examples:
        >>> # Stdio MCP server
        >>> mcp = MCPServer(
        ...     command="npx",
        ...     args=["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
        ...     transport="stdio"
        ... )

        >>> # HTTP MCP server
        >>> mcp = MCPServer(
        ...     url="http://localhost:3000/mcp",
        ...     transport="sse"
        ... )
    """

    # Stdio transport
    command: Optional[str] = None
    args: List[str] = field(default_factory=list)

    # HTTP transport
    url: Optional[str] = None

    # Common settings
    transport: Literal["stdio", "sse", "streamable-http"] = "stdio"
    env: Optional[Dict[str, str]] = None
    timeout_seconds: int = 30
    cache_tools_list: bool = False
    name: str = "mcp-server"
    
    # Internal state (not serialized)
    _session: Any = field(default=None, repr=False, init=False)
    _process: Any = field(default=None, repr=False, init=False)
    _tools: Dict[str, MCPTool] = field(default_factory=dict, repr=False, init=False)
    _connected: bool = field(default=False, repr=False, init=False)

    async def connect(self) -> None:
        """Connect to the MCP server.

        Raises:
            ValueError: If configuration is invalid
            ImportError: If MCP SDK not installed
        """
        if self._connected:
            logger.debug(f"MCP server {self.name} already connected")
            return
        
        self.validate_or_raise()
        
        if self.transport == "stdio":
            await self._connect_stdio()
        elif self.transport == "sse":
            await self._connect_sse()
        elif self.transport == "streamable-http":
            await self._connect_streamable_http()
        else:
            raise ValueError(f"Unknown transport: {self.transport}")
        
        self._connected = True
        logger.info(f"Connected to MCP server: {self.name}")
    
    async def _connect_stdio(self) -> None:
        """Connect via stdio transport."""
        try:
            from agents.mcp import MCPServerStdio, MCPServerStdioParams
        except ImportError:
            logger.warning("openai-agents MCP support not available, using fallback")
            # Fallback: just mark as connected with no tools
            self._connected = True
            return

        # Create the SDK's MCPServerStdio instance
        # This will be used by the agent when building
        # MCPServerStdio expects a MCPServerStdioParams dict as first argument
        params: MCPServerStdioParams = {
            'command': self.command,
            'args': self.args,
        }
        # Add optional env if provided
        if self.env:
            params['env'] = self.env

        self._sdk_server = MCPServerStdio(params)
        logger.debug(f"Created MCPServerStdio for {self.name}")

        # Connect the SDK server to initialize it
        # This must be done within an async context
        await self._sdk_server.connect()
        logger.debug(f"Connected SDK MCPServerStdio for {self.name}")
    
    async def _connect_sse(self) -> None:
        """Connect via SSE transport."""
        try:
            from agents.mcp import MCPServerSse, MCPServerSseParams
        except ImportError:
            logger.warning("openai-agents MCP SSE support not available")
            return

        # MCPServerSse expects a MCPServerSseParams dict as first argument
        params: MCPServerSseParams = {
            'url': self.url,
        }

        self._sdk_server = MCPServerSse(params)
        logger.debug(f"Created MCPServerSse for {self.name}")
        # Note: SDK server connects lazily during agent execution - don't call connect() here
    
    async def _connect_streamable_http(self) -> None:
        """Connect via streamable HTTP transport."""
        try:
            from agents.mcp import MCPServerStreamableHttp, MCPServerStreamableHttpParams
        except ImportError:
            logger.warning("openai-agents MCP streamable-http support not available")
            return

        # MCPServerStreamableHttp expects a MCPServerStreamableHttpParams dict as first argument
        params: MCPServerStreamableHttpParams = {
            'url': self.url,
        }

        self._sdk_server = MCPServerStreamableHttp(params)
        logger.debug(f"Created MCPServerStreamableHttp for {self.name}")
        # Note: SDK server connects lazily during agent execution - don't call connect() here
    
    async def disconnect(self) -> None:
        """Disconnect from the MCP server."""
        if not self._connected:
            return
        
        # Clean up SDK server if available
        if hasattr(self, '_sdk_server') and self._sdk_server:
            try:
                await self._sdk_server.__aexit__(None, None, None)
            except Exception as e:
                logger.warning(f"Error disconnecting from MCP server: {e}")
        
        self._connected = False
        self._tools.clear()
        logger.info(f"Disconnected from MCP server: {self.name}")
    
    def get_sdk_server(self) -> Any:
        """Get the underlying SDK MCP server instance.
        
        Returns:
            The SDK MCP server instance for agent integration
        """
        if hasattr(self, '_sdk_server'):
            return self._sdk_server
        return None

    def get_or_create_sdk_server(self) -> Any:
        """Get or create the underlying SDK MCP server instance without connecting.
        
        This method creates the SDK server instance but does NOT connect it.
        The SDK Runner handles the connection lifecycle properly using async
        context managers during agent execution.
        
        Returns:
            The SDK MCP server instance for agent integration
        """
        if hasattr(self, '_sdk_server') and self._sdk_server:
            return self._sdk_server
        
        self.validate_or_raise()
        
        if self.transport == "stdio":
            return self._create_stdio_server()
        elif self.transport == "sse":
            return self._create_sse_server()
        elif self.transport == "streamable-http":
            return self._create_streamable_http_server()
        else:
            raise ValueError(f"Unknown transport: {self.transport}")
    
    def _create_stdio_server(self) -> Any:
        """Create stdio SDK server without connecting."""
        try:
            from agents.mcp import MCPServerStdio, MCPServerStdioParams
        except ImportError:
            logger.warning("openai-agents MCP support not available")
            return None

        params: MCPServerStdioParams = {
            'command': self.command,
            'args': self.args,
        }
        if self.env:
            params['env'] = self.env

        self._sdk_server = MCPServerStdio(params, cache_tools_list=self.cache_tools_list, name=self.name)
        logger.debug(f"Created MCPServerStdio for {self.name} (deferred connection)")
        return self._sdk_server
    
    def _create_sse_server(self) -> Any:
        """Create SSE SDK server without connecting."""
        try:
            from agents.mcp import MCPServerSse, MCPServerSseParams
        except ImportError:
            logger.warning("openai-agents MCP SSE support not available")
            return None

        params: MCPServerSseParams = {
            'url': self.url,
        }

        self._sdk_server = MCPServerSse(params, cache_tools_list=self.cache_tools_list, name=self.name)
        logger.debug(f"Created MCPServerSse for {self.name} (deferred connection)")
        return self._sdk_server
    
    def _create_streamable_http_server(self) -> Any:
        """Create streamable HTTP SDK server without connecting."""
        try:
            from agents.mcp import MCPServerStreamableHttp, MCPServerStreamableHttpParams
        except ImportError:
            logger.warning("openai-agents MCP streamable-http support not available")
            return None

        params: MCPServerStreamableHttpParams = {
            'url': self.url,
        }

        self._sdk_server = MCPServerStreamableHttp(params, cache_tools_list=self.cache_tools_list, name=self.name)
        logger.debug(f"Created MCPServerStreamableHttp for {self.name} (deferred connection)")
        return self._sdk_server

    async def get_tools(self) -> Dict[str, MCPTool]:
        """Get available tools from the MCP server.

        Returns:
            Dictionary of tool definitions
        """
        if not self._connected:
            await self.connect()
        
        return self._tools
    
    async def fetch_tools_from_sdk(self) -> Dict[str, MCPTool]:
        """Fetch tools from the connected SDK server and populate _tools.
        
        This method queries the SDK server's list_tools() and creates
        MCPTool wrappers that can be used by CodeModeProxy.
        
        Returns:
            Dictionary of tool name -> MCPTool
        """
        if not hasattr(self, '_sdk_server') or not self._sdk_server:
            logger.warning(f"No SDK server available for {self.name}")
            return self._tools
        
        try:
            # The SDK server must be connected first
            # list_tools() is available after connection
            sdk_tools = await self._sdk_server.list_tools()
            
            for sdk_tool in sdk_tools:
                # Create MCPTool wrapper
                tool = MCPTool(
                    name=sdk_tool.name,
                    description=sdk_tool.description or "",
                    input_schema=sdk_tool.inputSchema if hasattr(sdk_tool, 'inputSchema') else {},
                    server=self,
                )
                self._tools[sdk_tool.name] = tool
                logger.debug(f"Registered MCP tool: {sdk_tool.name}")
            
            logger.info(f"Fetched {len(self._tools)} tools from MCP server {self.name}")
            
        except Exception as e:
            logger.error(f"Failed to fetch tools from SDK server {self.name}: {e}")
        
        return self._tools

    async def call_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any]
    ) -> Any:
        """Call a tool on the MCP server.

        Args:
            tool_name: Name of the tool to call
            arguments: Tool arguments

        Returns:
            Tool result (typically a CallToolResult with content)
        """
        logger.debug(f"Tool call requested: {tool_name} with args: {arguments}")
        
        # Use SDK server's call_tool if available
        if hasattr(self, '_sdk_server') and self._sdk_server:
            try:
                result = await self._sdk_server.call_tool(tool_name, arguments)
                # Extract text content from CallToolResult
                if hasattr(result, 'content') and result.content:
                    # Content is a list of content items
                    text_parts = []
                    for item in result.content:
                        if hasattr(item, 'text'):
                            text_parts.append(item.text)
                        elif hasattr(item, 'data'):
                            text_parts.append(str(item.data))
                    return "\n".join(text_parts) if text_parts else str(result)
                return str(result)
            except Exception as e:
                logger.error(f"Error calling tool {tool_name}: {e}")
                raise
        
        raise RuntimeError(f"No SDK server available to call tool {tool_name}")

    def validate(self) -> bool:
        """Validate server configuration.

        Returns:
            True if valid, False otherwise
        """
        if self.transport == "stdio":
            return bool(self.command)
        else:
            return bool(self.url)

    def validate_or_raise(self) -> None:
        """Validate or raise detailed error.

        Raises:
            ValueError: If configuration is invalid
        """
        if not self.validate():
            if self.transport == "stdio":
                raise ValueError("command is required for stdio transport")
            else:
                raise ValueError(f"url is required for {self.transport} transport")
