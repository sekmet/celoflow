"""CodeMode for MCP orchestration in Contextwise v0.3.0.

CodeMode provides safe code execution for MCP operations,
with sandbox support for security.

NOTE: This module is now a compatibility facade. The authoritative implementation
is in `contextwise.lib.codemode`. New code should use:
- `from contextwise.lib.codemode import CodeModeCorePlugin, CodeModeConfig`

The classes in this module (CodeMode, CodeModeProxy, CodeModePlugin) are maintained
for backwards compatibility but route to lib/codemode internally where possible.
"""

from __future__ import annotations

import asyncio
import logging
import subprocess
import tempfile
import os
import sys
from dataclasses import dataclass, field
from typing import Literal, Optional, Dict, Any, List

logger = logging.getLogger(__name__)


@dataclass
class CodeMode:
    """CodeMode configuration for safe code execution.

    Attributes:
        sandbox_backend: Sandbox backend to use
        timeout: Execution timeout in seconds
        memory_limit: Memory limit for sandbox
        max_retries: Maximum retry attempts on failure
        enable_network: Whether to allow network access
        allowed_imports: List of allowed Python imports

    Examples:
        >>> # Basic CodeMode
        >>> codemode = CodeMode()

        >>> # Custom CodeMode
        >>> codemode = CodeMode(
        ...     sandbox_backend="docker",
        ...     timeout=120,
        ...     memory_limit="1g"
        ... )
    """

    sandbox_backend: Literal["docker", "llm-sandbox", "codejail", "subprocess", "none"] = "docker"
    timeout: int = 60
    memory_limit: str = "512m"
    max_retries: int = 3
    enable_network: bool = False
    allowed_imports: Optional[list[str]] = None

    def validate(self) -> bool:
        """Validate CodeMode configuration.

        Returns:
            True if valid, False otherwise
        """
        return (
            self.timeout > 0
            and self.max_retries >= 0
            and self.sandbox_backend in ["docker", "llm-sandbox", "codejail", "subprocess", "none"]
        )

    def validate_or_raise(self) -> None:
        """Validate or raise detailed error.

        Raises:
            ValueError: If configuration is invalid
        """
        if not self.validate():
            errors = []
            if self.timeout <= 0:
                errors.append("timeout must be positive")
            if self.max_retries < 0:
                errors.append("max_retries cannot be negative")
            if errors:
                raise ValueError(f"Invalid CodeMode configuration: {', '.join(errors)}")

    async def execute_code(
        self,
        code: str,
        context: Optional[Dict[str, Any]] = None,
        tools: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute code in sandbox.

        Args:
            code: Python code to execute
            context: Optional execution context variables
            tools: Optional tool functions available to the code (including _call_tool)

        Returns:
            Execution result with stdout, stderr, return value, and success flag
            
        Note:
            For safe backends (subprocess, docker, llm-sandbox, codejail), MCP tools
            are accessible via the _call_tool function which uses IPC to communicate
            with the parent process. The tools dict should contain a '_call_tool' key
            with an async callable that forwards tool calls to the MCP servers.
        """
        self.validate_or_raise()
        
        if self.sandbox_backend == "none":
            return await self._execute_unsafe(code, context, tools)
        elif self.sandbox_backend == "docker":
            return await self._execute_docker(code, context, tools)
        elif self.sandbox_backend == "subprocess":
            return await self._execute_subprocess(code, context, tools)
        elif self.sandbox_backend == "llm-sandbox":
            return await self._execute_llm_sandbox(code, context, tools)
        elif self.sandbox_backend == "codejail":
            return await self._execute_codejail(code, context, tools)
        else:
            # Fallback to subprocess for unknown backends
            logger.warning(f"Sandbox backend '{self.sandbox_backend}' unknown, using subprocess")
            return await self._execute_subprocess(code, context, tools)
    
    async def _execute_unsafe(
        self,
        code: str,
        context: Optional[Dict[str, Any]] = None,
        tools: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute code without sandboxing (UNSAFE - for development only).
        
        WARNING: This should never be used in production!
        """
        import io
        import contextlib
        
        stdout_capture = io.StringIO()
        stderr_capture = io.StringIO()
        
        # Prepare execution namespace
        namespace = {
            "__builtins__": __builtins__,
            **(context or {}),
            **(tools or {}),
        }
        
        result = None
        success = True
        error = None
        
        try:
            with contextlib.redirect_stdout(stdout_capture):
                with contextlib.redirect_stderr(stderr_capture):
                    # Execute the code
                    exec(compile(code, "<codemode>", "exec"), namespace)
                    
                    # Try to get result variable if defined
                    result = namespace.get("result", namespace.get("output", None))
        except Exception as e:
            success = False
            error = str(e)
            logger.error(f"Code execution error: {e}")
        
        return {
            "success": success,
            "stdout": stdout_capture.getvalue(),
            "stderr": stderr_capture.getvalue(),
            "result": result,
            "error": error,
        }
    
    async def _execute_subprocess(
        self,
        code: str,
        context: Optional[Dict[str, Any]] = None,
        tools: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute code in a subprocess with timeout and IPC tool bridge.
        
        This backend supports MCP tool calls via an IPC bridge. The subprocess
        communicates with the parent process using stdin/stdout JSON-RPC messages
        to invoke tools registered in the tools dict.
        """
        import json
        
        # Check if we have a tool caller function
        has_tools = tools and "_call_tool" in tools
        
        # Create the IPC bridge code that will be injected into the subprocess
        ipc_bridge_code = '''
import sys
import json
import asyncio

# IPC Tool Bridge for subprocess sandbox
# This allows sandboxed code to call MCP tools via stdin/stdout JSON-RPC

_tool_request_id = 0

def _call_tool(tool_name: str, args: dict) -> str:
    """Call an MCP tool via IPC bridge.
    
    This function sends a JSON-RPC request to the parent process via stdout
    and reads the response from stdin. The parent process forwards the call
    to the actual MCP tool and returns the result.
    
    Args:
        tool_name: Name of the MCP tool to call
        args: Dictionary of arguments to pass to the tool
        
    Returns:
        Tool result as a string
    """
    global _tool_request_id
    _tool_request_id += 1
    
    # Send request to parent via stdout
    request = {
        "jsonrpc": "2.0",
        "method": "call_tool",
        "params": {"tool_name": tool_name, "args": args},
        "id": _tool_request_id
    }
    print("__IPC_REQUEST__:" + json.dumps(request), flush=True)
    
    # Read response from stdin
    response_line = sys.stdin.readline().strip()
    if response_line.startswith("__IPC_RESPONSE__:"):
        response_json = response_line[len("__IPC_RESPONSE__:"):]
        response = json.loads(response_json)
        if "error" in response:
            raise RuntimeError(f"Tool call failed: {response['error']}")
        return response.get("result", "")
    else:
        raise RuntimeError(f"Invalid IPC response: {response_line}")

# Make _call_tool available globally
globals()["_call_tool"] = _call_tool
'''
        
        # Create a wrapper script
        wrapper = f'''
import json
import sys

# Context variables
context = {json.dumps(context or {})}
locals().update(context)

{ipc_bridge_code if has_tools else "# No IPC bridge (no tools registered)"}

# User code
{code}

# Try to capture result
result = locals().get("result", locals().get("output", None))
if result is not None:
    print("__RESULT__:" + (json.dumps(result) if isinstance(result, (dict, list)) else str(result)))
'''
        
        try:
            # Run in subprocess with timeout
            process = await asyncio.create_subprocess_exec(
                sys.executable, "-c", wrapper,
                stdin=asyncio.subprocess.PIPE if has_tools else None,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            
            if has_tools:
                # Handle IPC communication with the subprocess
                return await self._handle_subprocess_ipc(process, tools)
            else:
                # No tools, just wait for completion
                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(),
                        timeout=self.timeout
                    )
                except asyncio.TimeoutError:
                    process.kill()
                    return {
                        "success": False,
                        "stdout": "",
                        "stderr": "",
                        "result": None,
                        "error": f"Execution timed out after {self.timeout} seconds",
                    }
                
                return self._parse_subprocess_output(process.returncode, stdout, stderr)
            
        except Exception as e:
            return {
                "success": False,
                "stdout": "",
                "stderr": "",
                "result": None,
                "error": str(e),
            }
    
    async def _handle_subprocess_ipc(
        self,
        process: asyncio.subprocess.Process,
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Handle IPC communication with subprocess for tool calls.
        
        This method reads stdout from the subprocess, handles IPC requests
        for tool calls, and sends responses back via stdin.
        """
        import json
        
        stdout_lines = []
        stderr_data = b""
        
        try:
            async def read_stderr():
                nonlocal stderr_data
                if process.stderr:
                    stderr_data = await process.stderr.read()
            
            # Start reading stderr in background
            stderr_task = asyncio.create_task(read_stderr())
            
            # Read stdout line by line and handle IPC requests
            start_time = asyncio.get_event_loop().time()
            
            while True:
                # Check timeout
                elapsed = asyncio.get_event_loop().time() - start_time
                if elapsed > self.timeout:
                    process.kill()
                    stderr_task.cancel()
                    return {
                        "success": False,
                        "stdout": "\n".join(stdout_lines),
                        "stderr": stderr_data.decode("utf-8", errors="replace"),
                        "result": None,
                        "error": f"Execution timed out after {self.timeout} seconds",
                    }
                
                # Read a line from stdout with timeout
                try:
                    if process.stdout is None:
                        break
                    line_bytes = await asyncio.wait_for(
                        process.stdout.readline(),
                        timeout=min(1.0, self.timeout - elapsed)
                    )
                except asyncio.TimeoutError:
                    # Check if process is still running
                    if process.returncode is not None:
                        break
                    continue
                
                if not line_bytes:
                    # EOF reached
                    break
                
                line = line_bytes.decode("utf-8", errors="replace").rstrip()
                
                if line.startswith("__IPC_REQUEST__:"):
                    # Handle IPC request
                    request_json = line[len("__IPC_REQUEST__:"):]
                    response = await self._handle_ipc_request(request_json, tools)
                    
                    # Send response to subprocess via stdin
                    if process.stdin:
                        response_line = f"__IPC_RESPONSE__:{json.dumps(response)}\n"
                        process.stdin.write(response_line.encode("utf-8"))
                        await process.stdin.drain()
                else:
                    # Regular output line
                    stdout_lines.append(line)
            
            # Wait for process to complete
            await process.wait()
            await stderr_task
            
            stdout_str = "\n".join(stdout_lines)
            stderr_str = stderr_data.decode("utf-8", errors="replace")
            
            return self._parse_subprocess_output(process.returncode, stdout_str.encode(), stderr_data)
            
        except Exception as e:
            logger.error(f"IPC handling error: {e}")
            return {
                "success": False,
                "stdout": "\n".join(stdout_lines),
                "stderr": stderr_data.decode("utf-8", errors="replace") if stderr_data else "",
                "result": None,
                "error": str(e),
            }
    
    async def _handle_ipc_request(
        self,
        request_json: str,
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Handle a single IPC request from the subprocess."""
        import json
        
        try:
            request = json.loads(request_json)
            method = request.get("method")
            params = request.get("params", {})
            request_id = request.get("id")
            
            if method == "call_tool":
                tool_name = params.get("tool_name")
                args = params.get("args", {})
                
                # Get the tool caller function
                call_tool = tools.get("_call_tool")
                if call_tool is None:
                    return {
                        "jsonrpc": "2.0",
                        "error": "No tool caller available",
                        "id": request_id
                    }
                
                # Call the tool
                try:
                    result = await call_tool(tool_name, args)
                    return {
                        "jsonrpc": "2.0",
                        "result": result,
                        "id": request_id
                    }
                except Exception as e:
                    return {
                        "jsonrpc": "2.0",
                        "error": str(e),
                        "id": request_id
                    }
            else:
                return {
                    "jsonrpc": "2.0",
                    "error": f"Unknown method: {method}",
                    "id": request_id
                }
                
        except json.JSONDecodeError as e:
            return {
                "jsonrpc": "2.0",
                "error": f"Invalid JSON: {e}",
                "id": None
            }
    
    def _parse_subprocess_output(
        self,
        returncode: Optional[int],
        stdout: bytes,
        stderr: bytes,
    ) -> Dict[str, Any]:
        """Parse subprocess output and extract result."""
        stdout_str = stdout.decode("utf-8", errors="replace") if isinstance(stdout, bytes) else stdout
        stderr_str = stderr.decode("utf-8", errors="replace") if isinstance(stderr, bytes) else stderr
        
        # Extract result if present
        result = None
        if "__RESULT__:" in stdout_str:
            parts = stdout_str.split("__RESULT__:", 1)
            stdout_str = parts[0]
            result = parts[1].strip()
        
        return {
            "success": returncode == 0,
            "stdout": stdout_str,
            "stderr": stderr_str,
            "result": result,
            "error": stderr_str if returncode != 0 else None,
        }
    
    async def _execute_docker(
        self,
        code: str,
        context: Optional[Dict[str, Any]] = None,
        tools: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute code in Docker container.
        
        Note: Docker backend currently does not support IPC tool bridge.
        If tools are provided, falls back to subprocess backend which supports IPC.
        """
        import json
        
        # If tools are provided, fall back to subprocess which supports IPC
        if tools and "_call_tool" in tools:
            logger.info("Docker backend does not support IPC tool bridge, using subprocess")
            return await self._execute_subprocess(code, context, tools)
        
        # Check if Docker is available
        try:
            result = subprocess.run(
                ["docker", "--version"],
                capture_output=True,
                timeout=5,
            )
            if result.returncode != 0:
                logger.warning("Docker not available, falling back to subprocess")
                return await self._execute_subprocess(code, context, tools)
        except Exception:
            logger.warning("Docker not available, falling back to subprocess")
            return await self._execute_subprocess(code, context, tools)
        
        # Create temporary file with code
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".py",
            delete=False,
        ) as f:
            # Write wrapper code
            f.write(f'''
import json
import sys

context = {json.dumps(context or {})}
locals().update(context)

{code}

result = locals().get("result", locals().get("output", None))
if result is not None:
    print("__RESULT__:" + (json.dumps(result) if isinstance(result, (dict, list)) else str(result)))
''')
            temp_path = f.name
        
        try:
            # Run in Docker container
            docker_cmd = [
                "docker", "run",
                "--rm",
                f"--memory={self.memory_limit}",
                f"--cpus=1",
                "--network=none" if not self.enable_network else "",
                "-v", f"{temp_path}:/code.py:ro",
                "python:3.11-slim",
                "python", "/code.py",
            ]
            # Filter out empty strings
            docker_cmd = [c for c in docker_cmd if c]
            
            process = await asyncio.create_subprocess_exec(
                *docker_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.timeout + 10,  # Extra time for Docker overhead
                )
            except asyncio.TimeoutError:
                # Try to kill Docker container
                subprocess.run(["docker", "kill", "-s", "9"], capture_output=True)
                return {
                    "success": False,
                    "stdout": "",
                    "stderr": "",
                    "result": None,
                    "error": f"Execution timed out after {self.timeout} seconds",
                }
            
            stdout_str = stdout.decode("utf-8", errors="replace")
            stderr_str = stderr.decode("utf-8", errors="replace")
            
            # Extract result if present
            result = None
            if "__RESULT__:" in stdout_str:
                parts = stdout_str.split("__RESULT__:", 1)
                stdout_str = parts[0]
                result = parts[1].strip()
            
            return {
                "success": process.returncode == 0,
                "stdout": stdout_str,
                "stderr": stderr_str,
                "result": result,
                "error": stderr_str if process.returncode != 0 else None,
            }
            
        finally:
            # Clean up temp file
            try:
                os.unlink(temp_path)
            except Exception:
                pass
    
    async def _execute_llm_sandbox(
        self,
        code: str,
        context: Optional[Dict[str, Any]] = None,
        tools: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute code using llm-sandbox library.
        
        llm-sandbox provides lightweight sandboxing for LLM-generated code
        with resource limits and import restrictions.
        
        Note: llm-sandbox backend currently does not support IPC tool bridge.
        If tools are provided, falls back to subprocess backend which supports IPC.
        
        Falls back to subprocess if llm-sandbox is not installed.
        """
        # If tools are provided, fall back to subprocess which supports IPC
        if tools and "_call_tool" in tools:
            logger.info("llm-sandbox backend does not support IPC tool bridge, using subprocess")
            return await self._execute_subprocess(code, context, tools)
        
        try:
            from llm_sandbox import SandboxSession
        except ImportError:
            logger.warning("llm-sandbox not installed, falling back to subprocess. Install with: uv add llm-sandbox")
            return await self._execute_subprocess(code, context, tools)
        
        import json
        
        # Build the wrapper code
        wrapper = f'''
import json
import sys

# Context variables
context = {json.dumps(context or {})}
locals().update(context)

# User code
{code}

# Try to capture result
result = locals().get("result", locals().get("output", None))
if result is not None:
    print("__RESULT__:" + (json.dumps(result) if isinstance(result, (dict, list)) else str(result)))
'''
        
        try:
            # Create sandbox session with configuration
            session = SandboxSession(
                lang="python",
                keep_template=False,
                verbose=False,
            )
            
            # Open session and run code
            async with session:
                output = await session.run(wrapper, libraries=self.allowed_imports or [])
            
            stdout_str = output.stdout if hasattr(output, 'stdout') else str(output)
            stderr_str = output.stderr if hasattr(output, 'stderr') else ""
            
            # Extract result if present
            result = None
            if "__RESULT__:" in stdout_str:
                parts = stdout_str.split("__RESULT__:", 1)
                stdout_str = parts[0]
                result = parts[1].strip()
            
            return {
                "success": True,
                "stdout": stdout_str,
                "stderr": stderr_str,
                "result": result,
                "error": None,
            }
            
        except Exception as e:
            logger.error(f"llm-sandbox execution error: {e}")
            return {
                "success": False,
                "stdout": "",
                "stderr": "",
                "result": None,
                "error": str(e),
            }
    
    async def _execute_codejail(
        self,
        code: str,
        context: Optional[Dict[str, Any]] = None,
        tools: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute code using codejail library.
        
        codejail provides secure Python code execution with resource limits,
        originally developed for educational platforms like edX.
        
        Note: codejail backend currently does not support IPC tool bridge.
        If tools are provided, falls back to subprocess backend which supports IPC.
        
        Falls back to subprocess if codejail is not installed.
        """
        # If tools are provided, fall back to subprocess which supports IPC
        if tools and "_call_tool" in tools:
            logger.info("codejail backend does not support IPC tool bridge, using subprocess")
            return await self._execute_subprocess(code, context, tools)
        
        try:
            import codejail.jail_code as jail
        except ImportError:
            logger.warning("codejail not installed, falling back to subprocess. Install with: uv add codejail")
            return await self._execute_subprocess(code, context, tools)
        
        import json
        
        # Build the wrapper code
        wrapper = f'''
import json
import sys

# Context variables
context = {json.dumps(context or {})}
locals().update(context)

# User code
{code}

# Try to capture result
result = locals().get("result", locals().get("output", None))
if result is not None:
    print("__RESULT__:" + (json.dumps(result) if isinstance(result, (dict, list)) else str(result)))
'''
        
        try:
            # Configure codejail limits
            # Note: codejail requires system-level configuration (AppArmor/SELinux)
            # This is a simplified implementation that uses the basic jail_code API
            
            # Run code in jail with timeout
            result_obj = jail.jail_code(
                "python",
                code=wrapper,
                stdin=None,
                files=None,
                extra_files=None,
                argv=None,
                slug=None,
            )
            
            stdout_str = result_obj.stdout.decode("utf-8", errors="replace") if result_obj.stdout else ""
            stderr_str = result_obj.stderr.decode("utf-8", errors="replace") if result_obj.stderr else ""
            
            # Extract result if present
            result = None
            if "__RESULT__:" in stdout_str:
                parts = stdout_str.split("__RESULT__:", 1)
                stdout_str = parts[0]
                result = parts[1].strip()
            
            success = result_obj.status == 0 if hasattr(result_obj, 'status') else True
            
            return {
                "success": success,
                "stdout": stdout_str,
                "stderr": stderr_str,
                "result": result,
                "error": stderr_str if not success else None,
            }
            
        except Exception as e:
            logger.error(f"codejail execution error: {e}")
            return {
                "success": False,
                "stdout": "",
                "stderr": "",
                "result": None,
                "error": str(e),
            }
    
    def create_sandbox(self) -> "CodeSandbox":
        """Create a sandbox instance.

        Returns:
            CodeSandbox instance for managing execution context
        """
        return CodeSandbox(self)


@dataclass
class CodeSandbox:
    """Sandbox environment for code execution.
    
    Manages the execution context and provides methods for running code safely.
    """
    
    config: CodeMode
    _context: Dict[str, Any] = field(default_factory=dict)
    _tools: Dict[str, Any] = field(default_factory=dict)
    
    def set_context(self, key: str, value: Any) -> None:
        """Set a context variable available to code."""
        self._context[key] = value
    
    def register_tool(self, name: str, func: Any) -> None:
        """Register a tool function available to code."""
        self._tools[name] = func
    
    async def run(self, code: str) -> Dict[str, Any]:
        """Execute code in the sandbox.
        
        Args:
            code: Python code to execute
            
        Returns:
            Execution result
        """
        return await self.config.execute_code(
            code,
            context=self._context,
            tools=self._tools,
        )
    
    def clear(self) -> None:
        """Clear all context and tools."""
        self._context.clear()
        self._tools.clear()


@dataclass
class CodeModeProxy:
    """Proxy for MCP tools to be used within CodeMode sandbox.
    
    This class wraps MCP tools and makes them available as Python functions
    that can be called from within the sandbox execution context.
    """
    
    _tools: Dict[str, Any] = field(default_factory=dict)
    _tool_schemas: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    def register_mcp_tool(
        self,
        name: str,
        description: str,
        input_schema: Dict[str, Any],
        call_fn: Any,
    ) -> None:
        """Register an MCP tool for use in CodeMode.
        
        Args:
            name: Tool name
            description: Tool description
            input_schema: JSON schema for tool inputs
            call_fn: Async function to call the tool
        """
        self._tools[name] = call_fn
        self._tool_schemas[name] = {
            "name": name,
            "description": description,
            "input_schema": input_schema,
        }
    
    def get_tool_definitions(self) -> str:
        """Generate Python type definitions for all registered tools.
        
        Returns:
            Python code string with type definitions and docstrings
        """
        lines = [
            "# Auto-generated tool definitions for CodeMode",
            "# These functions are available for calling MCP tools",
            "",
        ]
        
        for name, schema in self._tool_schemas.items():
            description = schema.get("description", "")
            input_schema = schema.get("input_schema", {})
            properties = input_schema.get("properties", {})
            required = input_schema.get("required", [])
            
            # Build function signature
            params = []
            for prop_name, prop_schema in properties.items():
                prop_type = self._json_type_to_python(prop_schema.get("type", "any"))
                if prop_name in required:
                    params.append(f"{prop_name}: {prop_type}")
                else:
                    params.append(f"{prop_name}: {prop_type} = None")
            
            param_str = ", ".join(params) if params else ""
            
            lines.append(f"async def {name}({param_str}) -> str:")
            lines.append(f'    """{description}"""')
            lines.append(f"    return await _call_tool('{name}', locals())")
            lines.append("")
        
        return "\n".join(lines)
    
    def _json_type_to_python(self, json_type: str) -> str:
        """Convert JSON schema type to Python type hint."""
        type_map = {
            "string": "str",
            "integer": "int",
            "number": "float",
            "boolean": "bool",
            "array": "list",
            "object": "dict",
        }
        return type_map.get(json_type, "Any")
    
    def get_tools_dict(self) -> Dict[str, Any]:
        """Get dictionary of tool callables for sandbox injection."""
        return dict(self._tools)
    
    def get_enhanced_prompt(self, base_instructions: str) -> str:
        """Generate enhanced system prompt with tool definitions.
        
        Args:
            base_instructions: Original agent instructions
            
        Returns:
            Enhanced prompt with CodeMode instructions and tool definitions
        """
        tool_defs = self.get_tool_definitions()
        
        return f"""{base_instructions}

## CodeMode Execution

You have access to MCP tools through Python code execution. When you need to perform 
complex operations involving multiple tool calls, you can generate Python code that 
will be executed in a secure sandbox.

### Available Tools

The following tools are available as async Python functions:

```python
{tool_defs}
```

### Code Generation Guidelines

1. Write clean, executable Python code
2. Use the provided tool functions to interact with MCP servers
3. Store your final result in a variable named `result`
4. Handle errors gracefully with try/except blocks
5. Only use allowed imports: {', '.join(['math', 'json', 'datetime', 'collections', 'itertools', 'functools', 're'])}

### Example

```python
# Example: Read a file and process its contents
content = await read_file(path="/tmp/data.txt")
result = {{"status": "success", "content": content}}
```
"""


class CodeModePlugin:
    """Plugin to integrate CodeMode with Agent execution.
    
    This plugin:
    1. Wraps MCP tools into a CodeModeProxy
    2. Adds a 'execute_code' tool to the agent
    3. Handles code execution requests from the LLM
    
    Example:
        >>> from contextwise import Agent
        >>> from contextwise.codemode import CodeMode, CodeModePlugin
        >>> 
        >>> codemode = CodeMode(sandbox_backend="docker")
        >>> plugin = CodeModePlugin(codemode)
        >>> 
        >>> agent = Agent(
        ...     model="gpt-4o-mini",
        ...     plugins=[plugin],
        ... )
    """
    
    # Plugin identity for PluginManager (AgentPlugin interface)
    id: str = "codemode"
    name: str = "CodeMode Plugin"
    version: str = "0.2.0"
    
    def __init__(self, config: CodeMode):
        """Initialize CodeModePlugin.
        
        Args:
            config: CodeMode configuration
        """
        self.config = config
        self.proxy = CodeModeProxy()
        self.sandbox = config.create_sandbox()
    
    def dependencies(self) -> List[str]:
        """Return plugin ids that must be loaded before this plugin."""
        return []
    
    def configure_agent(self, agent: Any) -> Any:
        """Configure agent with CodeMode tools.
        
        Args:
            agent: SDK Agent instance
            
        Returns:
            Agent with CodeMode tools added
        """
        # Add execute_code tool to agent
        tools = list(agent.tools) if agent.tools else []
        tools.extend(self.get_tools())
        
        # Clone agent with new tools
        return agent.clone(tools=tools)
    
    def configure_run_config(self, context: Any, base_config: Any) -> Any:
        """Optionally extend the run configuration."""
        return base_config
    
    def on_before_run(self, context: Any, input: str) -> None:
        """Hook invoked before each run starts."""
        pass
    
    def on_after_run(self, context: Any, result: Any) -> None:
        """Hook invoked after each completed run."""
        pass
    
    def get_tools(self) -> List[Any]:
        """Get tools provided by this plugin.
        
        Returns:
            List containing the execute_code tool
        """
        from agents import function_tool
        
        @function_tool
        async def execute_code(code: str) -> str:
            """Execute Python code in a secure sandbox.
            
            Use this tool when you need to:
            - Perform complex calculations
            - Process data with multiple steps
            - Chain multiple MCP tool calls together
            - Run algorithms or data transformations
            
            Args:
                code: Python code to execute. Must be valid Python.
                      Store your result in a variable named 'result'.
            
            Returns:
                JSON string with execution result containing:
                - success: boolean indicating if execution succeeded
                - result: the value of the 'result' variable if defined
                - stdout: any printed output
                - error: error message if execution failed
            """
            import json
            
            # Inject tool proxy into sandbox
            self.sandbox._tools["_call_tool"] = self._create_tool_caller()
            
            # Execute with retries
            last_error = None
            for attempt in range(self.config.max_retries + 1):
                result = await self.sandbox.run(code)
                
                if result["success"]:
                    return json.dumps({
                        "success": True,
                        "result": result["result"],
                        "stdout": result["stdout"],
                    })
                
                last_error = result["error"]
                logger.warning(f"Code execution attempt {attempt + 1} failed: {last_error}")
            
            return json.dumps({
                "success": False,
                "error": last_error,
                "stdout": result.get("stdout", ""),
            })
        
        return [execute_code]
    
    def _create_tool_caller(self) -> Any:
        """Create a tool caller function for sandbox injection."""
        proxy = self.proxy
        
        async def _call_tool(tool_name: str, args: Dict[str, Any]) -> str:
            """Call an MCP tool from within the sandbox."""
            if tool_name not in proxy._tools:
                raise ValueError(f"Unknown tool: {tool_name}")
            
            # Remove 'tool_name' from args if present
            args = {k: v for k, v in args.items() if k != "tool_name" and v is not None}
            
            try:
                result = await proxy._tools[tool_name](**args)
                return str(result)
            except Exception as e:
                return f"Error calling {tool_name}: {e}"
        
        return _call_tool
    
    def register_mcp_tools(self, mcp_servers: List[Any]) -> None:
        """Register MCP tools from servers.
        
        This method extracts tool definitions from MCPServer instances and
        registers them with the CodeModeProxy so they can be called from
        within the sandbox execution context.
        
        Args:
            mcp_servers: List of MCPServer instances
        """
        for server in mcp_servers:
            # Get tools from MCPServer._tools dict (MCPTool instances)
            if hasattr(server, '_tools') and server._tools:
                for name, tool in server._tools.items():
                    self.proxy.register_mcp_tool(
                        name=name,
                        description=tool.description if hasattr(tool, 'description') else "",
                        input_schema=tool.input_schema if hasattr(tool, 'input_schema') else {},
                        call_fn=tool,
                    )
            
            # Also try to get tools from SDK server if available
            # This handles cases where tools are discovered at runtime
            if hasattr(server, '_sdk_server') and server._sdk_server:
                try:
                    sdk_server = server._sdk_server
                    # The SDK server may have tools available after connection
                    if hasattr(sdk_server, 'list_tools'):
                        # This is async, so we can't call it here directly
                        # Tools will be registered when the server connects
                        pass
                except Exception as e:
                    logger.debug(f"Could not get tools from SDK server: {e}")
    
    def get_enhanced_instructions(self, base_instructions: str) -> str:
        """Get enhanced instructions with CodeMode capabilities.
        
        Args:
            base_instructions: Original agent instructions
            
        Returns:
            Enhanced instructions with CodeMode documentation
        """
        return self.proxy.get_enhanced_prompt(base_instructions)
