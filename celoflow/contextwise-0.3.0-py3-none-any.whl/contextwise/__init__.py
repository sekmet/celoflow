"""Contextwise v0.3.0 - A unified framework for AI agents.

This package provides:
- Unified Agent class with simple API
- Multi-channel support (WhatsApp, API, Voice)
- Voice integration with LiveKit
- Memory and storage backends
- MCP integration
- Plugin system for extensions

Quick start:
    >>> from contextwise import Agent
    >>> agent = Agent("gpt-4o-mini", "You are helpful")
    >>> response = agent.chat("Hello!")

With features:
    >>> from contextwise import Agent, WhatsAppChannel, VoiceConfig
    >>> agent = Agent(
    ...     model="gpt-4o-mini",
    ...     instructions="You are helpful",
    ...     channels=[WhatsAppChannel()],
    ...     voice=VoiceConfig(),
    ... )
"""

# New v0.3.0 unified API
from .agent import Agent
from .models import (
    Model,
    OpenAIModel,
    GroqModel,
    AnthropicModel,
    GeminiModel,
    OllamaModel,
    CloudflareModel,
    AzureForgeModel,
    CerebrasModel,
    parse_provider_model,
)
from .channels import (
    ChannelPlugin,
    APIChannel,
    WhatsAppChannel,
    TelegramChannel,
    VoiceChannel,
    DiscordChannel,
    SlackChannel,
    InstagramChannel,
    FacebookChannel,
    TikTokChannel,
)
from .server import (
    serve,
    create_app,
    create_router,
    create_v1_app,
    register_agent,
    get_agent,
    conversation_store,
)
from .voice import (
    VoiceConfig,
    VoiceAgentPlugin,
    parse_stt_config,
    parse_tts_config,
)
from .mcp import MCPServer, MCPTool
from .codemode import CodeMode, CodeSandbox, CodeModeProxy, CodeModePlugin
from .media import Image, Audio, Video
from .team import Team
from .a2a import (
    A2AServer,
    A2AClient,
    A2ASkill,
    A2AAgentCard,
    A2ATask,
    A2AMessage,
)

# Error handling
from .errors import ContextwiseExceptionCode, DEFAULT_ISE_CODE

# Core library exports
from .lib import (
    # Core plugin system
    AgentPlugin,
    PluginManager,
    PluginMetadata,
    AgentPluginManager,
    # Context
    AgentContext,
)

from .lib.session import (
    # Session management
    InMemorySession,
    InMemorySessionBackendPlugin,
)

from .lib.whatsapp import (
    # Notification plugins
    NotificationPlugin,
    WhatsAppNotificationPlugin,
    WhatsAppAPIPlugin,
    # Security utilities
    is_development_mode,
    get_app_secret,
    validate_webhook_signature,
    # Router utilities
    create_whatsapp_router,
    create_agent_message_handler,
    # API utilities
    get_access_token,
    get_phone_number_id,
    typing_indicator,
    typing_indicator_async,
    get_media,
    get_media_async,
    upload_media,
    upload_media_async,
    send_text_message,
    send_text_message_async,
    send_image_message,
    send_image_message_async,
)

# Storage backends
from .lib.storage import (
    Storage,
    StorageSession,
    InMemoryStorage,
    SqliteStorage,
    JsonStorage,
    PostgresStorage,
    RedisStorage,
    MongoDbStorage,
    MySQLStorage,
    YamlStorage,
    StoragePlugin,
    StorageBackendPlugin,
)

# Embedder backends
from .lib.embedder import (
    Embedder,
    OpenAIEmbedder,
    FastEmbedEmbedder,
)

# Vector database
from .lib.vector import (
    Document,
    Distance,
    SearchType,
    VectorDb,
    Qdrant,
    PgVector,
)

# Model abstractions (lib models - different from top-level models.py)
from .lib.models import (
    Model as LibModel,
    ModelMessage,
    ModelResponse,
    OpenAIModel as LibOpenAIModel,
    GroqModel as LibGroqModel,
    GeminiModel as LibGeminiModel,
    OllamaModel as LibOllamaModel,
    CloudflareModel as LibCloudflareModel,
    AzureForgeModel as LibAzureForgeModel,
    CerebrasModel as LibCerebrasModel,
)

# Acontext integration
from .lib.acontext import (
    AcontextClientPlugin,
    AcontextSessionPlugin,
    AcontextSpacePlugin,
    AcontextDiskPlugin,
    AcontextObservePlugin,
    AcontextConfig,
    AcontextAgentContext,
    AcontextPluginBundle,
    AcontextPlugin,
)

# HMLR Memory (deprecated - use AgentFS Memory instead)
from .lib.hmlrmem import (
    HMLRMemoryPlugin,
    HMLRMemoryConfig,
    HMLRMemoryFacade,
)

# AgentFS Memory (recommended replacement for HMLR)
from .lib.agentfs_memory import (
    AgentFSMemoryPlugin,
    AgentFSMemoryConfig,
    AgentFSClient,
    AgentFSEnvironment,
)

# AG-UI Protocol
from .lib.agui import (
    create_agui_router,
    AGUIRequest,
    AGUIStatusResponse,
    EventType,
    BaseEvent,
    EventBuffer,
)

# Observability (Opik integration)
"""
from .lib.observability import (
    OpikConfig,
    OpikObservabilityPlugin,
    initialize_opik,
    create_trace,
    create_span,
    OpikTraceHandle,
    OpikSpanHandle,
    OpikTestContext,
    TraceAssertion,
    assert_trace_count,
    assert_span_count,
    assert_no_errors,
    mock_opik_backend,
)
"""

# TEE (Trusted Execution Environment)
from .lib.tee import (
    TEEConfig,
    TEEManager,
    TEEIdentity,
    PluginPermission,
    PluginManifest,
    TEEAwarePlugin,
    TEEAuthPlugin,
    TEEMemoryPlugin,
    AuditEvent,
    AuditLog,
    EncryptedStorage,
    TEEFilesystem,
    TEENetworkRestrictor,
    TEESessionManager,
    validate_tee_configuration,
    detect_tee_environment,
)

__version__ = "0.4.0"

# Primary exports for v0.3.0 (simplified API)
__all__ = [
    # Core unified API
    "Agent",
    "Team",
    # Models
    "Model",
    "OpenAIModel",
    "GroqModel",
    "AnthropicModel",
    "GeminiModel",
    "OllamaModel",
    "CloudflareModel",
    "AzureForgeModel",
    "CerebrasModel",
    "parse_provider_model",
    # Channels
    "ChannelPlugin",
    "APIChannel",
    "WhatsAppChannel",
    "TelegramChannel",
    "VoiceChannel",
    "DiscordChannel",
    "SlackChannel",
    "InstagramChannel",
    "FacebookChannel",
    "TikTokChannel",
    # Voice
    "VoiceConfig",
    "VoiceAgentPlugin",
    "parse_stt_config",
    "parse_tts_config",
    # MCP & CodeMode
    "MCPServer",
    "CodeMode",
    "CodeSandbox",
    "CodeModeProxy",
    "CodeModePlugin",
    # Media
    "Image",
    "Audio",
    "Video",
    # Server
    "serve",
    "create_app",
    "create_router",
    # Plugin system
    "AgentPlugin",
    "PluginManager",
    "PluginMetadata",
    "AgentPluginManager",
    "AgentContext",
    # Session
    "InMemorySession",
    "InMemorySessionBackendPlugin",
    # WhatsApp
    "NotificationPlugin",
    "WhatsAppNotificationPlugin",
    "WhatsAppAPIPlugin",
    "is_development_mode",
    "get_app_secret",
    "validate_webhook_signature",
    "create_whatsapp_router",
    "create_agent_message_handler",
    "get_access_token",
    "get_phone_number_id",
    "typing_indicator",
    "typing_indicator_async",
    "get_media",
    "get_media_async",
    "upload_media",
    "upload_media_async",
    "send_text_message",
    "send_text_message_async",
    "send_image_message",
    "send_image_message_async",
    # Storage
    "Storage",
    "StorageSession",
    "InMemoryStorage",
    "SqliteStorage",
    "JsonStorage",
    "PostgresStorage",
    "RedisStorage",
    "MongoDbStorage",
    "MySQLStorage",
    "YamlStorage",
    "StoragePlugin",
    "StorageBackendPlugin",
    # Embedder
    "Embedder",
    "OpenAIEmbedder",
    "FastEmbedEmbedder",
    # Vector
    "Document",
    "Distance",
    "SearchType",
    "VectorDb",
    "Qdrant",
    "PgVector",
    # Lib Models
    "LibModel",
    "ModelMessage",
    "ModelResponse",
    "LibOpenAIModel",
    "LibGroqModel",
    "LibGeminiModel",
    "LibOllamaModel",
    "LibCloudflareModel",
    "LibAzureForgeModel",
    "LibCerebrasModel",
    # Acontext
    "AcontextPlugin",
    "AcontextClientPlugin",
    "AcontextSessionPlugin",
    "AcontextSpacePlugin",
    "AcontextDiskPlugin",
    "AcontextObservePlugin",
    "AcontextConfig",
    "AcontextAgentContext",
    "AcontextPluginBundle",
    # HMLR (deprecated)
    "HMLRMemoryPlugin",
    "HMLRMemoryConfig",
    "HMLRMemoryFacade",
    # AgentFS Memory
    "AgentFSMemoryPlugin",
    "AgentFSMemoryConfig",
    "AgentFSClient",
    "AgentFSEnvironment",
    # Errors
    "ContextwiseExceptionCode",
    "DEFAULT_ISE_CODE",
    # AG-UI
    "create_agui_router",
    "AGUIRequest",
    "AGUIStatusResponse",
    "EventType",
    "BaseEvent",
    "EventBuffer",
    # TEE
    "TEEConfig",
    "TEEManager",
    "TEEIdentity",
    "PluginPermission",
    "PluginManifest",
    "TEEAwarePlugin",
    "TEEAuthPlugin",
    "TEEMemoryPlugin",
    "AuditEvent",
    "AuditLog",
    "EncryptedStorage",
    "TEEFilesystem",
    "TEENetworkRestrictor",
    "TEESessionManager",
    "validate_tee_configuration",
    "detect_tee_environment",
]
