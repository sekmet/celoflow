"""Multimodal media classes for Contextwise v0.3.0.

Provides classes for handling images, audio, and video in agent interactions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
from pathlib import Path


@dataclass
class Image:
    """Image data for multimodal interactions.

    Supports images from file paths, URLs, or raw bytes.

    Attributes:
        filepath: Path to image file
        url: URL to image
        content: Raw image bytes
        mime_type: MIME type (auto-detected if not provided)
        alt_text: Alternative text description

    Examples:
        >>> # From file
        >>> img = Image(filepath="/path/to/image.png")

        >>> # From URL
        >>> img = Image(url="https://example.com/image.jpg")

        >>> # From bytes
        >>> img = Image(content=image_bytes, mime_type="image/png")
    """

    filepath: Optional[str] = None
    url: Optional[str] = None
    content: Optional[bytes] = None
    mime_type: Optional[str] = None
    alt_text: Optional[str] = None

    def __post_init__(self):
        """Validate that at least one source is provided."""
        if not any([self.filepath, self.url, self.content]):
            raise ValueError(
                "At least one of filepath, url, or content must be provided"
            )

        # Auto-detect MIME type from filepath
        if self.filepath and not self.mime_type:
            path = Path(self.filepath)
            ext = path.suffix.lower()
            mime_types = {
                ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg",
                ".png": "image/png",
                ".gif": "image/gif",
                ".webp": "image/webp",
                ".bmp": "image/bmp",
            }
            self.mime_type = mime_types.get(ext, "image/jpeg")

    def to_base64(self) -> str:
        """Convert image to base64 string.

        Returns:
            Base64-encoded image string

        Raises:
            NotImplementedError: Not yet implemented
        """
        # TODO: Implement base64 conversion
        raise NotImplementedError("Base64 conversion not yet implemented")

    async def load_from_url(self) -> bytes:
        """Load image from URL.

        Returns:
            Image bytes

        Raises:
            NotImplementedError: Not yet implemented
        """
        # TODO: Implement URL loading
        raise NotImplementedError("URL loading not yet implemented")


@dataclass
class Audio:
    """Audio data for multimodal interactions.

    Supports audio from file paths, URLs, or raw bytes.

    Attributes:
        filepath: Path to audio file
        url: URL to audio
        content: Raw audio bytes
        mime_type: MIME type (auto-detected if not provided)
        duration_seconds: Audio duration in seconds
        transcription: Optional text transcription

    Examples:
        >>> # From file
        >>> audio = Audio(filepath="/path/to/audio.mp3")

        >>> # From URL
        >>> audio = Audio(url="https://example.com/audio.wav")
    """

    filepath: Optional[str] = None
    url: Optional[str] = None
    content: Optional[bytes] = None
    mime_type: Optional[str] = None
    duration_seconds: Optional[float] = None
    transcription: Optional[str] = None

    def __post_init__(self):
        """Validate that at least one source is provided."""
        if not any([self.filepath, self.url, self.content]):
            raise ValueError(
                "At least one of filepath, url, or content must be provided"
            )

        # Auto-detect MIME type from filepath
        if self.filepath and not self.mime_type:
            path = Path(self.filepath)
            ext = path.suffix.lower()
            mime_types = {
                ".mp3": "audio/mpeg",
                ".wav": "audio/wav",
                ".ogg": "audio/ogg",
                ".m4a": "audio/mp4",
                ".flac": "audio/flac",
            }
            self.mime_type = mime_types.get(ext, "audio/mpeg")


@dataclass
class Video:
    """Video data for multimodal interactions.

    Supports video from file paths, URLs, or raw bytes.

    Attributes:
        filepath: Path to video file
        url: URL to video
        content: Raw video bytes
        mime_type: MIME type (auto-detected if not provided)
        duration_seconds: Video duration in seconds
        thumbnail: Optional thumbnail image

    Examples:
        >>> # From file
        >>> video = Video(filepath="/path/to/video.mp4")

        >>> # From URL
        >>> video = Video(url="https://example.com/video.mp4")
    """

    filepath: Optional[str] = None
    url: Optional[str] = None
    content: Optional[bytes] = None
    mime_type: Optional[str] = None
    duration_seconds: Optional[float] = None
    thumbnail: Optional[Image] = None

    def __post_init__(self):
        """Validate that at least one source is provided."""
        if not any([self.filepath, self.url, self.content]):
            raise ValueError(
                "At least one of filepath, url, or content must be provided"
            )

        # Auto-detect MIME type from filepath
        if self.filepath and not self.mime_type:
            path = Path(self.filepath)
            ext = path.suffix.lower()
            mime_types = {
                ".mp4": "video/mp4",
                ".avi": "video/x-msvideo",
                ".mov": "video/quicktime",
                ".wmv": "video/x-ms-wmv",
                ".webm": "video/webm",
            }
            self.mime_type = mime_types.get(ext, "video/mp4")
