"""Discord webhook router for Contextwise v0.3.0.

This module provides FastAPI router creation for Discord webhook endpoints,
handling interactions (slash commands, components, modals) via HTTP POST.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional, Callable, Any, Awaitable

from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse

from .utils import (
    verify_discord_signature,
    parse_discord_interaction,
    create_discord_response,
    DiscordInteractionType,
    DiscordResponseType,
)

if TYPE_CHECKING:
    from contextwise.channels import DiscordChannel

logger = logging.getLogger(__name__)


def create_discord_router(
    api_plugin: "DiscordChannel",
    async_message_handler: Optional[Callable[[dict], Awaitable[None]]] = None,
    command_handler: Optional[Callable[[dict], Awaitable[str]]] = None,
) -> APIRouter:
    """Create FastAPI router for Discord webhook endpoints.
    
    This router handles Discord interactions including:
    - PING verification (required by Discord)
    - APPLICATION_COMMAND (slash commands)
    - MESSAGE_COMPONENT (buttons, select menus)
    - MODAL_SUBMIT (modal form submissions)
    
    Args:
        api_plugin: DiscordChannel instance with configuration
        async_message_handler: Optional async handler for message-like interactions
        command_handler: Optional async handler that returns response text for commands
        
    Returns:
        FastAPI APIRouter with /webhook endpoint
    """
    router = APIRouter(tags=["discord"])
    
    @router.post("/webhook")
    async def discord_webhook(request: Request):
        """Handle Discord interaction webhook.
        
        Discord sends all interactions to this endpoint. We verify the signature,
        parse the interaction, and route to the appropriate handler.
        
        Returns:
            JSON response conforming to Discord interaction response format
        """
        # Get signature headers
        signature = request.headers.get("X-Signature-Ed25519", "")
        timestamp = request.headers.get("X-Signature-Timestamp", "")
        
        # Read raw body for signature verification
        body = await request.body()
        
        # Verify signature if public key is configured
        if api_plugin.public_key:
            if not verify_discord_signature(
                api_plugin.public_key,
                signature,
                timestamp,
                body,
            ):
                logger.warning("Discord signature verification failed")
                raise HTTPException(status_code=401, detail="Invalid signature")
        
        # Parse JSON body
        try:
            data = await request.json()
        except Exception as e:
            logger.error(f"Failed to parse Discord webhook body: {e}")
            raise HTTPException(status_code=400, detail="Invalid JSON body")
        
        # Parse interaction
        interaction = parse_discord_interaction(data)
        if not interaction:
            logger.warning(f"Unknown Discord interaction type: {data.get('type')}")
            raise HTTPException(status_code=400, detail="Unknown interaction type")
        
        # Handle PING (required for Discord endpoint verification)
        if interaction["type"] == "ping":
            logger.info("Discord PING received, responding with PONG")
            return JSONResponse({"type": DiscordResponseType.PONG})
        
        # Handle slash commands
        if interaction["type"] == "command":
            return await _handle_command(
                interaction,
                api_plugin,
                command_handler,
                async_message_handler,
            )
        
        # Handle message components (buttons, selects)
        if interaction["type"] == "component":
            return await _handle_component(
                interaction,
                api_plugin,
                async_message_handler,
            )
        
        # Handle modal submissions
        if interaction["type"] == "modal":
            return await _handle_modal(
                interaction,
                api_plugin,
                async_message_handler,
            )
        
        # Fallback response
        return JSONResponse(
            create_discord_response(
                "I received your message but I'm not sure how to handle it.",
                ephemeral=True,
            )
        )
    
    @router.get("/webhook")
    async def discord_webhook_verify():
        """Health check endpoint for Discord webhook.
        
        Discord may ping this endpoint to verify it's active.
        """
        return {"status": "ok", "channel": "discord"}
    
    return router


async def _handle_command(
    interaction: dict,
    api_plugin: "DiscordChannel",
    command_handler: Optional[Callable[[dict], Awaitable[str]]],
    async_message_handler: Optional[Callable[[dict], Awaitable[None]]],
) -> JSONResponse:
    """Handle Discord slash command interaction.
    
    If a command_handler is provided, it's called and its return value
    is sent as the response. Otherwise, if async_message_handler is provided,
    the command text is sent for processing and a deferred response is sent.
    
    Args:
        interaction: Parsed interaction dict
        api_plugin: DiscordChannel instance
        command_handler: Optional handler that returns response text
        async_message_handler: Optional handler for async processing
        
    Returns:
        JSONResponse with Discord interaction response
    """
    command_name = interaction.get("command_name", "")
    options = interaction.get("options", {})
    user_id = interaction.get("user_id", "")
    
    logger.info(
        f"Discord command: /{command_name} from user {user_id} "
        f"with options {options}"
    )
    
    # Use command_handler if provided (for direct response)
    if command_handler:
        try:
            response_text = await command_handler(interaction)
            return JSONResponse(
                create_discord_response(response_text)
            )
        except Exception as e:
            logger.exception(f"Error in Discord command handler: {e}")
            return JSONResponse(
                create_discord_response(
                    "Sorry, there was an error processing your command.",
                    ephemeral=True,
                )
            )
    
    # If no command handler, try to use async_message_handler with deferred response
    # For slash commands, we need to construct a message from the command and options
    if async_message_handler:
        # Construct message from command
        message_content = f"/{command_name}"
        if options:
            # Add options as part of the message
            for key, value in options.items():
                message_content += f" {key}={value}"
        
        # Create message dict for handler
        message = {
            "type": "command",
            "content": message_content,
            "from": user_id,
            "channel_id": interaction.get("channel_id"),
            "guild_id": interaction.get("guild_id"),
            "command_name": command_name,
            "options": options,
            "interaction_token": interaction.get("token"),
            "interaction_id": interaction.get("id"),
            "raw": interaction.get("raw"),
        }
        
        # Send to async handler (will respond via followup)
        try:
            await async_message_handler(message)
            # Return deferred response while processing
            return JSONResponse({
                "type": DiscordResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE,
            })
        except Exception as e:
            logger.exception(f"Error in Discord async message handler: {e}")
            return JSONResponse(
                create_discord_response(
                    "Sorry, there was an error processing your message.",
                    ephemeral=True,
                )
            )
    
    # No handler configured
    return JSONResponse(
        create_discord_response(
            f"Command /{command_name} received but no handler is configured.",
            ephemeral=True,
        )
    )


async def _handle_component(
    interaction: dict,
    api_plugin: "DiscordChannel",
    async_message_handler: Optional[Callable[[dict], Awaitable[None]]],
) -> JSONResponse:
    """Handle Discord message component interaction (buttons, selects).
    
    Args:
        interaction: Parsed interaction dict
        api_plugin: DiscordChannel instance
        async_message_handler: Optional handler for async processing
        
    Returns:
        JSONResponse with Discord interaction response
    """
    custom_id = interaction.get("custom_id", "")
    user_id = interaction.get("user_id", "")
    values = interaction.get("values", [])
    
    logger.info(
        f"Discord component: {custom_id} from user {user_id} "
        f"with values {values}"
    )
    
    if async_message_handler:
        message = {
            "type": "component",
            "content": f"Component interaction: {custom_id}",
            "from": user_id,
            "custom_id": custom_id,
            "values": values,
            "channel_id": interaction.get("channel_id"),
            "guild_id": interaction.get("guild_id"),
            "interaction_token": interaction.get("token"),
            "interaction_id": interaction.get("id"),
            "raw": interaction.get("raw"),
        }
        
        try:
            await async_message_handler(message)
            # Acknowledge the component interaction
            return JSONResponse({
                "type": DiscordResponseType.DEFERRED_UPDATE_MESSAGE,
            })
        except Exception as e:
            logger.exception(f"Error in Discord component handler: {e}")
            return JSONResponse(
                create_discord_response(
                    "Sorry, there was an error processing your interaction.",
                    ephemeral=True,
                )
            )
    
    # No handler - just acknowledge
    return JSONResponse({
        "type": DiscordResponseType.DEFERRED_UPDATE_MESSAGE,
    })


async def _handle_modal(
    interaction: dict,
    api_plugin: "DiscordChannel",
    async_message_handler: Optional[Callable[[dict], Awaitable[None]]],
) -> JSONResponse:
    """Handle Discord modal submission interaction.
    
    Args:
        interaction: Parsed interaction dict
        api_plugin: DiscordChannel instance
        async_message_handler: Optional handler for async processing
        
    Returns:
        JSONResponse with Discord interaction response
    """
    custom_id = interaction.get("custom_id", "")
    user_id = interaction.get("user_id", "")
    fields = interaction.get("fields", {})
    
    logger.info(
        f"Discord modal: {custom_id} from user {user_id} "
        f"with {len(fields)} fields"
    )
    
    if async_message_handler:
        # Construct content from modal fields
        content_parts = [f"Modal submission: {custom_id}"]
        for field_id, value in fields.items():
            content_parts.append(f"{field_id}: {value}")
        
        message = {
            "type": "modal",
            "content": "\n".join(content_parts),
            "from": user_id,
            "custom_id": custom_id,
            "fields": fields,
            "channel_id": interaction.get("channel_id"),
            "guild_id": interaction.get("guild_id"),
            "interaction_token": interaction.get("token"),
            "interaction_id": interaction.get("id"),
            "raw": interaction.get("raw"),
        }
        
        try:
            await async_message_handler(message)
            return JSONResponse({
                "type": DiscordResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE,
            })
        except Exception as e:
            logger.exception(f"Error in Discord modal handler: {e}")
            return JSONResponse(
                create_discord_response(
                    "Sorry, there was an error processing your submission.",
                    ephemeral=True,
                )
            )
    
    # No handler - send acknowledgement
    return JSONResponse(
        create_discord_response(
            "Your submission has been received.",
            ephemeral=True,
        )
    )
