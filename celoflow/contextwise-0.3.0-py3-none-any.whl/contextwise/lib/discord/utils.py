"""Discord utility functions for Contextwise v0.3.0.

This module provides utility functions for Discord API interactions,
including signature verification, message sending, and response formatting.
"""

from __future__ import annotations

import os
import logging
from enum import IntEnum
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class DiscordInteractionType(IntEnum):
    """Discord interaction types.
    
    See: https://discord.com/developers/docs/interactions/receiving-and-responding#interaction-object-interaction-type
    """
    PING = 1
    APPLICATION_COMMAND = 2
    MESSAGE_COMPONENT = 3
    APPLICATION_COMMAND_AUTOCOMPLETE = 4
    MODAL_SUBMIT = 5


class DiscordResponseType(IntEnum):
    """Discord interaction response types.
    
    See: https://discord.com/developers/docs/interactions/receiving-and-responding#interaction-response-object-interaction-callback-type
    """
    PONG = 1
    CHANNEL_MESSAGE_WITH_SOURCE = 4
    DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE = 5
    DEFERRED_UPDATE_MESSAGE = 6
    UPDATE_MESSAGE = 7
    APPLICATION_COMMAND_AUTOCOMPLETE_RESULT = 8
    MODAL = 9


def verify_discord_signature(
    public_key: str,
    signature: str,
    timestamp: str,
    body: bytes,
) -> bool:
    """Verify Discord interaction signature using Ed25519.
    
    Discord requires verification of all incoming interactions using
    the application's public key.
    
    Args:
        public_key: Discord application public key (hex string)
        signature: X-Signature-Ed25519 header value
        timestamp: X-Signature-Timestamp header value
        body: Raw request body bytes
        
    Returns:
        True if signature is valid, False otherwise
    """
    try:
        from nacl.signing import VerifyKey
        from nacl.exceptions import BadSignature
        
        verify_key = VerifyKey(bytes.fromhex(public_key))
        message = timestamp.encode() + body
        verify_key.verify(message, bytes.fromhex(signature))
        return True
    except ImportError:
        logger.warning(
            "PyNaCl not installed. Discord signature verification disabled. "
            "Install with: uv add pynacl"
        )
        # In development, allow without verification
        return os.getenv("DISCORD_SKIP_VERIFICATION", "").lower() in ("1", "true", "yes")
    except BadSignature:
        return False
    except Exception as e:
        logger.error(f"Error verifying Discord signature: {e}")
        return False


def create_discord_response(
    content: str,
    response_type: DiscordResponseType = DiscordResponseType.CHANNEL_MESSAGE_WITH_SOURCE,
    ephemeral: bool = False,
    embeds: Optional[list] = None,
    components: Optional[list] = None,
) -> Dict[str, Any]:
    """Create a Discord interaction response payload.
    
    Args:
        content: Message content text
        response_type: Type of response (default: CHANNEL_MESSAGE_WITH_SOURCE)
        ephemeral: If True, only visible to interaction user
        embeds: Optional list of embed objects
        components: Optional list of component objects
        
    Returns:
        Discord interaction response dict
    """
    data: Dict[str, Any] = {"content": content}
    
    if ephemeral:
        data["flags"] = 64  # EPHEMERAL flag
    
    if embeds:
        data["embeds"] = embeds
    
    if components:
        data["components"] = components
    
    return {
        "type": response_type,
        "data": data,
    }


def send_discord_message(
    channel_id: str,
    content: str,
    bot_token: Optional[str] = None,
    embeds: Optional[list] = None,
    components: Optional[list] = None,
) -> Dict[str, Any]:
    """Send a message to a Discord channel synchronously.
    
    Args:
        channel_id: Discord channel ID (snowflake)
        content: Message content text
        bot_token: Bot token (uses DISCORD_BOT_TOKEN env if not provided)
        embeds: Optional list of embed objects
        components: Optional list of component objects
        
    Returns:
        Discord API response dict
        
    Raises:
        ValueError: If bot token not configured
        Exception: If API request fails
    """
    import httpx
    
    token = bot_token or os.getenv("DISCORD_BOT_TOKEN", "")
    if not token:
        raise ValueError("Discord bot token not configured")
    
    url = f"https://discord.com/api/v10/channels/{channel_id}/messages"
    headers = {
        "Authorization": f"Bot {token}",
        "Content-Type": "application/json",
    }
    
    payload: Dict[str, Any] = {"content": content}
    if embeds:
        payload["embeds"] = embeds
    if components:
        payload["components"] = components
    
    with httpx.Client() as client:
        response = client.post(url, headers=headers, json=payload)
        
        if response.status_code == 429:
            # Rate limited
            retry_after = response.json().get("retry_after", 1)
            logger.warning(f"Discord rate limited. Retry after {retry_after}s")
            raise Exception(f"Rate limited. Retry after {retry_after} seconds")
        
        response.raise_for_status()
        return response.json()


async def send_discord_message_async(
    channel_id: str,
    content: str,
    bot_token: Optional[str] = None,
    embeds: Optional[list] = None,
    components: Optional[list] = None,
) -> Dict[str, Any]:
    """Send a message to a Discord channel asynchronously.
    
    Args:
        channel_id: Discord channel ID (snowflake)
        content: Message content text
        bot_token: Bot token (uses DISCORD_BOT_TOKEN env if not provided)
        embeds: Optional list of embed objects
        components: Optional list of component objects
        
    Returns:
        Discord API response dict
        
    Raises:
        ValueError: If bot token not configured
        Exception: If API request fails
    """
    import httpx
    
    token = bot_token or os.getenv("DISCORD_BOT_TOKEN", "")
    if not token:
        raise ValueError("Discord bot token not configured")
    
    url = f"https://discord.com/api/v10/channels/{channel_id}/messages"
    headers = {
        "Authorization": f"Bot {token}",
        "Content-Type": "application/json",
    }
    
    payload: Dict[str, Any] = {"content": content}
    if embeds:
        payload["embeds"] = embeds
    if components:
        payload["components"] = components
    
    async with httpx.AsyncClient() as client:
        response = await client.post(url, headers=headers, json=payload)
        
        if response.status_code == 429:
            # Rate limited
            retry_after = response.json().get("retry_after", 1)
            logger.warning(f"Discord rate limited. Retry after {retry_after}s")
            raise Exception(f"Rate limited. Retry after {retry_after} seconds")
        
        response.raise_for_status()
        return response.json()


async def send_discord_dm_async(
    user_id: str,
    content: str,
    bot_token: Optional[str] = None,
) -> Dict[str, Any]:
    """Send a direct message to a Discord user.
    
    Creates a DM channel with the user if needed, then sends the message.
    
    Args:
        user_id: Discord user ID (snowflake)
        content: Message content text
        bot_token: Bot token (uses DISCORD_BOT_TOKEN env if not provided)
        
    Returns:
        Discord API response dict
        
    Raises:
        ValueError: If bot token not configured
        Exception: If API request fails
    """
    import httpx
    
    token = bot_token or os.getenv("DISCORD_BOT_TOKEN", "")
    if not token:
        raise ValueError("Discord bot token not configured")
    
    headers = {
        "Authorization": f"Bot {token}",
        "Content-Type": "application/json",
    }
    
    async with httpx.AsyncClient() as client:
        # First, create DM channel
        dm_url = "https://discord.com/api/v10/users/@me/channels"
        dm_response = await client.post(
            dm_url,
            headers=headers,
            json={"recipient_id": user_id}
        )
        dm_response.raise_for_status()
        dm_channel = dm_response.json()
        channel_id = dm_channel["id"]
        
        # Send message to DM channel
        msg_url = f"https://discord.com/api/v10/channels/{channel_id}/messages"
        msg_response = await client.post(
            msg_url,
            headers=headers,
            json={"content": content}
        )
        
        if msg_response.status_code == 429:
            retry_after = msg_response.json().get("retry_after", 1)
            logger.warning(f"Discord rate limited. Retry after {retry_after}s")
            raise Exception(f"Rate limited. Retry after {retry_after} seconds")
        
        msg_response.raise_for_status()
        return msg_response.json()


def parse_discord_interaction(body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Parse Discord interaction payload to extract message data.
    
    Args:
        body: Discord interaction webhook payload
        
    Returns:
        Parsed interaction dict with normalized fields, or None if invalid
    """
    interaction_type = body.get("type")
    
    if interaction_type == DiscordInteractionType.PING:
        return {
            "type": "ping",
            "id": body.get("id"),
        }
    
    if interaction_type == DiscordInteractionType.APPLICATION_COMMAND:
        data = body.get("data", {})
        user = body.get("member", {}).get("user", {}) or body.get("user", {})
        
        # Extract command options as key-value pairs
        options = {}
        for opt in data.get("options", []):
            options[opt["name"]] = opt.get("value")
        
        return {
            "type": "command",
            "id": body.get("id"),
            "token": body.get("token"),
            "command_name": data.get("name"),
            "command_id": data.get("id"),
            "options": options,
            "user_id": user.get("id"),
            "username": user.get("username"),
            "guild_id": body.get("guild_id"),
            "channel_id": body.get("channel_id"),
            "raw": body,
        }
    
    if interaction_type == DiscordInteractionType.MESSAGE_COMPONENT:
        data = body.get("data", {})
        user = body.get("member", {}).get("user", {}) or body.get("user", {})
        
        return {
            "type": "component",
            "id": body.get("id"),
            "token": body.get("token"),
            "custom_id": data.get("custom_id"),
            "component_type": data.get("component_type"),
            "values": data.get("values", []),
            "user_id": user.get("id"),
            "username": user.get("username"),
            "guild_id": body.get("guild_id"),
            "channel_id": body.get("channel_id"),
            "message": body.get("message"),
            "raw": body,
        }
    
    if interaction_type == DiscordInteractionType.MODAL_SUBMIT:
        data = body.get("data", {})
        user = body.get("member", {}).get("user", {}) or body.get("user", {})
        
        # Extract modal field values
        fields = {}
        for row in data.get("components", []):
            for component in row.get("components", []):
                fields[component.get("custom_id")] = component.get("value")
        
        return {
            "type": "modal",
            "id": body.get("id"),
            "token": body.get("token"),
            "custom_id": data.get("custom_id"),
            "fields": fields,
            "user_id": user.get("id"),
            "username": user.get("username"),
            "guild_id": body.get("guild_id"),
            "channel_id": body.get("channel_id"),
            "raw": body,
        }
    
    return None
