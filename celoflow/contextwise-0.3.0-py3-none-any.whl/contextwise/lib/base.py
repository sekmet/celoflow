from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Generic, List, Optional, Protocol, TypeVar

from agents import Agent, RunConfig, RunResult, Runner, Session

from .context import AgentContext


# ============================================================================
# Generic Plugin System (following plugin-system-implementation-patterns-specs.md)
# ============================================================================

TContext = TypeVar("TContext")


@dataclass
class PluginMetadata:
    """Metadata describing a plugin for discovery and dependency management."""

    id: str
    name: str
    version: str = "0.1.0"
    description: str = ""
    author: str = ""
    dependencies: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)


class AgentPlugin(ABC, Generic[TContext]):
    """Base contract for agent plugins.

    Plugins are stateless or manage their own internal state.
    They must be safe to use across multiple concurrent requests.

    Type Parameters:
        TContext: The context type used by the agent and tools.
    """

    # Class-level attributes that subclasses can override
    id: str = ""
    name: str = ""
    version: str = "0.1.0"

    @property
    def metadata(self) -> PluginMetadata:
        """Return plugin metadata for discovery and validation."""
        return PluginMetadata(
            id=self.id,
            name=self.name,
            version=self.version,
            dependencies=self.dependencies(),
        )

    def dependencies(self) -> List[str]:
        """Return plugin ids that must be loaded before this plugin."""
        return []

    @abstractmethod
    def configure_agent(self, agent: Agent[TContext]) -> Agent[TContext]:
        """Return an agent with this plugin's changes applied.

        Implementations typically call `agent.clone(...)` and extend the
        `tools`, `input_guardrails`, `output_guardrails`, or `hooks` lists.
        """
        ...

    def configure_run_config(
        self,
        context: TContext,
        base_config: Optional[RunConfig],
    ) -> Optional[RunConfig]:
        """Optionally extend the run configuration for this request.

        If None is returned, the existing config is left unchanged.
        """
        return base_config

    def on_before_run(
        self,
        context: TContext,
        input: str,
    ) -> None:
        """Optional hook invoked before each run starts.

        Intended for setup, logging, or context enrichment.
        """
        pass

    def on_after_run(
        self,
        context: TContext,
        result: RunResult,
    ) -> None:
        """Optional hook invoked after each completed run.

        Intended for side effects such as analytics, audit logging, or cleanup.
        Implementations must not modify result.
        """
        pass

    async def on_before_run_async(
        self,
        context: TContext,
        input: str,
    ) -> None:
        """Async hook invoked before each run starts.

        Override this method for plugins that need async operations before run.
        This is called by PluginManager.run_async() instead of on_before_run().
        """
        # Default: call sync version for backwards compatibility
        self.on_before_run(context, input)

    async def on_after_run_async(
        self,
        context: TContext,
        result: RunResult,
    ) -> None:
        """Async hook invoked after each completed run.

        Override this method for plugins that need async operations after run.
        This is called by PluginManager.run_async() instead of on_after_run().
        """
        # Default: call sync version for backwards compatibility
        self.on_after_run(context, result)


@dataclass
class PluginManager(Generic[TContext]):
    """Orchestrates plugin lifecycle and agent integration.

    Type Parameters:
        TContext: The context type used by the agent and plugins.
    """

    base_agent: Agent[TContext]
    plugins: List[AgentPlugin[TContext]] = field(default_factory=list)

    def __post_init__(self) -> None:
        self._index: Dict[str, AgentPlugin[TContext]] = {
            p.id: p for p in self.plugins
        }
        self._validate_dependencies()

    def _validate_dependencies(self) -> None:
        """Validate that dependencies exist and appear earlier in the list."""
        seen: List[str] = []
        for plugin in self.plugins:
            for dep in plugin.dependencies():
                if dep not in self._index:
                    raise ValueError(
                        f"Plugin '{plugin.id}' depends on unknown plugin '{dep}'.",
                    )
                if dep not in seen:
                    raise ValueError(
                        f"Plugin '{plugin.id}' depends on '{dep}', which must be listed before it.",
                    )
            seen.append(plugin.id)

    def get_plugin(self, plugin_id: str) -> Optional[AgentPlugin[TContext]]:
        """Retrieve a plugin by its ID."""
        return self._index.get(plugin_id)

    def build_agent(self) -> Agent[TContext]:
        """Apply all plugin configure_agent operations in dependency order.

        Attaches plugin registry (agent.plugins and agent.plugin_index) to the SDK agent
        before and after each configure_agent() call to enable plugin discovery.
        This ensures ecommerce plugins can discover core skill plugins via agent.plugin_index.
        """
        agent = self.base_agent

        # Attach plugin registry before first configure_agent call
        # This enables plugins to discover each other during configuration
        agent.plugins = self.plugins
        agent.plugin_index = self._index

        for plugin in self.plugins:
            agent = plugin.configure_agent(agent)

            # Re-attach after each configure_agent (clone may drop custom attrs)
            # This ensures the registry survives agent.clone(...) operations
            agent.plugins = self.plugins
            agent.plugin_index = self._index

        return agent

    def build_run_config(
        self,
        context: TContext,
        base_config: Optional[RunConfig] = None,
    ) -> Optional[RunConfig]:
        """Fold plugin configure_run_config calls into a single RunConfig."""
        config = base_config
        for plugin in self.plugins:
            config = plugin.configure_run_config(context, config)
        return config

    def before_run(self, context: TContext, input: str) -> None:
        """Invoke on_before_run on all plugins."""
        for plugin in self.plugins:
            plugin.on_before_run(context, input)

    def after_run(self, context: TContext, result: RunResult) -> None:
        """Invoke on_after_run on all plugins."""
        for plugin in self.plugins:
            plugin.on_after_run(context, result)

    async def before_run_async(self, context: TContext, input: str) -> None:
        """Invoke on_before_run_async on all plugins."""
        for plugin in self.plugins:
            await plugin.on_before_run_async(context, input)

    async def after_run_async(self, context: TContext, result: RunResult) -> None:
        """Invoke on_after_run_async on all plugins."""
        for plugin in self.plugins:
            await plugin.on_after_run_async(context, result)

    def run_sync(
        self,
        user_input: str,
        context: TContext,
        *,
        session: Optional[Session] = None,
        base_run_config: Optional[RunConfig] = None,
        **runner_kwargs: Any,
    ) -> RunResult:
        """Run the plugin-enhanced workflow synchronously."""
        self.before_run(context, user_input)

        agent = self.build_agent()
        run_config = self.build_run_config(context, base_run_config)

        result = Runner.run_sync(
            starting_agent=agent,
            input=user_input,
            context=context,
            run_config=run_config,
            session=session,
            **runner_kwargs,
        )

        self.after_run(context, result)
        return result

    async def run_async(
        self,
        user_input: str,
        context: TContext,
        *,
        session: Optional[Session] = None,
        base_run_config: Optional[RunConfig] = None,
        **runner_kwargs: Any,
    ) -> RunResult:
        """Async variant of run_sync."""
        await self.before_run_async(context, user_input)

        agent = self.build_agent()
        run_config = self.build_run_config(context, base_run_config)

        result = await Runner.run(
            starting_agent=agent,
            input=user_input,
            context=context,
            run_config=run_config,
            session=session,
            **runner_kwargs,
        )

        await self.after_run_async(context, result)
        return result


# ============================================================================
# Backwards-compatible aliases for contextwise-specific code
# ============================================================================

# ContextwisePlugin is a type alias for plugins that use AgentContext
ContextwisePlugin = AgentPlugin[AgentContext]

# AgentPluginManager is a type alias for backwards compatibility
AgentPluginManager = PluginManager[AgentContext]
