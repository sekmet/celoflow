"""Debug Logging Plugin for Contextwise v0.3.0.

This plugin provides agent-level debug logging when DEBUG mode is enabled.
It uses the plugin lifecycle hooks (on_before_run, on_after_run) to observe
logical agent inputs/outputs in addition to HTTP-level I/O.

Usage:
    The plugin is automatically attached to the agent when debug=True
    is passed to Agent.serve() or create_app().

    Manual usage:
        >>> from contextwise.lib.debug_plugin import DebugLoggingPlugin
        >>> agent = Agent("gpt-4o-mini", "You are helpful")
        >>> agent.plugins.append(DebugLoggingPlugin())
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from ..lib.base import AgentContext

logger = logging.getLogger(__name__)


class DebugLoggingPlugin:
    """Plugin that logs agent-level input/output when DEBUG is enabled.
    
    This plugin is attached to agents when debug=True in serve() or create_app().
    It logs:
    - Incoming user messages (role, length) and channel/user/session IDs
    - Final agent response summary (length, truncated preview)
    - Timing information for agent runs
    
    The plugin is lightweight and should not add significant overhead,
    but is intended for development/debugging environments only.
    
    Attributes:
        id: Plugin identifier
        name: Human-readable plugin name
    """
    
    id = 'debug_logging'
    name = 'Debug Logging Plugin'
    
    def __init__(self, max_preview_length: int = 100):
        """Initialize the debug logging plugin.
        
        Args:
            max_preview_length: Maximum length of content previews in logs
        """
        self.max_preview_length = max_preview_length
        self._run_start_times: dict[str, float] = {}
    
    def _truncate(self, text: str) -> str:
        """Truncate text to max preview length."""
        if len(text) <= self.max_preview_length:
            return text
        return text[:self.max_preview_length] + '...'
    
    def _get_run_key(self, context: "AgentContext") -> str:
        """Generate a unique key for tracking run timing."""
        return f"{context.user_id}:{context.session_id}:{time.time()}"
    
    def on_before_run(
        self, 
        context: "AgentContext", 
        message: str,
        **kwargs: Any,
    ) -> None:
        """Log before agent run.
        
        Called by the plugin manager before the agent processes a message.
        
        Args:
            context: Agent context with user/session/channel info
            message: User message being processed
            **kwargs: Additional keyword arguments
        """
        run_key = self._get_run_key(context)
        self._run_start_times[run_key] = time.time()
        
        user_id = context.user_id or 'anonymous'
        session_id = context.session_id or 'none'
        channel = context.channel or 'unknown'
        message_length = len(message)
        message_preview = self._truncate(message)
        
        logger.debug(
            f"[DEBUG-PLUGIN] ▶ Agent run started | "
            f"user_id={user_id} session_id={session_id} channel={channel} | "
            f"message_length={message_length} preview=\"{message_preview}\""
        )
    
    def on_after_run(
        self,
        context: "AgentContext",
        response: Any,
        **kwargs: Any,
    ) -> None:
        """Log after agent run.
        
        Called by the plugin manager after the agent completes processing.
        
        Args:
            context: Agent context with user/session/channel info
            response: Agent response (may be a string or RunResult object)
            **kwargs: Additional keyword arguments
        """
        # Calculate elapsed time if we have a start time
        elapsed_ms = 0.0
        
        # Try to find any matching start time (approximate match)
        for key in list(self._run_start_times.keys()):
            if key.startswith(f"{context.user_id}:{context.session_id}:"):
                elapsed_ms = (time.time() - self._run_start_times[key]) * 1000
                del self._run_start_times[key]
                break
        
        user_id = context.user_id or 'anonymous'
        session_id = context.session_id or 'none'
        
        # Handle different response types (string or RunResult)
        if isinstance(response, str):
            response_text = response
        elif hasattr(response, 'final_output'):
            # RunResult object from openai-agents SDK
            response_text = str(response.final_output or '')
        else:
            response_text = str(response)
        
        response_length = len(response_text)
        response_preview = self._truncate(response_text)
        
        logger.debug(
            f"[DEBUG-PLUGIN] ◀ Agent run completed | "
            f"user_id={user_id} session_id={session_id} | "
            f"elapsed={elapsed_ms:.1f}ms response_length={response_length} | "
            f"preview=\"{response_preview}\""
        )
    
    def on_error(
        self,
        context: "AgentContext",
        error: Exception,
        **kwargs: Any,
    ) -> None:
        """Log agent errors.
        
        Called by the plugin manager when an error occurs during agent execution.
        
        Args:
            context: Agent context with user/session/channel info
            error: Exception that occurred
            **kwargs: Additional keyword arguments
        """
        user_id = context.user_id or 'anonymous'
        session_id = context.session_id or 'none'
        
        logger.debug(
            f"[DEBUG-PLUGIN] ✕ Agent error | "
            f"user_id={user_id} session_id={session_id} | "
            f"error={type(error).__name__}: {str(error)[:200]}"
        )


def create_debug_logging_plugin(max_preview_length: int = 100) -> DebugLoggingPlugin:
    """Factory function to create a DebugLoggingPlugin instance.
    
    Args:
        max_preview_length: Maximum length of content previews in logs
        
    Returns:
        DebugLoggingPlugin instance
    """
    return DebugLoggingPlugin(max_preview_length=max_preview_length)
