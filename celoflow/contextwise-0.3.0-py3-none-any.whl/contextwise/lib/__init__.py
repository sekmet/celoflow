from .context import AgentContext
from .base import (
    # Generic base classes
    AgentPlugin,
    PluginManager,
    PluginMetadata,
    # Backwards-compatible aliases
    ContextwisePlugin,
    AgentPluginManager,
)

# =============================================================================
# Monkey-patch SDK Agent with clone method for plugin compatibility
# =============================================================================
from agents import Agent as SDKAgent


def _sdk_agent_clone(self, *, tools=None, instructions=None, **kwargs):
    """Create a copy of this SDK Agent with optional overrides.
    
    This method is monkey-patched onto the SDK Agent class to support
    plugins that need to extend the agent with additional tools.
    
    Args:
        tools: Override or extend tools list
        instructions: Override instructions
        **kwargs: Additional overrides
        
    Returns:
        New SDK Agent instance with overrides applied
    """
    # Build new tools list
    new_tools = tools if tools is not None else list(self.tools or [])
    
    # Build new instructions
    new_instructions = instructions if instructions is not None else self.instructions
    
    # Create new agent with same base config but new tools/instructions
    new_agent = SDKAgent(
        name=kwargs.get('name', self.name),
        instructions=new_instructions,
        model=kwargs.get('model', self.model),
        tools=new_tools,
        mcp_servers=getattr(self, 'mcp_servers', None),
        input_guardrails=kwargs.get('input_guardrails', getattr(self, 'input_guardrails', None)),
        output_guardrails=kwargs.get('output_guardrails', getattr(self, 'output_guardrails', None)),
        handoffs=kwargs.get('handoffs', getattr(self, 'handoffs', None)),
        model_settings=kwargs.get('model_settings', getattr(self, 'model_settings', None)),
        output_type=kwargs.get('output_type', getattr(self, 'output_type', None)),
    )
    
    # Preserve custom attributes (like plugin_index, plugins)
    if hasattr(self, 'plugins'):
        new_agent.plugins = self.plugins
    if hasattr(self, 'plugin_index'):
        new_agent.plugin_index = self.plugin_index
    
    return new_agent


# Only patch if clone doesn't already exist
if not hasattr(SDKAgent, 'clone'):
    SDKAgent.clone = _sdk_agent_clone


__all__ = [
    # Generic base classes
    "AgentPlugin",
    "PluginManager",
    "PluginMetadata",
    # Backwards-compatible aliases
    "AgentContext",
    "ContextwisePlugin",
    "AgentPluginManager",
    # Proactive features (re-exported for convenience)
    "proactive",
]
