"""Slack webhook router for Contextwise v0.3.0.

This module provides FastAPI router creation for Slack webhook endpoints,
handling events via HTTP POST with signature verification.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional, Callable, Any, Awaitable

from fastapi import APIRouter, Request, HTTPException, Response
from fastapi.responses import JSONResponse

from .utils import (
    verify_slack_signature,
    parse_slack_event,
)

if TYPE_CHECKING:
    from contextwise.channels import SlackChannel

logger = logging.getLogger(__name__)


def create_slack_router(
    api_plugin: "SlackChannel",
    async_message_handler: Optional[Callable[[dict], Awaitable[None]]] = None,
) -> APIRouter:
    """Create FastAPI router for Slack webhook endpoints.
    
    This router handles Slack events including:
    - URL verification challenge
    - app_mention events
    - direct message events
    
    Args:
        api_plugin: SlackChannel instance with configuration
        async_message_handler: Optional async handler for message events
        
    Returns:
        FastAPI APIRouter with /events endpoint
    """
    router = APIRouter(tags=["slack"])
    
    @router.post("/events")
    async def slack_events(request: Request):
        """Handle Slack event webhooks.
        
        Slack sends all events to this endpoint. We verify the signature,
        parse the event, and route to the appropriate handler.
        
        Returns:
            JSON response or challenge string for URL verification
        """
        # Get signature headers
        signature = request.headers.get("X-Slack-Signature", "")
        timestamp = request.headers.get("X-Slack-Request-Timestamp", "")
        
        # Read raw body for signature verification
        body = await request.body()
        
        # Verify signature if signing secret is configured
        if api_plugin.signing_secret:
            if not verify_slack_signature(
                api_plugin.signing_secret,
                signature,
                timestamp,
                body,
            ):
                logger.warning("Slack signature verification failed")
                raise HTTPException(status_code=401, detail="Invalid signature")
        
        # Parse JSON body
        try:
            data = await request.json()
        except Exception as e:
            logger.error(f"Failed to parse Slack webhook body: {e}")
            raise HTTPException(status_code=400, detail="Invalid JSON body")
        
        # Parse event
        event = parse_slack_event(data)
        if not event:
            # Could be a bot message or unhandled event type
            logger.debug(f"Ignoring Slack event: {data.get('type')}")
            return Response(status_code=200)
        
        # Handle URL verification challenge
        if event["type"] == "url_verification":
            challenge = event.get("challenge", "")
            logger.info("Slack URL verification received")
            return JSONResponse({"challenge": challenge})
        
        # Handle app_mention and message events
        if event["type"] in ("app_mention", "message"):
            return await _handle_message_event(
                event,
                api_plugin,
                async_message_handler,
            )
        
        # Acknowledge unknown events
        return Response(status_code=200)
    
    @router.get("/events")
    async def slack_events_health():
        """Health check endpoint for Slack events.
        
        Useful for monitoring and debugging.
        """
        return {"status": "ok", "channel": "slack"}
    
    return router


async def _handle_message_event(
    event: dict,
    api_plugin: "SlackChannel",
    async_message_handler: Optional[Callable[[dict], Awaitable[None]]],
) -> Response:
    """Handle Slack message or app_mention event.
    
    Slack expects a 200 response within 3 seconds. For longer processing,
    we acknowledge immediately and process asynchronously.
    
    Args:
        event: Parsed event dict
        api_plugin: SlackChannel instance
        async_message_handler: Optional handler for async processing
        
    Returns:
        HTTP 200 response to acknowledge event
    """
    text = event.get("text", "")
    user_id = event.get("user_id", "")
    channel_id = event.get("channel_id", "")
    thread_ts = event.get("thread_ts", "")
    team_id = event.get("team_id", "")
    
    logger.info(
        f"Slack {event['type']}: user={user_id}, channel={channel_id}, "
        f"text={text[:50]}..."
    )
    
    if async_message_handler:
        # Prepare message dict for handler
        message = {
            "type": event["type"],
            "text": text,
            "from": user_id,
            "user_id": user_id,
            "channel_id": channel_id,
            "thread_ts": thread_ts,
            "team_id": team_id,
            "ts": event.get("ts"),
            "raw": event.get("raw"),
        }
        
        # Process asynchronously (fire and forget)
        # Note: In production, consider using a task queue
        import asyncio
        asyncio.create_task(_process_message_safe(message, async_message_handler))
    
    # Acknowledge immediately (Slack requires response within 3 seconds)
    return Response(status_code=200)


async def _process_message_safe(
    message: dict,
    handler: Callable[[dict], Awaitable[None]],
) -> None:
    """Process message with error handling.
    
    Args:
        message: Message dict
        handler: Async message handler
    """
    try:
        await handler(message)
    except Exception as e:
        logger.exception(f"Error processing Slack message: {e}")
