"""Slack integration utilities for Contextwise v0.3.0.

This module provides utilities for integrating Slack as a channel,
including webhook handling, message sending, and signature verification.
"""

from .utils import (
    verify_slack_signature,
    send_slack_message,
    send_slack_message_async,
    parse_slack_event,
    SlackEventType,
)
from .router import create_slack_router

__all__ = [
    "verify_slack_signature",
    "send_slack_message",
    "send_slack_message_async",
    "parse_slack_event",
    "create_slack_router",
    "SlackEventType",
]
