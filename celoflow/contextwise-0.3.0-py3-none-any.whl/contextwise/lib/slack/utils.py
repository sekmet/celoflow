"""Slack utility functions for Contextwise v0.3.0.

This module provides utility functions for Slack API interactions,
including signature verification, message sending, and event parsing.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import time
import logging
from enum import Enum
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class SlackEventType(str, Enum):
    """Slack event types.
    
    See: https://api.slack.com/events
    """
    URL_VERIFICATION = "url_verification"
    EVENT_CALLBACK = "event_callback"
    APP_MENTION = "app_mention"
    MESSAGE = "message"
    MESSAGE_IM = "message.im"
    MESSAGE_CHANNELS = "message.channels"
    MESSAGE_GROUPS = "message.groups"
    MESSAGE_MPIM = "message.mpim"


def verify_slack_signature(
    signing_secret: str,
    signature: str,
    timestamp: str,
    body: bytes,
) -> bool:
    """Verify Slack request signature using HMAC-SHA256.
    
    Slack requires verification of all incoming requests using
    the app's signing secret.
    
    See: https://api.slack.com/authentication/verifying-requests-from-slack
    
    Args:
        signing_secret: Slack app signing secret
        signature: X-Slack-Signature header value
        timestamp: X-Slack-Request-Timestamp header value
        body: Raw request body bytes
        
    Returns:
        True if signature is valid, False otherwise
    """
    try:
        # Check timestamp to prevent replay attacks (5 minutes tolerance)
        current_time = int(time.time())
        request_time = int(timestamp)
        if abs(current_time - request_time) > 300:
            logger.warning("Slack signature verification failed: timestamp too old")
            return False
        
        # Create signature base string
        sig_basestring = f"v0:{timestamp}:{body.decode('utf-8')}"
        
        # Compute HMAC-SHA256
        computed_signature = "v0=" + hmac.new(
            signing_secret.encode('utf-8'),
            sig_basestring.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        # Compare signatures using constant-time comparison
        return hmac.compare_digest(computed_signature, signature)
    except Exception as e:
        logger.error(f"Error verifying Slack signature: {e}")
        return False


def parse_slack_event(body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Parse Slack event payload to extract message data.
    
    Args:
        body: Slack event webhook payload
        
    Returns:
        Parsed event dict with normalized fields, or None if invalid
    """
    event_type = body.get("type")
    
    # Handle URL verification challenge
    if event_type == SlackEventType.URL_VERIFICATION:
        return {
            "type": "url_verification",
            "challenge": body.get("challenge"),
        }
    
    # Handle event callbacks
    if event_type == SlackEventType.EVENT_CALLBACK:
        event = body.get("event", {})
        inner_type = event.get("type")
        
        # Skip bot messages to prevent loops
        if event.get("bot_id") or event.get("subtype") == "bot_message":
            return None
        
        # Extract common fields
        user_id = event.get("user")
        channel_id = event.get("channel")
        text = event.get("text", "")
        thread_ts = event.get("thread_ts") or event.get("ts")
        team_id = body.get("team_id")
        
        # Handle app_mention events
        if inner_type == SlackEventType.APP_MENTION:
            # Remove bot mention from text if present
            # Mentions look like <@U123ABC> at the start
            if text.startswith("<@"):
                end_idx = text.find(">")
                if end_idx != -1:
                    text = text[end_idx + 1:].strip()
            
            return {
                "type": "app_mention",
                "text": text,
                "user_id": user_id,
                "channel_id": channel_id,
                "thread_ts": thread_ts,
                "team_id": team_id,
                "ts": event.get("ts"),
                "raw": body,
            }
        
        # Handle direct messages (message.im or message in DM channel)
        if inner_type == SlackEventType.MESSAGE:
            channel_type = event.get("channel_type", "")
            
            return {
                "type": "message",
                "channel_type": channel_type,
                "text": text,
                "user_id": user_id,
                "channel_id": channel_id,
                "thread_ts": thread_ts,
                "team_id": team_id,
                "ts": event.get("ts"),
                "raw": body,
            }
    
    return None


def send_slack_message(
    channel_id: str,
    text: str,
    bot_token: Optional[str] = None,
    thread_ts: Optional[str] = None,
    blocks: Optional[list] = None,
    attachments: Optional[list] = None,
) -> Dict[str, Any]:
    """Send a message to a Slack channel synchronously.
    
    Args:
        channel_id: Slack channel ID or user ID for DMs
        text: Message text (required, used as fallback for blocks)
        bot_token: Bot token (uses SLACK_BOT_TOKEN env if not provided)
        thread_ts: Thread timestamp to reply in thread
        blocks: Optional Block Kit blocks
        attachments: Optional legacy attachments
        
    Returns:
        Slack API response dict
        
    Raises:
        ValueError: If bot token not configured
        Exception: If API request fails
    """
    import httpx
    
    token = bot_token or os.getenv("SLACK_BOT_TOKEN", "")
    if not token:
        raise ValueError("Slack bot token not configured")
    
    url = "https://slack.com/api/chat.postMessage"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json; charset=utf-8",
    }
    
    payload: Dict[str, Any] = {
        "channel": channel_id,
        "text": text,
    }
    
    if thread_ts:
        payload["thread_ts"] = thread_ts
    if blocks:
        payload["blocks"] = blocks
    if attachments:
        payload["attachments"] = attachments
    
    with httpx.Client() as client:
        response = client.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        data = response.json()
        if not data.get("ok"):
            error = data.get("error", "unknown_error")
            logger.error(f"Slack API error: {error}")
            raise Exception(f"Slack API error: {error}")
        
        return data


async def send_slack_message_async(
    channel_id: str,
    text: str,
    bot_token: Optional[str] = None,
    thread_ts: Optional[str] = None,
    blocks: Optional[list] = None,
    attachments: Optional[list] = None,
) -> Dict[str, Any]:
    """Send a message to a Slack channel asynchronously.
    
    Args:
        channel_id: Slack channel ID or user ID for DMs
        text: Message text (required, used as fallback for blocks)
        bot_token: Bot token (uses SLACK_BOT_TOKEN env if not provided)
        thread_ts: Thread timestamp to reply in thread
        blocks: Optional Block Kit blocks
        attachments: Optional legacy attachments
        
    Returns:
        Slack API response dict
        
    Raises:
        ValueError: If bot token not configured
        Exception: If API request fails
    """
    import httpx
    
    token = bot_token or os.getenv("SLACK_BOT_TOKEN", "")
    if not token:
        raise ValueError("Slack bot token not configured")
    
    url = "https://slack.com/api/chat.postMessage"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json; charset=utf-8",
    }
    
    payload: Dict[str, Any] = {
        "channel": channel_id,
        "text": text,
    }
    
    if thread_ts:
        payload["thread_ts"] = thread_ts
    if blocks:
        payload["blocks"] = blocks
    if attachments:
        payload["attachments"] = attachments
    
    async with httpx.AsyncClient() as client:
        response = await client.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        data = response.json()
        if not data.get("ok"):
            error = data.get("error", "unknown_error")
            logger.error(f"Slack API error: {error}")
            raise Exception(f"Slack API error: {error}")
        
        return data


async def open_slack_dm_channel(
    user_id: str,
    bot_token: Optional[str] = None,
) -> str:
    """Open a DM channel with a Slack user.
    
    Args:
        user_id: Slack user ID
        bot_token: Bot token (uses SLACK_BOT_TOKEN env if not provided)
        
    Returns:
        Channel ID for the DM
        
    Raises:
        ValueError: If bot token not configured
        Exception: If API request fails
    """
    import httpx
    
    token = bot_token or os.getenv("SLACK_BOT_TOKEN", "")
    if not token:
        raise ValueError("Slack bot token not configured")
    
    url = "https://slack.com/api/conversations.open"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json; charset=utf-8",
    }
    
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url,
            headers=headers,
            json={"users": user_id}
        )
        response.raise_for_status()
        
        data = response.json()
        if not data.get("ok"):
            error = data.get("error", "unknown_error")
            raise Exception(f"Slack API error: {error}")
        
        return data["channel"]["id"]
