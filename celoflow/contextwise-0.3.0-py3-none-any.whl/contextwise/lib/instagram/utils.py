"""Utility functions for Instagram Business API.

This module provides functions for sending messages via Instagram API.
"""

import logging
import os
from typing import Optional

import httpx

from ..social import SocialHTTPClient, RateLimiter


logger = logging.getLogger(__name__)

# Rate limiter for Instagram API (10 requests/sec default)
_rate_limiter = RateLimiter(max_tokens=10, refill_rate=10.0)

# HTTP client for Instagram API
_http_client = SocialHTTPClient()


def get_access_token() -> str:
    """Get Instagram access token from environment.

    Returns:
        Access token from INSTAGRAM_ACCESS_TOKEN env var

    Raises:
        ValueError: If token not configured
    """
    token = os.getenv("INSTAGRAM_ACCESS_TOKEN", "")
    if not token:
        raise ValueError("INSTAGRAM_ACCESS_TOKEN not configured")
    return token


def get_page_id() -> str:
    """Get Instagram page/account ID from environment.

    Returns:
        Page ID from INSTAGRAM_PAGE_ID env var

    Raises:
        ValueError: If page ID not configured
    """
    page_id = os.getenv("INSTAGRAM_PAGE_ID", "")
    if not page_id:
        raise ValueError("INSTAGRAM_PAGE_ID not configured")
    return page_id


def send_instagram_message(
    recipient_id: str,
    text: str,
    access_token: Optional[str] = None,
    page_id: Optional[str] = None,
) -> Optional[str]:
    """Send a text message via Instagram (synchronous).

    Args:
        recipient_id: Instagram user ID (IGSID)
        text: Message text
        access_token: Access token (defaults to env var)
        page_id: Page ID (defaults to env var)

    Returns:
        Error message if failed, None if successful

    Example:
        >>> error = send_instagram_message("123456", "Hello!")
        >>> if error:
        ...     print(f"Failed: {error}")
    """
    access_token = access_token or get_access_token()
    page_id = page_id or get_page_id()

    url = f"https://graph.facebook.com/v18.0/{page_id}/messages"

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    payload = {
        "recipient": {"id": recipient_id},
        "message": {"text": text},
    }

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            logger.info(f"Instagram message sent to {recipient_id}")
            return None

    except httpx.HTTPError as e:
        error_msg = f"Failed to send Instagram message: {e}"
        logger.error(error_msg)
        return error_msg


async def send_instagram_message_async(
    recipient_id: str,
    text: str,
    access_token: Optional[str] = None,
    page_id: Optional[str] = None,
) -> Optional[str]:
    """Send a text message via Instagram (asynchronous).

    Args:
        recipient_id: Instagram user ID (IGSID)
        text: Message text
        access_token: Access token (defaults to env var)
        page_id: Page ID (defaults to env var)

    Returns:
        Error message if failed, None if successful

    Example:
        >>> error = await send_instagram_message_async("123456", "Hello!")
        >>> if error:
        ...     print(f"Failed: {error}")
    """
    access_token = access_token or get_access_token()
    page_id = page_id or get_page_id()

    # Acquire rate limit token
    await _rate_limiter.acquire()

    url = f"https://graph.facebook.com/v18.0/{page_id}/messages"

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    payload = {
        "recipient": {"id": recipient_id},
        "message": {"text": text},
    }

    try:
        result = await _http_client.post(url, headers, json_data=payload)
        logger.info(f"Instagram message sent to {recipient_id}")
        return None

    except httpx.HTTPError as e:
        error_msg = f"Failed to send Instagram message: {e}"
        logger.error(error_msg)
        return error_msg
