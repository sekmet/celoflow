"""Instagram channel plugin for Contextwise v0.3.0.

This module provides Instagram Business API integration as a Contextwise
channel plugin, including webhook handling and message sending.
"""

from .utils import send_instagram_message, send_instagram_message_async
from .router import create_instagram_router

__all__ = [
    "send_instagram_message",
    "send_instagram_message_async",
    "create_instagram_router",
]
