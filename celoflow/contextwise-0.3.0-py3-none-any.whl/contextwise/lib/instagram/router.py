"""FastAPI router for Instagram webhooks.

This module provides webhook endpoints for Instagram Business API events.
"""

import logging
from typing import Any, Callable, Dict, Optional

from fastapi import APIRouter, Request, Response, Query, Header

from ..social import verify_meta_signature, normalize_meta_event


logger = logging.getLogger(__name__)


def create_instagram_router(
    api_plugin: Any,
    async_message_handler: Optional[Callable] = None,
) -> APIRouter:
    """Create FastAPI router for Instagram webhooks.

    Args:
        api_plugin: Instagram channel plugin instance
        async_message_handler: Optional async handler for messages

    Returns:
        Configured APIRouter

    Example:
        >>> from contextwise.channels import InstagramChannel
        >>> channel = InstagramChannel()
        >>> router = create_instagram_router(channel, my_handler)
    """
    router = APIRouter()

    @router.get("/webhook")
    async def verify_webhook(
        mode: str = Query(alias="hub.mode"),
        token: str = Query(alias="hub.verify_token"),
        challenge: str = Query(alias="hub.challenge"),
    ):
        """Verify Instagram webhook (GET request).

        Meta sends a GET request with verification parameters during setup.

        Args:
            mode: Should be "subscribe"
            token: Verification token to match
            challenge: Challenge string to echo back

        Returns:
            Challenge string if verification succeeds
        """
        logger.info(f"Instagram webhook verification: mode={mode}")

        # Validate using plugin method
        if hasattr(api_plugin, 'validate_webhook'):
            result = api_plugin.validate_webhook(mode, token, challenge)
            if result:
                logger.info("Instagram webhook verified successfully")
                return Response(content=result, media_type="text/plain")

        logger.warning("Instagram webhook verification failed")
        return Response(content="Forbidden", status_code=403)

    @router.post("/webhook")
    async def receive_webhook(request: Request):
        """Receive Instagram webhook events (POST request).

        Args:
            request: FastAPI request object

        Returns:
            200 OK response
        """
        # Get signature header
        signature = request.headers.get("X-Hub-Signature-256", "")

        # Get raw body for signature verification
        body_bytes = await request.body()

        # Verify signature if app_secret is configured
        if hasattr(api_plugin, 'app_secret') and api_plugin.app_secret:
            if not verify_meta_signature(body_bytes, signature, api_plugin.app_secret):
                logger.warning("Invalid Instagram webhook signature")
                return Response(content="Forbidden", status_code=403)

        # Parse JSON body
        try:
            body = await request.json()
        except Exception as e:
            logger.error(f"Failed to parse Instagram webhook body: {e}")
            return Response(content="Bad Request", status_code=400)

        logger.info(f"Instagram webhook received: {body.get('object')}")

        # Normalize event
        event = normalize_meta_event(body, platform="instagram")

        if not event:
            logger.debug("No valid Instagram message found in webhook")
            return Response(content="OK", status_code=200)

        # Process message through handler
        if async_message_handler:
            try:
                message_data = {
                    "from": event.sender_id,
                    "content": event.text,
                    "message_id": event.platform_event_id,
                    "timestamp": event.timestamp,
                    "metadata": event.metadata,
                    "raw": event.raw,
                }

                # Call handler (fire and forget)
                import asyncio
                asyncio.create_task(async_message_handler(message_data))

            except Exception as e:
                logger.exception(f"Error in Instagram message handler: {e}")

        return Response(content="OK", status_code=200)

    return router
