"""Secrets management for Contextwise v0.3.0.

This module provides a provider-agnostic secrets management layer with support for:
- Infisical (production secret management)
- Environment variables (local development, fallback)
- Future: HashiCorp Vault, AWS Secrets Manager, etc.

Basic usage:
    >>> from contextwise.lib.secrets import EnvSecretsBackend
    >>> backend = EnvSecretsBackend()
    >>> api_key = await backend.get("OPENAI_API_KEY")

With Infisical:
    >>> from contextwise.lib.secrets import InfisicalSecretsBackend
    >>> backend = InfisicalSecretsBackend(
    ...     project_id="my-project",
    ...     environment_slug="dev"
    ... )
    >>> api_key = await backend.get("OPENAI_API_KEY")
"""

from .backend import SecretsBackend
from .config import SecretsConfig, create_secrets_backend
from .env import EnvSecretsBackend
from .infisical import InfisicalSecretsBackend
from .plugin import SecretsPlugin

__all__ = [
    "SecretsBackend",
    "SecretsConfig",
    "create_secrets_backend",
    "EnvSecretsBackend",
    "InfisicalSecretsBackend",
    "SecretsPlugin",
]
