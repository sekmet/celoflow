"""SecretsBackend Protocol for Contextwise v0.3.0.

This module defines the provider-agnostic interface for secrets management.
All secrets backends must implement this protocol to be used with SecretsPlugin.
"""

from __future__ import annotations

from typing import Optional, Protocol


class SecretsBackend(Protocol):
    """Protocol for secrets management backends.

    This protocol defines the interface that all secrets backends must implement.
    Backends can be backed by various providers (Infisical, Vault, environment, etc.).

    Example implementations:
        - EnvSecretsBackend: Reads from environment variables only
        - InfisicalSecretsBackend: Reads from Infisical using SDK client
        - VaultSecretsBackend: Reads from HashiCorp Vault (future)

    Usage:
        >>> backend: SecretsBackend = EnvSecretsBackend()
        >>> api_key = await backend.get("OPENAI_API_KEY")
        >>> all_secrets = await backend.list()
    """

    async def get(self, name: str) -> Optional[str]:
        """Get a secret value by name.

        Args:
            name: The secret name/key to retrieve

        Returns:
            The secret value as a string, or None if not found

        Examples:
            >>> api_key = await backend.get("OPENAI_API_KEY")
            >>> if api_key:
            ...     model = OpenAIModel(api_key=api_key)
        """
        ...

    async def list(self, path: str = "/") -> dict[str, str]:
        """List all secrets at a given path.

        Args:
            path: The path/prefix to filter secrets by. Default is "/" (all secrets).
                  For EnvSecretsBackend, this acts as a prefix filter.
                  For Infisical, this is the actual secret path in the project.

        Returns:
            Dictionary mapping secret names to values

        Examples:
            >>> # List all secrets
            >>> all_secrets = await backend.list()

            >>> # List secrets with specific prefix
            >>> db_secrets = await backend.list(path="DATABASE")
        """
        ...

    async def set(self, name: str, value: str, path: str = "/") -> bool:
        ...

    async def delete(self, name: str, path: str = "/") -> bool:
        ...
