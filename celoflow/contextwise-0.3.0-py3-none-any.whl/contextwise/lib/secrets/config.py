"""SecretsConfig - Configuration for secrets management.

This module provides configuration dataclass and factory functions for
creating secrets backends based on configuration.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Literal, Optional

from .backend import SecretsBackend
from .env import EnvSecretsBackend
from .infisical import InfisicalSecretsBackend


@dataclass
class SecretsConfig:
    """Configuration for secrets management layer.

    This dataclass holds all configuration needed to initialize a secrets backend.
    Can be created programmatically or loaded from environment variables.

    Attributes:
        backend: Backend type ("infisical" or "env-only")
        infisical_host: Infisical server URL (for self-hosted instances)
        infisical_project_id: Infisical project ID (required for "infisical" backend)
        infisical_env_slug: Environment name (dev, staging, prod, etc.)
        infisical_secret_path: Base path for secrets in the project
        cache_ttl: Cache TTL in seconds for Infisical client

    Examples:
        >>> # Default configuration (Infisical)
        >>> config = SecretsConfig()

        >>> # Environment-only backend
        >>> config = SecretsConfig(backend="env-only")

        >>> # Load from environment variables
        >>> config = SecretsConfig.from_env()

        >>> # Create backend from config
        >>> backend = create_secrets_backend(config)
    """

    backend: Literal["infisical", "env-only"] = "infisical"
    infisical_host: str = "https://vault.contextwise.xyz"
    infisical_project_id: Optional[str] = None
    infisical_env_slug: str = "dev"
    infisical_secret_path: str = "/contextwise/v020"
    cache_ttl: int = 300

    @classmethod
    def from_env(cls) -> SecretsConfig:
        """Create SecretsConfig from environment variables.

        Reads configuration from the following environment variables:
        - SECRETS_BACKEND: Backend type ("infisical" or "env-only")
        - INFISICAL_HOST: Infisical server URL
        - INFISICAL_PROJECT_ID: Infisical project ID
        - INFISICAL_ENV_SLUG: Environment name
        - INFISICAL_SECRET_PATH: Base path for secrets
        - INFISICAL_CACHE_TTL: Cache TTL in seconds

        Returns:
            SecretsConfig instance with values from environment

        Examples:
            >>> import os
            >>> os.environ["SECRETS_BACKEND"] = "infisical"
            >>> os.environ["INFISICAL_PROJECT_ID"] = "my-project"
            >>> config = SecretsConfig.from_env()
            >>> config.backend
            'infisical'
        """
        return cls(
            backend=os.environ.get("SECRETS_BACKEND", "infisical"),  # type: ignore
            infisical_host=os.environ.get(
                "INFISICAL_HOST", "https://vault.contextwise.xyz"
            ),
            infisical_project_id=os.environ.get("INFISICAL_PROJECT_ID"),
            infisical_env_slug=os.environ.get("INFISICAL_ENV_SLUG", "dev"),
            infisical_secret_path=os.environ.get(
                "INFISICAL_SECRET_PATH", "/contextwise/v020"
            ),
            cache_ttl=int(os.environ.get("INFISICAL_CACHE_TTL", "300")),
        )

    @classmethod
    def from_dict(cls, data: dict) -> SecretsConfig:
        """Create SecretsConfig from dictionary.

        Args:
            data: Configuration dictionary

        Returns:
            SecretsConfig instance
        """
        return cls(**data)

    def to_dict(self) -> dict:
        """Convert configuration to dictionary.

        Returns:
            Configuration as dictionary
        """
        return {
            "backend": self.backend,
            "infisical_host": self.infisical_host,
            "infisical_project_id": self.infisical_project_id,
            "infisical_env_slug": self.infisical_env_slug,
            "infisical_secret_path": self.infisical_secret_path,
            "cache_ttl": self.cache_ttl,
        }

    def validate(self) -> list[str]:
        """Validate secrets configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        if self.backend not in ["infisical", "env-only"]:
            errors.append(
                f"Invalid backend: {self.backend} (must be 'infisical' or 'env-only')"
            )

        if self.backend == "infisical":
            if not self.infisical_project_id:
                errors.append("infisical_project_id required when backend='infisical'")

            if self.cache_ttl < 0:
                errors.append(f"Invalid cache_ttl: {self.cache_ttl} (must be >= 0)")

        return errors

    def validate_or_raise(self) -> None:
        """Validate configuration and raise on errors.

        Raises:
            ValueError: If configuration is invalid
        """
        errors = self.validate()
        if errors:
            raise ValueError(f"Invalid SecretsConfig:\n" + "\n".join(errors))


def create_secrets_backend(config: SecretsConfig) -> SecretsBackend:
    """Factory function to create a secrets backend from configuration.

    Args:
        config: SecretsConfig instance

    Returns:
        SecretsBackend instance (EnvSecretsBackend or InfisicalSecretsBackend)

    Raises:
        ValueError: If backend type is invalid or required config is missing

    Examples:
        >>> # Create env-only backend
        >>> config = SecretsConfig(backend="env-only")
        >>> backend = create_secrets_backend(config)
        >>> isinstance(backend, EnvSecretsBackend)
        True

        >>> # Create Infisical backend
        >>> config = SecretsConfig(
        ...     backend="infisical",
        ...     infisical_project_id="my-project"
        ... )
        >>> backend = create_secrets_backend(config)
        >>> isinstance(backend, InfisicalSecretsBackend)
        True
    """
    if config.backend == "env-only":
        return EnvSecretsBackend()

    elif config.backend == "infisical":
        # Validate required config
        if not config.infisical_project_id:
            raise ValueError(
                "infisical_project_id is required when using 'infisical' backend"
            )

        return InfisicalSecretsBackend(
            project_id=config.infisical_project_id,
            environment_slug=config.infisical_env_slug,
            host=config.infisical_host,
            secret_path=config.infisical_secret_path,
            cache_ttl=config.cache_ttl,
        )

    else:
        raise ValueError(f"Unknown secrets backend: {config.backend}")
