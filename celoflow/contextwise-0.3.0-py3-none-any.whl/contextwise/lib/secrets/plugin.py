"""SecretsPlugin - Agent plugin for secrets management.

This plugin attaches a secrets backend to agents and optionally exposes
a get_secret tool for LLM usage.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from ..base import AgentPlugin
from ..context import AgentContext
from .backend import SecretsBackend

if TYPE_CHECKING:
    from agents import Agent, RunConfig, RunResult

logger = logging.getLogger(__name__)


class SecretsPlugin(AgentPlugin[AgentContext]):
    """Plugin that provides secrets management to agents.

    This plugin:
    1. Attaches a secrets_backend to the agent for accessing secrets
    2. Optionally exposes a get_secret tool for LLM usage

    Usage:
        >>> from contextwise.lib.secrets import EnvSecretsBackend, SecretsPlugin
        >>> backend = EnvSecretsBackend()
        >>> plugin = SecretsPlugin(secrets_backend=backend)

        >>> from contextwise import Agent
        >>> agent = Agent(
        ...     model="gpt-4o-mini",
        ...     instructions="You are helpful",
        ...     plugins=[plugin]
        ... )

        >>> # Agent now has access to secrets
        >>> # In agent code: api_key = await agent.secrets_backend.get("API_KEY")

    With LLM tool exposure:
        >>> plugin = SecretsPlugin(
        ...     secrets_backend=backend,
        ...     expose_tool_to_llm=True
        ... )
    """

    id = "secrets"
    name = "Secrets Plugin"
    version = "0.1.0"

    def __init__(
        self,
        secrets_backend: SecretsBackend,
        expose_tool_to_llm: bool = False,
    ):
        """Initialize SecretsPlugin.

        Args:
            secrets_backend: Backend for fetching secrets
            expose_tool_to_llm: If True, adds get_secret as a tool callable by LLM
        """
        self.secrets_backend = secrets_backend
        self.expose_tool_to_llm = expose_tool_to_llm

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Attach secrets backend to agent.

        Args:
            agent: SDK agent to configure

        Returns:
            Agent with secrets_backend attached
        """
        # Attach secrets_backend to agent
        agent.secrets_backend = self.secrets_backend

        # Optionally add get_secret tool for LLM usage
        if self.expose_tool_to_llm:
            get_secret_tool = self._create_get_secret_tool()

            # Clone agent with additional tool
            if hasattr(agent, "tools") and agent.tools:
                agent = agent.clone(tools=agent.tools + [get_secret_tool])
            else:
                agent = agent.clone(tools=[get_secret_tool])

            # Re-attach secrets_backend to cloned agent
            agent.secrets_backend = self.secrets_backend

        return agent

    def _create_get_secret_tool(self):
        """Create the get_secret tool function for LLM usage.

        Returns:
            Async function that fetches secrets
        """

        async def get_secret(name: str) -> Optional[str]:
            """Get a secret value by name.

            Args:
                name: Secret name to retrieve

            Returns:
                Secret value, or None if not found
            """
            try:
                value = await self.secrets_backend.get(name)
                if value:
                    # Log that secret was retrieved (but not the value)
                    logger.info(f"Secret '{name}' retrieved successfully")
                else:
                    logger.warning(f"Secret '{name}' not found")
                return value
            except Exception as e:
                logger.error(f"Error retrieving secret '{name}': {e}")
                return None

        # Set function metadata for tool registration
        get_secret.__name__ = "get_secret"
        get_secret.__doc__ = """Get a secret value by name.

        Use this to retrieve API keys, tokens, and other sensitive configuration values.

        Args:
            name: The name of the secret to retrieve (e.g., "OPENAI_API_KEY")

        Returns:
            The secret value as a string, or None if not found
        """

        return get_secret

    def configure_run_config(
        self,
        context: AgentContext,
        base_config: Optional[RunConfig],
    ) -> Optional[RunConfig]:
        """Configure run config (currently no modifications needed).

        Args:
            context: Agent context
            base_config: Base run configuration

        Returns:
            Unmodified base_config
        """
        return base_config

    def on_before_run(self, context: AgentContext, input: str) -> None:
        """Hook called before agent run (currently no action needed).

        Args:
            context: Agent context
            input: User input
        """
        pass

    def on_after_run(self, context: AgentContext, result: RunResult) -> None:
        """Hook called after agent run (currently no action needed).

        Args:
            context: Agent context
            result: Run result
        """
        pass
