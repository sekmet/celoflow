"""InfisicalSecretsBackend - Infisical-backed secrets backend.

This backend integrates with Infisical using the official Python SDK.
It's suitable for production environments where centralized secret management is needed.

Features:
- Token-based authentication (via INFISICAL_TOKEN env var or explicit token)
- Client-side caching (configurable TTL)
- Project and environment scoping
- Custom secret paths for organization
"""

from __future__ import annotations

import os
from typing import Optional

try:
    from infisical_sdk import InfisicalSDKClient
except ModuleNotFoundError:  # pragma: no cover
    InfisicalSDKClient = None  # type: ignore[assignment]


class InfisicalSecretsBackend:
    """Secrets backend powered by Infisical.

    This backend wraps the InfisicalSDKClient and provides async operations
    for fetching secrets from Infisical projects.

    Authentication:
        Uses token-based auth. Token can be provided via:
        1. Explicit `token` parameter
        2. INFISICAL_TOKEN environment variable

    Caching:
        The InfisicalSDKClient provides built-in client-side caching.
        Cache TTL is configurable (default: 300 seconds).

    Usage:
        >>> # Using environment variable
        >>> os.environ["INFISICAL_TOKEN"] = "your-token"
        >>> backend = InfisicalSecretsBackend(
        ...     project_id="my-project",
        ...     environment_slug="dev"
        ... )

        >>> # Using explicit token
        >>> backend = InfisicalSecretsBackend(
        ...     project_id="my-project",
        ...     environment_slug="dev",
        ...     token="explicit-token"
        ... )

        >>> # Fetch a secret
        >>> api_key = await backend.get("OPENAI_API_KEY")

        >>> # List all secrets in path
        >>> all_secrets = await backend.list()
    """

    def __init__(
        self,
        project_id: str,
        environment_slug: str = "dev",
        token: Optional[str] = None,
        host: str = "https://vault.contextwise.xyz",
        secret_path: str = "/contextwise/v020",
        cache_ttl: int = 300,
    ):
        """Initialize Infisical secrets backend.

        Args:
            project_id: Infisical project ID
            environment_slug: Environment name (e.g., "dev", "staging", "prod")
            token: Infisical token. If None, reads from INFISICAL_TOKEN env var
            host: Infisical host URL (for self-hosted instances)
            secret_path: Base path for secrets in the project
            cache_ttl: Cache TTL in seconds (default: 300)

        Raises:
            ValueError: If no token is provided and INFISICAL_TOKEN is not set
        """
        self._project_id = project_id
        self._environment_slug = environment_slug
        self._secret_path = secret_path

        # Get token from parameter or environment
        auth_token = token or os.environ.get("INFISICAL_TOKEN")
        if not auth_token:
            raise ValueError(
                "Infisical token not provided. "
                "Set INFISICAL_TOKEN environment variable or pass token parameter."
            )

        # Initialize Infisical SDK client with caching
        if InfisicalSDKClient is None:
            raise ModuleNotFoundError(
                "Missing optional dependency 'infisicalsdk'. "
                "Install it to use InfisicalSecretsBackend."
            )

        self._client = InfisicalSDKClient(
            host=host,
            cache_ttl=cache_ttl,
        )

        # Authenticate using token
        self._client.auth.token_auth.login(token=auth_token)

    async def get(self, name: str) -> Optional[str]:
        """Get a secret value by name from Infisical.

        Args:
            name: Secret name/key to retrieve

        Returns:
            Secret value as string, or None if not found or error occurs

        Examples:
            >>> backend = InfisicalSecretsBackend(project_id="my-project")
            >>> api_key = await backend.get("OPENAI_API_KEY")
            >>> if api_key:
            ...     print(f"Found API key: {api_key[:10]}...")
        """
        try:
            response = self._client.secrets.get_secret_by_name(
                secret_name=name,
                project_id=self._project_id,
                environment_slug=self._environment_slug,
                secret_path=self._secret_path,
            )
            return response.secret_value
        except Exception:
            # Secret not found or API error - return None
            # We don't log the exception to avoid leaking secret names
            return None

    async def list(self, path: str = "/") -> dict[str, str]:
        """List all secrets at a given path in Infisical.

        Args:
            path: Secret path in the Infisical project. If "/" (default),
                  uses the backend's configured secret_path.

        Returns:
            Dictionary mapping secret names to values

        Examples:
            >>> backend = InfisicalSecretsBackend(project_id="my-project")

            >>> # List secrets at configured path
            >>> all_secrets = await backend.list()

            >>> # List secrets at custom path
            >>> db_secrets = await backend.list(path="/database/prod")
        """
        try:
            # Use custom path if provided, otherwise use configured path
            effective_path = self._secret_path if path == "/" else path

            response = self._client.secrets.list_secrets(
                project_id=self._project_id,
                environment_slug=self._environment_slug,
                secret_path=effective_path,
            )

            # Convert list of secret objects to dictionary
            return {
                secret.secret_key: secret.secret_value
                for secret in response.secrets
            }
        except Exception:
            # API error - return empty dict
            # We don't log the exception to avoid leaking path information
            return {}

    async def set(self, name: str, value: str, path: str = "/") -> bool:
        effective_path = self._secret_path if path == "/" else path

        try:
            # Determine whether to create or update by attempting to read.
            # We intentionally treat any exception as "not found" to avoid
            # leaking information and to keep behavior consistent with get().
            try:
                self._client.secrets.get_secret_by_name(
                    secret_name=name,
                    project_id=self._project_id,
                    environment_slug=self._environment_slug,
                    secret_path=effective_path,
                )
                exists = True
            except Exception:
                exists = False

            if exists:
                self._client.secrets.update_secret_by_name(
                    current_secret_name=name,
                    project_id=self._project_id,
                    secret_path=effective_path,
                    environment_slug=self._environment_slug,
                    secret_value=value,
                    skip_multiline_encoding=False,
                )
                return True

            self._client.secrets.create_secret_by_name(
                secret_name=name,
                project_id=self._project_id,
                secret_path=effective_path,
                environment_slug=self._environment_slug,
                secret_value=value,
                skip_multiline_encoding=False,
            )
            return True
        except Exception:
            return False

    async def delete(self, name: str, path: str = "/") -> bool:
        effective_path = self._secret_path if path == "/" else path

        try:
            self._client.secrets.delete_secret_by_name(
                secret_name=name,
                project_id=self._project_id,
                environment_slug=self._environment_slug,
                secret_path=effective_path,
            )
            return True
        except Exception:
            return False
