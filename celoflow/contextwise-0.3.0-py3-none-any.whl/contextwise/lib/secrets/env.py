"""EnvSecretsBackend - Environment-based secrets backend.

This backend reads secrets directly from environment variables.
It's the simplest implementation and useful for:
- Local development
- Environments where Infisical is not needed/available
- Testing and CI/CD pipelines
"""

from __future__ import annotations

import os
from typing import Optional


class EnvSecretsBackend:
    """Secrets backend that reads from environment variables.

    This is a simple, stateless backend that uses os.environ to fetch secrets.
    No network calls, no caching - just direct environment variable access.

    Usage:
        >>> backend = EnvSecretsBackend()
        >>> api_key = await backend.get("OPENAI_API_KEY")

    Features:
        - Zero configuration required
        - No external dependencies
        - Synchronous operation (wrapped in async for protocol compatibility)
        - Prefix-based filtering for list() operations
    """

    async def get(self, name: str) -> Optional[str]:
        """Get a secret from environment variables.

        Args:
            name: Environment variable name

        Returns:
            Environment variable value, or None if not set

        Examples:
            >>> backend = EnvSecretsBackend()
            >>> api_key = await backend.get("OPENAI_API_KEY")
            >>> if api_key:
            ...     print(f"API key found: {api_key[:10]}...")
        """
        return os.environ.get(name)

    async def list(self, path: str = "/") -> dict[str, str]:
        """List environment variables, optionally filtered by prefix.

        Args:
            path: Prefix to filter environment variables. Default "/" returns all.
                  Non-root paths are treated as prefixes (e.g., "DATABASE" matches
                  "DATABASE_URL", "DATABASE_PASSWORD", etc.)

        Returns:
            Dictionary of environment variables matching the prefix

        Examples:
            >>> backend = EnvSecretsBackend()

            >>> # List all environment variables
            >>> all_vars = await backend.list()

            >>> # List only database-related variables
            >>> db_vars = await backend.list(path="DATABASE")
            >>> # Returns: {"DATABASE_URL": "...", "DATABASE_PASSWORD": "..."}
        """
        if path == "/":
            # Return all environment variables
            return dict(os.environ)

        # Treat path as a prefix filter
        # Remove leading/trailing slashes for consistent behavior
        prefix = path.strip("/")

        return {
            key: value
            for key, value in os.environ.items()
            if key.startswith(prefix)
        }

    async def set(self, name: str, value: str, path: str = "/") -> bool:
        os.environ[name] = value
        return True

    async def delete(self, name: str, path: str = "/") -> bool:
        if name in os.environ:
            del os.environ[name]
        return True
