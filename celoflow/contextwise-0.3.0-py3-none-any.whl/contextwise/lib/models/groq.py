"""Groq model implementation for contextwise using OpenAI-compatible API.

This module provides Groq chat completion capabilities using the OpenAI SDK
with Groq's OpenAI-compatible endpoint.

Groq supports OpenAI-compatible API at: https://api.groq.com/openai/v1
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from os import getenv
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Union

from .base import Model, ModelMessage, ModelResponse

logger = logging.getLogger(__name__)

# Groq OpenAI-compatible endpoint
GROQ_OPENAI_BASE_URL = "https://api.groq.com/openai/v1"

try:
    from openai import DEFAULT_MAX_RETRIES, AsyncOpenAI, OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

# Optional integration with the agents SDK (used by demos)
try:
    from agents.models import _openai_shared as agents_openai_shared

    AGENTS_OPENAI_SHARED_AVAILABLE = True
except ImportError:  # pragma: no cover - optional dependency
    AGENTS_OPENAI_SHARED_AVAILABLE = False
    agents_openai_shared = None  # type: ignore[misc,assignment]


@dataclass
class GroqModel(Model):
    """Groq chat model using OpenAI-compatible API.
    
    This model uses Groq's OpenAI-compatible endpoint for ultra-fast inference
    with LLaMA and other open models.
    
    Attributes:
        id: Model identifier (e.g., "openai/gpt-oss-120b").
        api_key: Groq API key.
        base_url: API endpoint (defaults to Groq's OpenAI-compatible endpoint).
        temperature: Sampling temperature (0-2).
        max_tokens: Maximum tokens in response.
    
    Example:
        >>> model = GroqModel(
        ...     id="openai/gpt-oss-120b",
        ...     api_key="gsk_...",
        ... )
        >>> response = model.chat([
        ...     ModelMessage(role="user", content="Hello!"),
        ... ])
        >>> print(response.content)
    """
    
    id: str = "openai/gpt-oss-120b"
    name: str = "Groq"
    provider: str = "Groq"
    
    # API configuration - uses OpenAI SDK with Groq's endpoint
    api_key: Optional[str] = getenv("GROQ_API_KEY")
    base_url: str = GROQ_OPENAI_BASE_URL
    timeout: Optional[float] = None
    max_retries: Optional[int] = None
    
    # Request parameters
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    stop: Optional[Union[str, List[str]]] = None
    seed: Optional[int] = None
    
    # Client instances (OpenAI SDK)
    _client: Optional[Any] = field(default=None, repr=False)
    _async_client: Optional[Any] = field(default=None, repr=False)
    
    def __post_init__(self):
        """Validate dependencies are available."""
        if not OPENAI_AVAILABLE:
            raise ImportError(
                "openai not installed. Install with: uv add openai"
            )
        
        # Get API key from environment if not provided
        if not self.api_key:
            self.api_key = getenv("GROQ_API_KEY")

        # Provide defaults for the agents SDK so MultiProvider can route Groq calls
        # without requiring OPENAI_API_KEY. Do not change the global responses/chat
        # default here; the builder plugin will choose the correct API per provider.
        if AGENTS_OPENAI_SHARED_AVAILABLE and self.api_key:
            try:
                # Preserve any existing defaults to avoid overriding user configuration
                current_key = agents_openai_shared.get_default_openai_key()
                if current_key is None:
                    agents_openai_shared.set_default_openai_key(self.api_key)

                current_client = agents_openai_shared.get_default_openai_client()
                if current_client is None:
                    groq_client = AsyncOpenAI(
                        api_key=self.api_key,
                        base_url=self.base_url,
                        timeout=self.timeout,
                        max_retries=self._resolved_max_retries,
                    )
                    agents_openai_shared.set_default_openai_client(groq_client)
            except Exception as exc:  # pragma: no cover - best-effort integration
                logger.warning(
                    "Could not register Groq client with agents SDK defaults: %s", exc
                )
    
    @property
    def client(self) -> "OpenAI":
        """Get or create the OpenAI client with Groq base_url."""
        if self._client is None:
            client_params = {
                "api_key": self.api_key,
                "base_url": self.base_url,
                "timeout": self.timeout,
                "max_retries": self._resolved_max_retries,
            }
            client_params = {k: v for k, v in client_params.items() if v is not None}
            self._client = OpenAI(**client_params)
        return self._client
    
    @property
    def async_client(self) -> "AsyncOpenAI":
        """Get or create the async OpenAI client with Groq base_url."""
        if self._async_client is None:
            client_params = {
                "api_key": self.api_key,
                "base_url": self.base_url,
                "timeout": self.timeout,
                "max_retries": self._resolved_max_retries,
            }
            client_params = {k: v for k, v in client_params.items() if v is not None}
            self._async_client = AsyncOpenAI(**client_params)
        return self._async_client

    @property
    def _resolved_max_retries(self) -> Optional[int]:
        """Return a max_retries value acceptable by OpenAI SDK."""
        if self.max_retries is None:
            return DEFAULT_MAX_RETRIES
        return self.max_retries
    
    def _build_request_params(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> Dict[str, Any]:
        """Build request parameters for API call."""
        params: Dict[str, Any] = {
            "model": self.id,
            "messages": [m.to_dict() for m in messages],
        }
        
        # Add optional parameters
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.max_tokens is not None:
            params["max_tokens"] = self.max_tokens
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.frequency_penalty is not None:
            params["frequency_penalty"] = self.frequency_penalty
        if self.presence_penalty is not None:
            params["presence_penalty"] = self.presence_penalty
        if self.stop is not None:
            params["stop"] = self.stop
        if self.seed is not None:
            params["seed"] = self.seed
        
        # Override with kwargs
        params.update(kwargs)
        
        return params
    
    def _parse_response(self, response: Any) -> ModelResponse:
        """Parse OpenAI response to ModelResponse."""
        choice = response.choices[0]
        message = choice.message
        
        usage = None
        if response.usage:
            usage = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            }
        
        tool_calls = None
        if message.tool_calls:
            tool_calls = [
                {
                    "id": tc.id,
                    "type": tc.type,
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in message.tool_calls
            ]
        
        return ModelResponse(
            content=message.content or "",
            role=message.role,
            tool_calls=tool_calls,
            usage=usage,
            model=response.model,
            finish_reason=choice.finish_reason,
            raw_response=response,
        )
    
    def chat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Generate a chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Groq-specific parameters.
            
        Returns:
            ModelResponse with the completion.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            response = self.client.chat.completions.create(**params)
            return self._parse_response(response)
        except Exception as e:
            logger.error(f"Error in Groq chat completion: {e}")
            raise
    
    async def achat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Async chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Groq-specific parameters.
            
        Returns:
            ModelResponse with the completion.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            response = await self.async_client.chat.completions.create(**params)
            return self._parse_response(response)
        except Exception as e:
            logger.error(f"Error in async Groq chat completion: {e}")
            raise
    
    def chat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> Iterator[ModelResponse]:
        """Generate a streaming chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Groq-specific parameters.
            
        Yields:
            ModelResponse chunks.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            params["stream"] = True
            
            stream = self.client.chat.completions.create(**params)
            
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield ModelResponse(
                        content=chunk.choices[0].delta.content,
                        role="assistant",
                        model=chunk.model,
                    )
        except Exception as e:
            logger.error(f"Error in Groq streaming chat: {e}")
            raise
    
    async def achat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> AsyncIterator[ModelResponse]:
        """Async streaming chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Groq-specific parameters.
            
        Yields:
            ModelResponse chunks.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            params["stream"] = True
            
            stream = await self.async_client.chat.completions.create(**params)
            
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield ModelResponse(
                        content=chunk.choices[0].delta.content,
                        role="assistant",
                        model=chunk.model,
                    )
        except Exception as e:
            logger.error(f"Error in async Groq streaming chat: {e}")
            raise
