"""Google GenAI SDK integration for GeminiModel.

This module provides native Google GenAI SDK support for Gemini 3+ models,
enabling proper tool/function calling with automatic thought_signature handling.

The Google GenAI SDK handles thought_signature automatically when using
client.models.generate_content() - no manual management required.

Reference: https://ai.google.dev/gemini-api/docs/function-calling
Reference: https://ai.google.dev/gemini-api/docs/gemini-3
"""

from __future__ import annotations

import json
import logging
import os
import uuid
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..session.chat_history_service import ChatHistoryService

logger = logging.getLogger(__name__)

# Google GenAI SDK - handles thought_signature automatically
try:
    from google import genai
    from google.genai import types as genai_types
    GOOGLE_GENAI_AVAILABLE = True
except ImportError:
    GOOGLE_GENAI_AVAILABLE = False
    genai = None
    genai_types = None


def is_adk_available() -> bool:
    """Check if Google GenAI SDK is available for native Gemini support."""
    return GOOGLE_GENAI_AVAILABLE


def clean_schema_for_genai(schema: dict) -> dict:
    """Clean JSON schema for Google GenAI compatibility.
    
    Removes properties that Google GenAI doesn't support like additionalProperties.
    
    Args:
        schema: JSON schema dict
        
    Returns:
        Cleaned schema dict
    """
    if not isinstance(schema, dict):
        return schema
    
    # Properties to remove (not supported by Google GenAI)
    unsupported_keys = {
        'additional_properties', 'additionalProperties', 
        '$schema', '$id', '$ref', 'definitions',
        'thought_signature', 'strict'
    }
    
    cleaned = {}
    for key, value in schema.items():
        if key in unsupported_keys:
            continue
        
        if isinstance(value, dict):
            cleaned[key] = clean_schema_for_genai(value)
        elif isinstance(value, list):
            cleaned[key] = [
                clean_schema_for_genai(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            cleaned[key] = value
    
    return cleaned


def convert_openai_tools_to_genai(openai_tools: List[Dict[str, Any]]) -> List[Any]:
    """Convert OpenAI-style tool definitions to Google GenAI format.
    
    Args:
        openai_tools: List of tools in OpenAI format
        
    Returns:
        List of Google GenAI Tool objects
    """
    if not GOOGLE_GENAI_AVAILABLE or not openai_tools:
        return []
    
    declarations = []
    for tool in openai_tools:
        if tool.get("type") != "function":
            continue
        
        func_spec = tool.get("function", {})
        params_schema = func_spec.get("parameters", {})
        
        # Clean schema for GenAI compatibility
        cleaned_params = clean_schema_for_genai(params_schema)
        
        decl = genai_types.FunctionDeclaration(
            name=func_spec.get("name", "unknown"),
            description=func_spec.get("description", ""),
            parameters=cleaned_params if cleaned_params else None,
        )
        declarations.append(decl)
        logger.debug(f"Converted tool {func_spec.get('name')} to GenAI format")
    
    if declarations:
        return [genai_types.Tool(function_declarations=declarations)]
    return []


# Backwards compatibility alias
convert_openai_tools_to_adk = convert_openai_tools_to_genai


@dataclass
class GeminiNativeClient:
    """Native Google GenAI client for Gemini 3+ models.
    
    This client uses the native Google GenAI SDK which handles thought_signature
    automatically. No manual thought_signature management is required.
    
    The SDK automatically:
    - Returns thought_signature in function call responses
    - Includes thought_signature in subsequent requests
    - Manages the full conversation flow
    
    Supports conversation_id for stateful multi-turn conversations with:
    - In-memory conversation history tracking per conversation_id
    - Optional integration with ChatHistoryService for persistent storage
    - Thread-safe conversation state management
    
    Attributes:
        model_id: Gemini model identifier (e.g., "gemini-3-flash-preview")
        api_key: Google API key
        temperature: Sampling temperature
        max_tokens: Maximum output tokens
    """
    
    model_id: str = "gemini-3-flash-preview"
    api_key: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    
    _client: Optional[Any] = field(default=None, repr=False)
    _conversation_history: List[Any] = field(default_factory=list, repr=False)
    _conversations: Dict[str, List[Any]] = field(default_factory=dict, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)
    _chat_history_service: Optional["ChatHistoryService"] = field(default=None, repr=False)
    
    def __post_init__(self):
        """Initialize the GenAI client."""
        if not GOOGLE_GENAI_AVAILABLE:
            raise ImportError("google-genai not installed. Install with: uv add google-genai")
        
        if not self.api_key:
            self.api_key = os.getenv("GEMINI_API_KEY")
        
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY not provided")
        
        self._client = genai.Client(api_key=self.api_key)
        self._conversation_history = []
        self._conversations = {}
        self._lock = threading.Lock()
    
    def set_chat_history_service(self, service: "ChatHistoryService") -> None:
        """Set the ChatHistoryService for persistent conversation storage.
        
        Args:
            service: ChatHistoryService instance
        """
        self._chat_history_service = service
        logger.debug(f"ChatHistoryService attached to GeminiNativeClient")
    
    def get_conversation_history(self, conversation_id: str) -> List[Any]:
        """Get conversation history for a specific conversation_id.
        
        Args:
            conversation_id: Unique conversation identifier
            
        Returns:
            List of Content objects for the conversation
        """
        with self._lock:
            return list(self._conversations.get(conversation_id, []))
    
    def add_to_conversation(
        self,
        conversation_id: str,
        content: Any,
        role: Optional[str] = None,
    ) -> None:
        """Add content to conversation history.
        
        Args:
            conversation_id: Unique conversation identifier
            content: Content object or text string to add
            role: Role for the content (user/model) if content is string
        """
        with self._lock:
            if conversation_id not in self._conversations:
                self._conversations[conversation_id] = []
            
            if isinstance(content, str):
                content = genai_types.Content(
                    role=role or "user",
                    parts=[genai_types.Part(text=content)]
                )
            
            self._conversations[conversation_id].append(content)
            logger.debug(f"Added content to conversation {conversation_id}, total: {len(self._conversations[conversation_id])}")
    
    def clear_conversation(self, conversation_id: str) -> None:
        """Clear conversation history for a specific conversation_id.
        
        Args:
            conversation_id: Unique conversation identifier
        """
        with self._lock:
            if conversation_id in self._conversations:
                del self._conversations[conversation_id]
                logger.debug(f"Cleared conversation {conversation_id}")
    
    def list_conversations(self) -> List[str]:
        """List all active conversation IDs.
        
        Returns:
            List of conversation IDs
        """
        with self._lock:
            return list(self._conversations.keys())
    
    def _build_config(
        self,
        system_instruction: Optional[str] = None,
        tools: Optional[List[Any]] = None,
    ) -> Any:
        """Build GenerateContentConfig with tools and settings.
        
        Args:
            system_instruction: System instruction for the model
            tools: List of GenAI Tool objects
            
        Returns:
            GenerateContentConfig instance
        """
        config_kwargs = {}
        
        if self.temperature is not None:
            config_kwargs["temperature"] = self.temperature
        if self.max_tokens is not None:
            config_kwargs["max_output_tokens"] = self.max_tokens
        
        if system_instruction or tools or config_kwargs:
            return genai_types.GenerateContentConfig(
                system_instruction=system_instruction,
                tools=tools if tools else None,
                **config_kwargs,
            )
        return None
    
    async def generate_content_async(
        self,
        contents: List[Any],
        system_instruction: Optional[str] = None,
        tools: Optional[List[Any]] = None,
        conversation_id: Optional[str] = None,
    ) -> Any:
        """Generate content asynchronously.
        
        The SDK handles thought_signature automatically - it's included in
        responses and managed internally for multi-turn conversations.
        
        When conversation_id is provided, the conversation history is automatically
        prepended to contents and the response is stored for future turns.
        
        Args:
            contents: List of Content objects
            system_instruction: System instruction
            tools: List of GenAI Tool objects
            conversation_id: Optional conversation ID for stateful conversations
            
        Returns:
            GenerateContentResponse
        """
        config = self._build_config(system_instruction, tools)
        
        # Build full conversation context if conversation_id provided
        full_contents = contents
        if conversation_id:
            history = self.get_conversation_history(conversation_id)
            if history:
                full_contents = history + contents
                logger.debug(f"Conversation {conversation_id}: {len(history)} history + {len(contents)} new = {len(full_contents)} total")
        
        response = await self._client.aio.models.generate_content(
            model=self.model_id,
            contents=full_contents,
            config=config,
        )
        
        # Store conversation state if conversation_id provided
        if conversation_id and response.candidates:
            # Add user content to history
            for content in contents:
                self.add_to_conversation(conversation_id, content)
            
            # Add model response to history
            model_content = response.candidates[0].content
            self.add_to_conversation(conversation_id, model_content)
            
            # Persist to ChatHistoryService if available
            await self._persist_conversation_async(conversation_id, contents, response)
        
        return response
    
    async def _persist_conversation_async(
        self,
        conversation_id: str,
        user_contents: List[Any],
        response: Any,
    ) -> None:
        """Persist conversation to ChatHistoryService if available.
        
        Args:
            conversation_id: Conversation ID
            user_contents: User content that was sent
            response: Model response
        """
        if not self._chat_history_service:
            return
        
        try:
            # Extract user message text
            user_text = ""
            for content in user_contents:
                if hasattr(content, 'parts'):
                    for part in content.parts:
                        if hasattr(part, 'text') and part.text:
                            user_text += part.text
            
            # Extract assistant response text
            assistant_text = ""
            if response.candidates:
                for part in response.candidates[0].content.parts:
                    if hasattr(part, 'text') and part.text:
                        assistant_text += part.text
            
            # Save messages to persistent storage
            if user_text:
                await self._chat_history_service.save_message(
                    session_id=conversation_id,
                    role="user",
                    content=user_text,
                )
            
            if assistant_text:
                await self._chat_history_service.save_message(
                    session_id=conversation_id,
                    role="assistant",
                    content=assistant_text,
                )
            
            logger.debug(f"Persisted conversation {conversation_id} to ChatHistoryService")
        except Exception as e:
            logger.warning(f"Failed to persist conversation {conversation_id}: {e}")
    
    def generate_content_sync(
        self,
        contents: List[Any],
        system_instruction: Optional[str] = None,
        tools: Optional[List[Any]] = None,
        conversation_id: Optional[str] = None,
    ) -> Any:
        """Generate content synchronously.
        
        When conversation_id is provided, the conversation history is automatically
        prepended to contents and the response is stored for future turns.
        
        Args:
            contents: List of Content objects
            system_instruction: System instruction
            tools: List of GenAI Tool objects
            conversation_id: Optional conversation ID for stateful conversations
            
        Returns:
            GenerateContentResponse
        """
        config = self._build_config(system_instruction, tools)
        
        # Build full conversation context if conversation_id provided
        full_contents = contents
        if conversation_id:
            history = self.get_conversation_history(conversation_id)
            if history:
                full_contents = history + contents
                logger.debug(f"Conversation {conversation_id}: {len(history)} history + {len(contents)} new = {len(full_contents)} total")
        
        response = self._client.models.generate_content(
            model=self.model_id,
            contents=full_contents,
            config=config,
        )
        
        # Store conversation state if conversation_id provided
        if conversation_id and response.candidates:
            # Add user content to history
            for content in contents:
                self.add_to_conversation(conversation_id, content)
            
            # Add model response to history
            model_content = response.candidates[0].content
            self.add_to_conversation(conversation_id, model_content)
            
            # Persist synchronously (best effort)
            self._persist_conversation_sync(conversation_id, contents, response)
        
        return response
    
    def _persist_conversation_sync(
        self,
        conversation_id: str,
        user_contents: List[Any],
        response: Any,
    ) -> None:
        """Persist conversation to ChatHistoryService synchronously.
        
        Args:
            conversation_id: Conversation ID
            user_contents: User content that was sent
            response: Model response
        """
        if not self._chat_history_service:
            return
        
        try:
            import asyncio
            
            # Extract user message text
            user_text = ""
            for content in user_contents:
                if hasattr(content, 'parts'):
                    for part in content.parts:
                        if hasattr(part, 'text') and part.text:
                            user_text += part.text
            
            # Extract assistant response text
            assistant_text = ""
            if response.candidates:
                for part in response.candidates[0].content.parts:
                    if hasattr(part, 'text') and part.text:
                        assistant_text += part.text
            
            # Run async save in sync context
            async def _save():
                if user_text:
                    await self._chat_history_service.save_message(
                        session_id=conversation_id,
                        role="user",
                        content=user_text,
                    )
                if assistant_text:
                    await self._chat_history_service.save_message(
                        session_id=conversation_id,
                        role="assistant",
                        content=assistant_text,
                    )
            
            try:
                loop = asyncio.get_running_loop()
                # If in async context, schedule as task
                asyncio.create_task(_save())
            except RuntimeError:
                # No running loop, run directly
                asyncio.run(_save())
            
            logger.debug(f"Persisted conversation {conversation_id} to ChatHistoryService (sync)")
        except Exception as e:
            logger.warning(f"Failed to persist conversation {conversation_id}: {e}")


@dataclass
class GeminiADKRunner:
    """Native Google GenAI runner for Gemini 3+ models.
    
    This runner uses the native Google GenAI SDK which handles thought_signature
    automatically. It provides a simple interface for chat with optional tools.
    
    Supports conversation_id for stateful multi-turn conversations:
    - Conversation history is automatically managed per conversation_id
    - History is prepended to each request for context continuity
    - Optional integration with ChatHistoryService for persistence
    
    Attributes:
        model_id: Gemini model identifier
        api_key: Google API key
        instructions: System instructions
        temperature: Sampling temperature
        max_tokens: Maximum output tokens
    """
    
    model_id: str = "gemini-3-flash-preview"
    api_key: Optional[str] = None
    instructions: str = "You are a helpful assistant."
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    
    _client: Optional[GeminiNativeClient] = field(default=None, repr=False)
    
    def __post_init__(self):
        """Initialize the native client."""
        if not GOOGLE_GENAI_AVAILABLE:
            raise ImportError("google-genai not installed. Install with: uv add google-genai")
        
        self._client = GeminiNativeClient(
            model_id=self.model_id,
            api_key=self.api_key,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
    
    def set_chat_history_service(self, service: "ChatHistoryService") -> None:
        """Set the ChatHistoryService for persistent conversation storage.
        
        Args:
            service: ChatHistoryService instance
        """
        if self._client:
            self._client.set_chat_history_service(service)
    
    def get_conversation_history(self, conversation_id: str) -> List[Any]:
        """Get conversation history for a specific conversation_id.
        
        Args:
            conversation_id: Unique conversation identifier
            
        Returns:
            List of Content objects for the conversation
        """
        if self._client:
            return self._client.get_conversation_history(conversation_id)
        return []
    
    def clear_conversation(self, conversation_id: str) -> None:
        """Clear conversation history for a specific conversation_id.
        
        Args:
            conversation_id: Unique conversation identifier
        """
        if self._client:
            self._client.clear_conversation(conversation_id)
    
    def list_conversations(self) -> List[str]:
        """List all active conversation IDs.
        
        Returns:
            List of conversation IDs
        """
        if self._client:
            return self._client.list_conversations()
        return []
    
    async def run_async(
        self,
        message: str,
        tools: Optional[List[Any]] = None,
        conversation_id: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Run chat asynchronously.
        
        When conversation_id is provided, the conversation history is automatically
        managed - previous turns are included for context and the response is stored.
        
        Args:
            message: User message
            tools: Optional list of tools (in OpenAI or GenAI format)
            conversation_id: Optional conversation ID for stateful conversations
            **kwargs: Additional parameters
            
        Returns:
            Dict with content, tool_calls, role, model, conversation_id
        """
        # Convert tools if needed
        genai_tools = None
        if tools:
            if isinstance(tools[0], dict):
                genai_tools = convert_openai_tools_to_genai(tools)
            else:
                genai_tools = tools
        
        # Create user content
        contents = [
            genai_types.Content(
                role="user",
                parts=[genai_types.Part(text=message)]
            )
        ]
        
        # Generate response with conversation context
        response = await self._client.generate_content_async(
            contents=contents,
            system_instruction=self.instructions,
            tools=genai_tools,
            conversation_id=conversation_id,
        )
        
        return self._parse_response(response, conversation_id)
    
    def run_sync(
        self,
        message: str,
        tools: Optional[List[Any]] = None,
        conversation_id: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Run chat synchronously.
        
        When conversation_id is provided, the conversation history is automatically
        managed - previous turns are included for context and the response is stored.
        
        Args:
            message: User message
            tools: Optional list of tools
            conversation_id: Optional conversation ID for stateful conversations
            **kwargs: Additional parameters
            
        Returns:
            Dict with content, tool_calls, role, model, conversation_id
        """
        # Convert tools if needed
        genai_tools = None
        if tools:
            if isinstance(tools[0], dict):
                genai_tools = convert_openai_tools_to_genai(tools)
            else:
                genai_tools = tools
        
        # Create user content
        contents = [
            genai_types.Content(
                role="user",
                parts=[genai_types.Part(text=message)]
            )
        ]
        
        # Generate response with conversation context
        response = self._client.generate_content_sync(
            contents=contents,
            system_instruction=self.instructions,
            tools=genai_tools,
            conversation_id=conversation_id,
        )
        
        return self._parse_response(response, conversation_id)
    
    def run_with_history_sync(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Any]] = None,
        conversation_id: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Run chat synchronously with full conversation history.
        
        This method accepts a list of messages (OpenAI format) and converts them
        to GenAI format, providing full conversation context to the model.
        
        Args:
            messages: List of messages in OpenAI format [{role, content}, ...]
            tools: Optional list of tools
            conversation_id: Optional conversation ID for additional state tracking
            **kwargs: Additional parameters
            
        Returns:
            Dict with content, tool_calls, role, model, conversation_id
        """
        # Convert tools if needed
        genai_tools = None
        if tools:
            if isinstance(tools[0], dict):
                genai_tools = convert_openai_tools_to_genai(tools)
            else:
                genai_tools = tools
        
        # Convert messages to GenAI Content format
        contents = []
        system_instruction = self.instructions
        
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            if role == "system":
                # System messages become system instruction
                system_instruction = content
            elif role == "user":
                contents.append(genai_types.Content(
                    role="user",
                    parts=[genai_types.Part(text=content)]
                ))
            elif role in ("assistant", "model"):
                contents.append(genai_types.Content(
                    role="model",
                    parts=[genai_types.Part(text=content)]
                ))
        
        if not contents:
            return {
                "content": "",
                "tool_calls": None,
                "role": "assistant",
                "model": self.model_id,
            }
        
        # Generate response - pass full history directly, no conversation_id tracking needed
        # since history is already included
        response = self._client.generate_content_sync(
            contents=contents,
            system_instruction=system_instruction,
            tools=genai_tools,
            conversation_id=None,  # History already included
        )
        
        return self._parse_response(response, conversation_id)
    
    async def run_with_history_async(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Any]] = None,
        conversation_id: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Run chat asynchronously with full conversation history.
        
        This method accepts a list of messages (OpenAI format) and converts them
        to GenAI format, providing full conversation context to the model.
        
        Args:
            messages: List of messages in OpenAI format [{role, content}, ...]
            tools: Optional list of tools
            conversation_id: Optional conversation ID for additional state tracking
            **kwargs: Additional parameters
            
        Returns:
            Dict with content, tool_calls, role, model, conversation_id
        """
        # Convert tools if needed
        genai_tools = None
        if tools:
            if isinstance(tools[0], dict):
                genai_tools = convert_openai_tools_to_genai(tools)
            else:
                genai_tools = tools
        
        # Convert messages to GenAI Content format
        contents = []
        system_instruction = self.instructions
        
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            if role == "system":
                system_instruction = content
            elif role == "user":
                contents.append(genai_types.Content(
                    role="user",
                    parts=[genai_types.Part(text=content)]
                ))
            elif role in ("assistant", "model"):
                contents.append(genai_types.Content(
                    role="model",
                    parts=[genai_types.Part(text=content)]
                ))
        
        if not contents:
            return {
                "content": "",
                "tool_calls": None,
                "role": "assistant",
                "model": self.model_id,
            }
        
        # Generate response - pass full history directly
        response = await self._client.generate_content_async(
            contents=contents,
            system_instruction=system_instruction,
            tools=genai_tools,
            conversation_id=None,  # History already included
        )
        
        return self._parse_response(response, conversation_id)
    
    def _parse_response(
        self,
        response: Any,
        conversation_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Parse GenAI response to dict format.
        
        Args:
            response: GenerateContentResponse
            conversation_id: Optional conversation ID to include in response
            
        Returns:
            Dict with content, tool_calls, role, model, conversation_id
        """
        if not response.candidates:
            result = {
                "content": "",
                "tool_calls": None,
                "role": "assistant",
                "model": self.model_id,
            }
            if conversation_id:
                result["conversation_id"] = conversation_id
            return result
        
        candidate = response.candidates[0]
        content = candidate.content
        
        text_content = ""
        tool_calls = []
        
        for part in content.parts:
            if hasattr(part, 'text') and part.text:
                text_content += part.text
            
            if hasattr(part, 'function_call') and part.function_call:
                fc = part.function_call
                call_id = f"call_{uuid.uuid4().hex[:8]}"
                tool_calls.append({
                    "id": call_id,
                    "type": "function",
                    "function": {
                        "name": fc.name,
                        "arguments": json.dumps(dict(fc.args)) if fc.args else "{}",
                    },
                })
        
        result = {
            "content": text_content,
            "tool_calls": tool_calls if tool_calls else None,
            "role": "assistant",
            "model": self.model_id,
        }
        if conversation_id:
            result["conversation_id"] = conversation_id
        
        return result
