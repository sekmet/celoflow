"""Resilient model wrapper with error handling and fallbacks.

This module provides a transparent Model wrapper that adds retry logic,
circuit breakers, and multi-provider fallback using the error_handler
orchestrator. Zero modifications to Agent required.

Usage:
    from contextwise.lib.models import with_resilience

    model = with_resilience(
        primary="gemini-3-flash-preview",
        fallbacks=["llama-3.3-70b-versatile", "gpt-4o-mini"],
    )
    agent = Agent(model=model, instructions="...")
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Iterator, List, Optional, Union

from .base import Model, ModelMessage, ModelResponse
from ..error_handler import (
    ErrorHandlingOrchestrator,
    ErrorHandlerConfig,
    ErrorContext,
    ErrorHandlingResult,
    AllProvidersFailedError,
)

logger = logging.getLogger(__name__)


class LocalizedError(Exception):
    """User-facing error with localization context."""

    def __init__(self, message: str, original_error: Exception, locale: str):
        super().__init__(message)
        self.original_error = original_error
        self.locale = locale


@dataclass
class ResilientModel(Model):
    """Wraps any Model with error handling and fallbacks.

    Implements the same Model interface, so Agent accepts it transparently.
    Uses the full ErrorHandlingOrchestrator for retry, circuit breaker,
    and fallback logic.

    Attributes:
        id: Delegates to primary model's ID.
        name: Delegates to primary model's name.
        provider: Delegates to primary model's provider.
    """

    # Override base defaults — will be set from primary in __post_init__
    id: str = ""
    name: Optional[str] = None
    provider: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    base_url: Optional[str] = None

    # Resilient-specific fields
    _primary: Model = field(default=None, repr=False)
    _fallbacks: List[Model] = field(default_factory=list, repr=False)
    _locale: str = field(default="en", repr=False)
    _orchestrator: Optional[ErrorHandlingOrchestrator] = field(
        default=None, repr=False
    )
    _config: Optional[ErrorHandlerConfig] = field(default=None, repr=False)
    _chat_history_service: Optional[Any] = field(default=None, repr=False)

    def __post_init__(self):
        """Propagate primary model attributes to this wrapper."""
        if self._primary is not None:
            self.id = self._primary.id
            self.name = self._primary.name or self._primary.id
            self.provider = self._primary.provider
            self.temperature = self._primary.temperature
            self.max_tokens = self._primary.max_tokens
            self.base_url = getattr(self._primary, "base_url", None)

            # Copy Gemini-specific attributes if present
            if hasattr(self._primary, "use_native_sdk"):
                self.use_native_sdk = self._primary.use_native_sdk
            if hasattr(self._primary, "api_key"):
                self.api_key = self._primary.api_key
            
            # Copy conversation history service if present
            if hasattr(self._primary, "_chat_history_service") and self._primary._chat_history_service:
                self._chat_history_service = self._primary._chat_history_service
                # Also set it on fallback models if they support it
                for fallback in self._fallbacks:
                    if hasattr(fallback, "set_chat_history_service"):
                        fallback.set_chat_history_service(self._chat_history_service)

    @property
    def orchestrator(self) -> ErrorHandlingOrchestrator:
        """Lazy-initialize orchestrator on first use."""
        if self._orchestrator is None:
            config = self._config or ErrorHandlerConfig.from_env()
            config.default_locale = self._locale
            self._orchestrator = ErrorHandlingOrchestrator(config=config)
        return self._orchestrator

    # ── Sync chat ────────────────────────────────────────────────────

    def chat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Sync chat with error handling and fallbacks."""
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(
                    asyncio.run, self.achat(messages, **kwargs)
                )
                return future.result()
        else:
            return asyncio.run(self.achat(messages, **kwargs))

    # ── Async chat ───────────────────────────────────────────────────

    async def achat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Async chat with error handling and fallbacks."""
        context = self._create_context(self._primary)

        # Build primary operation
        async def primary_op(**model_kwargs):
            # Filter out orchestrator-specific parameters
            filtered_kwargs = {k: v for k, v in model_kwargs.items() 
                            if k not in ['fallback_providers', 'fallback_operations']}
            return await self._primary.achat(messages, **filtered_kwargs)

        # Build fallback operations
        fallback_ops = []
        fallback_provider_ids = []
        for fb_model in self._fallbacks:
            async def _make_fb_op(m=fb_model, **model_kwargs):
                # Filter out orchestrator-specific parameters
                filtered_kwargs = {k: v for k, v in model_kwargs.items() 
                                if k not in ['fallback_providers', 'fallback_operations']}
                return await m.achat(messages, **filtered_kwargs)

            fallback_ops.append(_make_fb_op)
            fallback_provider_ids.append(fb_model.provider or fb_model.id)

        result: ErrorHandlingResult = (
            await self.orchestrator.execute_with_resilience(
                operation=primary_op,
                context=context,
                fallback_operations=fallback_ops if fallback_ops else None,
                fallback_providers=fallback_provider_ids,
            )
        )

        if result.success and result.response is not None:
            response = result.response
            if isinstance(response, ModelResponse):
                if result.fallback_used:
                    self._mark_fallback_used(response, result)
                return response
            # Wrap raw response
            return ModelResponse(
                content=str(response),
                role="assistant",
                raw_response={"resilient_result": True},
            )

        # All providers failed — raise localized error
        raise self._create_user_error(
            result.error or AllProvidersFailedError("All providers failed"),
            result.user_message,
        )

    # ── Sync streaming ───────────────────────────────────────────────

    def chat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> Iterator[ModelResponse]:
        """Streaming chat with fallbacks."""
        models_to_try = [self._primary] + self._fallbacks
        last_error: Optional[Exception] = None

        for model in models_to_try:
            try:
                yield from model.chat_stream(messages, **kwargs)
                return
            except Exception as e:
                logger.warning(
                    f"Streaming failed for {model.id}: {e}, "
                    f"trying next provider"
                )
                last_error = e
                continue

        raise self._create_user_error(
            last_error or AllProvidersFailedError("All providers failed")
        )

    # ── Async streaming ──────────────────────────────────────────────

    async def achat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> AsyncIterator[ModelResponse]:
        """Async streaming chat with fallbacks."""
        models_to_try = [self._primary] + self._fallbacks
        last_error: Optional[Exception] = None

        for model in models_to_try:
            try:
                async for chunk in model.achat_stream(messages, **kwargs):
                    yield chunk
                return
            except Exception as e:
                logger.warning(
                    f"Async streaming failed for {model.id}: {e}, "
                    f"trying next provider"
                )
                last_error = e
                continue

        raise self._create_user_error(
            last_error or AllProvidersFailedError("All providers failed")
        )

    # ── Internal helpers ─────────────────────────────────────────────

    def _create_context(self, model: Model) -> ErrorContext:
        """Create error context for a model."""
        return ErrorContext(
            provider_id=model.provider or model.id or "unknown",
            operation="chat",
            attempt=1,
            total_cost=0.0,
            user_locale=self._locale,
            metadata={"model": model.id},
        )

    @staticmethod
    def _mark_fallback_used(
        response: ModelResponse, result: ErrorHandlingResult
    ) -> None:
        """Annotate response with fallback metadata."""
        if response.raw_response is None:
            response.raw_response = {}
        if isinstance(response.raw_response, dict):
            response.raw_response["fallback_used"] = True
            response.raw_response["provider_used"] = result.provider_used
            response.raw_response["providers_tried"] = result.providers_tried

    def _create_user_error(
        self,
        error: Exception,
        user_message: Optional[str] = None,
    ) -> LocalizedError:
        """Create localized user-facing error."""
        if user_message:
            return LocalizedError(user_message, error, self._locale)

        if self._locale.startswith("pt"):
            message = (
                "Desculpe, estou com dificuldades técnicas. "
                "Por favor, tente novamente."
            )
        elif self._locale.startswith("es"):
            message = (
                "Lo siento, estoy experimentando dificultades técnicas. "
                "Por favor, inténtelo de nuevo."
            )
        else:
            message = (
                "Sorry, I'm experiencing technical difficulties. "
                "Please try again."
            )

        return LocalizedError(message, error, self._locale)

    # ── Conversation History Management ──────────────────────────────────

    def set_chat_history_service(self, service: Any) -> None:
        """Set the ChatHistoryService for persistent conversation storage.
        
        Args:
            service: ChatHistoryService instance
        """
        self._chat_history_service = service
        # Propagate to primary and fallback models
        if self._primary and hasattr(self._primary, "set_chat_history_service"):
            self._primary.set_chat_history_service(service)
        for fallback in self._fallbacks:
            if hasattr(fallback, "set_chat_history_service"):
                fallback.set_chat_history_service(service)
        logger.debug(f"ChatHistoryService attached to ResilientModel")
    
    def get_conversation_history(self, conversation_id: str) -> List[Any]:
        """Get conversation history for a specific conversation_id.
        
        Args:
            conversation_id: Unique conversation identifier
            
        Returns:
            List of conversation content
        """
        if self._primary and hasattr(self._primary, "get_conversation_history"):
            return self._primary.get_conversation_history(conversation_id)
        return []
    
    def clear_conversation(self, conversation_id: str) -> None:
        """Clear conversation history for a specific conversation_id.
        
        Args:
            conversation_id: Unique conversation identifier
        """
        if self._primary and hasattr(self._primary, "clear_conversation"):
            self._primary.clear_conversation(conversation_id)
        for fallback in self._fallbacks:
            if hasattr(fallback, "clear_conversation"):
                fallback.clear_conversation(conversation_id)
    
    def list_conversations(self) -> List[str]:
        """List all active conversation IDs.
        
        Returns:
            List of conversation IDs
        """
        if self._primary and hasattr(self._primary, "list_conversations"):
            return self._primary.list_conversations()
        return []


# ── Convenience functions ────────────────────────────────────────────


def with_resilience(
    primary: Union[str, Model],
    fallbacks: Optional[List[Union[str, Model]]] = None,
    max_retries: int = 3,
    locale: str = "en",
    **kwargs,
) -> Model:
    """Wrap a model with error handling and fallbacks.

    Convenience function that:
    1. Creates Model instances from strings if needed
    2. Wraps with ResilientModel
    3. Returns a Model that works transparently with Agent

    Args:
        primary: Primary model (string ID or Model instance).
        fallbacks: Optional list of fallback models (strings or Model instances).
        max_retries: Maximum retry attempts per model.
        locale: Locale for error messages.
        **kwargs: Additional config (temperature, etc.).

    Returns:
        ResilientModel instance that works with Agent.

    Example:
        model = with_resilience(
            primary="gemini-3-flash-preview",
            fallbacks=["llama-3.3-70b-versatile", "gpt-4o-mini"],
        )
        agent = Agent(model=model, instructions="...")
    """
    primary_model = _resolve_model(primary, **kwargs)

    fallback_models: List[Model] = []
    if fallbacks:
        for fb in fallbacks:
            fallback_models.append(_resolve_model(fb, **kwargs))

    config = ErrorHandlerConfig.from_env()
    config.max_retries = max_retries
    config.default_locale = locale

    return ResilientModel(
        _primary=primary_model,
        _fallbacks=fallback_models,
        _locale=locale,
        _config=config,
    )


def with_resilience_from_env(
    primary: Union[str, Model],
    **kwargs,
) -> Model:
    """Create resilient model with config from environment variables.

    Environment Variables:
        ERROR_HANDLER_ENABLED: Enable error handling (default: true).
        ERROR_HANDLER_FALLBACKS: Comma-separated fallback model IDs.
        ERROR_HANDLER_MAX_RETRIES: Max retries per model (default: 3).
        ERROR_HANDLER_LOCALE: Error message locale (default: en).

    Args:
        primary: Primary model (string ID or Model instance).
        **kwargs: Additional config (temperature, etc.).

    Returns:
        ResilientModel if enabled, otherwise unwrapped Model.

    Example:
        model = with_resilience_from_env("gemini-3-flash-preview")
        agent = Agent(model=model, instructions="...")
    """
    enabled = os.getenv("ERROR_HANDLER_ENABLED", "true").lower() == "true"
    if not enabled:
        return _resolve_model(primary, **kwargs)

    fallback_str = os.getenv("ERROR_HANDLER_FALLBACKS", "")
    fallbacks = [fb.strip() for fb in fallback_str.split(",") if fb.strip()]

    max_retries = int(os.getenv("ERROR_HANDLER_MAX_RETRIES", "3"))
    locale = os.getenv("ERROR_HANDLER_LOCALE", "en")

    return with_resilience(
        primary=primary,
        fallbacks=fallbacks or None,
        max_retries=max_retries,
        locale=locale,
        **kwargs,
    )


def _resolve_model(model: Union[str, Model], **kwargs) -> Model:
    """Resolve model string to Model instance.

    Detects provider from model ID string and creates the appropriate
    Model subclass with sensible defaults.

    Args:
        model: Model string ID or existing Model instance.
        **kwargs: Override temperature, use_native_sdk, etc.

    Returns:
        Concrete Model instance.
    """
    if not isinstance(model, str):
        return model

    from .gemini import GeminiModel
    from .groq import GroqModel
    from .openai import OpenAIModel

    model_lower = model.lower()

    if "gemini" in model_lower:
        return GeminiModel(
            id=model,
            api_key=os.getenv("GEMINI_API_KEY"),
            use_native_sdk=kwargs.get("use_native_sdk", True),
            temperature=kwargs.get("temperature"),
            max_tokens=kwargs.get("max_tokens"),
        )

    if "llama" in model_lower or "mixtral" in model_lower:
        return GroqModel(
            id=model,
            api_key=os.getenv("GROQ_API_KEY"),
            temperature=kwargs.get("temperature"),
            max_tokens=kwargs.get("max_tokens"),
        )

    if "gpt" in model_lower or "o1" in model_lower or "o3" in model_lower:
        return OpenAIModel(
            id=model,
            api_key=os.getenv("OPENAI_API_KEY"),
            temperature=kwargs.get("temperature"),
            max_tokens=kwargs.get("max_tokens"),
        )

    # Default to OpenAI-compatible
    return OpenAIModel(
        id=model,
        api_key=os.getenv("OPENAI_API_KEY"),
        temperature=kwargs.get("temperature"),
        max_tokens=kwargs.get("max_tokens"),
    )
