"""Native Gemini Model for OpenAI Agents SDK.

This module provides an agents SDK-compatible Model implementation that uses
the native Google GenAI SDK. This enables proper thought_signature handling
for Gemini 3+ models with tool calling.

The Google GenAI SDK handles thought_signature automatically - no manual
management required.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..session.chat_history_service import ChatHistoryService

logger = logging.getLogger(__name__)

# Google GenAI SDK
try:
    from google import genai
    from google.genai import types as genai_types
    GOOGLE_GENAI_AVAILABLE = True
except ImportError:
    GOOGLE_GENAI_AVAILABLE = False
    genai = None
    genai_types = None

# Agents SDK
try:
    from agents.models.interface import Model, ModelProvider
    from agents.items import (
        ModelResponse, 
        ResponseOutputMessage, 
        ResponseOutputText,
        ResponseFunctionToolCall,
        ResponseOutputRefusal,
    )
    from agents.usage import Usage
    from agents.tool import Tool, FunctionTool
    from agents.handoffs import Handoff
    from agents.model_settings import ModelSettings
    from agents.agent_output import AgentOutputSchemaBase
    AGENTS_SDK_AVAILABLE = True
    # ModelTracing is optional - used for type hints only
    try:
        from agents.tracing import ModelTracing
    except ImportError:
        ModelTracing = None
except ImportError:
    AGENTS_SDK_AVAILABLE = False
    Model = object
    ModelProvider = object
    ModelTracing = None
    Usage = None


def clean_schema_for_genai(schema: dict) -> dict:
    """Clean JSON schema for Google GenAI compatibility."""
    if not isinstance(schema, dict):
        return schema
    
    unsupported_keys = {
        'additional_properties', 'additionalProperties', 
        '$schema', '$id', '$ref', '$defs', 'definitions',
        'thought_signature', 'strict', 'title'
    }
    
    cleaned = {}
    for key, value in schema.items():
        if key in unsupported_keys:
            continue
        if isinstance(value, dict):
            cleaned[key] = clean_schema_for_genai(value)
        elif isinstance(value, list):
            cleaned[key] = [
                clean_schema_for_genai(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            cleaned[key] = value
    
    return cleaned


@dataclass
class GeminiNativeModel(Model):
    """Agents SDK Model using native Google GenAI SDK.
    
    This model uses the native Google GenAI SDK which handles thought_signature
    automatically for Gemini 3+ models with tool calling.
    
    Supports conversation_id for stateful multi-turn conversations:
    - In-memory conversation history tracking per conversation_id
    - Optional integration with ChatHistoryService for persistent storage
    - Thread-safe conversation state management
    
    Attributes:
        model_id: Gemini model ID (e.g., "gemini-3-flash-preview")
        api_key: Google API key
        temperature: Sampling temperature
        max_tokens: Maximum output tokens
    """
    
    model_id: str = "gemini-3-flash-preview"
    api_key: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    
    _client: Optional[Any] = field(default=None, repr=False, init=False)
    _conversation_history: List[Any] = field(default_factory=list, repr=False, init=False)
    _conversations: Dict[str, List[Any]] = field(default_factory=dict, repr=False, init=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False, init=False)
    _chat_history_service: Optional["ChatHistoryService"] = field(default=None, repr=False, init=False)
    
    def __post_init__(self):
        if not GOOGLE_GENAI_AVAILABLE:
            raise ImportError("google-genai not installed. Install with: uv add google-genai")
        
        if not self.api_key:
            self.api_key = os.getenv("GEMINI_API_KEY")
        
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY not provided")
        
        self._client = genai.Client(api_key=self.api_key)
        self._conversation_history = []
        self._conversations = {}
        self._lock = threading.Lock()
    
    def set_chat_history_service(self, service: "ChatHistoryService") -> None:
        """Set the ChatHistoryService for persistent conversation storage.
        
        Args:
            service: ChatHistoryService instance
        """
        self._chat_history_service = service
        logger.debug(f"ChatHistoryService attached to GeminiNativeModel")
    
    def get_conversation_history(self, conversation_id: str) -> List[Any]:
        """Get conversation history for a specific conversation_id.
        
        Args:
            conversation_id: Unique conversation identifier
            
        Returns:
            List of Content objects for the conversation
        """
        with self._lock:
            return list(self._conversations.get(conversation_id, []))
    
    def add_to_conversation(
        self,
        conversation_id: str,
        content: Any,
        role: Optional[str] = None,
    ) -> None:
        """Add content to conversation history.
        
        Args:
            conversation_id: Unique conversation identifier
            content: Content object or text string to add
            role: Role for the content (user/model) if content is string
        """
        with self._lock:
            if conversation_id not in self._conversations:
                self._conversations[conversation_id] = []
            
            if isinstance(content, str):
                content = genai_types.Content(
                    role=role or "user",
                    parts=[genai_types.Part(text=content)]
                )
            
            self._conversations[conversation_id].append(content)
            logger.debug(f"Added content to conversation {conversation_id}, total: {len(self._conversations[conversation_id])}")
    
    def clear_conversation(self, conversation_id: str) -> None:
        """Clear conversation history for a specific conversation_id.
        
        Args:
            conversation_id: Unique conversation identifier
        """
        with self._lock:
            if conversation_id in self._conversations:
                del self._conversations[conversation_id]
                logger.debug(f"Cleared conversation {conversation_id}")
    
    def list_conversations(self) -> List[str]:
        """List all active conversation IDs.
        
        Returns:
            List of conversation IDs
        """
        with self._lock:
            return list(self._conversations.keys())
    
    def _convert_tools_to_genai(self, tools: List[Tool]) -> List[Any]:
        """Convert agents SDK tools to GenAI format."""
        if not tools:
            return []
        
        declarations = []
        for tool in tools:
            if isinstance(tool, FunctionTool):
                params_schema = {}
                if hasattr(tool, 'params_json_schema') and tool.params_json_schema:
                    params_schema = clean_schema_for_genai(tool.params_json_schema)
                
                decl = genai_types.FunctionDeclaration(
                    name=tool.name,
                    description=tool.description or "",
                    parameters=params_schema if params_schema else None,
                )
                declarations.append(decl)
        
        if declarations:
            return [genai_types.Tool(function_declarations=declarations)]
        return []
    
    def _convert_input_to_genai(
        self,
        system_instructions: Optional[str],
        input_items: Any,
    ) -> tuple[Optional[str], List[Any]]:
        """Convert agents SDK input to GenAI format.
        
        Handles:
        - String input (user message)
        - List input (conversation history)
        - Tool call items (model's function calls)
        - Tool call output items (function results)
        """
        contents = []
        
        logger.debug(f"_convert_input_to_genai: input type={type(input_items)}")
        
        # Handle string input
        if isinstance(input_items, str):
            contents.append(genai_types.Content(
                role="user",
                parts=[genai_types.Part(text=input_items)]
            ))
            return system_instructions, contents
        
        # Handle None or empty input
        if input_items is None:
            return system_instructions, contents
        
        # Handle list input (conversation history from agents SDK)
        if isinstance(input_items, list):
            # Group consecutive tool calls and their outputs for proper ordering
            pending_function_calls = []  # Model's function calls
            pending_function_responses = []  # Tool outputs
            
            for item in input_items:
                item_type = getattr(item, 'type', None) or (item.get('type') if isinstance(item, dict) else None)
                
                # Handle tool_call_item (model's function call)
                if item_type == 'tool_call_item':
                    # Flush any pending text content first
                    self._flush_pending_to_contents(contents, pending_function_calls, pending_function_responses)
                    pending_function_calls = []
                    pending_function_responses = []
                    
                    raw_item = getattr(item, 'raw_item', item)
                    if hasattr(raw_item, 'name') and hasattr(raw_item, 'arguments'):
                        # This is a function call from the model
                        args_str = raw_item.arguments if isinstance(raw_item.arguments, str) else json.dumps(raw_item.arguments)
                        try:
                            args_dict = json.loads(args_str) if args_str else {}
                        except (json.JSONDecodeError, TypeError):
                            args_dict = {}
                        
                        fc_part = genai_types.Part(
                            function_call=genai_types.FunctionCall(
                                name=raw_item.name,
                                args=args_dict
                            )
                        )
                        pending_function_calls.append(fc_part)
                        logger.debug(f"Added function_call: {raw_item.name}")
                    continue
                
                # Handle tool_call_output_item (tool result)
                if item_type == 'tool_call_output_item':
                    raw_item = getattr(item, 'raw_item', item)
                    output = getattr(item, 'output', None)
                    
                    # Get function name and call_id
                    func_name = None
                    if isinstance(raw_item, dict):
                        func_name = raw_item.get('name')
                        if not func_name and 'call_id' in raw_item:
                            # Try to extract name from call_id or use generic
                            func_name = raw_item.get('call_id', 'function').split('_')[0]
                    elif hasattr(raw_item, 'name'):
                        func_name = raw_item.name
                    
                    if not func_name:
                        func_name = 'function'
                    
                    # Convert output to string
                    if output is None:
                        output_str = "null"
                    elif isinstance(output, str):
                        output_str = output
                    else:
                        try:
                            output_str = json.dumps(output)
                        except (TypeError, ValueError):
                            output_str = str(output)
                    
                    fr_part = genai_types.Part(
                        function_response=genai_types.FunctionResponse(
                            name=func_name,
                            response={"result": output_str}
                        )
                    )
                    pending_function_responses.append(fr_part)
                    logger.debug(f"Added function_response for: {func_name}")
                    continue
                
                # Flush pending function calls/responses before processing other items
                self._flush_pending_to_contents(contents, pending_function_calls, pending_function_responses)
                pending_function_calls = []
                pending_function_responses = []
                
                # Handle dict-style items
                if isinstance(item, dict):
                    role = item.get('role', 'user')
                    content = item.get('content', '')
                    item_type_dict = item.get('type', '')
                    
                    # Skip function_call_output dict items (handled above)
                    if item_type_dict == 'function_call_output':
                        func_name = item.get('name', 'function')
                        output = item.get('output', '')
                        if isinstance(output, str):
                            output_str = output
                        else:
                            try:
                                output_str = json.dumps(output)
                            except (TypeError, ValueError):
                                output_str = str(output)
                        
                        contents.append(genai_types.Content(
                            role="user",
                            parts=[genai_types.Part(
                                function_response=genai_types.FunctionResponse(
                                    name=func_name,
                                    response={"result": output_str}
                                )
                            )]
                        ))
                        continue
                    
                    if role == 'user':
                        if isinstance(content, str) and content:
                            contents.append(genai_types.Content(
                                role="user",
                                parts=[genai_types.Part(text=content)]
                            ))
                        elif isinstance(content, list):
                            parts = []
                            for part in content:
                                if isinstance(part, dict) and 'text' in part:
                                    parts.append(genai_types.Part(text=part['text']))
                                elif isinstance(part, str):
                                    parts.append(genai_types.Part(text=part))
                            if parts:
                                contents.append(genai_types.Content(role="user", parts=parts))
                    elif role in ('assistant', 'model'):
                        # Handle string content
                        if isinstance(content, str) and content:
                            contents.append(genai_types.Content(
                                role="model",
                                parts=[genai_types.Part(text=content)]
                            ))
                        # Handle list content (SDK format with output_text objects)
                        elif isinstance(content, list):
                            text_parts = []
                            for part in content:
                                if isinstance(part, dict):
                                    # Handle SDK output_text format: {'text': '...', 'type': 'output_text'}
                                    if 'text' in part:
                                        text_parts.append(part['text'])
                                elif isinstance(part, str):
                                    text_parts.append(part)
                            if text_parts:
                                combined_text = "".join(text_parts)
                                contents.append(genai_types.Content(
                                    role="model",
                                    parts=[genai_types.Part(text=combined_text)]
                                ))
                    continue
                
                # Handle object-style items (agents SDK format)
                if hasattr(item, 'role'):
                    role = item.role
                    
                    # Get text content from item
                    text_content = None
                    if hasattr(item, 'content'):
                        if isinstance(item.content, str):
                            text_content = item.content
                        elif isinstance(item.content, list):
                            text_parts = []
                            for part in item.content:
                                if hasattr(part, 'text'):
                                    text_parts.append(part.text)
                                elif isinstance(part, str):
                                    text_parts.append(part)
                            text_content = "".join(text_parts) if text_parts else None
                    elif hasattr(item, 'text'):
                        text_content = item.text
                    
                    if text_content:
                        genai_role = "model" if role in ('assistant', 'model') else "user"
                        contents.append(genai_types.Content(
                            role=genai_role,
                            parts=[genai_types.Part(text=text_content)]
                        ))
                    continue
                
                # Handle string items directly
                if isinstance(item, str):
                    contents.append(genai_types.Content(
                        role="user",
                        parts=[genai_types.Part(text=item)]
                    ))
            
            # Flush any remaining pending items
            self._flush_pending_to_contents(contents, pending_function_calls, pending_function_responses)
        
        # If still no contents, try to extract text from the input object
        if not contents and input_items:
            if hasattr(input_items, 'text'):
                contents.append(genai_types.Content(
                    role="user",
                    parts=[genai_types.Part(text=input_items.text)]
                ))
            elif hasattr(input_items, 'content'):
                content = input_items.content
                if isinstance(content, str):
                    contents.append(genai_types.Content(
                        role="user",
                        parts=[genai_types.Part(text=content)]
                    ))
        
        logger.debug(f"_convert_input_to_genai: generated {len(contents)} content items")
        return system_instructions, contents
    
    def _flush_pending_to_contents(
        self,
        contents: List[Any],
        pending_function_calls: List[Any],
        pending_function_responses: List[Any],
    ) -> None:
        """Flush pending function calls and responses to contents list."""
        # Add model's function calls
        if pending_function_calls:
            contents.append(genai_types.Content(
                role="model",
                parts=pending_function_calls
            ))
        
        # Add tool responses
        if pending_function_responses:
            contents.append(genai_types.Content(
                role="user",
                parts=pending_function_responses
            ))
    
    def _convert_response_to_sdk(self, response: Any) -> ModelResponse:
        """Convert GenAI response to agents SDK ModelResponse."""
        # Create usage from response metadata if available
        usage_data = Usage(
            requests=1,
            input_tokens=getattr(response, 'prompt_token_count', 0) or 0,
            output_tokens=getattr(response, 'candidates_token_count', 0) or 0,
        )
        
        if not response.candidates:
            return ModelResponse(
                output=[ResponseOutputMessage(
                    id=f"msg_{uuid.uuid4().hex[:8]}",
                    type="message",
                    role="assistant",
                    status="completed",
                    content=[ResponseOutputText(type="output_text", text="", annotations=[])],
                )],
                usage=usage_data,
                response_id=f"resp_{uuid.uuid4().hex[:8]}",
            )
        
        candidate = response.candidates[0]
        content = candidate.content
        
        output_items = []
        text_parts = []
        function_calls = []
        
        for part in content.parts:
            if hasattr(part, 'text') and part.text:
                text_parts.append(part.text)
            
            if hasattr(part, 'function_call') and part.function_call:
                fc = part.function_call
                call_id = f"call_{uuid.uuid4().hex[:8]}"
                function_calls.append(ResponseFunctionToolCall(
                    id=call_id,
                    type="function_call",
                    call_id=call_id,
                    name=fc.name,
                    arguments=json.dumps(dict(fc.args)) if fc.args else "{}",
                ))
        
        # Add text content if present
        if text_parts:
            output_items.append(ResponseOutputMessage(
                id=f"msg_{uuid.uuid4().hex[:8]}",
                type="message",
                role="assistant",
                status="completed",
                content=[ResponseOutputText(type="output_text", text="".join(text_parts), annotations=[])],
            ))
        
        # Add function calls
        output_items.extend(function_calls)
        
        # If no output, add empty message
        if not output_items:
            output_items.append(ResponseOutputMessage(
                id=f"msg_{uuid.uuid4().hex[:8]}",
                type="message",
                role="assistant",
                status="completed",
                content=[ResponseOutputText(type="output_text", text="", annotations=[])],
            ))
        
        return ModelResponse(
            output=output_items,
            usage=usage_data,
            response_id=f"resp_{uuid.uuid4().hex[:8]}",
        )
    
    async def get_response(
        self,
        system_instructions: Optional[str],
        input: Any,
        model_settings: ModelSettings,
        tools: List[Tool],
        output_schema: Optional[AgentOutputSchemaBase],
        handoffs: List[Handoff],
        tracing: ModelTracing,
        *,
        previous_response_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        **kwargs,
    ) -> ModelResponse:
        """Get response using native GenAI SDK.
        
        The SDK handles thought_signature automatically.
        
        When conversation_id is provided, conversation history is automatically
        managed for multi-turn context.
        
        Args:
            system_instructions: System prompt
            input: User input (string or conversation history)
            model_settings: Model configuration
            tools: List of tools
            output_schema: Output schema (if any)
            handoffs: Handoff configurations
            tracing: Tracing configuration
            previous_response_id: Previous response ID (if any)
            conversation_id: Optional conversation ID for stateful conversations
            **kwargs: Additional parameters (may include conversation_id)
        """
        # Extract conversation_id from kwargs if not provided directly
        if conversation_id is None:
            conversation_id = kwargs.get('conversation_id')
        
        logger.debug(f"GeminiNativeModel.get_response for {self.model_id}, conversation_id={conversation_id}")
        
        # Convert tools
        genai_tools = self._convert_tools_to_genai(tools)
        
        # Convert input
        system_instr, contents = self._convert_input_to_genai(system_instructions, input)
        
        # Build full conversation context if conversation_id provided
        full_contents = contents
        if conversation_id:
            history = self.get_conversation_history(conversation_id)
            if history:
                full_contents = history + contents
                logger.debug(f"Conversation {conversation_id}: {len(history)} history + {len(contents)} new = {len(full_contents)} total")
        
        # Build config
        config_kwargs = {}
        if self.temperature is not None:
            config_kwargs["temperature"] = self.temperature
        elif model_settings and hasattr(model_settings, 'temperature') and model_settings.temperature is not None:
            config_kwargs["temperature"] = model_settings.temperature
        
        if self.max_tokens is not None:
            config_kwargs["max_output_tokens"] = self.max_tokens
        elif model_settings and hasattr(model_settings, 'max_tokens') and model_settings.max_tokens is not None:
            config_kwargs["max_output_tokens"] = model_settings.max_tokens
        
        config = None
        if system_instr or genai_tools or config_kwargs:
            config = genai_types.GenerateContentConfig(
                system_instruction=system_instr,
                tools=genai_tools if genai_tools else None,
                **config_kwargs,
            )
        
        try:
            # Use native GenAI SDK - handles thought_signature automatically
            response = await self._client.aio.models.generate_content(
                model=self.model_id,
                contents=full_contents,
                config=config,
            )
            
            # Store conversation state if conversation_id provided
            if conversation_id and response.candidates:
                # Add user content to history
                for content in contents:
                    self.add_to_conversation(conversation_id, content)
                
                # Add model response to history
                model_content = response.candidates[0].content
                self.add_to_conversation(conversation_id, model_content)
                
                # Persist to ChatHistoryService if available
                await self._persist_conversation_async(conversation_id, contents, response)
            
            logger.debug(f"GeminiNativeModel received response from {self.model_id}")
            return self._convert_response_to_sdk(response)
            
        except Exception as e:
            logger.error(f"GeminiNativeModel error: {e}")
            raise
    
    async def _persist_conversation_async(
        self,
        conversation_id: str,
        user_contents: List[Any],
        response: Any,
    ) -> None:
        """Persist conversation to ChatHistoryService if available.
        
        Args:
            conversation_id: Conversation ID
            user_contents: User content that was sent
            response: Model response
        """
        if not self._chat_history_service:
            return
        
        try:
            # Extract user message text
            user_text = ""
            for content in user_contents:
                if hasattr(content, 'parts'):
                    for part in content.parts:
                        if hasattr(part, 'text') and part.text:
                            user_text += part.text
            
            # Extract assistant response text
            assistant_text = ""
            if response.candidates:
                for part in response.candidates[0].content.parts:
                    if hasattr(part, 'text') and part.text:
                        assistant_text += part.text
            
            # Save messages to persistent storage
            if user_text:
                await self._chat_history_service.save_message(
                    session_id=conversation_id,
                    role="user",
                    content=user_text,
                )
            
            if assistant_text:
                await self._chat_history_service.save_message(
                    session_id=conversation_id,
                    role="assistant",
                    content=assistant_text,
                )
            
            logger.debug(f"Persisted conversation {conversation_id} to ChatHistoryService")
        except Exception as e:
            logger.warning(f"Failed to persist conversation {conversation_id}: {e}")
    
    def stream_response(self, *args, **kwargs):
        """Streaming not yet implemented for native model."""
        raise NotImplementedError("Streaming not yet implemented for GeminiNativeModel")


@dataclass
class GeminiNativeModelProvider(ModelProvider):
    """Model provider for native Gemini models.
    
    Returns GeminiNativeModel instances which use the native GenAI SDK
    for proper thought_signature handling.
    """
    
    api_key: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    
    def get_model(self, model_name: Optional[str]) -> GeminiNativeModel:
        """Get a native Gemini model."""
        return GeminiNativeModel(
            model_id=model_name or "gemini-3-flash-preview",
            api_key=self.api_key,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )


def is_gemini_native_model_available() -> bool:
    """Check if native Gemini model is available."""
    return AGENTS_SDK_AVAILABLE and GOOGLE_GENAI_AVAILABLE
