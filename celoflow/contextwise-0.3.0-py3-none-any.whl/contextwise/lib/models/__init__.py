"""Model module for contextwise.

This module provides language model abstractions for chat completions.

Supported providers:
- OpenAI (GPT-4o, GPT-4o-mini, etc.)
- Groq (LLaMA 3.3, Mixtral, etc.)
- Google Gemini (gemini-2.0-flash, etc.)
- Ollama (local models - LLaMA, Mistral, etc.)
- Cloudflare Workers AI (edge inference - @cf/ models)
- Azure AI Forge (enterprise - GPT-5-mini, Grok-4, Kimi-K2.5, etc.)
- Cerebras (high-performance - llama-3.3-70b, gpt-oss-120b, etc.)

Example:
    >>> from contextwise.lib.models import OpenAIModel, ModelMessage
    >>> 
    >>> model = OpenAIModel(id="gpt-4o-mini")
    >>> response = model.chat([
    ...     ModelMessage(role="user", content="Hello!"),
    ... ])
    >>> print(response.content)
    
    >>> from contextwise.lib.models import GroqModel
    >>> model = GroqModel(id="openai/gpt-oss-120b")
    >>> response = model.chat([...])
    
    >>> from contextwise.lib.models import GeminiModel
    >>> model = GeminiModel(id="gemini-2.0-flash-001")
    >>> response = model.chat([...])
    
    >>> from contextwise.lib.models import OllamaModel
    >>> model = OllamaModel(id="llama3.2:latest")
    >>> response = model.chat([...])
    
    >>> from contextwise.lib.models import CloudflareModel
    >>> model = CloudflareModel(id="@cf/meta/llama-3.1-8b-instruct")
    >>> response = model.chat([...])
    
    >>> from contextwise.lib.models import AzureForgeModel
    >>> model = AzureForgeModel(id="gpt-5-mini")
    >>> response = model.chat([...])
    
    >>> from contextwise.lib.models import CerebrasModel
    >>> model = CerebrasModel(id="llama-3.3-70b")
    >>> response = model.chat([...])
"""

from .base import Model, ModelMessage, ModelResponse
from .openai import OpenAIModel
from .groq import GroqModel
from .gemini import GeminiModel
from .ollama import OllamaModel
from .cloudflare import CloudflareModel
from .azure_forge import AzureForgeModel
from .cerebras import CerebrasModel
from .resilient import ResilientModel, with_resilience, with_resilience_from_env

# Google ADK integration (optional, for use_native_sdk=True)
try:
    from .gemini_adk import GeminiADKRunner, is_adk_available
    GOOGLE_ADK_AVAILABLE = is_adk_available()
except ImportError:
    GeminiADKRunner = None
    GOOGLE_ADK_AVAILABLE = False

__all__ = [
    "Model",
    "ModelMessage",
    "ModelResponse",
    "OpenAIModel",
    "GroqModel",
    "GeminiModel",
    "OllamaModel",
    "CloudflareModel",
    "AzureForgeModel",
    "CerebrasModel",
    "GeminiADKRunner",
    "GOOGLE_ADK_AVAILABLE",
    "ResilientModel",
    "with_resilience",
    "with_resilience_from_env",
]
