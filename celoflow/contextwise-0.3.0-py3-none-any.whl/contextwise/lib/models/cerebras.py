"""Cerebras model implementation for contextwise using OpenAI-compatible API.

This module provides Cerebras chat completion capabilities using the OpenAI SDK
with Cerebras' OpenAI-compatible endpoint for high-performance inference.

Cerebras supports OpenAI-compatible API at: https://api.cerebras.ai/v1

Cerebras-specific features:
- reasoning_effort: Controls reasoning depth ("low", "medium", "high") for gpt-oss-120b
- clear_thinking: Controls thinking content from previous turns (zai-glm-4.7)
- parallel_tool_calls: Enable/disable parallel function calling
- Prompt caching: Automatic caching for repeated prompt prefixes

Note: Cerebras does NOT support frequency_penalty, logit_bias, or presence_penalty.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from os import getenv
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Union

from .base import Model, ModelMessage, ModelResponse

logger = logging.getLogger(__name__)

# Cerebras OpenAI-compatible endpoint
CEREBRAS_DEFAULT_BASE_URL = "https://api.cerebras.ai/v1"

try:
    from openai import DEFAULT_MAX_RETRIES, AsyncOpenAI, OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

# Optional integration with the agents SDK (used by demos)
try:
    from agents.models import _openai_shared as agents_openai_shared

    AGENTS_OPENAI_SHARED_AVAILABLE = True
except ImportError:  # pragma: no cover - optional dependency
    AGENTS_OPENAI_SHARED_AVAILABLE = False
    agents_openai_shared = None  # type: ignore[misc,assignment]


@dataclass
class CerebrasModel(Model):
    """Cerebras chat model using OpenAI-compatible API.
    
    This model uses Cerebras' OpenAI-compatible endpoint for ultra-fast inference
    powered by Cerebras wafer-scale hardware.
    
    Supported models:
    - llama3.1-8b
    - llama-3.3-70b
    - qwen-3-32b
    - gpt-oss-120b (supports reasoning_effort)
    - zai-glm-4.7 (supports clear_thinking, disable_reasoning)
    
    Attributes:
        id: Model identifier (e.g., "llama-3.3-70b").
        api_key: Cerebras API key.
        base_url: API endpoint (defaults to https://api.cerebras.ai/v1).
        temperature: Sampling temperature (0-1.5).
        max_tokens: Maximum tokens in response.
        reasoning_effort: Reasoning depth for gpt-oss-120b ("low", "medium", "high").
    
    Example:
        >>> model = CerebrasModel(
        ...     id="llama-3.3-70b",
        ...     api_key="csk_...",
        ... )
        >>> response = model.chat([
        ...     ModelMessage(role="user", content="Hello!"),
        ... ])
        >>> print(response.content)
    """
    
    id: str = "llama-3.3-70b"
    name: str = "Cerebras"
    provider: str = "Cerebras"
    
    # API configuration - uses OpenAI SDK with Cerebras' endpoint
    api_key: Optional[str] = None
    base_url: str = CEREBRAS_DEFAULT_BASE_URL
    timeout: Optional[float] = None
    max_retries: Optional[int] = None
    
    # Request parameters
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    stop: Optional[Union[str, List[str]]] = None
    seed: Optional[int] = None
    
    # Cerebras-specific parameters
    reasoning_effort: Optional[str] = None  # "low", "medium", "high" (gpt-oss-120b only)
    clear_thinking: Optional[bool] = None  # zai-glm-4.7 only
    parallel_tool_calls: Optional[bool] = None
    max_completion_tokens: Optional[int] = None
    
    # Client instances (OpenAI SDK)
    _client: Optional[Any] = field(default=None, repr=False)
    _async_client: Optional[Any] = field(default=None, repr=False)
    
    def __post_init__(self):
        """Validate dependencies are available."""
        if not OPENAI_AVAILABLE:
            raise ImportError(
                "openai not installed. Install with: uv add openai"
            )
        
        # Get base_url from environment if available
        env_base_url = getenv("CEREBRAS_BASE_URL")
        if env_base_url:
            self.base_url = env_base_url
        
        # Get API key from environment if not provided
        if not self.api_key:
            self.api_key = getenv("CEREBRAS_API_KEY")

        # Provide defaults for the agents SDK so MultiProvider can route Cerebras calls
        if AGENTS_OPENAI_SHARED_AVAILABLE and self.api_key:
            try:
                current_key = agents_openai_shared.get_default_openai_key()
                if current_key is None:
                    agents_openai_shared.set_default_openai_key(self.api_key)

                current_client = agents_openai_shared.get_default_openai_client()
                if current_client is None:
                    cerebras_client = AsyncOpenAI(
                        api_key=self.api_key,
                        base_url=self.base_url,
                        timeout=self.timeout,
                        max_retries=self._resolved_max_retries,
                    )
                    agents_openai_shared.set_default_openai_client(cerebras_client)
            except Exception as exc:  # pragma: no cover - best-effort integration
                logger.warning(
                    "Could not register Cerebras client with agents SDK defaults: %s", exc
                )
    
    @property
    def client(self) -> "OpenAI":
        """Get or create the OpenAI client with Cerebras base_url."""
        if self._client is None:
            client_params = {
                "api_key": self.api_key,
                "base_url": self.base_url,
                "timeout": self.timeout,
                "max_retries": self._resolved_max_retries,
            }
            client_params = {k: v for k, v in client_params.items() if v is not None}
            self._client = OpenAI(**client_params)
        return self._client
    
    @property
    def async_client(self) -> "AsyncOpenAI":
        """Get or create the async OpenAI client with Cerebras base_url."""
        if self._async_client is None:
            client_params = {
                "api_key": self.api_key,
                "base_url": self.base_url,
                "timeout": self.timeout,
                "max_retries": self._resolved_max_retries,
            }
            client_params = {k: v for k, v in client_params.items() if v is not None}
            self._async_client = AsyncOpenAI(**client_params)
        return self._async_client

    @property
    def _resolved_max_retries(self) -> Optional[int]:
        """Return a max_retries value acceptable by OpenAI SDK."""
        if self.max_retries is None:
            return DEFAULT_MAX_RETRIES
        return self.max_retries
    
    def _build_request_params(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> Dict[str, Any]:
        """Build request parameters for API call.
        
        Note: Cerebras does NOT support frequency_penalty, logit_bias,
        or presence_penalty. These are intentionally excluded.
        """
        params: Dict[str, Any] = {
            "model": self.id,
            "messages": [m.to_dict() for m in messages],
        }
        
        # Add optional standard parameters
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.max_tokens is not None:
            params["max_tokens"] = self.max_tokens
        if self.max_completion_tokens is not None:
            params["max_completion_tokens"] = self.max_completion_tokens
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.stop is not None:
            params["stop"] = self.stop
        if self.seed is not None:
            params["seed"] = self.seed
        if self.parallel_tool_calls is not None:
            params["parallel_tool_calls"] = self.parallel_tool_calls
        
        # Cerebras-specific parameters via extra_body (OpenAI SDK convention)
        extra_body = {}
        if self.reasoning_effort is not None:
            extra_body["reasoning_effort"] = self.reasoning_effort
        if self.clear_thinking is not None:
            extra_body["clear_thinking"] = self.clear_thinking
        
        # Merge any extra_body from kwargs
        if "extra_body" in kwargs:
            extra_body.update(kwargs.pop("extra_body"))
        
        if extra_body:
            params["extra_body"] = extra_body
        
        # Override with kwargs
        params.update(kwargs)
        
        return params
    
    def _parse_response(self, response: Any) -> ModelResponse:
        """Parse OpenAI response to ModelResponse."""
        choice = response.choices[0]
        message = choice.message
        
        usage = None
        if response.usage:
            usage = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            }
        
        tool_calls = None
        if message.tool_calls:
            tool_calls = [
                {
                    "id": tc.id,
                    "type": tc.type,
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in message.tool_calls
            ]
        
        return ModelResponse(
            content=message.content or "",
            role=message.role,
            tool_calls=tool_calls,
            usage=usage,
            model=response.model,
            finish_reason=choice.finish_reason,
            raw_response=response,
        )
    
    def chat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Generate a chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Cerebras-specific parameters.
                Cerebras-specific params (reasoning_effort, clear_thinking)
                can be passed via extra_body kwarg.
            
        Returns:
            ModelResponse with the completion.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            response = self.client.chat.completions.create(**params)
            return self._parse_response(response)
        except Exception as e:
            logger.error(f"Error in Cerebras chat completion: {e}")
            raise
    
    async def achat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Async chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Cerebras-specific parameters.
            
        Returns:
            ModelResponse with the completion.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            response = await self.async_client.chat.completions.create(**params)
            return self._parse_response(response)
        except Exception as e:
            logger.error(f"Error in async Cerebras chat completion: {e}")
            raise
    
    def chat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> Iterator[ModelResponse]:
        """Generate a streaming chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Cerebras-specific parameters.
            
        Yields:
            ModelResponse chunks.
            
        Note:
            Streaming is not supported when using reasoning models with
            JSON mode or tool calling. Streaming works with gpt-oss-120b,
            zai-glm-4.7, and non-reasoning models.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            params["stream"] = True
            
            stream = self.client.chat.completions.create(**params)
            
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield ModelResponse(
                        content=chunk.choices[0].delta.content,
                        role="assistant",
                        model=chunk.model,
                    )
        except Exception as e:
            logger.error(f"Error in Cerebras streaming chat: {e}")
            raise
    
    async def achat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> AsyncIterator[ModelResponse]:
        """Async streaming chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Cerebras-specific parameters.
            
        Yields:
            ModelResponse chunks.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            params["stream"] = True
            
            stream = await self.async_client.chat.completions.create(**params)
            
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield ModelResponse(
                        content=chunk.choices[0].delta.content,
                        role="assistant",
                        model=chunk.model,
                    )
        except Exception as e:
            logger.error(f"Error in async Cerebras streaming chat: {e}")
            raise
