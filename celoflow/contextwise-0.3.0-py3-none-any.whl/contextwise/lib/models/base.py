"""Base model class for contextwise.

This module provides the abstract base class for model implementations
that can be used with contextwise agents.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Union


@dataclass
class ModelMessage:
    """A message in a conversation.
    
    Attributes:
        role: Message role (system, user, assistant, tool).
        content: Message content.
        name: Optional name for the message sender.
        tool_calls: Optional list of tool calls.
        tool_call_id: Optional tool call ID for tool responses.
    """
    role: str
    content: str
    name: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary."""
        data = {"role": self.role, "content": self.content}
        if self.name:
            data["name"] = self.name
        if self.tool_calls:
            data["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            data["tool_call_id"] = self.tool_call_id
        return data


@dataclass
class ModelResponse:
    """Response from a model.
    
    Attributes:
        content: Response content text.
        role: Response role (usually assistant).
        tool_calls: Optional tool calls in response.
        usage: Token usage information.
        model: Model ID used.
        finish_reason: Reason for completion.
        conversation_id: Optional conversation ID for stateful conversations.
    """
    content: str = ""
    role: str = "assistant"
    tool_calls: Optional[List[Dict[str, Any]]] = None
    usage: Optional[Dict[str, int]] = None
    model: Optional[str] = None
    finish_reason: Optional[str] = None
    raw_response: Optional[Any] = None
    conversation_id: Optional[str] = None
    
    @property
    def input_tokens(self) -> int:
        """Get input token count."""
        if self.usage:
            return self.usage.get("prompt_tokens", 0) or self.usage.get("input_tokens", 0)
        return 0
    
    @property
    def output_tokens(self) -> int:
        """Get output token count."""
        if self.usage:
            return self.usage.get("completion_tokens", 0) or self.usage.get("output_tokens", 0)
        return 0
    
    @property
    def total_tokens(self) -> int:
        """Get total token count."""
        if self.usage:
            return self.usage.get("total_tokens", 0) or (self.input_tokens + self.output_tokens)
        return 0


@dataclass
class Model(ABC):
    """Abstract base class for language models.
    
    This class defines the interface for all model implementations.
    Models handle chat completions with various providers.
    
    Attributes:
        id: Model identifier (e.g., "gpt-4o", "claude-3-opus").
        name: Human-readable model name.
        provider: Model provider name.
        temperature: Sampling temperature.
        max_tokens: Maximum tokens in response.
        base_url: Custom API base URL for OpenAI-compatible endpoints.
    
    Example:
        >>> class MyModel(Model):
        ...     def chat(self, messages):
        ...         # Your chat logic here
        ...         return ModelResponse(content="Hello!")
    """
    
    id: str = "gpt-4o"
    name: Optional[str] = None
    provider: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    base_url: Optional[str] = None  # For OpenAI-compatible endpoints
    
    @abstractmethod
    def chat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Generate a chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional provider-specific parameters.
            
        Returns:
            ModelResponse with the completion.
        """
        raise NotImplementedError
    
    @abstractmethod
    async def achat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Async version of chat.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional provider-specific parameters.
            
        Returns:
            ModelResponse with the completion.
        """
        raise NotImplementedError
    
    def chat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> Iterator[ModelResponse]:
        """Generate a streaming chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional provider-specific parameters.
            
        Yields:
            ModelResponse chunks.
        """
        # Default implementation: non-streaming
        yield self.chat(messages, **kwargs)
    
    async def achat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> AsyncIterator[ModelResponse]:
        """Async streaming chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional provider-specific parameters.
            
        Yields:
            ModelResponse chunks.
        """
        # Default implementation: non-streaming
        yield await self.achat(messages, **kwargs)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "provider": self.provider,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
