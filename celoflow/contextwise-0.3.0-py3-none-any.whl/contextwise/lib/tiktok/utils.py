"""Utility functions for TikTok API.

This module provides functions for replying to comments via TikTok API.
Note: TikTok API capabilities vary by account/app permissions.
"""

import logging
import os
from typing import Optional

import httpx

from ..social import SocialHTTPClient, RateLimiter


logger = logging.getLogger(__name__)

# Rate limiter for TikTok API (5 requests/sec default - conservative)
_rate_limiter = RateLimiter(max_tokens=5, refill_rate=5.0)

# HTTP client for TikTok API
_http_client = SocialHTTPClient()


def get_access_token() -> str:
    """Get TikTok access token from environment.

    Returns:
        Access token from TIKTOK_ACCESS_TOKEN env var

    Raises:
        ValueError: If token not configured
    """
    token = os.getenv("TIKTOK_ACCESS_TOKEN", "")
    if not token:
        raise ValueError("TIKTOK_ACCESS_TOKEN not configured")
    return token


def get_client_key() -> str:
    """Get TikTok client key from environment.

    Returns:
        Client key from TIKTOK_CLIENT_KEY env var

    Raises:
        ValueError: If client key not configured
    """
    client_key = os.getenv("TIKTOK_CLIENT_KEY", "")
    if not client_key:
        raise ValueError("TIKTOK_CLIENT_KEY not configured")
    return client_key


def send_tiktok_comment(
    video_id: str,
    text: str,
    access_token: Optional[str] = None,
    comment_id: Optional[str] = None,
) -> Optional[str]:
    """Reply to a TikTok comment or post a comment (synchronous).

    Note: This is a placeholder implementation. Actual TikTok API
    endpoints depend on the specific API product and permissions.

    Args:
        video_id: TikTok video ID
        text: Comment text
        access_token: Access token (defaults to env var)
        comment_id: Parent comment ID if replying to a comment

    Returns:
        Error message if failed, None if successful

    Example:
        >>> error = send_tiktok_comment("video_123", "Great video!")
        >>> if error:
        ...     print(f"Failed: {error}")
    """
    access_token = access_token or get_access_token()

    # TikTok API endpoint (placeholder - update based on actual API docs)
    url = "https://open.tiktokapis.com/v2/comment/reply/"

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    payload = {
        "video_id": video_id,
        "text": text,
    }

    if comment_id:
        payload["comment_id"] = comment_id

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(url, headers=headers, json=payload)

            # TikTok API may not support comment replies
            # Log and return success to avoid retries
            if response.status_code == 404:
                logger.warning(
                    f"TikTok comment API not available or not permitted. "
                    f"Cannot reply to video {video_id}"
                )
                return None

            response.raise_for_status()
            logger.info(f"TikTok comment posted on video {video_id}")
            return None

    except httpx.HTTPError as e:
        error_msg = f"Failed to post TikTok comment: {e}"
        logger.error(error_msg)
        return error_msg


async def send_tiktok_comment_async(
    video_id: str,
    text: str,
    access_token: Optional[str] = None,
    comment_id: Optional[str] = None,
) -> Optional[str]:
    """Reply to a TikTok comment or post a comment (asynchronous).

    Note: This is a placeholder implementation. Actual TikTok API
    endpoints depend on the specific API product and permissions.

    Args:
        video_id: TikTok video ID
        text: Comment text
        access_token: Access token (defaults to env var)
        comment_id: Parent comment ID if replying to a comment

    Returns:
        Error message if failed, None if successful

    Example:
        >>> error = await send_tiktok_comment_async("video_123", "Great!")
        >>> if error:
        ...     print(f"Failed: {error}")
    """
    access_token = access_token or get_access_token()

    # Acquire rate limit token
    await _rate_limiter.acquire()

    # TikTok API endpoint (placeholder - update based on actual API docs)
    url = "https://open.tiktokapis.com/v2/comment/reply/"

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    payload = {
        "video_id": video_id,
        "text": text,
    }

    if comment_id:
        payload["comment_id"] = comment_id

    try:
        result = await _http_client.post(url, headers, json_data=payload)
        logger.info(f"TikTok comment posted on video {video_id}")
        return None

    except httpx.HTTPError as e:
        # TikTok API may not support comment replies
        # Log and return success to avoid retries
        if hasattr(e, 'response') and e.response.status_code == 404:
            logger.warning(
                f"TikTok comment API not available or not permitted. "
                f"Cannot reply to video {video_id}"
            )
            return None

        error_msg = f"Failed to post TikTok comment: {e}"
        logger.error(error_msg)
        return error_msg
