"""FastAPI router for TikTok webhooks.

This module provides webhook endpoints for TikTok events (comments, mentions).
"""

import logging
from typing import Any, Callable, Dict, Optional

from fastapi import APIRouter, Request, Response, Query, Header

from ..social import normalize_tiktok_event


logger = logging.getLogger(__name__)


def create_tiktok_router(
    api_plugin: Any,
    async_message_handler: Optional[Callable] = None,
) -> APIRouter:
    """Create FastAPI router for TikTok webhooks.

    Args:
        api_plugin: TikTok channel plugin instance
        async_message_handler: Optional async handler for messages

    Returns:
        Configured APIRouter

    Example:
        >>> from contextwise.channels import TikTokChannel
        >>> channel = TikTokChannel()
        >>> router = create_tiktok_router(channel, my_handler)
    """
    router = APIRouter()

    @router.get("/webhook")
    async def verify_webhook(
        challenge: Optional[str] = Query(None),
    ):
        """Verify TikTok webhook (GET request).

        TikTok may send a GET request with a challenge parameter during setup.

        Args:
            challenge: Challenge string to echo back

        Returns:
            Challenge string if present
        """
        logger.info(f"TikTok webhook verification: challenge={challenge}")

        if challenge:
            logger.info("TikTok webhook verified successfully")
            return Response(content=challenge, media_type="text/plain")

        logger.warning("TikTok webhook verification: no challenge provided")
        return Response(content="OK", status_code=200)

    @router.post("/webhook")
    async def receive_webhook(request: Request):
        """Receive TikTok webhook events (POST request).

        Args:
            request: FastAPI request object

        Returns:
            200 OK response
        """
        # Get signature header (if TikTok provides one)
        signature = request.headers.get("X-TikTok-Signature", "")

        # Get raw body for signature verification
        body_bytes = await request.body()

        # TODO: Implement TikTok signature verification when available
        # if hasattr(api_plugin, 'client_secret') and api_plugin.client_secret:
        #     if not verify_tiktok_signature(body_bytes, signature, api_plugin.client_secret):
        #         logger.warning("Invalid TikTok webhook signature")
        #         return Response(content="Forbidden", status_code=403)

        # Parse JSON body
        try:
            body = await request.json()
        except Exception as e:
            logger.error(f"Failed to parse TikTok webhook body: {e}")
            return Response(content="Bad Request", status_code=400)

        logger.info(f"TikTok webhook received: {body.get('event')}")

        # Normalize event
        event = normalize_tiktok_event(body)

        if not event:
            logger.debug("No valid TikTok event found in webhook")
            return Response(content="OK", status_code=200)

        # Process message through handler
        if async_message_handler:
            try:
                message_data = {
                    "from": event.sender_id,
                    "content": event.text,
                    "message_id": event.platform_event_id,
                    "timestamp": event.timestamp,
                    "metadata": event.metadata,
                    "raw": event.raw,
                }

                # Call handler (fire and forget)
                import asyncio
                asyncio.create_task(async_message_handler(message_data))

            except Exception as e:
                logger.exception(f"Error in TikTok message handler: {e}")

        return Response(content="OK", status_code=200)

    return router
