"""TikTok channel plugin for Contextwise v0.3.0.

This module provides TikTok API integration as a Contextwise
channel plugin, focusing on comments and mentions.
"""

from .utils import send_tiktok_comment, send_tiktok_comment_async
from .router import create_tiktok_router

__all__ = [
    "send_tiktok_comment",
    "send_tiktok_comment_async",
    "create_tiktok_router",
]
