"""Agent Platform Runtime - Authoritative in-process state management.

This module provides the AgentRuntime class which maintains the authoritative
state for agents, tasks, runs, memory, and artifacts in the platform API.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .models import (
    Agent as AgentModel,
    AgentConfig,
    AgentCreate,
    Run,
    RunStatus,
    Memory,
    MemoryType,
    MemoryCreate,
    Artifact,
    RunStep,
    RunLogEntry,
    StepType,
)
from .errors import AgentNotFound, RunNotFound, TaskNotFound

if TYPE_CHECKING:
    from ...agent import Agent

logger = logging.getLogger(__name__)


class AgentRuntime:
    """Authoritative in-process state for the platform API.

    Manages agents, tasks, runs, memory, artifacts, and provides SSE event
    streaming capabilities.

    Attributes:
        agents: Dict mapping agent_id -> Agent instance
        agent_metadata: Dict mapping agent_id -> AgentModel (API metadata)
        tasks: Dict mapping task_id -> task data
        runs: Dict mapping run_id -> Run instance
        run_queues: Dict mapping run_id -> asyncio.Queue (for SSE)
        run_tasks: Dict mapping run_id -> asyncio.Task (for cancellation)
        memory: Dict mapping agent_id -> Dict[memory_id -> Memory]
        artifacts: Dict mapping run_id -> Dict[artifact_id -> Artifact]
        run_steps: Dict mapping run_id -> List[RunStep]
        run_logs: Dict mapping run_id -> List[RunLogEntry]
    """

    def __init__(self):
        """Initialize runtime state."""
        # Agent storage
        self.agents: Dict[str, Agent] = {}
        self.agent_metadata: Dict[str, AgentModel] = {}

        # Task & Run storage
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self.runs: Dict[str, Run] = {}

        # SSE event queues (per-run)
        self.run_queues: Dict[str, asyncio.Queue] = {}

        # Background execution tasks (for cancellation)
        self.run_tasks: Dict[str, asyncio.Task] = {}

        # Memory storage (per-agent)
        self.memory: Dict[str, Dict[str, Memory]] = {}

        # Artifact storage (per-run)
        self.artifacts: Dict[str, Dict[str, Artifact]] = {}

        # Steps and logs (per-run)
        self.run_steps: Dict[str, List[RunStep]] = {}
        self.run_logs: Dict[str, List[RunLogEntry]] = {}

    # ==========================================================================
    # Agent Management
    # ==========================================================================

    def register_agent(self, agent: Agent, agent_id: Optional[str] = None) -> str:
        """Register an agent with the runtime.

        Args:
            agent: Agent instance to register
            agent_id: Optional custom agent ID (auto-generated if None)

        Returns:
            Agent ID
        """
        if agent_id is None:
            agent_id = f"agent_{agent.name.lower().replace(' ', '_')}"

        # Check if already registered
        if agent_id in self.agents:
            logger.warning(f"Agent {agent_id} already registered, updating")

        self.agents[agent_id] = agent

        # Create metadata
        config = AgentConfig(
            model=agent._resolve_model_id() if hasattr(agent, "_resolve_model_id") else str(agent.model),
            instructions=agent.instructions,
            tools=[
                getattr(t, "name", getattr(t, "__name__", str(t)))
                for t in (agent.tools or [])
            ],
        )

        self.agent_metadata[agent_id] = AgentModel(
            id=agent_id,
            name=agent.name,
            description=agent.description or "",
            config=config,
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )

        logger.info(f"Registered agent: {agent_id}")
        return agent_id

    def get_agent(self, agent_id: str) -> Agent:
        """Get an agent by ID.

        Args:
            agent_id: Agent ID

        Returns:
            Agent instance

        Raises:
            AgentNotFound: If agent not found
        """
        if agent_id not in self.agents:
            raise AgentNotFound(agent_id)
        return self.agents[agent_id]

    def get_agent_metadata(self, agent_id: str) -> AgentModel:
        """Get agent metadata by ID.

        Args:
            agent_id: Agent ID

        Returns:
            AgentModel instance

        Raises:
            AgentNotFound: If agent not found
        """
        if agent_id not in self.agent_metadata:
            raise AgentNotFound(agent_id)
        return self.agent_metadata[agent_id]

    def list_agents(self) -> List[AgentModel]:
        """List all registered agents.

        Returns:
            List of AgentModel instances
        """
        return list(self.agent_metadata.values())

    def update_agent_metadata(
        self,
        agent_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        config: Optional[AgentConfig] = None,
    ) -> AgentModel:
        """Update agent metadata.

        Args:
            agent_id: Agent ID
            name: New name (optional)
            description: New description (optional)
            config: New config (optional)

        Returns:
            Updated AgentModel

        Raises:
            AgentNotFound: If agent not found
        """
        metadata = self.get_agent_metadata(agent_id)

        if name is not None:
            metadata.name = name
        if description is not None:
            metadata.description = description
        if config is not None:
            metadata.config = config

        metadata.updated_at = datetime.now()
        return metadata

    def delete_agent(self, agent_id: str) -> None:
        """Delete an agent from the runtime.

        Args:
            agent_id: Agent ID

        Raises:
            AgentNotFound: If agent not found
        """
        if agent_id not in self.agents:
            raise AgentNotFound(agent_id)

        del self.agents[agent_id]
        del self.agent_metadata[agent_id]

        # Clean up associated memory
        if agent_id in self.memory:
            del self.memory[agent_id]

        logger.info(f"Deleted agent: {agent_id}")

    # ==========================================================================
    # Task & Run Management
    # ==========================================================================

    def create_task(
        self,
        agent_id: str,
        message: str,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> tuple[str, str]:
        """Create a new task and associated run.

        Args:
            agent_id: Agent ID
            message: User message
            user_id: User ID (optional)
            session_id: Session ID (optional)
            context: Additional context (optional)

        Returns:
            Tuple of (task_id, run_id)

        Raises:
            AgentNotFound: If agent not found
        """
        # Verify agent exists
        self.get_agent(agent_id)

        task_id = f"task_{uuid.uuid4().hex[:12]}"
        run_id = f"run_{uuid.uuid4().hex[:12]}"

        # Create task
        self.tasks[task_id] = {
            "id": task_id,
            "agent_id": agent_id,
            "message": message,
            "user_id": user_id,
            "session_id": session_id,
            "context": context or {},
            "created_at": datetime.now(),
        }

        # Create run
        self.runs[run_id] = Run(
            id=run_id,
            task_id=task_id,
            agent_id=agent_id,
            status=RunStatus.QUEUED,
            message=message,
            user_id=user_id,
            session_id=session_id,
            started_at=None,
            updated_at=datetime.now(),
            completed_at=None,
        )

        # Create SSE queue for this run
        self.run_queues[run_id] = asyncio.Queue()

        # Initialize steps and logs
        self.run_steps[run_id] = []
        self.run_logs[run_id] = []

        logger.info(f"Created task {task_id} and run {run_id} for agent {agent_id}")
        return task_id, run_id

    def get_run(self, run_id: str) -> Run:
        """Get a run by ID.

        Args:
            run_id: Run ID

        Returns:
            Run instance

        Raises:
            RunNotFound: If run not found
        """
        if run_id not in self.runs:
            raise RunNotFound(run_id)
        return self.runs[run_id]

    def list_runs(self, agent_id: Optional[str] = None, status: Optional[RunStatus] = None) -> List[Run]:
        """List runs with optional filtering.

        Args:
            agent_id: Filter by agent ID (optional)
            status: Filter by status (optional)

        Returns:
            List of Run instances
        """
        runs = list(self.runs.values())

        if agent_id is not None:
            runs = [r for r in runs if r.agent_id == agent_id]

        if status is not None:
            runs = [r for r in runs if r.status == status]

        # Sort by updated_at descending
        runs.sort(key=lambda r: r.updated_at or datetime.min, reverse=True)

        return runs

    def update_run_status(
        self,
        run_id: str,
        status: RunStatus,
        result: Optional[str] = None,
        error: Optional[str] = None,
    ) -> Run:
        """Update run status.

        Args:
            run_id: Run ID
            status: New status
            result: Result text (for success)
            error: Error text (for error)

        Returns:
            Updated Run instance

        Raises:
            RunNotFound: If run not found
        """
        run = self.get_run(run_id)

        run.status = status
        run.updated_at = datetime.now()

        if status == RunStatus.RUNNING and run.started_at is None:
            run.started_at = datetime.now()

        if status in (RunStatus.SUCCESS, RunStatus.ERROR, RunStatus.CANCELLED):
            run.completed_at = datetime.now()

        if result is not None:
            run.result = result

        if error is not None:
            run.error = error

        return run

    def cancel_run(self, run_id: str) -> Run:
        """Cancel a running task.

        Args:
            run_id: Run ID

        Returns:
            Updated Run instance

        Raises:
            RunNotFound: If run not found
        """
        run = self.get_run(run_id)

        # Cancel the background task if it exists
        if run_id in self.run_tasks:
            task = self.run_tasks[run_id]
            if not task.done():
                task.cancel()
            del self.run_tasks[run_id]

        # Update status
        return self.update_run_status(run_id, RunStatus.CANCELLED)

    # ==========================================================================
    # Steps & Logs
    # ==========================================================================

    def add_step(
        self,
        run_id: str,
        step_type: str,
        tool: Optional[str] = None,
        input_data: Optional[Any] = None,
        output_data: Optional[Any] = None,
    ) -> RunStep:
        """Add a step to a run.

        Args:
            run_id: Run ID
            step_type: Step type
            tool: Tool name (optional)
            input_data: Input data (optional)
            output_data: Output data (optional)

        Returns:
            Created RunStep
        """
        if run_id not in self.run_steps:
            self.run_steps[run_id] = []

        step_number = len(self.run_steps[run_id])

        step = RunStep(
            step=step_number,
            type=step_type,
            tool=tool,
            input=input_data,
            output=output_data,
            timestamp=datetime.now(),
        )

        self.run_steps[run_id].append(step)
        return step

    def get_steps(self, run_id: str) -> List[RunStep]:
        """Get all steps for a run.

        Args:
            run_id: Run ID

        Returns:
            List of RunStep instances
        """
        return self.run_steps.get(run_id, [])

    def add_log(
        self,
        run_id: str,
        action: Optional[str] = None,
        message: Optional[str] = None,
        tool: Optional[str] = None,
        input_data: Optional[Any] = None,
        step: Optional[int] = None,
    ) -> RunLogEntry:
        """Add a log entry to a run.

        Args:
            run_id: Run ID
            action: Action type (optional)
            message: Log message (optional)
            tool: Tool name (optional)
            input_data: Input data (optional)
            step: Step number (optional)

        Returns:
            Created RunLogEntry
        """
        if run_id not in self.run_logs:
            self.run_logs[run_id] = []

        log_entry = RunLogEntry(
            step=step,
            action=action,
            tool=tool,
            input=input_data,
            message=message,
            timestamp=datetime.now(),
        )

        self.run_logs[run_id].append(log_entry)
        return log_entry

    def get_logs(self, run_id: str) -> List[RunLogEntry]:
        """Get all log entries for a run.

        Args:
            run_id: Run ID

        Returns:
            List of RunLogEntry instances
        """
        return self.run_logs.get(run_id, [])

    # ==========================================================================
    # Memory Management
    # ==========================================================================

    def create_memory(
        self,
        agent_id: str,
        memory_type: MemoryType,
        label: str,
        data: Dict[str, Any],
    ) -> Memory:
        """Create a memory entry.

        Args:
            agent_id: Agent ID
            memory_type: Memory type
            label: Label
            data: Data dictionary

        Returns:
            Created Memory instance

        Raises:
            AgentNotFound: If agent not found
        """
        # Verify agent exists
        self.get_agent(agent_id)

        memory_id = f"mem_{uuid.uuid4().hex[:12]}"

        memory = Memory(
            id=memory_id,
            agent_id=agent_id,
            type=memory_type,
            label=label,
            data=data,
            created_at=datetime.now(),
        )

        if agent_id not in self.memory:
            self.memory[agent_id] = {}

        self.memory[agent_id][memory_id] = memory

        logger.info(f"Created memory {memory_id} for agent {agent_id}")
        return memory

    def get_memory(self, agent_id: str, memory_id: str) -> Memory:
        """Get a memory entry.

        Args:
            agent_id: Agent ID
            memory_id: Memory ID

        Returns:
            Memory instance

        Raises:
            AgentNotFound: If agent not found
        """
        if agent_id not in self.memory or memory_id not in self.memory[agent_id]:
            from .errors import MemoryNotFound
            raise MemoryNotFound(memory_id)

        return self.memory[agent_id][memory_id]

    def list_memory(
        self,
        agent_id: str,
        memory_type: Optional[MemoryType] = None,
        search: Optional[str] = None,
    ) -> List[Memory]:
        """List memory entries for an agent.

        Args:
            agent_id: Agent ID
            memory_type: Filter by type (optional)
            search: Filter by label substring (optional)

        Returns:
            List of Memory instances

        Raises:
            AgentNotFound: If agent not found
        """
        # Verify agent exists
        self.get_agent(agent_id)

        if agent_id not in self.memory:
            return []

        memories = list(self.memory[agent_id].values())

        if memory_type is not None:
            memories = [m for m in memories if m.type == memory_type]

        if search is not None:
            search_lower = search.lower()
            memories = [m for m in memories if search_lower in m.label.lower()]

        # Sort by created_at descending
        memories.sort(key=lambda m: m.created_at, reverse=True)

        return memories

    def delete_memory(self, agent_id: str, memory_id: str) -> None:
        """Delete a memory entry.

        Args:
            agent_id: Agent ID
            memory_id: Memory ID

        Raises:
            AgentNotFound: If agent not found
        """
        memory = self.get_memory(agent_id, memory_id)
        del self.memory[agent_id][memory_id]
        logger.info(f"Deleted memory {memory_id} for agent {agent_id}")

    # ==========================================================================
    # Artifact Management
    # ==========================================================================

    def create_artifact(
        self,
        run_id: str,
        filename: Optional[str] = None,
        content_type: Optional[str] = None,
        size_bytes: Optional[int] = None,
        url: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Artifact:
        """Create an artifact entry.

        Args:
            run_id: Run ID
            filename: Filename (optional)
            content_type: Content type (optional)
            size_bytes: Size in bytes (optional)
            url: URL to artifact (optional)
            metadata: Additional metadata (optional)

        Returns:
            Created Artifact instance

        Raises:
            RunNotFound: If run not found
        """
        # Verify run exists
        self.get_run(run_id)

        artifact_id = f"art_{uuid.uuid4().hex[:12]}"

        artifact = Artifact(
            id=artifact_id,
            run_id=run_id,
            filename=filename,
            content_type=content_type,
            size_bytes=size_bytes,
            url=url,
            metadata=metadata,
            created_at=datetime.now(),
        )

        if run_id not in self.artifacts:
            self.artifacts[run_id] = {}

        self.artifacts[run_id][artifact_id] = artifact

        logger.info(f"Created artifact {artifact_id} for run {run_id}")
        return artifact

    def list_artifacts(self, run_id: str) -> List[Artifact]:
        """List artifacts for a run.

        Args:
            run_id: Run ID

        Returns:
            List of Artifact instances

        Raises:
            RunNotFound: If run not found
        """
        # Verify run exists
        self.get_run(run_id)

        if run_id not in self.artifacts:
            return []

        artifacts = list(self.artifacts[run_id].values())

        # Sort by created_at descending
        artifacts.sort(key=lambda a: a.created_at or datetime.min, reverse=True)

        return artifacts

    def get_artifact(self, run_id: str, artifact_id: str) -> Artifact:
        """Get an artifact.

        Args:
            run_id: Run ID
            artifact_id: Artifact ID

        Returns:
            Artifact instance

        Raises:
            ArtifactNotFound: If artifact not found
        """
        if run_id not in self.artifacts or artifact_id not in self.artifacts[run_id]:
            from .errors import ArtifactNotFound
            raise ArtifactNotFound(artifact_id)

        return self.artifacts[run_id][artifact_id]

    # ==========================================================================
    # SSE Event Streaming
    # ==========================================================================

    async def emit_event(self, run_id: str, event: Dict[str, Any]) -> None:
        """Emit an SSE event for a run.

        Args:
            run_id: Run ID
            event: Event data dictionary
        """
        if run_id in self.run_queues:
            await self.run_queues[run_id].put(event)

    def cleanup_run(self, run_id: str) -> None:
        """Clean up resources for a completed run.

        Args:
            run_id: Run ID
        """
        # Remove SSE queue
        if run_id in self.run_queues:
            del self.run_queues[run_id]

        # Remove background task
        if run_id in self.run_tasks:
            del self.run_tasks[run_id]

        logger.debug(f"Cleaned up resources for run {run_id}")
