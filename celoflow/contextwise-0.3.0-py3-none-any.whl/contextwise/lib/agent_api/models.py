"""Pydantic models for the Agent Platform REST API.

This module defines request/response models that mirror the OpenAPI specification
for the agent platform API, ensuring strict contract compliance.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, ConfigDict, Field


# =============================================================================
# Enums
# =============================================================================

class RunStatus(str, Enum):
    """Run lifecycle status."""
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"
    CANCELLED = "cancelled"


class MemoryType(str, Enum):
    """Memory entry type."""
    FACT = "fact"
    EVENT = "event"
    EMBEDDING = "embedding"


class StepType(str, Enum):
    """Step type for structured run tracking."""
    MODEL_CALL = "model_call"
    TOOL_CALL = "tool_call"
    TOOL_OUTPUT = "tool_output"
    ASSISTANT_OUTPUT = "assistant_output"
    CHANNEL_INBOUND = "channel_inbound"
    CHANNEL_OUTBOUND = "channel_outbound"
    SYSTEM = "system"


# =============================================================================
# Base Models
# =============================================================================

class ErrorDetail(BaseModel):
    """Error detail for error envelope."""
    message: str
    code: Optional[str] = None
    details: Optional[Dict[str, Any]] = None


class ErrorResponse(BaseModel):
    """OpenAPI-compliant error response envelope."""
    error: ErrorDetail


class ListEnvelope(BaseModel):
    """List envelope for collection responses."""
    items: List[Any]


# =============================================================================
# Agent Models
# =============================================================================

class AgentConfig(BaseModel):
    """Agent configuration."""
    model: str
    instructions: Optional[str] = None
    tools: Optional[List[str]] = Field(default_factory=list)
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class AgentCreate(BaseModel):
    """Request model for creating an agent."""
    name: str
    description: Optional[str] = None
    config: AgentConfig


class AgentUpdate(BaseModel):
    """Request model for updating an agent."""
    name: Optional[str] = None
    description: Optional[str] = None
    config: Optional[AgentConfig] = None


class Agent(BaseModel):
    """Agent response model."""
    id: str
    name: str
    description: Optional[str] = None
    config: AgentConfig
    created_at: datetime
    updated_at: datetime


class AgentList(BaseModel):
    """List of agents."""
    items: List[Agent]


# =============================================================================
# Task & Run Models
# =============================================================================

class TaskCreate(BaseModel):
    """Request model for creating a task."""
    message: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)


class TaskResponse(BaseModel):
    """Response for task creation."""
    task_id: str
    run_id: str


class Run(BaseModel):
    """Run response model."""
    id: str
    task_id: str
    agent_id: str
    status: RunStatus
    message: Optional[str] = None
    result: Optional[str] = None
    error: Optional[str] = None
    started_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None


class RunList(BaseModel):
    """List of runs."""
    items: List[Run]


# =============================================================================
# Steps & Logs Models
# =============================================================================

class RunStep(BaseModel):
    """Structured step in a run."""
    model_config = ConfigDict(extra="allow")

    step: int = Field(ge=0)
    type: str
    tool: Optional[str] = None
    input: Optional[Union[Dict[str, Any], str]] = None
    output: Optional[Union[Dict[str, Any], str]] = None
    timestamp: Optional[datetime] = None


class RunStepsList(BaseModel):
    """List of run steps."""
    items: List[RunStep]


class RunLogEntry(BaseModel):
    """Log entry for a run."""
    model_config = ConfigDict(extra="allow")

    step: Optional[int] = None
    action: Optional[str] = None
    tool: Optional[str] = None
    input: Optional[Union[Dict[str, Any], str]] = None
    message: Optional[str] = None
    timestamp: Optional[datetime] = None


class RunLogsList(BaseModel):
    """List of run logs."""
    items: List[RunLogEntry]


# =============================================================================
# Memory Models
# =============================================================================

class MemoryCreate(BaseModel):
    """Request model for creating a memory entry."""
    type: MemoryType
    label: str
    data: Dict[str, Any]


class Memory(BaseModel):
    """Memory response model."""
    id: str
    agent_id: str
    type: MemoryType
    label: str
    data: Dict[str, Any]
    created_at: datetime


class MemoryList(BaseModel):
    """List of memory entries."""
    items: List[Memory]


# =============================================================================
# Artifact Models
# =============================================================================

class Artifact(BaseModel):
    """Artifact response model."""
    id: str
    run_id: str
    filename: Optional[str] = None
    content_type: Optional[str] = None
    size_bytes: Optional[int] = None
    url: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None


class ArtifactList(BaseModel):
    """List of artifacts."""
    items: List[Artifact]


# =============================================================================
# Tool Models
# =============================================================================

class ToolSummary(BaseModel):
    """Tool summary for listing."""
    model_config = ConfigDict(extra="allow")

    name: str
    type: Optional[str] = None
    description: Optional[str] = None
    owner: Optional[str] = None
    tool_schema: Optional[Dict[str, Any]] = Field(default=None, alias="schema")
    requires_context: Optional[bool] = False


class ToolsList(BaseModel):
    """List of tools."""
    items: List[ToolSummary]


class ToolInvokeRequest(BaseModel):
    """Request model for tool invocation."""
    args: Dict[str, Any]
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)
    timeout_ms: Optional[int] = None


class ToolInvokeResponse(BaseModel):
    """Response model for tool invocation."""
    result: Any


# =============================================================================
# Channel Models
# =============================================================================

class Channel(BaseModel):
    """Channel response model."""
    id: str
    type: str
    display_name: Optional[str] = None
    category: Optional[str] = None
    webhook_path: Optional[str] = None
    inbound_path: Optional[str] = None
    inbound_stream_path: Optional[str] = None
    health_path: Optional[str] = None
    required_env: List[str] = Field(default_factory=list)
    options: Optional[Dict[str, Any]] = Field(default_factory=dict)
    supports: List[str] = Field(default_factory=list)


class ChannelsList(BaseModel):
    """List of channels."""
    items: List[Channel]


# =============================================================================
# Session Models
# =============================================================================

class SessionMetadata(BaseModel):
    """Session metadata response model."""
    session_id: str
    user_id: str
    created_at: datetime
    last_activity: datetime
    message_count: int = 0
    channel: str = "api"
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SessionInfo(BaseModel):
    """Session information response model."""
    session_id: str
    user_id: str
    created_at: datetime
    last_activity: datetime
    message_count: int
    channel: str
    metadata: Dict[str, Any]


class SessionList(BaseModel):
    """List of sessions."""
    items: List[SessionInfo]


class SessionExportResponse(BaseModel):
    """Session export response model."""
    session_id: str
    export_data: str  # JSON string


class SessionImportRequest(BaseModel):
    """Session import request model."""
    export_data: str  # JSON string


class SessionClearResponse(BaseModel):
    """Session clear response model."""
    session_id: str
    cleared: bool
    message: str
