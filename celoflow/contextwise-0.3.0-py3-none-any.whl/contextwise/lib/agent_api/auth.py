"""Authentication for the Agent Platform REST API.

This module provides bearer token authentication with minimal/mock-compatible
JWT token issuance for the platform API.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

logger = logging.getLogger(__name__)

# Bearer security scheme
security = HTTPBearer(auto_error=False)


def get_auth_enabled() -> bool:
    """Check if authentication is enabled.

    Authentication is disabled by default for development/testing.
    Set AGENT_API_AUTH_ENABLED=true to enable.

    Returns:
        True if authentication is enabled
    """
    return os.environ.get("AGENT_API_AUTH_ENABLED", "").lower() in ("1", "true", "yes")


def get_auth_token() -> Optional[str]:
    """Get the configured auth token.

    Reads from AGENT_API_AUTH_TOKEN environment variable.
    If not set, uses a default token for development.

    Returns:
        Auth token string or None if auth is disabled
    """
    if not get_auth_enabled():
        return None

    # Get from env or use default dev token
    return os.environ.get("AGENT_API_AUTH_TOKEN", "dev-token-change-in-production")


async def require_bearer_auth(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Optional[str]:
    """Dependency for bearer token authentication.

    Validates the bearer token from the Authorization header.
    If auth is disabled, returns None without validation.

    Args:
        credentials: HTTP authorization credentials from header

    Returns:
        Token string if valid, None if auth is disabled

    Raises:
        HTTPException: If auth is enabled and token is invalid/missing
    """
    if not get_auth_enabled():
        # Auth disabled - allow all requests
        return None

    expected_token = get_auth_token()

    if credentials is None:
        logger.warning("Missing authorization header")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authorization header",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if credentials.credentials != expected_token:
        logger.warning("Invalid bearer token")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return credentials.credentials


async def optional_bearer_auth(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Optional[str]:
    """Optional dependency for bearer token authentication.

    Similar to require_bearer_auth but doesn't raise an error if token is missing.
    Useful for endpoints that support both authenticated and anonymous access.

    Args:
        credentials: HTTP authorization credentials from header

    Returns:
        Token string if valid, None if missing or auth is disabled
    """
    if not get_auth_enabled():
        return None

    if credentials is None:
        return None

    expected_token = get_auth_token()

    if credentials.credentials == expected_token:
        return credentials.credentials

    return None


def create_auth_token() -> str:
    """Create a bearer token for authentication.

    For development/testing, returns the configured token.
    In production, this would generate a JWT token.

    Returns:
        Bearer token string
    """
    token = get_auth_token()
    if token:
        return token

    # Fallback for when auth is disabled
    return "dev-token-change-in-production"
