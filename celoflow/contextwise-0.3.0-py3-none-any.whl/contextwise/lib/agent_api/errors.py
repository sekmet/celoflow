"""Error handling for the Agent Platform REST API.

This module provides utilities for creating OpenAPI-compliant error responses
with the standard error envelope format.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from fastapi import Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from pydantic import ValidationError

from .models import ErrorResponse, ErrorDetail

logger = logging.getLogger(__name__)


class AgentAPIException(Exception):
    """Base exception for Agent API errors.

    Attributes:
        message: Human-readable error message
        code: Error code (e.g., "AGENT_NOT_FOUND")
        details: Additional error details
        status_code: HTTP status code
    """

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
    ):
        self.message = message
        self.code = code
        self.details = details
        self.status_code = status_code
        super().__init__(message)


class AgentNotFound(AgentAPIException):
    """Agent not found error."""

    def __init__(self, agent_id: str):
        super().__init__(
            message=f"Agent not found: {agent_id}",
            code="AGENT_NOT_FOUND",
            status_code=status.HTTP_404_NOT_FOUND,
        )


class RunNotFound(AgentAPIException):
    """Run not found error."""

    def __init__(self, run_id: str):
        super().__init__(
            message=f"Run not found: {run_id}",
            code="RUN_NOT_FOUND",
            status_code=status.HTTP_404_NOT_FOUND,
        )


class TaskNotFound(AgentAPIException):
    """Task not found error."""

    def __init__(self, task_id: str):
        super().__init__(
            message=f"Task not found: {task_id}",
            code="TASK_NOT_FOUND",
            status_code=status.HTTP_404_NOT_FOUND,
        )


class MemoryNotFound(AgentAPIException):
    """Memory entry not found error."""

    def __init__(self, memory_id: str):
        super().__init__(
            message=f"Memory entry not found: {memory_id}",
            code="MEMORY_NOT_FOUND",
            status_code=status.HTTP_404_NOT_FOUND,
        )


class ArtifactNotFound(AgentAPIException):
    """Artifact not found error."""

    def __init__(self, artifact_id: str):
        super().__init__(
            message=f"Artifact not found: {artifact_id}",
            code="ARTIFACT_NOT_FOUND",
            status_code=status.HTTP_404_NOT_FOUND,
        )


class ToolNotFound(AgentAPIException):
    """Tool not found error."""

    def __init__(self, tool_name: str):
        super().__init__(
            message=f"Tool not found: {tool_name}",
            code="TOOL_NOT_FOUND",
            status_code=status.HTTP_404_NOT_FOUND,
        )


class InvalidAgentConfig(AgentAPIException):
    """Invalid agent configuration error."""

    def __init__(self, details: str):
        super().__init__(
            message=f"Invalid agent configuration: {details}",
            code="INVALID_AGENT_CONFIG",
            status_code=status.HTTP_400_BAD_REQUEST,
        )


class RunExecutionError(AgentAPIException):
    """Run execution error."""

    def __init__(self, run_id: str, details: str):
        super().__init__(
            message=f"Run execution failed: {details}",
            code="RUN_EXECUTION_ERROR",
            details={"run_id": run_id},
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


class ToolInvocationError(AgentAPIException):
    """Tool invocation error."""

    def __init__(self, tool_name: str, details: str):
        super().__init__(
            message=f"Tool invocation failed: {details}",
            code="TOOL_INVOCATION_ERROR",
            details={"tool_name": tool_name},
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


def create_error_response(
    message: str,
    code: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
    status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
) -> JSONResponse:
    """Create an OpenAPI-compliant error response.

    Args:
        message: Human-readable error message
        code: Error code
        details: Additional error details
        status_code: HTTP status code

    Returns:
        JSONResponse with error envelope
    """
    error_detail = ErrorDetail(message=message, code=code, details=details)
    error_response = ErrorResponse(error=error_detail)

    return JSONResponse(
        status_code=status_code,
        content=error_response.model_dump(),
    )


async def agent_api_exception_handler(request: Request, exc: AgentAPIException) -> JSONResponse:
    """Exception handler for AgentAPIException.

    Args:
        request: FastAPI request
        exc: AgentAPIException instance

    Returns:
        JSONResponse with error envelope
    """
    logger.error(
        f"AgentAPIException: {exc.message} (code={exc.code}, status={exc.status_code})",
        extra={"details": exc.details},
    )

    return create_error_response(
        message=exc.message,
        code=exc.code,
        details=exc.details,
        status_code=exc.status_code,
    )


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    """Exception handler for request validation errors.

    Args:
        request: FastAPI request
        exc: RequestValidationError instance

    Returns:
        JSONResponse with error envelope
    """
    logger.warning(f"Validation error: {exc.errors()}")

    return create_error_response(
        message="Validation error",
        code="VALIDATION_ERROR",
        details={"errors": exc.errors()},
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
    )


async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Exception handler for unhandled exceptions.

    Args:
        request: FastAPI request
        exc: Exception instance

    Returns:
        JSONResponse with error envelope
    """
    logger.exception("Unhandled exception in Agent API")

    return create_error_response(
        message="Internal server error",
        code="INTERNAL_ERROR",
        details={"error": str(exc)},
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
    )
