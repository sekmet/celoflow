"""Agent Platform REST API Layer for Contextwise v0.3.0.

This module provides a separated/independent control-plane REST API that can run
as its own FastAPI service while remaining deeply integrated with the in-process
Contextwise runtime.

Key Features:
    - Manage agents and their configuration
    - Create/track/cancel runs via submitted tasks
    - Manage agent resources (sessions, memory, artifacts, tools, channels)
    - Provide realtime run updates via SSE (WebSocket optional later)

Main Components:
    - AgentRuntime: Authoritative in-process state management
    - create_agent_api_router: Router factory for platform API
    - create_platform_app: Standalone FastAPI app entry point

Example:
    >>> from contextwise import Agent
    >>> from contextwise.lib.agent_api import create_platform_app
    >>>
    >>> agent = Agent("gpt-4o-mini", "You are helpful")
    >>> app = create_platform_app(agents=[agent])
    >>>
    >>> # Run with uvicorn
    >>> import uvicorn
    >>> uvicorn.run(app, host="0.0.0.0", port=8001)
"""

from .runtime import AgentRuntime
from .router import create_agent_api_router, create_platform_app

__all__ = [
    "AgentRuntime",
    "create_agent_api_router",
    "create_platform_app",
]
