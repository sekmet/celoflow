"""FastAPI router for the Agent Platform REST API.

This module provides the router factory and entry points for the platform API,
implementing all endpoints defined in the OpenAPI specification.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any, AsyncGenerator, Dict, List, Optional

from fastapi import (
    APIRouter,
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
    status,
)
from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import ValidationError

from .runtime import AgentRuntime
from .models import (
    Agent,
    AgentCreate,
    AgentUpdate,
    AgentList,
    TaskCreate,
    TaskResponse,
    Run,
    RunList,
    RunStepsList,
    RunLogsList,
    MemoryCreate,
    Memory,
    MemoryList,
    MemoryType,
    Artifact,
    ArtifactList,
    ToolSummary,
    ToolsList,
    ToolInvokeRequest,
    ToolInvokeResponse,
    Channel,
    ChannelsList,
    RunStatus,
    SessionInfo,
    SessionList,
    SessionExportResponse,
    SessionImportRequest,
    SessionClearResponse,
)
from .errors import (
    AgentAPIException,
    AgentNotFound,
    RunNotFound,
    ToolNotFound,
    create_error_response,
    agent_api_exception_handler,
    validation_exception_handler,
    generic_exception_handler,
)
from .auth import require_bearer_auth, create_auth_token

if TYPE_CHECKING:
    from ...agent import Agent as ContextwiseAgent

logger = logging.getLogger(__name__)


# =============================================================================
# Router Factory
# =============================================================================

def create_agent_api_router(
    runtime: AgentRuntime,
    require_auth: bool = False,
) -> APIRouter:
    """Create a FastAPI router for the Agent Platform API.

    Args:
        runtime: AgentRuntime instance for state management
        require_auth: Whether to require bearer token authentication

    Returns:
        Configured APIRouter with all platform endpoints
    """
    router = APIRouter(prefix="/v1", tags=["Agent Platform API"])

    # Auth dependency (optional)
    auth_dep = require_bearer_auth if require_auth else lambda: None

    # =========================================================================
    # Agent Endpoints
    # =========================================================================

    @router.get("/agents", response_model=AgentList)
    async def list_agents(token: Optional[str] = Depends(auth_dep)):
        """List all available agents."""
        agents = runtime.list_agents()
        return AgentList(items=agents)

    @router.post("/agents", response_model=Agent, status_code=status.HTTP_201_CREATED)
    async def create_agent(
        request: AgentCreate,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Create a new agent.

        Note: This endpoint has limitations in the current implementation.
        Creating agents dynamically from API config requires a tool registry
        to map tool names to callables. For now, agents should be pre-registered
        with the runtime.
        """
        # For now, raise an error indicating this is not yet supported
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Dynamic agent creation not yet implemented. Pre-register agents with runtime.",
        )

    @router.get("/agents/{agentId}", response_model=Agent)
    async def get_agent(
        agentId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Get an agent by ID."""
        try:
            metadata = runtime.get_agent_metadata(agentId)
            return metadata
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.patch("/agents/{agentId}", response_model=Agent)
    async def update_agent(
        agentId: str,
        request: AgentUpdate,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Update an agent."""
        try:
            metadata = runtime.update_agent_metadata(
                agent_id=agentId,
                name=request.name,
                description=request.description,
                config=request.config,
            )
            return metadata
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.delete("/agents/{agentId}", status_code=status.HTTP_204_NO_CONTENT)
    async def delete_agent(
        agentId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Delete an agent."""
        try:
            runtime.delete_agent(agentId)
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    # =========================================================================
    # Task & Run Endpoints
    # =========================================================================

    @router.post("/agents/{agentId}/tasks", response_model=TaskResponse, status_code=status.HTTP_201_CREATED)
    async def create_task(
        agentId: str,
        request: TaskCreate,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Create a new task for an agent.

        This endpoint creates a task and associated run, then spawns a
        background execution coroutine.
        """
        try:
            # Create task and run
            task_id, run_id = runtime.create_task(
                agent_id=agentId,
                message=request.message,
                user_id=request.user_id,
                session_id=request.session_id,
                context=request.context,
            )

            # Spawn background execution
            asyncio.create_task(_execute_run(runtime, run_id))

            return TaskResponse(task_id=task_id, run_id=run_id)

        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.get("/runs", response_model=RunList)
    async def list_runs(
        agent_id: Optional[str] = Query(None),
        status: Optional[RunStatus] = Query(None),
        token: Optional[str] = Depends(auth_dep),
    ):
        """List runs with optional filtering."""
        runs = runtime.list_runs(agent_id=agent_id, status=status)
        return RunList(items=runs)

    @router.get("/runs/{runId}", response_model=Run)
    async def get_run(
        runId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Get a run by ID."""
        try:
            run = runtime.get_run(runId)
            return run
        except RunNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.get("/runs/{runId}/stream")
    async def stream_run(
        runId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Stream SSE events for a run."""
        try:
            run = runtime.get_run(runId)
        except RunNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

        return StreamingResponse(
            _stream_run_events(runtime, runId),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    @router.post("/runs/{runId}/cancel", response_model=Run)
    async def cancel_run(
        runId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Cancel a running task."""
        try:
            run = runtime.cancel_run(runId)
            return run
        except RunNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    # =========================================================================
    # Steps & Logs Endpoints
    # =========================================================================

    @router.get("/runs/{runId}/steps", response_model=RunStepsList)
    async def list_run_steps(
        runId: str,
        after_step: Optional[int] = Query(None),
        limit: Optional[int] = Query(200, ge=1, le=200),
        type: Optional[str] = Query(None),
        token: Optional[str] = Depends(auth_dep),
    ):
        """List structured steps for a run."""
        try:
            runtime.get_run(runId)  # Verify run exists
        except RunNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

        steps = runtime.get_steps(runId)

        # Filter by after_step
        if after_step is not None:
            steps = [s for s in steps if s.step > after_step]

        # Filter by type
        if type is not None:
            steps = [s for s in steps if s.type == type]

        # Apply limit
        steps = steps[:limit]

        return RunStepsList(items=steps)

    @router.get("/runs/{runId}/logs", response_model=RunLogsList)
    async def list_run_logs(
        runId: str,
        after_step: Optional[int] = Query(None),
        since: Optional[str] = Query(None),
        limit: Optional[int] = Query(200, ge=1, le=1000),
        token: Optional[str] = Depends(auth_dep),
    ):
        """List log entries for a run."""
        try:
            runtime.get_run(runId)  # Verify run exists
        except RunNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

        logs = runtime.get_logs(runId)

        # Filter by after_step
        if after_step is not None:
            logs = [log for log in logs if log.step is not None and log.step > after_step]

        # TODO: Filter by since timestamp

        # Apply limit
        logs = logs[:limit]

        return RunLogsList(items=logs)

    # =========================================================================
    # Memory Endpoints
    # =========================================================================

    @router.post("/agents/{agentId}/memory", response_model=Memory, status_code=status.HTTP_201_CREATED)
    async def create_memory(
        agentId: str,
        request: MemoryCreate,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Create a memory entry for an agent."""
        try:
            memory = runtime.create_memory(
                agent_id=agentId,
                memory_type=request.type,
                label=request.label,
                data=request.data,
            )
            return memory
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.get("/agents/{agentId}/memory", response_model=MemoryList)
    async def list_memory(
        agentId: str,
        type: Optional[MemoryType] = Query(None),
        search: Optional[str] = Query(None),
        limit: Optional[int] = Query(50, ge=1, le=200),
        token: Optional[str] = Depends(auth_dep),
    ):
        """Query memory for an agent."""
        try:
            memories = runtime.list_memory(
                agent_id=agentId,
                memory_type=type,
                search=search,
            )

            # Apply limit
            memories = memories[:limit]

            return MemoryList(items=memories)
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.delete("/agents/{agentId}/memory/{memoryId}", status_code=status.HTTP_204_NO_CONTENT)
    async def delete_memory(
        agentId: str,
        memoryId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Delete a memory entry."""
        try:
            runtime.delete_memory(agentId, memoryId)
        except (AgentNotFound, Exception) as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    # =========================================================================
    # Artifact Endpoints
    # =========================================================================

    @router.post("/runs/{runId}/artifacts", response_model=Artifact, status_code=status.HTTP_201_CREATED)
    async def upload_artifact(
        runId: str,
        file: UploadFile = File(...),
        metadata: Optional[str] = Form(None),
        token: Optional[str] = Depends(auth_dep),
    ):
        """Upload an artifact for a run."""
        try:
            runtime.get_run(runId)  # Verify run exists
        except RunNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

        # Parse metadata
        metadata_dict = {}
        if metadata:
            try:
                metadata_dict = json.loads(metadata)
            except json.JSONDecodeError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid JSON in metadata field",
                )

        # Read file content
        content = await file.read()
        size_bytes = len(content)

        # Save file to artifacts directory
        artifacts_dir = Path("./agent_api_artifacts") / runId
        artifacts_dir.mkdir(parents=True, exist_ok=True)

        artifact_id = f"art_{uuid.uuid4().hex[:12]}"
        file_path = artifacts_dir / f"{artifact_id}_{file.filename}"

        with open(file_path, "wb") as f:
            f.write(content)

        # Create artifact record
        artifact = runtime.create_artifact(
            run_id=runId,
            filename=file.filename,
            content_type=file.content_type,
            size_bytes=size_bytes,
            url=f"/v1/runs/{runId}/artifacts/{artifact_id}/download",
            metadata=metadata_dict,
        )

        logger.info(f"Uploaded artifact {artifact_id} for run {runId}")
        return artifact

    @router.get("/runs/{runId}/artifacts", response_model=ArtifactList)
    async def list_artifacts(
        runId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """List artifacts for a run."""
        try:
            artifacts = runtime.list_artifacts(runId)
            return ArtifactList(items=artifacts)
        except RunNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.get("/runs/{runId}/artifacts/{artifactId}", response_model=Artifact)
    async def get_artifact(
        runId: str,
        artifactId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Get artifact metadata."""
        try:
            artifact = runtime.get_artifact(runId, artifactId)
            return artifact
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.get("/runs/{runId}/artifacts/{artifactId}/download")
    async def download_artifact(
        runId: str,
        artifactId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Download artifact bytes."""
        try:
            artifact = runtime.get_artifact(runId, artifactId)
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

        # Find file in artifacts directory
        artifacts_dir = Path("./agent_api_artifacts") / runId
        matching_files = list(artifacts_dir.glob(f"{artifactId}_*"))

        if not matching_files:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Artifact file not found on disk",
            )

        file_path = matching_files[0]

        return FileResponse(
            path=file_path,
            filename=artifact.filename,
            media_type=artifact.content_type or "application/octet-stream",
        )

    @router.delete("/runs/{runId}/artifacts/{artifactId}", status_code=status.HTTP_204_NO_CONTENT)
    async def delete_artifact(
        runId: str,
        artifactId: str,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Delete an artifact."""
        try:
            artifact = runtime.get_artifact(runId, artifactId)
        except Exception as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

        # Delete file from disk
        artifacts_dir = Path("./agent_api_artifacts") / runId
        matching_files = list(artifacts_dir.glob(f"{artifactId}_*"))

        for file_path in matching_files:
            file_path.unlink()

        # Remove from runtime
        if runId in runtime.artifacts and artifactId in runtime.artifacts[runId]:
            del runtime.artifacts[runId][artifactId]

    # =========================================================================
    # Tools Endpoints
    # =========================================================================

    @router.get("/tools", response_model=ToolsList)
    async def list_tools(
        agent_id: Optional[str] = Query(None),
        include_schemas: bool = Query(False),
        include_internal: bool = Query(False),
        token: Optional[str] = Depends(auth_dep),
    ):
        """List available tools."""
        tools: List[ToolSummary] = []

        # If agent_id specified, get tools from that agent only
        if agent_id:
            try:
                agent = runtime.get_agent(agent_id)
                tools = _extract_tools_from_agent(agent, include_schemas)
            except AgentNotFound as e:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
        else:
            # Get tools from all agents
            for agent in runtime.agents.values():
                tools.extend(_extract_tools_from_agent(agent, include_schemas))

        return ToolsList(items=tools)

    @router.post("/tools/{toolName}/invoke", response_model=ToolInvokeResponse)
    async def invoke_tool(
        toolName: str,
        request: ToolInvokeRequest,
        token: Optional[str] = Depends(auth_dep),
    ):
        """Invoke a tool out-of-band."""
        # Find the tool across all agents
        tool_callable = None
        for agent in runtime.agents.values():
            for tool in agent.tools or []:
                tool_name = getattr(tool, "name", getattr(tool, "__name__", None))
                if tool_name == toolName:
                    tool_callable = tool
                    break
            if tool_callable:
                break

        if not tool_callable:
            raise ToolNotFound(toolName)

        # Invoke the tool
        try:
            # Check if tool is async
            import inspect
            if inspect.iscoroutinefunction(tool_callable):
                result = await tool_callable(**request.args)
            else:
                result = tool_callable(**request.args)

            return ToolInvokeResponse(result=result)

        except Exception as e:
            logger.exception(f"Tool invocation failed: {toolName}")
            from .errors import ToolInvocationError
            raise ToolInvocationError(toolName, str(e))

    # =========================================================================
    # Channels Endpoints
    # =========================================================================

    @router.get("/channels", response_model=ChannelsList)
    async def list_channels(
        agent_id: Optional[str] = Query(None),
        include_known: bool = Query(True),
        token: Optional[str] = Depends(auth_dep),
    ):
        """List available channels."""
        channels: List[Channel] = []

        # Get channels from specified agent or all agents
        agents_to_check = []
        if agent_id:
            try:
                agents_to_check = [runtime.get_agent(agent_id)]
            except AgentNotFound as e:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
        else:
            agents_to_check = list(runtime.agents.values())

        # Extract channels from agents
        seen_types = set()
        for agent in agents_to_check:
            for channel in agent.channels:
                channel_data = _extract_channel_info(channel)
                if channel_data and channel_data.type not in seen_types:
                    channels.append(channel_data)
                    seen_types.add(channel_data.type)

        # Optionally include known channel types (even if not configured)
        if include_known:
            known_channels = _get_known_channels()
            for channel in known_channels:
                if channel.type not in seen_types:
                    channels.append(channel)

        return ChannelsList(items=channels)

    # =========================================================================
    # Session Endpoints
    # =========================================================================

    @router.get("/sessions", response_model=SessionList)
    async def list_sessions(
        agent_id: str = Query(..., description="Agent ID"),
        user_id: Optional[str] = Query(None, description="Filter by user ID"),
        channel: Optional[str] = Query(None, description="Filter by channel"),
        token: Optional[str] = Depends(auth_dep),
    ):
        """List sessions for an agent with optional filtering."""
        try:
            agent = runtime.get_agent(agent_id)
            sessions = await agent.list_sessions(user_id=user_id, channel=channel)
            
            session_items = [
                SessionInfo(
                    session_id=s["session_id"],
                    user_id=s["user_id"],
                    created_at=datetime.fromisoformat(s["created_at"]),
                    last_activity=datetime.fromisoformat(s["last_activity"]),
                    message_count=s["message_count"],
                    channel=s["channel"],
                    metadata=s["metadata"],
                )
                for s in sessions
            ]
            
            return SessionList(items=session_items)
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.get("/sessions/{sessionId}", response_model=SessionInfo)
    async def get_session(
        sessionId: str,
        agent_id: str = Query(..., description="Agent ID"),
        token: Optional[str] = Depends(auth_dep),
    ):
        """Get session information."""
        try:
            agent = runtime.get_agent(agent_id)
            session_data = await agent.get_session_info(sessionId)
            
            if not session_data:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Session {sessionId} not found"
                )
            
            return SessionInfo(
                session_id=session_data["session_id"],
                user_id=session_data["user_id"],
                created_at=datetime.fromisoformat(session_data["created_at"]),
                last_activity=datetime.fromisoformat(session_data["last_activity"]),
                message_count=session_data["message_count"],
                channel=session_data["channel"],
                metadata=session_data["metadata"],
            )
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.post("/sessions/{sessionId}/clear", response_model=SessionClearResponse)
    async def clear_session(
        sessionId: str,
        agent_id: str = Query(..., description="Agent ID"),
        token: Optional[str] = Depends(auth_dep),
    ):
        """Clear a session's conversation history."""
        try:
            agent = runtime.get_agent(agent_id)
            cleared = await agent.clear_session(sessionId)
            
            return SessionClearResponse(
                session_id=sessionId,
                cleared=cleared,
                message=f"Session {sessionId} cleared" if cleared else f"Session {sessionId} not found"
            )
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.get("/sessions/{sessionId}/export", response_model=SessionExportResponse)
    async def export_session(
        sessionId: str,
        agent_id: str = Query(..., description="Agent ID"),
        token: Optional[str] = Depends(auth_dep),
    ):
        """Export session data for backup or migration."""
        try:
            agent = runtime.get_agent(agent_id)
            export_data = await agent.export_session(sessionId)
            
            if not export_data:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Session {sessionId} not found"
                )
            
            return SessionExportResponse(
                session_id=sessionId,
                export_data=export_data
            )
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    @router.post("/sessions/import", response_model=SessionInfo)
    async def import_session(
        request: SessionImportRequest,
        agent_id: str = Query(..., description="Agent ID"),
        token: Optional[str] = Depends(auth_dep),
    ):
        """Import session data from export."""
        try:
            agent = runtime.get_agent(agent_id)
            success = await agent.import_session(request.export_data)
            
            if not success:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Failed to import session data"
                )
            
            import json
            export_dict = json.loads(request.export_data)
            metadata = export_dict["metadata"]
            
            return SessionInfo(
                session_id=metadata["session_id"],
                user_id=metadata["user_id"],
                created_at=datetime.fromisoformat(metadata["created_at"]),
                last_activity=datetime.fromisoformat(metadata["last_activity"]),
                message_count=metadata["message_count"],
                channel=metadata["channel"],
                metadata=metadata["metadata"],
            )
        except AgentNotFound as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
        except json.JSONDecodeError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid export data format"
            )

    return router


# =============================================================================
# Helper Functions
# =============================================================================

async def _execute_run(runtime: AgentRuntime, run_id: str) -> None:
    """Execute a run in the background.

    Args:
        runtime: AgentRuntime instance
        run_id: Run ID
    """
    try:
        run = runtime.get_run(run_id)
        agent = runtime.get_agent(run.agent_id)

        # Update status to running
        runtime.update_run_status(run_id, RunStatus.RUNNING)
        await runtime.emit_event(run_id, {"type": "run.status", "status": "running"})

        # Add log entry
        runtime.add_log(run_id, action="run_started", message="Run started")

        # Execute agent
        try:
            response = await agent.chat_async(
                message=run.message,
                user_id=run.user_id,
                channel="api",
            )

            # Update run with success
            runtime.update_run_status(run_id, RunStatus.SUCCESS, result=response)
            await runtime.emit_event(run_id, {
                "type": "run.output.final",
                "result": response,
            })
            await runtime.emit_event(run_id, {"type": "run.status", "status": "success"})

            # Add log entry
            runtime.add_log(run_id, action="run_completed", message="Run completed successfully")

        except asyncio.CancelledError:
            # Run was cancelled
            runtime.update_run_status(run_id, RunStatus.CANCELLED)
            await runtime.emit_event(run_id, {"type": "run.status", "status": "cancelled"})
            runtime.add_log(run_id, action="run_cancelled", message="Run was cancelled")
            raise

        except Exception as e:
            # Run failed
            error_msg = str(e)
            runtime.update_run_status(run_id, RunStatus.ERROR, error=error_msg)
            await runtime.emit_event(run_id, {
                "type": "run.status",
                "status": "error",
                "error": error_msg,
            })
            runtime.add_log(run_id, action="run_failed", message=f"Run failed: {error_msg}")
            logger.exception(f"Run {run_id} execution failed")

    except Exception as e:
        logger.exception(f"Critical error in run execution: {run_id}")
    finally:
        # Signal completion (for SSE streaming)
        if run_id in runtime.run_queues:
            await runtime.run_queues[run_id].put(None)  # Sentinel value


async def _stream_run_events(runtime: AgentRuntime, run_id: str) -> AsyncGenerator[str, None]:
    """Stream SSE events for a run.

    Args:
        runtime: AgentRuntime instance
        run_id: Run ID

    Yields:
        SSE-formatted event strings
    """
    if run_id not in runtime.run_queues:
        logger.warning(f"No event queue for run {run_id}")
        return

    queue = runtime.run_queues[run_id]

    try:
        while True:
            # Wait for next event
            event = await queue.get()

            # None is sentinel value indicating completion
            if event is None:
                break

            # Format as SSE
            yield f"data: {json.dumps(event)}\n\n"

    except asyncio.CancelledError:
        logger.info(f"SSE stream cancelled for run {run_id}")
    finally:
        # Clean up
        runtime.cleanup_run(run_id)


def _extract_tools_from_agent(agent: "ContextwiseAgent", include_schemas: bool) -> List[ToolSummary]:
    """Extract tools from an agent.

    Args:
        agent: Contextwise Agent instance
        include_schemas: Whether to include tool schemas

    Returns:
        List of ToolSummary instances
    """
    tools = []

    for tool in agent.tools or []:
        tool_name = getattr(tool, "name", getattr(tool, "__name__", "unknown"))
        tool_desc = getattr(tool, "description", getattr(tool, "__doc__", None))

        summary = ToolSummary(
            name=tool_name,
            type="function",
            description=tool_desc,
            owner="agent",
        )

        if include_schemas and hasattr(tool, "parameters"):
            summary.tool_schema = tool.parameters

        tools.append(summary)

    return tools


def _extract_channel_info(channel: Any) -> Optional[Channel]:
    """Extract channel information from a channel instance.

    Args:
        channel: Channel instance or string

    Returns:
        Channel model or None
    """
    if isinstance(channel, str):
        # Simple string channel ID
        return Channel(
            id=f"channel_{channel}",
            type=channel,
            display_name=channel.title(),
            category="api" if channel == "api" else "messaging",
            supports=["text"],
        )

    # Complex channel object
    channel_id = getattr(channel, "channel_id", "unknown")
    channel_type = getattr(channel, "type", channel_id)

    return Channel(
        id=channel_id,
        type=channel_type,
        display_name=getattr(channel, "display_name", channel_type.title()),
        category=getattr(channel, "category", "messaging"),
        supports=getattr(channel, "supports", ["text"]),
    )


def _get_known_channels() -> List[Channel]:
    """Get list of known channel types.

    Returns:
        List of known Channel instances
    """
    return [
        Channel(
            id="channel_api",
            type="api",
            display_name="REST API",
            category="api",
            inbound_path="/chat",
            inbound_stream_path="/chat/stream",
            health_path="/health",
            required_env=[],
            supports=["text", "sse"],
        ),
        Channel(
            id="channel_whatsapp",
            type="whatsapp",
            display_name="WhatsApp",
            category="messaging",
            webhook_path="/whatsapp/webhook",
            health_path="/whatsapp/status",
            required_env=[
                "WHATSAPP_ACCESS_TOKEN",
                "WHATSAPP_PHONE_NUMBER_ID",
                "WHATSAPP_VERIFY_TOKEN",
            ],
            supports=["text", "image", "video", "audio", "document", "voice_call"],
        ),
    ]


# =============================================================================
# Platform App Factory
# =============================================================================

def create_platform_app(
    agents: Optional[List["ContextwiseAgent"]] = None,
    runtime: Optional[AgentRuntime] = None,
    require_auth: bool = False,
    title: str = "Contextwise Agent Platform API",
    version: str = "0.2.0",
) -> FastAPI:
    """Create a standalone FastAPI app for the Agent Platform API.

    Args:
        agents: List of agents to register (optional if runtime provided)
        runtime: Existing AgentRuntime (created if None)
        require_auth: Whether to require bearer token authentication
        title: API title
        version: API version

    Returns:
        Configured FastAPI application

    Example:
        >>> from contextwise import Agent
        >>> from contextwise.lib.agent_api import create_platform_app
        >>>
        >>> agent = Agent("gpt-4o-mini", "You are helpful")
        >>> app = create_platform_app(agents=[agent])
        >>>
        >>> # Run with uvicorn
        >>> import uvicorn
        >>> uvicorn.run(app, host="0.0.0.0", port=8001)
    """
    # Create or use provided runtime
    if runtime is None:
        runtime = AgentRuntime()

    # Register agents
    if agents:
        for agent in agents:
            runtime.register_agent(agent)

    # Create FastAPI app
    app = FastAPI(
        title=title,
        description="Agent Platform REST API for Contextwise v0.3.0",
        version=version,
    )

    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Register exception handlers
    app.add_exception_handler(AgentAPIException, agent_api_exception_handler)
    app.add_exception_handler(ValidationError, validation_exception_handler)
    app.add_exception_handler(Exception, generic_exception_handler)

    # Create and include router
    router = create_agent_api_router(runtime, require_auth=require_auth)
    app.include_router(router)

    # Health check endpoint
    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        return {
            "status": "healthy",
            "agents": len(runtime.agents),
            "runs": len(runtime.runs),
        }

    # Auth token endpoint (for development/testing)
    @app.post("/v1/auth/token")
    async def get_auth_token():
        """Get an auth token (development/testing only)."""
        token = create_auth_token()
        return {"token": token, "type": "bearer"}

    logger.info(f"Platform API created with {len(runtime.agents)} agents")

    return app
