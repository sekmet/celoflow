"""Proactive Features Plugin Ecosystem for Contextwise v0.3.0.

This module provides proactive automation capabilities that enable agents to
independently monitor, schedule, and execute tasks without user intervention.

Components:
    - HeartbeatPlugin: Periodic automated checks with configurable intervals
    - SystemEventsPlugin: In-memory event queue with deduplication
    - WakeTriggerPlugin: Immediate activation mechanism with coalescing
    - ProactiveSchedulerMixin: Enhanced job scheduling with plugin integration
    - EnhancedAPSchedulerPlugin: Extended scheduler with proactive metadata
    - WebhookPlugin: External webhook integration with authentication

Example:
    >>> from contextwise import Agent
    >>> from contextwise.lib.proactive import HeartbeatPlugin, HeartbeatConfig
    >>>
    >>> agent = Agent(
    ...     model="gpt-5-mini-2025-08-07",
    ...     plugins=[
    ...         HeartbeatPlugin(config=HeartbeatConfig(
    ...             interval_minutes=30,
    ...             enable_channel_delivery=True,
    ...         )),
    ...     ],
    ... )

Webhook Example:
    >>> from contextwise.lib.proactive import WebhookPlugin, WebhookConfig
    >>>
    >>> agent = Agent(
    ...     model="gpt-5-mini-2025-08-07",
    ...     plugins=[
    ...         WebhookPlugin(config=WebhookConfig(
    ...             enabled=True,
    ...             auth_method="bearer",
    ...             bearer_tokens=["my-secret-token"],
    ...         )),
    ...     ],
    ... )
"""

from .heartbeat_plugin import HeartbeatConfig, HeartbeatPlugin
from .system_events_plugin import SystemEvent, SystemEventsPlugin
from .wake_trigger_plugin import WakeCoordinator, WakeRequest, WakeTriggerPlugin
from .scheduler_mixin import ProactiveSchedulerMixin
from .enhanced_scheduler_plugin import (
    EnhancedAPSchedulerPlugin,
    EnhancedJobConfig,
    EnhancedSchedulerConfig,
    SessionTarget,
    WakeMode,
    PayloadKind,
)
from .webhook_plugin import (
    WebhookPlugin,
    WebhookConfig,
    WebhookEvent,
    WebhookResponse,
    ExecutionMode,
    AuthMethod,
    RateLimitConfig,
)

__all__ = [
    # Heartbeat
    "HeartbeatConfig",
    "HeartbeatPlugin",
    # System Events
    "SystemEvent",
    "SystemEventsPlugin",
    # Wake Trigger
    "WakeCoordinator",
    "WakeRequest",
    "WakeTriggerPlugin",
    # Scheduler
    "ProactiveSchedulerMixin",
    "EnhancedAPSchedulerPlugin",
    "EnhancedJobConfig",
    "EnhancedSchedulerConfig",
    "SessionTarget",
    "WakeMode",
    "PayloadKind",
    # Webhook
    "WebhookPlugin",
    "WebhookConfig",
    "WebhookEvent",
    "WebhookResponse",
    "ExecutionMode",
    "AuthMethod",
    "RateLimitConfig",
]
