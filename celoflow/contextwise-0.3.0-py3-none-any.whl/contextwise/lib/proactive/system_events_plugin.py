"""System Events Plugin for Contextwise v0.3.0.

This module provides an in-memory event queue with deduplication
for cross-plugin communication and event tracking.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from agents import Agent, RunContextWrapper, Tool, ToolOutputText, function_tool

from ..base import AgentPlugin
from ..context import AgentContext

logger = logging.getLogger(__name__)


@dataclass
class SystemEvent:
    """System event for queue."""

    text: str
    timestamp: float
    source: str = "system"


class SystemEventsPlugin(AgentPlugin[AgentContext]):
    """Plugin for managing system events queue.

    Provides an in-memory ephemeral event queue with deduplication
    for cross-plugin communication and proactive event tracking.

    Attributes:
        id: Plugin identifier
        name: Human-readable plugin name
        version: Plugin version
    """

    id = "system_events"
    name = "System Events Plugin"
    version = "1.0.0"

    def __init__(self, max_events: int = 20):
        """Initialize the system events plugin.

        Args:
            max_events: Maximum events per session queue (default 20)
        """
        self._queues: Dict[str, List[SystemEvent]] = {}
        self._max_events = max_events

    def dependencies(self) -> List[str]:
        """Return plugin dependencies."""
        return []

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Add system events tools to agent."""
        tools = [
            self._make_enqueue_event_tool(),
            self._make_peek_events_tool(),
            self._make_drain_events_tool(),
            self._make_clear_events_tool(),
        ]
        return agent.clone(tools=[*agent.tools, *tools])

    def _make_enqueue_event_tool(self) -> Tool:
        """Create tool for enqueuing system events."""

        @function_tool
        def enqueue_system_event(
            ctx: RunContextWrapper[AgentContext],
            text: str,
            source: str = "user",
        ) -> ToolOutputText:
            """Add event to system events queue.

            Args:
                text: Event text/message
                source: Event source identifier
            """
            session_key = self._get_session_key(ctx)
            self.enqueue_event(text, session_key, source)
            return ToolOutputText(text=f"Event enqueued: {text[:50]}...")

        return enqueue_system_event

    def _make_peek_events_tool(self) -> Tool:
        """Create tool for peeking at events."""

        @function_tool
        def peek_system_events(
            ctx: RunContextWrapper[AgentContext],
            limit: int = 10,
        ) -> ToolOutputText:
            """View events in queue without removing them.

            Args:
                limit: Maximum number of events to return
            """
            session_key = self._get_session_key(ctx)
            events = self.peek_events(session_key)

            if not events:
                return ToolOutputText(text="No events in queue")

            lines = [f"System Events Queue ({len(events)} events):"]
            for i, event in enumerate(events[-limit:], 1):
                timestamp = datetime.fromtimestamp(event.timestamp).strftime("%H:%M:%S")
                lines.append(f"{i}. [{timestamp}] {event.source}: {event.text}")

            return ToolOutputText(text="\n".join(lines))

        return peek_system_events

    def _make_drain_events_tool(self) -> Tool:
        """Create tool for draining events."""

        @function_tool
        def drain_system_events(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            """Get and remove all events from queue."""
            session_key = self._get_session_key(ctx)
            events = self.drain_events(session_key)

            if not events:
                return ToolOutputText(text="No events in queue")

            lines = [f"Drained {len(events)} events:"]
            for i, event in enumerate(events, 1):
                timestamp = datetime.fromtimestamp(event.timestamp).strftime("%H:%M:%S")
                lines.append(f"{i}. [{timestamp}] {event.source}: {event.text}")

            return ToolOutputText(text="\n".join(lines))

        return drain_system_events

    def _make_clear_events_tool(self) -> Tool:
        """Create tool for clearing events."""

        @function_tool
        def clear_system_events(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            """Clear all events from queue."""
            session_key = self._get_session_key(ctx)
            count = len(self._queues.get(session_key, []))
            self._queues[session_key] = []
            return ToolOutputText(text=f"Cleared {count} events from queue")

        return clear_system_events

    def enqueue_event(
        self, text: str, session_key: str, source: str = "system"
    ) -> None:
        """Add event to session queue.

        Args:
            text: Event text/message
            session_key: Session identifier
            source: Event source identifier
        """
        if session_key not in self._queues:
            self._queues[session_key] = []

        queue = self._queues[session_key]

        # Deduplicate consecutive identical events
        if queue and queue[-1].text == text:
            logger.debug(f"Skipping duplicate event: {text[:50]}...")
            return

        queue.append(
            SystemEvent(text=text, timestamp=datetime.now().timestamp(), source=source)
        )

        # Enforce max events limit
        if len(queue) > self._max_events:
            self._queues[session_key] = queue[-self._max_events :]

        logger.debug(f"Enqueued system event for {session_key}: {text[:50]}...")

    def drain_events(self, session_key: str) -> List[SystemEvent]:
        """Get and clear events for session.

        Args:
            session_key: Session identifier

        Returns:
            List of system events
        """
        events = self._queues.get(session_key, [])
        self._queues[session_key] = []
        return events

    def peek_events(self, session_key: str) -> List[SystemEvent]:
        """Get events without clearing.

        Args:
            session_key: Session identifier

        Returns:
            Copy of events list
        """
        return self._queues.get(session_key, []).copy()

    def get_event_count(self, session_key: str) -> int:
        """Get count of events in queue.

        Args:
            session_key: Session identifier

        Returns:
            Number of events
        """
        return len(self._queues.get(session_key, []))

    def _get_session_key(self, ctx: RunContextWrapper[AgentContext]) -> str:
        """Extract session key from context.

        Args:
            ctx: Run context wrapper

        Returns:
            Session key string
        """
        if ctx and hasattr(ctx, "context") and ctx.context:
            user_id = getattr(ctx.context, "user_id", "default")
            session_id = getattr(ctx.context, "session_id", "main") or "main"
            return f"{user_id}:{session_id}"
        return "default:main"
