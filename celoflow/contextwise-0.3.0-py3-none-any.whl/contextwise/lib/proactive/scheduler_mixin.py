"""Proactive Scheduler Mixin for Contextwise v0.3.0.

This module provides enhanced scheduling capabilities with plugin integration
for proactive job execution.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from ..context import AgentContext

logger = logging.getLogger(__name__)


class CronSessionTarget(str, Enum):
    """Target session for cron job execution."""

    MAIN = "main"
    ISOLATED = "isolated"


class CronWakeMode(str, Enum):
    """Wake mode for cron jobs."""

    NOW = "now"
    NEXT_HEARTBEAT = "next-heartbeat"


class CronPayloadKind(str, Enum):
    """Types of cron payloads."""

    SYSTEM_EVENT = "systemEvent"
    AGENT_TURN = "agentTurn"


@dataclass
class EnhancedJobConfig:
    """Enhanced job configuration with proactive features."""

    job_id: str
    name: str
    schedule: Optional[str] = None
    run_at: Optional[str] = None
    target: Optional[Callable] = None
    priority: int = 5
    enabled: bool = True
    max_retries: int = 3
    timezone: str = "UTC"
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Proactive features
    session_target: CronSessionTarget = CronSessionTarget.MAIN
    wake_mode: CronWakeMode = CronWakeMode.NEXT_HEARTBEAT
    payload_kind: CronPayloadKind = CronPayloadKind.SYSTEM_EVENT
    payload_message: str = ""
    deliver_to_channel: Optional[str] = None
    deliver_to_recipient: Optional[str] = None
    agent_id: Optional[str] = None

    # Plugin integration options
    use_memory_for_context: bool = True
    use_observability: bool = True
    store_results_in_memory: bool = True


class ProactiveSchedulerMixin:
    """Mixin adding proactive features to scheduler backends.

    Provides:
    - System events queue with deduplication
    - Heartbeat callback registration
    - Immediate wake requests
    - Plugin integration for job execution
    """

    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self._system_events_queue: Dict[str, List[str]] = {}
        self._heartbeat_callback: Optional[Callable] = None

        # Plugin integration references
        self._memory_plugin: Optional[Any] = None
        self._observability_plugin: Optional[Any] = None
        self._system_events_plugin: Optional[Any] = None
        self._agent_plugins: Dict[str, Any] = {}

    def set_agent_plugins(self, plugins: Dict[str, Any]) -> None:
        """Set references to other agent plugins for integration.

        Args:
            plugins: Dictionary of plugin_id -> plugin instance
        """
        self._agent_plugins = plugins
        self._memory_plugin = plugins.get("agentfs_memory")
        self._observability_plugin = plugins.get("opik_observability")
        self._system_events_plugin = plugins.get("system_events")

        logger.debug(
            f"Proactive scheduler plugins set: memory={bool(self._memory_plugin)}, "
            f"observability={bool(self._observability_plugin)}, "
            f"system_events={bool(self._system_events_plugin)}"
        )

    def set_heartbeat_callback(self, callback: Callable) -> None:
        """Register callback for immediate heartbeat triggers.

        Args:
            callback: Function to call for immediate heartbeat
        """
        self._heartbeat_callback = callback
        logger.debug("Heartbeat callback registered")

    def enqueue_system_event(
        self, text: str, session_key: str = "default", source: str = "cron"
    ) -> None:
        """Add event to system queue for session.

        Args:
            text: Event text
            session_key: Session identifier
            source: Event source
        """
        if session_key not in self._system_events_queue:
            self._system_events_queue[session_key] = []

        queue = self._system_events_queue[session_key]

        # Deduplication logic - skip consecutive duplicates
        if queue and queue[-1] == text:
            logger.debug(f"Skipping duplicate system event: {text[:50]}...")
            return

        queue.append(text)

        # Keep only last 20 events
        if len(queue) > 20:
            self._system_events_queue[session_key] = queue[-20:]

        # Also add to system events plugin if available
        if self._system_events_plugin:
            self._system_events_plugin.enqueue_event(text, session_key, source)

        logger.debug(f"Enqueued system event for {session_key}: {text[:50]}...")

    def drain_system_events(self, session_key: str = "default") -> List[str]:
        """Get and clear events for session.

        Args:
            session_key: Session identifier

        Returns:
            List of event strings
        """
        events = self._system_events_queue.get(session_key, [])
        self._system_events_queue[session_key] = []
        return events

    def peek_system_events(self, session_key: str = "default") -> List[str]:
        """Get events without clearing.

        Args:
            session_key: Session identifier

        Returns:
            Copy of events list
        """
        return self._system_events_queue.get(session_key, []).copy()

    def request_immediate_wake(self, reason: str = "requested") -> None:
        """Request immediate heartbeat execution.

        Args:
            reason: Reason for wake request
        """
        if self._heartbeat_callback:
            try:
                result = self._heartbeat_callback(reason)
                if asyncio.iscoroutine(result):
                    asyncio.create_task(result)
                logger.info(f"Immediate wake requested: {reason}")
            except Exception as e:
                logger.error(f"Failed to trigger immediate wake: {e}")
        else:
            logger.warning("No heartbeat callback registered for immediate wake")

        # Add system event for tracking
        if self._observability_plugin:
            logger.debug(f"Immediate wake tracked in observability: {reason}")

    async def execute_job_with_plugins(
        self, job_config: EnhancedJobConfig, context: Dict[str, Any]
    ) -> Any:
        """Execute job with full plugin integration.

        Args:
            job_config: Enhanced job configuration
            context: Execution context

        Returns:
            Job execution result
        """
        # Create observability span if available
        span = None
        if self._observability_plugin and job_config.use_observability:
            try:
                span = self._observability_plugin.start_tool_span(
                    context=context.get("agent_context"),
                    tool_name="proactive_job",
                    arguments={
                        "job_id": job_config.job_id,
                        "job_name": job_config.name,
                        "session_target": job_config.session_target.value,
                        "payload_kind": job_config.payload_kind.value,
                    },
                )
            except Exception as e:
                logger.warning(f"Failed to create observability span: {e}")

        try:
            result = None

            if job_config.session_target == CronSessionTarget.MAIN:
                # Enqueue system event for main session
                self.enqueue_system_event(
                    job_config.payload_message,
                    context.get("session_key", "default"),
                    "cron",
                )

                # Get context from memory if enabled
                if job_config.use_memory_for_context and self._memory_plugin:
                    try:
                        memory_context = self._memory_plugin.client.get_context(
                            query=job_config.payload_message,
                            session_id=context.get("session_key"),
                            limit=3,
                        )
                        if memory_context.get("results"):
                            enriched_message = (
                                job_config.payload_message
                                + "\n\nContext from memory:\n"
                            )
                            for mem_result in memory_context["results"][:2]:
                                enriched_message += f"- {mem_result.get('text', '')}\n"
                            # Update the message in system events
                            self.enqueue_system_event(
                                enriched_message,
                                context.get("session_key", "default"),
                                "cron_memory",
                            )
                    except Exception as e:
                        logger.warning(f"Failed to get memory context for cron job: {e}")

                # Trigger wake if needed
                if job_config.wake_mode == CronWakeMode.NOW:
                    self.request_immediate_wake(f"cron:{job_config.job_id}")

                result = "Event enqueued for main session"

            else:  # ISOLATED
                # Run isolated agent turn with plugin integration
                result = await self._run_isolated_agent_turn(job_config, context)

                # Store result in memory if enabled
                if job_config.store_results_in_memory and self._memory_plugin:
                    try:
                        session_key = context.get("session_key", "isolated")
                        self._memory_plugin.client.store_memory(
                            text=f"Cron job {job_config.job_id} result: {result}",
                            session_id=session_key,
                            tags=["cron", "isolated", job_config.job_id],
                        )
                    except Exception as e:
                        logger.warning(f"Failed to store cron result in memory: {e}")

            # Close observability span
            if span:
                try:
                    self._observability_plugin.end_tool_span(span, result=result)
                except Exception as e:
                    logger.warning(f"Failed to end observability span: {e}")

            return result

        except Exception as e:
            logger.error(f"Cron job execution failed: {e}")
            if span:
                try:
                    self._observability_plugin.end_tool_span(span, error=e)
                except Exception:
                    pass
            raise

    async def _run_isolated_agent_turn(
        self, config: EnhancedJobConfig, context: Dict[str, Any]
    ) -> Any:
        """Execute agent in isolated session.

        Args:
            config: Enhanced job configuration
            context: Execution context

        Returns:
            Execution result
        """
        # Create isolated context
        isolated_context = AgentContext(
            user_id=config.agent_id or "cron",
            session_id=f"cron:{config.job_id}",
            channel="cron",
            metadata={
                "cron_job": True,
                "job_id": config.job_id,
                "job_name": config.name,
            },
        )

        # Get additional context from memory if enabled
        enriched_message = config.payload_message
        if config.use_memory_for_context and self._memory_plugin:
            try:
                memory_context = self._memory_plugin.client.get_context(
                    query=config.payload_message, limit=5
                )
                if memory_context.get("results"):
                    enriched_message += "\n\nRelevant context from memory:\n"
                    for mem_result in memory_context["results"][:3]:
                        enriched_message += f"- {mem_result.get('text', '')}\n"
            except Exception as e:
                logger.warning(f"Failed to get memory context for isolated job: {e}")

        # Execute the job target if available
        if config.target:
            try:
                result = config.target({"message": enriched_message, "context": isolated_context})
                if asyncio.iscoroutine(result):
                    result = await result
                return result
            except Exception as e:
                logger.error(f"Isolated job target execution failed: {e}")
                return f"Error executing job: {e}"

        return f"Executed isolated job: {config.name} - {enriched_message[:100]}..."
