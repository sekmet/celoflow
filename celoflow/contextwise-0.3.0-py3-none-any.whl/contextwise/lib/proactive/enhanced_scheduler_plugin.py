"""Enhanced Scheduler Plugin for Contextwise v0.3.0.

This module provides enhanced job scheduling capabilities with proactive-specific
metadata, webhook integration, and plugin coordination features.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

from agents import Agent, RunContextWrapper, Tool, ToolOutputText, function_tool

from ..base import AgentPlugin
from ..context import AgentContext
from ..scheduler.base import (
    JobConfig,
    JobExecution,
    JobInfo,
    JobStatus,
    RetryStrategy,
)

logger = logging.getLogger(__name__)


class SessionTarget(str, Enum):
    """Target session for job execution."""

    MAIN = "main"
    ISOLATED = "isolated"


class WakeMode(str, Enum):
    """Wake mode for scheduled jobs."""

    NOW = "now"
    NEXT_HEARTBEAT = "next_heartbeat"


class PayloadKind(str, Enum):
    """Types of job payloads."""

    SYSTEM_EVENT = "system_event"
    AGENT_TURN = "agent_turn"
    WEBHOOK_TRIGGER = "webhook_trigger"


@dataclass
class EnhancedJobConfig(JobConfig):
    """Enhanced job configuration with proactive and webhook integration.

    Extends base JobConfig with proactive-specific fields for session targeting,
    webhook integration, and plugin coordination.

    Attributes:
        session_target: Whether to execute in main or isolated session
        wake_mode: Immediate execution or wait for next heartbeat
        payload_kind: Type of payload for the job
        payload_message: Message content for the job
        deliver_to_channel: Optional channel for result delivery
        deliver_to_recipient: Optional recipient for delivery
        webhook_source: Source webhook that triggered this job
        event_type: Type of event that triggered the job
        use_memory: Whether to use memory plugin for context
        use_observability: Whether to trace job execution
        store_results: Whether to store results in memory
    """

    session_target: SessionTarget = SessionTarget.MAIN
    wake_mode: WakeMode = WakeMode.NEXT_HEARTBEAT
    payload_kind: PayloadKind = PayloadKind.SYSTEM_EVENT
    payload_message: str = ""
    deliver_to_channel: Optional[str] = None
    deliver_to_recipient: Optional[str] = None
    webhook_source: Optional[str] = None
    event_type: Optional[str] = None
    use_memory: bool = True
    use_observability: bool = True
    store_results: bool = True


@dataclass
class EnhancedSchedulerConfig:
    """Configuration for enhanced scheduler plugin.

    Attributes:
        max_concurrent_jobs: Maximum concurrent job executions
        default_priority: Default job priority (0-10)
        enable_webhook_jobs: Enable webhook-triggered job creation
        enable_plugin_integration: Enable integration with other plugins
        job_timeout_seconds: Default job execution timeout
        history_limit: Maximum execution history per job
    """

    max_concurrent_jobs: int = 5
    default_priority: int = 5
    enable_webhook_jobs: bool = True
    enable_plugin_integration: bool = True
    job_timeout_seconds: int = 300
    history_limit: int = 100


class EnhancedAPSchedulerPlugin(AgentPlugin[AgentContext]):
    """Enhanced scheduler plugin with proactive features and webhook integration.

    Extends the base APScheduler functionality with:
    - Plugin discovery and integration (memory, observability, system events)
    - Webhook-triggered job creation
    - Session targeting (main/isolated)
    - Result delivery via channels
    - Observability tracing

    Attributes:
        id: Plugin identifier
        name: Human-readable plugin name
        version: Plugin version
        config: EnhancedSchedulerConfig instance
    """

    id = "enhanced_scheduler"
    name = "Enhanced APScheduler Plugin"
    version = "1.0.0"

    def __init__(self, config: Optional[EnhancedSchedulerConfig] = None):
        """Initialize enhanced scheduler plugin.

        Args:
            config: Optional EnhancedSchedulerConfig instance
        """
        self.config = config or EnhancedSchedulerConfig()
        self._agent: Optional[Agent] = None

        # Plugin integration references
        self._base_scheduler: Optional[Any] = None
        self._memory_plugin: Optional[Any] = None
        self._observability_plugin: Optional[Any] = None
        self._system_events_plugin: Optional[Any] = None
        self._wake_trigger_plugin: Optional[Any] = None
        self._heartbeat_plugin: Optional[Any] = None

        # Enhanced job tracking
        self._enhanced_jobs: Dict[str, EnhancedJobConfig] = {}
        self._job_results: Dict[str, List[Dict[str, Any]]] = {}
        self._webhook_jobs: Dict[str, str] = {}  # webhook_source -> job_id mapping

    def dependencies(self) -> List[str]:
        """Declare plugin dependencies for proper loading order."""
        return ["apscheduler"]

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Add enhanced scheduler tools and integrate with existing plugins."""
        self._agent = agent

        # Discover and integrate with existing plugins
        plugin_index = getattr(agent, "plugin_index", {}) or {}

        self._base_scheduler = plugin_index.get("apscheduler")
        self._memory_plugin = plugin_index.get("agentfs_memory")
        self._observability_plugin = plugin_index.get("opik_observability")
        self._system_events_plugin = plugin_index.get("system_events")
        self._wake_trigger_plugin = plugin_index.get("wake_trigger")
        self._heartbeat_plugin = plugin_index.get("heartbeat")

        # Log plugin discovery
        plugins_found = []
        if self._base_scheduler:
            plugins_found.append("APScheduler")
        if self._memory_plugin:
            plugins_found.append("AgentFS Memory")
        if self._observability_plugin:
            plugins_found.append("Opik Observability")
        if self._system_events_plugin:
            plugins_found.append("System Events")
        if self._wake_trigger_plugin:
            plugins_found.append("Wake Trigger")
        if self._heartbeat_plugin:
            plugins_found.append("Heartbeat")

        if plugins_found:
            logger.info(
                f"Enhanced Scheduler discovered plugins: {', '.join(plugins_found)}"
            )

        # Create enhanced scheduler tools
        tools = [
            self._make_enhanced_job_status_tool(),
            self._make_webhook_job_tool(),
            self._make_plugin_integration_tool(),
            self._make_create_proactive_job_tool(),
            self._make_job_results_tool(),
        ]

        return agent.clone(tools=[*agent.tools, *tools])

    def create_enhanced_job(self, config: EnhancedJobConfig) -> bool:
        """Create and schedule an enhanced job with plugin integration.

        Args:
            config: Enhanced job configuration

        Returns:
            True if job was created successfully
        """
        if not self._base_scheduler:
            logger.error("Base APScheduler plugin not available")
            return False

        # Store enhanced config
        self._enhanced_jobs[config.job_id] = config

        # Create observability span if enabled
        span = None
        if config.use_observability and self._observability_plugin:
            try:
                span = self._observability_plugin.start_tool_span(
                    context=None,
                    tool_name="enhanced_job_creation",
                    arguments={
                        "job_id": config.job_id,
                        "name": config.name,
                        "session_target": config.session_target.value,
                        "payload_kind": config.payload_kind.value,
                        "webhook_source": config.webhook_source,
                    },
                )
            except Exception as e:
                logger.warning(f"Failed to create observability span: {e}")

        try:
            # Create wrapper target that includes plugin integration
            original_target = config.target

            def enhanced_target(context: Dict[str, Any]) -> Any:
                return self._execute_enhanced_job(config, context, original_target)

            # Create base job config
            base_config = JobConfig(
                job_id=config.job_id,
                name=config.name,
                schedule=config.schedule,
                run_at=config.run_at,
                target=enhanced_target,
                priority=config.priority,
                max_retries=config.max_retries,
                retry_strategy=config.retry_strategy,
                timezone=config.timezone,
                metadata={
                    **config.metadata,
                    "enhanced": True,
                    "session_target": config.session_target.value,
                    "payload_kind": config.payload_kind.value,
                    "webhook_source": config.webhook_source,
                },
                enabled=config.enabled,
            )

            # Create job via base scheduler
            success = self._base_scheduler.create_job(base_config)

            if success:
                # Track webhook job mapping
                if config.webhook_source:
                    self._webhook_jobs[config.webhook_source] = config.job_id

                # Add system event
                if self._system_events_plugin:
                    self._system_events_plugin.enqueue_event(
                        f"Enhanced job created: {config.name} ({config.job_id})",
                        "system:scheduler",
                        "enhanced_scheduler",
                    )

                logger.info(f"Enhanced job created: {config.job_id}")

            if span:
                self._observability_plugin.end_tool_span(
                    span, result=f"success={success}"
                )

            return success

        except Exception as e:
            logger.error(f"Failed to create enhanced job: {e}")
            if span:
                self._observability_plugin.end_tool_span(span, error=e)
            return False

    def _execute_enhanced_job(
        self,
        config: EnhancedJobConfig,
        context: Dict[str, Any],
        target: Callable,
    ) -> Any:
        """Execute enhanced job with full plugin integration.

        Args:
            config: Enhanced job configuration
            context: Execution context
            target: Original target callable

        Returns:
            Job execution result
        """
        execution_id = f"{config.job_id}_{uuid4().hex[:8]}"
        start_time = datetime.now()

        # Create observability span
        span = None
        if config.use_observability and self._observability_plugin:
            try:
                span = self._observability_plugin.start_tool_span(
                    context=None,
                    tool_name="enhanced_job_execution",
                    arguments={
                        "job_id": config.job_id,
                        "execution_id": execution_id,
                        "session_target": config.session_target.value,
                    },
                )
            except Exception as e:
                logger.warning(f"Failed to create execution span: {e}")

        try:
            # Enrich context from memory if enabled
            if config.use_memory and self._memory_plugin:
                try:
                    memory_context = self._memory_plugin.client.get_context(
                        query=config.payload_message or config.name,
                        limit=3,
                    )
                    if memory_context.get("results"):
                        context["memory_context"] = memory_context["results"]
                except Exception as e:
                    logger.warning(f"Failed to get memory context: {e}")

            # Handle session targeting
            if config.session_target == SessionTarget.MAIN:
                # Enqueue system event for main session processing
                if self._system_events_plugin and config.payload_message:
                    self._system_events_plugin.enqueue_event(
                        config.payload_message,
                        context.get("session_key", "default:main"),
                        "enhanced_scheduler",
                    )

                # Trigger wake if configured
                if config.wake_mode == WakeMode.NOW and self._wake_trigger_plugin:
                    self._wake_trigger_plugin.request_wake(
                        f"scheduled_job:{config.job_id}",
                        source="enhanced_scheduler",
                    )

            # Execute target
            result = target(context)

            # Handle async results
            if asyncio.iscoroutine(result):
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        future = asyncio.run_coroutine_threadsafe(result, loop)
                        result = future.result(timeout=self.config.job_timeout_seconds)
                    else:
                        result = loop.run_until_complete(result)
                except RuntimeError:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        result = loop.run_until_complete(result)
                    finally:
                        loop.close()

            # Store result
            end_time = datetime.now()
            result_record = {
                "execution_id": execution_id,
                "job_id": config.job_id,
                "status": "completed",
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_ms": (end_time - start_time).total_seconds() * 1000,
                "result": str(result) if result else "Completed",
            }

            if config.job_id not in self._job_results:
                self._job_results[config.job_id] = []
            self._job_results[config.job_id].append(result_record)

            # Limit history
            if len(self._job_results[config.job_id]) > self.config.history_limit:
                self._job_results[config.job_id] = self._job_results[config.job_id][
                    -self.config.history_limit :
                ]

            # Store in memory if enabled
            if config.store_results and self._memory_plugin and result:
                try:
                    self._memory_plugin.client.store_memory(
                        text=f"Scheduled job result ({config.name}): {result}",
                        session_id=context.get("session_key", "system:scheduler"),
                        tags=["scheduled_job", config.job_id],
                    )
                except Exception as e:
                    logger.warning(f"Failed to store job result in memory: {e}")

            if span:
                self._observability_plugin.end_tool_span(span, result=str(result))

            logger.info(f"Enhanced job executed: {config.job_id} ({execution_id})")
            return result

        except Exception as e:
            # Store error result
            end_time = datetime.now()
            result_record = {
                "execution_id": execution_id,
                "job_id": config.job_id,
                "status": "failed",
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_ms": (end_time - start_time).total_seconds() * 1000,
                "error": str(e),
            }

            if config.job_id not in self._job_results:
                self._job_results[config.job_id] = []
            self._job_results[config.job_id].append(result_record)

            if span:
                self._observability_plugin.end_tool_span(span, error=e)

            logger.error(f"Enhanced job failed: {config.job_id} - {e}")
            raise

    def create_webhook_job(
        self,
        webhook_source: str,
        event_type: str,
        message: str,
        session_target: SessionTarget = SessionTarget.MAIN,
        schedule: Optional[str] = None,
        priority: int = 7,
    ) -> Optional[str]:
        """Create a job triggered by webhook events.

        Args:
            webhook_source: Source identifier for the webhook
            event_type: Type of webhook event
            message: Message to process
            session_target: Target session for execution
            schedule: Optional cron schedule for recurring
            priority: Job priority (0-10)

        Returns:
            Job ID if created successfully, None otherwise
        """
        job_id = f"webhook_{webhook_source}_{uuid4().hex[:8]}"

        def webhook_target(context: Dict[str, Any]) -> str:
            return f"Webhook job executed: {message}"

        config = EnhancedJobConfig(
            job_id=job_id,
            name=f"Webhook Job - {webhook_source}",
            target=webhook_target,
            schedule=schedule,
            run_at=datetime.now().isoformat() if not schedule else None,
            priority=priority,
            session_target=session_target,
            payload_kind=PayloadKind.WEBHOOK_TRIGGER,
            payload_message=message,
            webhook_source=webhook_source,
            event_type=event_type,
            metadata={
                "webhook_source": webhook_source,
                "event_type": event_type,
            },
        )

        success = self.create_enhanced_job(config)
        return job_id if success else None

    def get_enhanced_job(self, job_id: str) -> Optional[EnhancedJobConfig]:
        """Get enhanced job configuration.

        Args:
            job_id: Job identifier

        Returns:
            Enhanced job config or None if not found
        """
        return self._enhanced_jobs.get(job_id)

    def get_job_results(self, job_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get execution results for a job.

        Args:
            job_id: Job identifier
            limit: Maximum results to return

        Returns:
            List of result records
        """
        results = self._job_results.get(job_id, [])
        return results[-limit:]

    def _make_enhanced_job_status_tool(self) -> Tool:
        """Create tool for checking enhanced job status."""

        @function_tool
        def enhanced_job_status(
            ctx: RunContextWrapper[AgentContext],
            job_id: Optional[str] = None,
        ) -> ToolOutputText:
            """Get status of enhanced scheduler jobs and plugin integration.

            Args:
                job_id: Optional specific job ID to check
            """
            lines = ["Enhanced Scheduler Status:"]

            # Plugin integration status
            plugins = []
            if self._base_scheduler:
                plugins.append("✓ APScheduler")
            if self._memory_plugin:
                plugins.append("✓ Memory")
            if self._observability_plugin:
                plugins.append("✓ Observability")
            if self._system_events_plugin:
                plugins.append("✓ System Events")
            if self._wake_trigger_plugin:
                plugins.append("✓ Wake Trigger")

            lines.append(f"Plugin Integration: {', '.join(plugins) or 'None'}")
            lines.append(f"Enhanced Jobs: {len(self._enhanced_jobs)}")
            lines.append(f"Webhook Jobs: {len(self._webhook_jobs)}")

            if job_id:
                config = self._enhanced_jobs.get(job_id)
                if config:
                    lines.append(f"\nJob Details ({job_id}):")
                    lines.append(f"  Name: {config.name}")
                    lines.append(f"  Session Target: {config.session_target.value}")
                    lines.append(f"  Payload Kind: {config.payload_kind.value}")
                    lines.append(f"  Enabled: {config.enabled}")

                    results = self.get_job_results(job_id, 3)
                    if results:
                        lines.append(f"  Recent Executions: {len(results)}")
                        for r in results[-3:]:
                            lines.append(f"    - {r['status']}: {r.get('result', r.get('error', 'N/A'))[:50]}")
                else:
                    lines.append(f"\nJob {job_id} not found in enhanced jobs")

            return ToolOutputText(text="\n".join(lines))

        return enhanced_job_status

    def _make_webhook_job_tool(self) -> Tool:
        """Create tool for creating webhook-triggered jobs."""

        @function_tool
        def create_webhook_job(
            ctx: RunContextWrapper[AgentContext],
            webhook_source: str,
            event_type: str,
            message: str,
            session_target: str = "main",
            schedule: Optional[str] = None,
            priority: int = 7,
        ) -> ToolOutputText:
            """Create a job that can be triggered by webhooks.

            Args:
                webhook_source: Source identifier for the webhook
                event_type: Type of webhook event to handle
                message: Message to process when triggered
                session_target: Target session ('main' or 'isolated')
                schedule: Optional cron schedule for recurring execution
                priority: Job priority (0-10, higher = more important)
            """
            if not self.config.enable_webhook_jobs:
                return ToolOutputText(text="Webhook jobs are disabled")

            target = (
                SessionTarget.ISOLATED
                if session_target == "isolated"
                else SessionTarget.MAIN
            )

            job_id = self.create_webhook_job(
                webhook_source=webhook_source,
                event_type=event_type,
                message=message,
                session_target=target,
                schedule=schedule,
                priority=priority,
            )

            if job_id:
                return ToolOutputText(
                    text=f"Webhook job created: {job_id}\n"
                    f"Source: {webhook_source}\n"
                    f"Event: {event_type}\n"
                    f"Target: {session_target}"
                )
            else:
                return ToolOutputText(text="Failed to create webhook job")

        return create_webhook_job

    def _make_plugin_integration_tool(self) -> Tool:
        """Create tool for checking plugin integration status."""

        @function_tool
        def scheduler_plugin_status(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            """Get detailed plugin integration status for scheduler."""
            lines = ["Scheduler Plugin Integration Status:"]

            # Base scheduler
            if self._base_scheduler:
                jobs = self._base_scheduler.list_jobs() if hasattr(self._base_scheduler, 'list_jobs') else []
                lines.append(f"✓ APScheduler: {len(jobs)} active jobs")
            else:
                lines.append("✗ APScheduler: Not available")

            # Memory plugin
            if self._memory_plugin:
                lines.append("✓ AgentFS Memory: Connected")
            else:
                lines.append("○ AgentFS Memory: Not configured")

            # Observability
            if self._observability_plugin:
                lines.append("✓ Opik Observability: Tracing enabled")
            else:
                lines.append("○ Opik Observability: Not configured")

            # System Events
            if self._system_events_plugin:
                lines.append("✓ System Events: Queue active")
            else:
                lines.append("○ System Events: Not configured")

            # Wake Trigger
            if self._wake_trigger_plugin:
                lines.append("✓ Wake Trigger: Ready")
            else:
                lines.append("○ Wake Trigger: Not configured")

            # Heartbeat
            if self._heartbeat_plugin:
                lines.append("✓ Heartbeat: Connected")
            else:
                lines.append("○ Heartbeat: Not configured")

            # Configuration
            lines.append(f"\nConfiguration:")
            lines.append(f"  Max Concurrent: {self.config.max_concurrent_jobs}")
            lines.append(f"  Default Priority: {self.config.default_priority}")
            lines.append(f"  Webhook Jobs: {'enabled' if self.config.enable_webhook_jobs else 'disabled'}")
            lines.append(f"  Job Timeout: {self.config.job_timeout_seconds}s")

            return ToolOutputText(text="\n".join(lines))

        return scheduler_plugin_status

    def _make_create_proactive_job_tool(self) -> Tool:
        """Create tool for creating proactive scheduled jobs."""

        @function_tool
        def create_proactive_job(
            ctx: RunContextWrapper[AgentContext],
            name: str,
            message: str,
            schedule: Optional[str] = None,
            run_at: Optional[str] = None,
            session_target: str = "main",
            use_memory: bool = True,
            store_results: bool = True,
            priority: int = 5,
        ) -> ToolOutputText:
            """Create a proactive scheduled job with full plugin integration.

            Args:
                name: Job name
                message: Message to process when job executes
                schedule: Cron expression for recurring (e.g., "0 9 * * *")
                run_at: ISO8601 datetime for one-time execution
                session_target: Target session ('main' or 'isolated')
                use_memory: Whether to use memory for context
                store_results: Whether to store results in memory
                priority: Job priority (0-10)
            """
            if not schedule and not run_at:
                return ToolOutputText(
                    text="Error: Must provide either 'schedule' or 'run_at'"
                )

            job_id = f"proactive_{name.lower().replace(' ', '_')}_{uuid4().hex[:8]}"

            def proactive_target(context: Dict[str, Any]) -> str:
                # Execute via agent if available
                if self._agent and hasattr(self._agent, "chat"):
                    try:
                        result = self._agent.chat(
                            message=message,
                            user_id="scheduler",
                            channel="scheduler",
                        )
                        return str(result)
                    except Exception as e:
                        return f"Proactive job error: {e}"
                return f"Proactive job executed: {message}"

            target = (
                SessionTarget.ISOLATED
                if session_target == "isolated"
                else SessionTarget.MAIN
            )

            config = EnhancedJobConfig(
                job_id=job_id,
                name=name,
                target=proactive_target,
                schedule=schedule,
                run_at=run_at,
                priority=priority,
                session_target=target,
                payload_kind=PayloadKind.AGENT_TURN,
                payload_message=message,
                use_memory=use_memory,
                store_results=store_results,
            )

            success = self.create_enhanced_job(config)

            if success:
                schedule_info = schedule or f"once at {run_at}"
                return ToolOutputText(
                    text=f"Proactive job created: {name}\n"
                    f"ID: {job_id}\n"
                    f"Schedule: {schedule_info}\n"
                    f"Session: {session_target}\n"
                    f"Memory: {'enabled' if use_memory else 'disabled'}"
                )
            else:
                return ToolOutputText(text=f"Failed to create proactive job: {name}")

        return create_proactive_job

    def _make_job_results_tool(self) -> Tool:
        """Create tool for viewing job execution results."""

        @function_tool
        def view_job_results(
            ctx: RunContextWrapper[AgentContext],
            job_id: str,
            limit: int = 10,
        ) -> ToolOutputText:
            """View execution results for an enhanced job.

            Args:
                job_id: Job identifier
                limit: Maximum results to return
            """
            results = self.get_job_results(job_id, limit)

            if not results:
                return ToolOutputText(text=f"No execution results for job: {job_id}")

            lines = [f"Execution Results for {job_id} ({len(results)} executions):"]
            for r in results:
                status = r.get("status", "unknown")
                duration = r.get("duration_ms", 0)
                start = r.get("start_time", "N/A")

                if status == "completed":
                    result_text = r.get("result", "N/A")[:80]
                    lines.append(f"✓ [{start}] {duration:.0f}ms - {result_text}")
                else:
                    error_text = r.get("error", "Unknown error")[:80]
                    lines.append(f"✗ [{start}] {duration:.0f}ms - {error_text}")

            return ToolOutputText(text="\n".join(lines))

        return view_job_results
