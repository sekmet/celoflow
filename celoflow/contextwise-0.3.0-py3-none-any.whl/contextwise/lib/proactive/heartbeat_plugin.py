"""Heartbeat Plugin for Contextwise v0.3.0.

This module provides periodic automated checks with configurable intervals
and multi-channel result delivery.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from agents import Agent, RunContextWrapper, Tool, ToolOutputText, function_tool

from ..base import AgentPlugin
from ..context import AgentContext

logger = logging.getLogger(__name__)


@dataclass
class HeartbeatConfig:
    """Configuration for heartbeat system."""

    enabled: bool = True
    interval_minutes: int = 30
    prompt: str = (
        "Read HEARTBEAT.md if it exists (workspace context). "
        "Follow it strictly. If nothing needs attention, reply HEARTBEAT_OK."
    )
    model: Optional[str] = None
    active_hours: Optional[Dict[str, Any]] = None
    max_response_chars: int = 300
    session_target: str = "main"
    delivery_channel: Optional[str] = None

    # Integration with existing plugins
    use_memory_for_context: bool = True
    use_observability: bool = True
    use_scheduler: bool = True

    # Channel integration
    enable_channel_delivery: bool = True
    preferred_channels: List[str] = field(
        default_factory=lambda: ["api", "whatsapp", "slack"]
    )
    channel_priority: Dict[str, int] = field(
        default_factory=lambda: {
            "api": 1,
            "whatsapp": 2,
            "slack": 3,
            "discord": 4,
            "voice": 5,
        }
    )


class HeartbeatPlugin(AgentPlugin[AgentContext]):
    """Plugin for proactive heartbeat checks with full plugin and channel integration.

    Provides periodic automated checks that integrate with:
    - AgentFS Memory for context enrichment
    - Opik Observability for tracing
    - APScheduler for job scheduling
    - Multi-channel delivery system

    Attributes:
        id: Plugin identifier
        name: Human-readable plugin name
        version: Plugin version
        config: HeartbeatConfig instance
    """

    id = "heartbeat"
    name = "Heartbeat Plugin"
    version = "1.0.0"

    def __init__(self, config: Optional[HeartbeatConfig] = None):
        """Initialize heartbeat plugin.

        Args:
            config: Optional HeartbeatConfig instance
        """
        self.config = config or HeartbeatConfig()
        self._timer: Optional[asyncio.Task] = None
        self._running = False
        self._last_responses: Dict[str, datetime] = {}
        self._agent: Optional[Agent] = None

        # Plugin integration references
        self._memory_plugin: Optional[Any] = None
        self._observability_plugin: Optional[Any] = None
        self._scheduler_plugin: Optional[Any] = None
        self._system_events_plugin: Optional[Any] = None
        self._wake_trigger_plugin: Optional[Any] = None

        # Channel integration references
        self._channels: Dict[str, Any] = {}
        self._available_channels: List[str] = []

    def dependencies(self) -> List[str]:
        """Declare plugin dependencies for proper loading order."""
        deps = []
        if self.config.use_memory_for_context:
            deps.append("agentfs_memory")
        if self.config.use_observability:
            deps.append("opik_observability")
        if self.config.use_scheduler:
            deps.append("apscheduler")
        return deps

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Add heartbeat tools and integrate with existing plugins and channels."""
        self._agent = agent

        # Discover and integrate with existing plugins
        plugin_index = getattr(agent, "plugin_index", {}) or {}

        self._memory_plugin = plugin_index.get("agentfs_memory")
        self._observability_plugin = plugin_index.get("opik_observability")
        self._scheduler_plugin = plugin_index.get("apscheduler")
        self._system_events_plugin = plugin_index.get("system_events")
        self._wake_trigger_plugin = plugin_index.get("wake_trigger")

        # Log plugin discovery
        plugins_found = []
        if self._memory_plugin:
            plugins_found.append("AgentFS Memory")
        if self._observability_plugin:
            plugins_found.append("Opik Observability")
        if self._scheduler_plugin:
            plugins_found.append("APScheduler")
        if self._system_events_plugin:
            plugins_found.append("System Events")
        if self._wake_trigger_plugin:
            plugins_found.append("Wake Trigger")

        if plugins_found:
            logger.info(f"Heartbeat plugin discovered: {', '.join(plugins_found)}")

        # Discover available channels
        self._discover_channels(agent)

        # Create heartbeat tools with plugin and channel integration
        tools = [
            self._make_heartbeat_status_tool(),
            self._make_trigger_heartbeat_tool(),
            self._make_schedule_heartbeat_tool(),
            self._make_heartbeat_memory_tool(),
            self._make_channel_delivery_tool(),
        ]

        # Schedule heartbeat via scheduler if available
        if self._scheduler_plugin and self.config.enabled:
            self._schedule_via_scheduler(agent)

        return agent.clone(tools=[*agent.tools, *tools])

    def _discover_channels(self, agent: Agent[AgentContext]) -> None:
        """Discover and register available communication channels."""
        # Get channels from agent configuration
        agent_channels = getattr(agent, "channels", [])
        if isinstance(agent_channels, list) and agent_channels:
            for channel in agent_channels:
                if isinstance(channel, str):
                    self._available_channels.append(channel)
                elif hasattr(channel, "channel_id"):
                    channel_id = channel.channel_id
                    self._available_channels.append(channel_id)
                    self._channels[channel_id] = channel

        # Discover channel plugins from plugin index
        plugin_index = getattr(agent, "plugin_index", {}) or {}

        # Known channel plugins
        channel_plugin_ids = [
            "api-channel",
            "whatsapp-channel",
            "slack-channel",
            "discord-channel",
            "voice-channel",
            "tiktok-channel",
            "instagram-channel",
            "facebook-channel",
            "whatsmeow-channel",
        ]

        for plugin_id in channel_plugin_ids:
            if plugin_id in plugin_index:
                channel_plugin = plugin_index[plugin_id]
                channel_name = plugin_id.replace("-channel", "")
                self._channels[channel_name] = channel_plugin
                if channel_name not in self._available_channels:
                    self._available_channels.append(channel_name)

        # Filter by preferred channels and priority
        self._available_channels = [
            ch
            for ch in self.config.preferred_channels
            if ch in self._available_channels
        ]

        # Sort by priority
        self._available_channels.sort(
            key=lambda ch: self.config.channel_priority.get(ch, 999)
        )

        if self._available_channels:
            logger.info(
                f"Heartbeat channels discovered: {', '.join(self._available_channels)}"
            )

    def _schedule_via_scheduler(self, agent: Agent[AgentContext]) -> None:
        """Schedule heartbeat via APScheduler plugin."""
        if not self._scheduler_plugin:
            return

        try:
            from ..scheduler.base import JobConfig

            # Create recurring job for heartbeat
            cron_expr = f"*/{self.config.interval_minutes} * * * *"
            agent_name = getattr(agent, "name", "default") or "default"

            job_config = JobConfig(
                job_id=f"heartbeat_{agent_name}",
                name=f"Heartbeat Check - {agent_name}",
                schedule=cron_expr,
                target=lambda ctx: self._run_heartbeat_check_sync("scheduled"),
                priority=8,
                metadata={
                    "heartbeat": True,
                    "agent_name": agent_name,
                    "session_target": self.config.session_target,
                    "enable_channel_delivery": self.config.enable_channel_delivery,
                    "preferred_channels": self._available_channels,
                },
            )

            success = self._scheduler_plugin.create_job(job_config)
            if success:
                logger.info(f"Heartbeat scheduled via APScheduler: {cron_expr}")
            else:
                logger.warning("Failed to schedule heartbeat via APScheduler")

        except Exception as e:
            logger.error(f"Failed to schedule heartbeat via APScheduler: {e}")

    def _make_channel_delivery_tool(self) -> Tool:
        """Create tool for managing channel delivery of heartbeat results."""

        @function_tool
        def configure_channel_delivery(
            ctx: RunContextWrapper[AgentContext],
            enable: bool = True,
            preferred_channels: Optional[List[str]] = None,
            delivery_channel: Optional[str] = None,
        ) -> ToolOutputText:
            """Configure how heartbeat results are delivered via channels.

            Args:
                enable: Enable/disable channel delivery
                preferred_channels: List of preferred channel IDs (priority order)
                delivery_channel: Specific channel for all heartbeat results
            """
            self.config.enable_channel_delivery = enable

            if preferred_channels:
                self.config.preferred_channels = preferred_channels
                # Re-filter available channels
                self._available_channels = [
                    ch for ch in preferred_channels if ch in self._channels
                ]
                self._available_channels.sort(
                    key=lambda ch: self.config.channel_priority.get(ch, 999)
                )

            if delivery_channel and delivery_channel in self._available_channels:
                self.config.delivery_channel = delivery_channel

            status = "enabled" if self.config.enable_channel_delivery else "disabled"
            channels = (
                ", ".join(self._available_channels)
                if self._available_channels
                else "none"
            )

            return ToolOutputText(
                text=f"Channel delivery {status}. Available channels: {channels}"
            )

        return configure_channel_delivery

    async def _deliver_via_channels(
        self, message: str, context: AgentContext, reason: str
    ) -> None:
        """Deliver heartbeat result via configured channels."""
        if not self.config.enable_channel_delivery or not message.strip():
            return

        # Skip HEARTBEAT_OK responses unless explicitly configured
        if "HEARTBEAT_OK" in message and not self.config.delivery_channel:
            logger.debug(f"Skipping channel delivery for HEARTBEAT_OK: {reason}")
            return

        # Determine target channel
        target_channel = self.config.delivery_channel
        if not target_channel and self._available_channels:
            target_channel = self._available_channels[0]

        if not target_channel:
            logger.warning("No channels available for heartbeat delivery")
            return

        # Prepare message with context
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        delivery_message = f"[{timestamp}] 🫀 Heartbeat Check ({reason}):\n\n{message}"

        # Deliver via each available channel (with fallbacks)
        delivery_attempts = []
        for channel_id in self._available_channels:
            try:
                success = await self._send_to_channel(
                    channel_id, context.user_id, delivery_message, context
                )
                delivery_attempts.append((channel_id, success))

                if success:
                    logger.info(f"Heartbeat result delivered via {channel_id}")
                    break

            except Exception as e:
                logger.error(f"Failed to deliver heartbeat via {channel_id}: {e}")
                delivery_attempts.append((channel_id, False))

        if not any(success for _, success in delivery_attempts):
            logger.error(
                f"All channel delivery attempts failed for heartbeat: {reason}"
            )

    async def _send_to_channel(
        self,
        channel_id: str,
        user_id: str,
        message: str,
        context: AgentContext,
    ) -> bool:
        """Send message via specific channel."""
        try:
            if channel_id == "api":
                # API channel - log only (responses returned directly)
                logger.info(f"API Channel heartbeat: {message[:100]}...")
                return True

            channel = self._channels.get(channel_id)
            if not channel:
                logger.warning(f"Channel {channel_id} not found")
                return False

            if hasattr(channel, "send_message"):
                channel.send_message(user_id, message, metadata={"source": "heartbeat"})
                return True

            logger.warning(f"Channel {channel_id} has no send_message method")
            return False

        except Exception as e:
            logger.error(f"Error sending to channel {channel_id}: {e}")
            return False

    def _make_heartbeat_status_tool(self) -> Tool:
        """Create tool for checking heartbeat status."""

        @function_tool
        def heartbeat_status(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            """Get current heartbeat system status and plugin/channel integration info."""
            status = "running" if self._running else "stopped"
            next_run = "N/A"

            if self._timer and not self._timer.done():
                next_run = (
                    datetime.now() + timedelta(minutes=self.config.interval_minutes)
                ).strftime("%Y-%m-%d %H:%M:%S")

            # Plugin integration status
            plugin_status = []
            if self._memory_plugin:
                plugin_status.append("✓ AgentFS Memory")
            if self._observability_plugin:
                plugin_status.append("✓ Opik Observability")
            if self._scheduler_plugin:
                plugin_status.append("✓ APScheduler")
            if self._system_events_plugin:
                plugin_status.append("✓ System Events")
            if self._wake_trigger_plugin:
                plugin_status.append("✓ Wake Trigger")

            # Channel integration status
            channel_status = []
            for channel_id in self._available_channels:
                if channel_id in self._channels:
                    channel_status.append(f"✓ {channel_id.title()}")
                else:
                    channel_status.append(f"⚠ {channel_id.title()}")

            delivery_status = (
                "enabled" if self.config.enable_channel_delivery else "disabled"
            )

            status_text = (
                f"Heartbeat Status: {status}\n"
                f"Next run: {next_run}\n"
                f"Interval: {self.config.interval_minutes} minutes\n"
                f"Channel Delivery: {delivery_status}\n"
                f"Plugin Integrations: {', '.join(plugin_status) if plugin_status else 'None'}\n"
                f"Available Channels: {', '.join(channel_status) if channel_status else 'None'}"
            )

            return ToolOutputText(text=status_text)

        return heartbeat_status

    def _make_trigger_heartbeat_tool(self) -> Tool:
        """Create tool for manual heartbeat trigger."""

        @function_tool
        def trigger_heartbeat(
            ctx: RunContextWrapper[AgentContext],
            reason: str = "manual",
            deliver_via_channels: bool = True,
        ) -> ToolOutputText:
            """Manually trigger a heartbeat check with full plugin and channel integration.

            Args:
                reason: Reason for triggering heartbeat
                deliver_via_channels: Whether to deliver results via channels
            """
            if not self.config.enabled:
                return ToolOutputText(text="Heartbeat system is disabled")

            # Add system event for tracking
            if self._system_events_plugin and ctx and hasattr(ctx, "context"):
                session_key = f"{ctx.context.user_id}:{ctx.context.session_id or 'main'}"
                self._system_events_plugin.enqueue_event(
                    f"Manual heartbeat triggered: {reason}",
                    session_key,
                    "heartbeat",
                )

            # Schedule immediate heartbeat
            asyncio.create_task(
                self._run_heartbeat_check(reason, ctx, deliver_via_channels)
            )
            return ToolOutputText(text="Heartbeat triggered successfully")

        return trigger_heartbeat

    def _make_schedule_heartbeat_tool(self) -> Tool:
        """Create tool for scheduling heartbeat."""

        @function_tool
        def schedule_heartbeat(
            ctx: RunContextWrapper[AgentContext],
            interval_minutes: Optional[int] = None,
            enable_channel_delivery: Optional[bool] = None,
        ) -> ToolOutputText:
            """Schedule or reschedule heartbeat checks.

            Args:
                interval_minutes: Interval between heartbeat checks in minutes
                enable_channel_delivery: Enable/disable channel delivery
            """
            if not self._scheduler_plugin:
                return ToolOutputText(text="APScheduler plugin not available")

            # Update configuration
            if interval_minutes:
                self.config.interval_minutes = interval_minutes
            if enable_channel_delivery is not None:
                self.config.enable_channel_delivery = enable_channel_delivery

            # Create new schedule
            user_id = ctx.context.user_id if ctx.context else "default"
            job_id = f"heartbeat_{user_id}"

            # Remove existing job if present
            try:
                self._scheduler_plugin.delete_job(job_id)
            except Exception:
                pass

            # Create new job
            try:
                from ..scheduler.base import JobConfig

                cron_expr = f"*/{self.config.interval_minutes} * * * *"

                job_config = JobConfig(
                    job_id=job_id,
                    name=f"Heartbeat Check - {user_id}",
                    schedule=cron_expr,
                    target=lambda ctx: self._run_heartbeat_check_sync("scheduled"),
                    priority=8,
                    metadata={
                        "enable_channel_delivery": self.config.enable_channel_delivery,
                        "preferred_channels": self._available_channels,
                    },
                )

                success = self._scheduler_plugin.create_job(job_config)
                if success:
                    delivery_info = f"Channel delivery: {'enabled' if self.config.enable_channel_delivery else 'disabled'}"
                    return ToolOutputText(
                        text=f"Heartbeat rescheduled: every {self.config.interval_minutes} minutes. {delivery_info}"
                    )
                else:
                    return ToolOutputText(text="Failed to schedule heartbeat")

            except Exception as e:
                return ToolOutputText(text=f"Failed to schedule heartbeat: {e}")

        return schedule_heartbeat

    def _make_heartbeat_memory_tool(self) -> Tool:
        """Create tool for heartbeat memory integration."""

        @function_tool
        def heartbeat_memory_context(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            """Get heartbeat context from AgentFS memory."""
            if not self._memory_plugin:
                return ToolOutputText(text="AgentFS Memory plugin not available")

            try:
                session_key = f"{ctx.context.user_id}:{ctx.context.session_id or 'main'}"
                memory_context = self._memory_plugin.client.get_context(
                    query="heartbeat tasks proactive check",
                    session_id=session_key,
                    limit=5,
                )

                if memory_context.get("results"):
                    context_text = "Relevant heartbeat context from memory:\n"
                    for result in memory_context["results"][:3]:
                        context_text += f"- {result.get('text', '')[:100]}...\n"
                    return ToolOutputText(text=context_text)
                else:
                    return ToolOutputText(text="No heartbeat context found in memory")

            except Exception as e:
                return ToolOutputText(text=f"Error accessing memory: {str(e)}")

        return heartbeat_memory_context

    async def start(self, agent: Agent[AgentContext]) -> None:
        """Start heartbeat timer with plugin and channel integration."""
        if not self.config.enabled:
            return

        self._running = True
        self._agent = agent

        # Use scheduler if available, otherwise fallback to timer
        if self._scheduler_plugin:
            logger.info("Heartbeat using APScheduler for timing")
        else:
            self._timer = asyncio.create_task(self._heartbeat_loop(agent))
            logger.info(
                f"Heartbeat started with {self.config.interval_minutes} minute interval"
            )

        # Log channel availability
        if self._available_channels:
            logger.info(
                f"Heartbeat channels available: {', '.join(self._available_channels)}"
            )

    async def stop(self) -> None:
        """Stop heartbeat timer."""
        self._running = False
        if self._timer:
            self._timer.cancel()
            try:
                await self._timer
            except asyncio.CancelledError:
                pass
        logger.info("Heartbeat stopped")

    async def _heartbeat_loop(self, agent: Agent[AgentContext]) -> None:
        """Main heartbeat loop with plugin and channel integration."""
        while self._running:
            try:
                await asyncio.sleep(self.config.interval_minutes * 60)
                if self._running:
                    await self._run_heartbeat_check("scheduled", None, True)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Heartbeat loop error: {e}")

    def _run_heartbeat_check_sync(self, reason: str) -> str:
        """Synchronous wrapper for heartbeat check."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.create_task(self._run_heartbeat_check(reason, None, True))
                return "Heartbeat check scheduled"
            else:
                return loop.run_until_complete(
                    self._run_heartbeat_check(reason, None, True)
                )
        except RuntimeError:
            # No event loop
            logger.warning("No event loop available for heartbeat check")
            return "Heartbeat check skipped - no event loop"

    async def _run_heartbeat_check(
        self,
        reason: str,
        ctx: Optional[RunContextWrapper[AgentContext]],
        deliver_via_channels: bool = True,
    ) -> str:
        """Execute a single heartbeat check with full plugin and channel integration."""
        try:
            # Create observability span if available
            span = None
            if self._observability_plugin:
                try:
                    context = ctx.context if ctx else None
                    span = self._observability_plugin.start_tool_span(
                        context=context,
                        tool_name="heartbeat_check",
                        arguments={
                            "reason": reason,
                            "interval": self.config.interval_minutes,
                            "channel_delivery": deliver_via_channels,
                            "available_channels": self._available_channels,
                        },
                    )
                except Exception as e:
                    logger.warning(f"Failed to create observability span: {e}")

            # Get context from memory if available
            context_message = self.config.prompt
            if self._memory_plugin:
                try:
                    memory_context = self._memory_plugin.client.get_context(
                        query="HEARTBEAT.md tasks proactive", limit=3
                    )
                    if memory_context.get("results"):
                        context_message += "\n\nRelevant context from memory:\n"
                        for result in memory_context["results"][:2]:
                            context_message += f"- {result.get('text', '')}\n"
                except Exception as e:
                    logger.warning(f"Failed to get memory context: {e}")

            # Add system event
            if self._system_events_plugin and ctx:
                session_key = (
                    f"{ctx.context.user_id}:{ctx.context.session_id or 'main'}"
                )
                self._system_events_plugin.enqueue_event(
                    f"Heartbeat check: {reason}", session_key, "heartbeat"
                )

            # Execute heartbeat
            logger.info(f"Executing heartbeat check: {reason}")

            # Execute via agent if available
            heartbeat_result = "HEARTBEAT_OK"
            if self._agent and hasattr(self._agent, "chat_async"):
                try:
                    result = await self._agent.chat_async(
                        message=context_message,
                        user_id="heartbeat",
                        channel="heartbeat",
                    )
                    if result:
                        heartbeat_result = str(result)[: self.config.max_response_chars]
                except Exception as e:
                    logger.warning(f"Agent chat failed for heartbeat: {e}")
                    heartbeat_result = f"Heartbeat check error: {e}"

            # Store result in memory if available and meaningful
            if self._memory_plugin and ctx and heartbeat_result != "HEARTBEAT_OK":
                try:
                    session_key = (
                        f"{ctx.context.user_id}:{ctx.context.session_id or 'main'}"
                    )
                    self._memory_plugin.client.store_memory(
                        text=f"Heartbeat result ({reason}): {heartbeat_result}",
                        session_id=session_key,
                        tags=["heartbeat", "proactive", reason],
                    )
                except Exception as e:
                    logger.warning(f"Failed to store heartbeat result in memory: {e}")

            # Deliver via channels if enabled and result is meaningful
            if deliver_via_channels and ctx and heartbeat_result != "HEARTBEAT_OK":
                await self._deliver_via_channels(
                    heartbeat_result, ctx.context, reason
                )

            # Close observability span
            if span:
                try:
                    self._observability_plugin.end_tool_span(
                        span, result=heartbeat_result
                    )
                except Exception as e:
                    logger.warning(f"Failed to end observability span: {e}")

            return heartbeat_result

        except Exception as e:
            logger.error(f"Heartbeat check failed: {e}")
            if span:
                try:
                    self._observability_plugin.end_tool_span(span, error=e)
                except Exception:
                    pass
            return f"Heartbeat check failed: {e}"
