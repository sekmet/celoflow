"""Webhook Plugin for Contextwise v0.3.0.

This module provides webhook integration for external system triggers with
authentication, rate limiting, and dual execution modes (main/isolated session).
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple, Union

# Type alias for action handlers: async functions that receive event data and return result
ActionHandler = Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]

from agents import Agent, RunContextWrapper, Tool, ToolOutputText, function_tool
from fastapi import APIRouter, HTTPException, Request, Depends
from fastapi.responses import JSONResponse
from fastapi.security import APIKeyHeader
from pydantic import BaseModel, Field

from ..base import AgentPlugin
from ..context import AgentContext

logger = logging.getLogger(__name__)


class ExecutionMode(str, Enum):
    """Execution mode for webhook processing."""

    MAIN_SESSION = "main"
    ISOLATED_SESSION = "isolated"


class AuthMethod(str, Enum):
    """Authentication methods for webhooks."""

    NONE = "none"
    API_KEY = "api_key"
    HMAC_SIGNATURE = "hmac"
    BEARER_TOKEN = "bearer"


class WebhookEvent(BaseModel):
    """Webhook event payload model."""

    event_type: str = Field(..., description="Type of the webhook event")
    data: Dict[str, Any] = Field(default_factory=dict, description="Event payload data")
    timestamp: Optional[str] = Field(default=None, description="Event timestamp (ISO8601)")
    source: Optional[str] = Field(default=None, description="Event source identifier")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")


class WebhookResponse(BaseModel):
    """Webhook response model."""

    success: bool
    message: str
    execution_id: Optional[str] = None
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class RateLimitConfig:
    """Rate limiting configuration."""

    enabled: bool = True
    requests_per_minute: int = 60
    requests_per_hour: int = 1000
    burst_limit: int = 10


@dataclass
class WebhookConfig:
    """Configuration for webhook plugin.

    Attributes:
        enabled: Whether webhook endpoints are enabled
        auth_method: Authentication method to use
        api_key: API key for authentication (if using api_key method)
        hmac_secret: Secret for HMAC signature verification
        bearer_tokens: List of valid bearer tokens
        default_execution_mode: Default execution mode for webhooks
        rate_limit: Rate limiting configuration
        allowed_sources: List of allowed webhook sources (empty = all)
        max_payload_size: Maximum payload size in bytes
        log_events: Whether to log webhook events
        store_events: Whether to store events in memory
        action_handlers: Mapping of event_type to async handler functions
    """

    enabled: bool = True
    auth_method: AuthMethod = AuthMethod.BEARER_TOKEN
    api_key: Optional[str] = None
    hmac_secret: Optional[str] = None
    bearer_tokens: List[str] = field(default_factory=lambda: ["test-token"])
    default_execution_mode: ExecutionMode = ExecutionMode.MAIN_SESSION
    rate_limit: RateLimitConfig = field(default_factory=RateLimitConfig)
    allowed_sources: List[str] = field(default_factory=list)
    max_payload_size: int = 1024 * 1024  # 1MB
    log_events: bool = True
    store_events: bool = True
    action_handlers: Dict[str, "ActionHandler"] = field(default_factory=dict)


@dataclass
class WebhookEventRecord:
    """Record of a processed webhook event."""

    event_id: str
    source: str
    event_type: str
    execution_mode: str
    status: str
    timestamp: float
    duration_ms: float = 0
    result: Optional[str] = None
    error: Optional[str] = None


class RateLimiter:
    """Simple rate limiter for webhook requests."""

    def __init__(self, config: RateLimitConfig):
        self.config = config
        self._minute_counts: Dict[str, List[float]] = defaultdict(list)
        self._hour_counts: Dict[str, List[float]] = defaultdict(list)
        self._burst_counts: Dict[str, List[float]] = defaultdict(list)

    def check_rate_limit(self, source: str) -> Tuple[bool, str]:
        """Check if request is within rate limits.

        Args:
            source: Request source identifier

        Returns:
            Tuple of (allowed, reason)
        """
        if not self.config.enabled:
            return True, "Rate limiting disabled"

        now = time.time()

        # Clean old entries
        self._minute_counts[source] = [
            t for t in self._minute_counts[source] if now - t < 60
        ]
        self._hour_counts[source] = [
            t for t in self._hour_counts[source] if now - t < 3600
        ]
        self._burst_counts[source] = [
            t for t in self._burst_counts[source] if now - t < 1
        ]

        # Check limits
        if len(self._burst_counts[source]) >= self.config.burst_limit:
            return False, f"Burst limit exceeded ({self.config.burst_limit}/sec)"

        if len(self._minute_counts[source]) >= self.config.requests_per_minute:
            return False, f"Rate limit exceeded ({self.config.requests_per_minute}/min)"

        if len(self._hour_counts[source]) >= self.config.requests_per_hour:
            return False, f"Rate limit exceeded ({self.config.requests_per_hour}/hour)"

        # Record request
        self._minute_counts[source].append(now)
        self._hour_counts[source].append(now)
        self._burst_counts[source].append(now)

        return True, "OK"

    def get_status(self, source: str) -> Dict[str, Any]:
        """Get rate limit status for a source."""
        now = time.time()

        # Clean and count
        minute_count = len([t for t in self._minute_counts.get(source, []) if now - t < 60])
        hour_count = len([t for t in self._hour_counts.get(source, []) if now - t < 3600])

        return {
            "source": source,
            "minute": {
                "used": minute_count,
                "limit": self.config.requests_per_minute,
                "remaining": self.config.requests_per_minute - minute_count,
            },
            "hour": {
                "used": hour_count,
                "limit": self.config.requests_per_hour,
                "remaining": self.config.requests_per_hour - hour_count,
            },
        }


class WebhookPlugin(AgentPlugin[AgentContext]):
    """Plugin for webhook integration with external systems.

    Provides:
    - Authenticated webhook endpoints
    - Rate limiting
    - Dual execution modes (main/isolated session)
    - Event history and tracking
    - Integration with proactive plugins

    Attributes:
        id: Plugin identifier
        name: Human-readable plugin name
        version: Plugin version
        config: WebhookConfig instance
    """

    id = "webhook"
    name = "Webhook Plugin"
    version = "1.0.0"

    def __init__(self, config: Optional[WebhookConfig] = None):
        """Initialize webhook plugin.

        Args:
            config: Optional WebhookConfig instance
        """
        self.config = config or WebhookConfig()
        self._agent: Optional[Agent] = None
        self._contextwise_agent: Optional[Any] = None  # Contextwise Agent with chat_async
        self._router: Optional[APIRouter] = None

        # Rate limiter
        self._rate_limiter = RateLimiter(self.config.rate_limit)

        # Event tracking
        self._event_history: List[WebhookEventRecord] = []
        self._max_history = 1000
        self._event_counter = 0

        # Plugin integration references
        self._system_events_plugin: Optional[Any] = None
        self._wake_trigger_plugin: Optional[Any] = None
        self._enhanced_scheduler_plugin: Optional[Any] = None
        self._memory_plugin: Optional[Any] = None
        self._observability_plugin: Optional[Any] = None

    def dependencies(self) -> List[str]:
        """Return plugin dependencies."""
        return []

    def set_contextwise_agent(self, agent: Any) -> None:
        """Set reference to Contextwise Agent for chat_async() calls.

        Called by Agent._build() after plugin configuration completes.

        Args:
            agent: Contextwise Agent instance with chat_async method
        """
        self._contextwise_agent = agent

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Configure agent with webhook tools and create router."""
        self._agent = agent

        # Discover proactive plugins
        plugin_index = getattr(agent, "plugin_index", {}) or {}

        self._system_events_plugin = plugin_index.get("system_events")
        self._wake_trigger_plugin = plugin_index.get("wake_trigger")
        self._enhanced_scheduler_plugin = plugin_index.get("enhanced_scheduler")
        self._memory_plugin = plugin_index.get("agentfs_memory")
        self._observability_plugin = plugin_index.get("opik_observability")

        # Log plugin discovery
        plugins_found = []
        if self._system_events_plugin:
            plugins_found.append("System Events")
        if self._wake_trigger_plugin:
            plugins_found.append("Wake Trigger")
        if self._enhanced_scheduler_plugin:
            plugins_found.append("Enhanced Scheduler")
        if self._memory_plugin:
            plugins_found.append("Memory")
        if self._observability_plugin:
            plugins_found.append("Observability")

        if plugins_found:
            logger.info(f"Webhook plugin discovered: {', '.join(plugins_found)}")

        # Create webhook router
        self._router = self._create_webhook_router()

        # Create webhook tools
        tools = [
            self._make_webhook_status_tool(),
            self._make_webhook_config_tool(),
            self._make_webhook_history_tool(),
        ]

        return agent.clone(tools=[*agent.tools, *tools])

    def get_router(self) -> Optional[APIRouter]:
        """Get the webhook FastAPI router for mounting.

        Returns:
            APIRouter instance or None if not configured
        """
        return self._router

    def get_fastapi_routers(self) -> List[APIRouter]:
        """Get FastAPI routers for server integration.

        This method is called by the server's create_app() to auto-mount
        plugin-provided routers.

        Returns:
            List of APIRouter instances
        """
        if self._router and self.config.enabled:
            return [self._router]
        return []

    def _create_webhook_router(self) -> APIRouter:
        """Create FastAPI router for webhook endpoints."""
        router = APIRouter(prefix="/webhook", tags=["webhook"])

        # Authentication dependency
        api_key_header = APIKeyHeader(name="Authorization", auto_error=False)

        async def verify_auth(
            request: Request,
            auth_header: Optional[str] = Depends(api_key_header),
        ) -> str:
            """Verify request authentication."""
            if self.config.auth_method == AuthMethod.NONE:
                return "anonymous"

            if not auth_header:
                raise HTTPException(status_code=401, detail="Missing authorization header")

            if self.config.auth_method == AuthMethod.BEARER_TOKEN:
                if auth_header.startswith("Bearer "):
                    token = auth_header[7:]
                    if token in self.config.bearer_tokens:
                        return token
                raise HTTPException(status_code=401, detail="Invalid bearer token")

            if self.config.auth_method == AuthMethod.API_KEY:
                if auth_header == self.config.api_key:
                    return "api_key"
                raise HTTPException(status_code=401, detail="Invalid API key")

            if self.config.auth_method == AuthMethod.HMAC_SIGNATURE:
                # HMAC verification would check request body signature
                # This is a simplified implementation
                if self.config.hmac_secret:
                    return "hmac_verified"
                raise HTTPException(status_code=401, detail="HMAC verification failed")

            raise HTTPException(status_code=401, detail="Authentication failed")

        @router.post("/trigger/{source}", response_model=WebhookResponse)
        async def webhook_trigger(
            source: str,
            event: WebhookEvent,
            request: Request,
            auth_result: str = Depends(verify_auth),
        ) -> WebhookResponse:
            """Handle incoming webhook trigger.

            Args:
                source: Webhook source identifier
                event: Webhook event payload
                request: FastAPI request object
                auth_result: Authentication result

            Returns:
                WebhookResponse with execution status
            """
            if not self.config.enabled:
                raise HTTPException(status_code=503, detail="Webhook service disabled")

            # Check allowed sources
            if self.config.allowed_sources and source not in self.config.allowed_sources:
                raise HTTPException(status_code=403, detail=f"Source '{source}' not allowed")

            # Check rate limit
            allowed, reason = self._rate_limiter.check_rate_limit(source)
            if not allowed:
                raise HTTPException(status_code=429, detail=reason)

            # Process webhook
            try:
                result = await self._handle_webhook_trigger(source, event)
                return result
            except Exception as e:
                logger.error(f"Webhook processing error: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @router.get("/status")
        async def webhook_status(
            auth_result: str = Depends(verify_auth),
        ) -> Dict[str, Any]:
            """Get webhook system status."""
            return {
                "enabled": self.config.enabled,
                "auth_method": self.config.auth_method.value,
                "rate_limit_enabled": self.config.rate_limit.enabled,
                "total_events": len(self._event_history),
                "allowed_sources": self.config.allowed_sources or "all",
                "plugins": {
                    "system_events": self._system_events_plugin is not None,
                    "wake_trigger": self._wake_trigger_plugin is not None,
                    "enhanced_scheduler": self._enhanced_scheduler_plugin is not None,
                    "memory": self._memory_plugin is not None,
                    "observability": self._observability_plugin is not None,
                },
            }

        @router.get("/history")
        async def webhook_history(
            limit: int = 50,
            source: Optional[str] = None,
            auth_result: str = Depends(verify_auth),
        ) -> Dict[str, Any]:
            """Get webhook event history."""
            events = self._event_history

            if source:
                events = [e for e in events if e.source == source]

            events = events[-limit:]

            return {
                "total": len(self._event_history),
                "returned": len(events),
                "events": [
                    {
                        "event_id": e.event_id,
                        "source": e.source,
                        "event_type": e.event_type,
                        "execution_mode": e.execution_mode,
                        "status": e.status,
                        "timestamp": datetime.fromtimestamp(e.timestamp).isoformat(),
                        "duration_ms": e.duration_ms,
                        "result": e.result,
                        "error": e.error,
                    }
                    for e in events
                ],
            }

        @router.get("/rate-limit/{source}")
        async def rate_limit_status(
            source: str,
            auth_result: str = Depends(verify_auth),
        ) -> Dict[str, Any]:
            """Get rate limit status for a source."""
            return self._rate_limiter.get_status(source)

        return router

    async def _handle_webhook_trigger(
        self,
        source: str,
        event: WebhookEvent,
    ) -> WebhookResponse:
        """Handle webhook trigger with authentication and rate limiting.

        Args:
            source: Webhook source identifier
            event: Webhook event payload

        Returns:
            WebhookResponse with execution result
        """
        start_time = time.time()
        self._event_counter += 1
        event_id = f"wh_{source}_{self._event_counter}_{int(start_time)}"

        # Create observability span
        span = None
        if self._observability_plugin:
            try:
                span = self._observability_plugin.start_tool_span(
                    context=None,
                    tool_name="webhook_trigger",
                    arguments={
                        "source": source,
                        "event_type": event.event_type,
                        "event_id": event_id,
                    },
                )
            except Exception as e:
                logger.warning(f"Failed to create observability span: {e}")

        # Log event
        if self.config.log_events:
            logger.info(f"Webhook received: {source}/{event.event_type} ({event_id})")

        try:
            # Determine execution mode
            execution_mode = self.config.default_execution_mode

            # Check if event data specifies execution mode
            if event.data.get("execution_mode"):
                mode_str = event.data["execution_mode"]
                if mode_str == "isolated":
                    execution_mode = ExecutionMode.ISOLATED_SESSION

            # Process webhook event
            result = await self._process_webhook_event(source, event, execution_mode)

            # Record event
            duration_ms = (time.time() - start_time) * 1000
            record = WebhookEventRecord(
                event_id=event_id,
                source=source,
                event_type=event.event_type,
                execution_mode=execution_mode.value,
                status="success",
                timestamp=start_time,
                duration_ms=duration_ms,
                result=result[:500] if result else None,
            )
            self._add_event_record(record)

            # Store in memory if enabled
            if self.config.store_events and self._memory_plugin:
                try:
                    self._memory_plugin.client.store_memory(
                        text=f"Webhook event ({source}/{event.event_type}): {result[:200] if result else 'processed'}",
                        session_id="system:webhook",
                        tags=["webhook", source, event.event_type],
                    )
                except Exception as e:
                    logger.warning(f"Failed to store webhook event in memory: {e}")

            if span:
                self._observability_plugin.end_tool_span(span, result=result)

            return WebhookResponse(
                success=True,
                message=result or "Event processed successfully",
                execution_id=event_id,
            )

        except Exception as e:
            # Record error
            duration_ms = (time.time() - start_time) * 1000
            record = WebhookEventRecord(
                event_id=event_id,
                source=source,
                event_type=event.event_type,
                execution_mode=self.config.default_execution_mode.value,
                status="error",
                timestamp=start_time,
                duration_ms=duration_ms,
                error=str(e),
            )
            self._add_event_record(record)

            if span:
                self._observability_plugin.end_tool_span(span, error=e)

            logger.error(f"Webhook processing failed: {e}")
            raise

    async def _process_webhook_event(
        self,
        source: str,
        event: WebhookEvent,
        execution_mode: ExecutionMode,
    ) -> str:
        """Process webhook event based on execution mode.

        Args:
            source: Webhook source
            event: Webhook event
            execution_mode: How to execute the event

        Returns:
            Processing result string
        """
        message = event.data.get("message", f"Webhook event: {event.event_type}")

        if execution_mode == ExecutionMode.MAIN_SESSION:
            return await self._process_main_session_webhook(source, event, message)
        else:
            return await self._process_isolated_session_webhook(source, event, message)

    async def _process_main_session_webhook(
        self,
        source: str,
        event: WebhookEvent,
        message: str,
    ) -> str:
        """Process webhook in main session via system events queue.

        Args:
            source: Webhook source
            event: Webhook event
            message: Message to process

        Returns:
            Processing result
        """
        # Enqueue system event
        if self._system_events_plugin:
            session_key = event.data.get("session_key", "default:main")
            self._system_events_plugin.enqueue_event(
                f"[Webhook:{source}] {message}",
                session_key,
                f"webhook_{source}",
            )

        # Trigger wake for immediate processing
        if self._wake_trigger_plugin:
            self._wake_trigger_plugin.request_wake(
                f"webhook:{source}/{event.event_type}",
                source="webhook",
            )

        return f"Event queued for main session: {event.event_type}"

    async def _process_isolated_session_webhook(
        self,
        source: str,
        event: WebhookEvent,
        message: str,
    ) -> str:
        """Process webhook in isolated session with direct action handler or agent execution.

        Args:
            source: Webhook source
            event: Webhook event
            message: Message to process

        Returns:
            Action handler result or agent response
        """
        # PRIORITY 1: Check for registered action handler for this event_type
        handler = self.config.action_handlers.get(event.event_type)
        if handler:
            try:
                logger.info(f"Executing action handler for event_type: {event.event_type}")
                result = await handler(event.data)
                if isinstance(result, dict):
                    if result.get("error"):
                        return f"Action error: {result['error']}"
                    return result.get("message", "Action executed successfully")
                return str(result) if result else "Action executed"
            except Exception as e:
                logger.error(f"Action handler failed for {event.event_type}: {e}")
                return f"Action error: {e}"

        # PRIORITY 2: Fall back to agent chat_async (LLM-based processing)
        agent = self._contextwise_agent or self._agent
        if not agent:
            return "No action handler registered and agent not available"

        try:
            if hasattr(agent, "chat_async"):
                result = await agent.chat_async(
                    message=f"[Webhook:{source}] {message}",
                    user_id=f"webhook_{source}",
                    channel="webhook",
                )
                return str(result) if result else "Processed"
            elif hasattr(agent, "chat"):
                result = agent.chat(
                    message=f"[Webhook:{source}] {message}",
                    user_id=f"webhook_{source}",
                    channel="webhook",
                )
                return str(result) if result else "Processed"
            else:
                return "Agent execution method not available"

        except Exception as e:
            logger.error(f"Isolated webhook execution failed: {e}")
            return f"Execution error: {e}"

    def _add_event_record(self, record: WebhookEventRecord) -> None:
        """Add event record to history."""
        self._event_history.append(record)
        if len(self._event_history) > self._max_history:
            self._event_history = self._event_history[-self._max_history :]

    def _make_webhook_status_tool(self) -> Tool:
        """Create tool for checking webhook status."""

        @function_tool
        def webhook_status(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            """Get current webhook system status and configuration."""
            lines = ["Webhook System Status:"]
            lines.append(f"Enabled: {self.config.enabled}")
            lines.append(f"Auth Method: {self.config.auth_method.value}")
            lines.append(f"Default Mode: {self.config.default_execution_mode.value}")

            # Rate limiting
            lines.append(f"\nRate Limiting: {'enabled' if self.config.rate_limit.enabled else 'disabled'}")
            if self.config.rate_limit.enabled:
                lines.append(f"  Per Minute: {self.config.rate_limit.requests_per_minute}")
                lines.append(f"  Per Hour: {self.config.rate_limit.requests_per_hour}")
                lines.append(f"  Burst: {self.config.rate_limit.burst_limit}")

            # Event stats
            lines.append(f"\nEvent History: {len(self._event_history)} events")
            if self._event_history:
                recent = self._event_history[-5:]
                lines.append("Recent events:")
                for e in recent:
                    ts = datetime.fromtimestamp(e.timestamp).strftime("%H:%M:%S")
                    lines.append(f"  [{ts}] {e.source}/{e.event_type}: {e.status}")

            # Plugin integration
            plugins = []
            if self._system_events_plugin:
                plugins.append("✓ System Events")
            if self._wake_trigger_plugin:
                plugins.append("✓ Wake Trigger")
            if self._enhanced_scheduler_plugin:
                plugins.append("✓ Enhanced Scheduler")
            if self._memory_plugin:
                plugins.append("✓ Memory")
            lines.append(f"\nPlugin Integration: {', '.join(plugins) or 'None'}")

            return ToolOutputText(text="\n".join(lines))

        return webhook_status

    def _make_webhook_config_tool(self) -> Tool:
        """Create tool for configuring webhooks."""

        @function_tool
        def configure_webhook(
            ctx: RunContextWrapper[AgentContext],
            enabled: Optional[bool] = None,
            default_mode: Optional[str] = None,
            rate_limit_enabled: Optional[bool] = None,
            requests_per_minute: Optional[int] = None,
        ) -> ToolOutputText:
            """Configure webhook system settings.

            Args:
                enabled: Enable/disable webhook endpoints
                default_mode: Default execution mode ('main' or 'isolated')
                rate_limit_enabled: Enable/disable rate limiting
                requests_per_minute: Rate limit per minute
            """
            changes = []

            if enabled is not None:
                self.config.enabled = enabled
                changes.append(f"Enabled: {enabled}")

            if default_mode:
                if default_mode == "isolated":
                    self.config.default_execution_mode = ExecutionMode.ISOLATED_SESSION
                else:
                    self.config.default_execution_mode = ExecutionMode.MAIN_SESSION
                changes.append(f"Default mode: {default_mode}")

            if rate_limit_enabled is not None:
                self.config.rate_limit.enabled = rate_limit_enabled
                changes.append(f"Rate limit: {'enabled' if rate_limit_enabled else 'disabled'}")

            if requests_per_minute:
                self.config.rate_limit.requests_per_minute = requests_per_minute
                changes.append(f"Requests/min: {requests_per_minute}")

            if changes:
                return ToolOutputText(text=f"Webhook configuration updated:\n" + "\n".join(f"  - {c}" for c in changes))
            else:
                return ToolOutputText(text="No configuration changes made")

        return configure_webhook

    def _make_webhook_history_tool(self) -> Tool:
        """Create tool for viewing webhook history."""

        @function_tool
        def webhook_history(
            ctx: RunContextWrapper[AgentContext],
            limit: int = 10,
            source: Optional[str] = None,
            status: Optional[str] = None,
        ) -> ToolOutputText:
            """View webhook event history.

            Args:
                limit: Maximum events to return
                source: Filter by source
                status: Filter by status ('success' or 'error')
            """
            events = self._event_history

            if source:
                events = [e for e in events if e.source == source]

            if status:
                events = [e for e in events if e.status == status]

            events = events[-limit:]

            if not events:
                return ToolOutputText(text="No webhook events found matching criteria")

            lines = [f"Webhook History ({len(events)} events):"]
            for e in events:
                ts = datetime.fromtimestamp(e.timestamp).strftime("%Y-%m-%d %H:%M:%S")
                status_icon = "✓" if e.status == "success" else "✗"
                result_text = e.result[:50] if e.result else e.error[:50] if e.error else "N/A"
                lines.append(
                    f"{status_icon} [{ts}] {e.source}/{e.event_type} ({e.duration_ms:.0f}ms)"
                )
                lines.append(f"   → {result_text}")

            return ToolOutputText(text="\n".join(lines))

        return webhook_history
