"""Wake Trigger Plugin for Contextwise v0.3.0.

This module provides immediate activation mechanism with coalescing
for proactive agent wake requests.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

from agents import Agent, RunContextWrapper, Tool, ToolOutputText, function_tool

from ..base import AgentPlugin
from ..context import AgentContext

logger = logging.getLogger(__name__)


@dataclass
class WakeRequest:
    """Request for immediate wake."""

    reason: str
    timestamp: float
    coalesce_ms: int = 250
    source: str = "system"


class WakeCoordinator:
    """Coordinates wake requests with coalescing.

    Multiple wake requests within the coalesce window are merged
    to prevent excessive agent activations.
    """

    def __init__(self, default_coalesce_ms: int = 250):
        """Initialize wake coordinator.

        Args:
            default_coalesce_ms: Default coalescing window in milliseconds
        """
        self.default_coalesce_ms = default_coalesce_ms
        self._pending_request: Optional[WakeRequest] = None
        self._timer: Optional[asyncio.Task] = None
        self._handler: Optional[Callable] = None
        self._running = False
        self._wake_history: List[WakeRequest] = []
        self._max_history = 50

    def set_handler(self, handler: Callable) -> None:
        """Set wake handler callback.

        Args:
            handler: Async callable to handle wake requests
        """
        self._handler = handler

    def request_wake(
        self,
        reason: str,
        coalesce_ms: Optional[int] = None,
        source: str = "system",
    ) -> None:
        """Request immediate wake with coalescing.

        Args:
            reason: Reason for wake request
            coalesce_ms: Optional custom coalesce window
            source: Source of the wake request
        """
        if not self._running:
            logger.debug("Wake coordinator not running, ignoring request")
            return

        try:
            loop = asyncio.get_running_loop()
            timestamp = loop.time()
        except RuntimeError:
            timestamp = datetime.now().timestamp()

        request = WakeRequest(
            reason=reason,
            timestamp=timestamp,
            coalesce_ms=coalesce_ms or self.default_coalesce_ms,
            source=source,
        )

        self._pending_request = request
        self._schedule_wake()
        logger.debug(f"Wake requested: {reason} (coalesce={request.coalesce_ms}ms)")

    def start(self) -> None:
        """Start wake coordinator."""
        self._running = True
        logger.info("Wake coordinator started")

    def stop(self) -> None:
        """Stop wake coordinator."""
        self._running = False
        if self._timer and not self._timer.done():
            self._timer.cancel()
            self._timer = None
        logger.info("Wake coordinator stopped")

    def get_wake_history(self, limit: int = 10) -> List[WakeRequest]:
        """Get recent wake history.

        Args:
            limit: Maximum number of entries to return

        Returns:
            List of recent wake requests
        """
        return self._wake_history[-limit:]

    def _schedule_wake(self) -> None:
        """Schedule wake execution."""
        if self._timer and not self._timer.done():
            return  # Already scheduled

        if not self._pending_request:
            return

        coalesce_ms = self._pending_request.coalesce_ms

        try:
            self._timer = asyncio.create_task(self._execute_after_delay(coalesce_ms))
        except RuntimeError:
            # No event loop running - execute immediately in sync context
            logger.warning("No event loop - executing wake immediately")
            if self._handler and self._pending_request:
                reason = self._pending_request.reason
                self._pending_request = None
                # Can't await in sync context, just log
                logger.info(f"Wake triggered (sync): {reason}")

    async def _execute_after_delay(self, delay_ms: int) -> None:
        """Execute wake after delay.

        Args:
            delay_ms: Delay in milliseconds
        """
        await asyncio.sleep(delay_ms / 1000)

        if not self._running or not self._pending_request:
            return

        request = self._pending_request
        self._pending_request = None

        # Record in history
        self._wake_history.append(request)
        if len(self._wake_history) > self._max_history:
            self._wake_history = self._wake_history[-self._max_history :]

        if self._handler:
            try:
                result = self._handler(request.reason)
                if asyncio.iscoroutine(result):
                    await result
                logger.info(f"Wake executed: {request.reason}")
            except Exception as e:
                logger.error(f"Wake handler error: {e}")


class WakeTriggerPlugin(AgentPlugin[AgentContext]):
    """Plugin for immediate wake/trigger activation.

    Provides coalesced immediate activation requests for proactive
    agent behavior.

    Attributes:
        id: Plugin identifier
        name: Human-readable plugin name
        version: Plugin version
    """

    id = "wake_trigger"
    name = "Wake Trigger Plugin"
    version = "1.0.0"

    def __init__(self, default_coalesce_ms: int = 250):
        """Initialize wake trigger plugin.

        Args:
            default_coalesce_ms: Default coalescing window in milliseconds
        """
        self._coordinator = WakeCoordinator(default_coalesce_ms)
        self._heartbeat_plugin: Optional[Any] = None
        self._system_events_plugin: Optional[Any] = None

    def dependencies(self) -> List[str]:
        """Return plugin dependencies."""
        return []

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Add wake trigger tools to agent."""
        # Discover related plugins
        plugin_index = getattr(agent, "plugin_index", {}) or {}
        self._heartbeat_plugin = plugin_index.get("heartbeat")
        self._system_events_plugin = plugin_index.get("system_events")

        # Set wake handler
        if self._heartbeat_plugin and hasattr(self._heartbeat_plugin, "_run_heartbeat_check"):
            self._coordinator.set_handler(
                lambda reason: self._heartbeat_plugin._run_heartbeat_check(reason, None, True)
            )

        tools = [
            self._make_request_wake_tool(),
            self._make_wake_status_tool(),
        ]
        return agent.clone(tools=[*agent.tools, *tools])

    def _make_request_wake_tool(self) -> Tool:
        """Create tool for requesting immediate wake."""

        @function_tool
        def request_immediate_wake(
            ctx: RunContextWrapper[AgentContext],
            reason: str = "manual",
            coalesce_ms: Optional[int] = None,
        ) -> ToolOutputText:
            """Request immediate agent wake for proactive action.

            Args:
                reason: Reason for the wake request
                coalesce_ms: Optional custom coalesce window in milliseconds
            """
            # Add system event if available
            if self._system_events_plugin and ctx and hasattr(ctx, "context"):
                session_key = self._get_session_key(ctx)
                self._system_events_plugin.enqueue_event(
                    f"Wake requested: {reason}",
                    session_key,
                    "wake_trigger",
                )

            self._coordinator.request_wake(reason, coalesce_ms, "tool")
            return ToolOutputText(
                text=f"Wake requested: {reason} (coalesce={coalesce_ms or self._coordinator.default_coalesce_ms}ms)"
            )

        return request_immediate_wake

    def _make_wake_status_tool(self) -> Tool:
        """Create tool for checking wake status."""

        @function_tool
        def wake_trigger_status(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            """Get wake trigger system status and recent history."""
            status = "running" if self._coordinator._running else "stopped"
            pending = "yes" if self._coordinator._pending_request else "no"

            history = self._coordinator.get_wake_history(5)
            history_lines = []
            for req in history:
                ts = datetime.fromtimestamp(req.timestamp).strftime("%H:%M:%S")
                history_lines.append(f"  - [{ts}] {req.source}: {req.reason}")

            history_text = "\n".join(history_lines) if history_lines else "  (none)"

            return ToolOutputText(
                text=f"Wake Trigger Status: {status}\n"
                f"Pending request: {pending}\n"
                f"Coalesce window: {self._coordinator.default_coalesce_ms}ms\n"
                f"Recent wakes:\n{history_text}"
            )

        return wake_trigger_status

    def start(self) -> None:
        """Start the wake coordinator."""
        self._coordinator.start()

    def stop(self) -> None:
        """Stop the wake coordinator."""
        self._coordinator.stop()

    def request_wake(
        self,
        reason: str,
        coalesce_ms: Optional[int] = None,
        source: str = "system",
    ) -> None:
        """Request immediate wake.

        Args:
            reason: Reason for wake request
            coalesce_ms: Optional custom coalesce window
            source: Source of the request
        """
        self._coordinator.request_wake(reason, coalesce_ms, source)

    def set_handler(self, handler: Callable) -> None:
        """Set wake handler callback.

        Args:
            handler: Callback function for wake events
        """
        self._coordinator.set_handler(handler)

    def _get_session_key(self, ctx: RunContextWrapper[AgentContext]) -> str:
        """Extract session key from context."""
        if ctx and hasattr(ctx, "context") and ctx.context:
            user_id = getattr(ctx.context, "user_id", "default")
            session_id = getattr(ctx.context, "session_id", "main") or "main"
            return f"{user_id}:{session_id}"
        return "default:main"
