"""WhatsApp notification plugin implementation.

This module provides the WhatsAppNotificationPlugin class for sending
messages via WhatsApp with proper handling of message length limits,
batching, and formatting.

The plugin follows the generic plugin pattern and works with any agent
context type (Agent[TContext]).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Generic, List, Optional, TypeVar

from .base import NotificationPlugin


TContext = TypeVar("TContext")

logger = logging.getLogger(__name__)


@dataclass
class WhatsAppNotificationPlugin(NotificationPlugin[TContext], Generic[TContext]):
    """WhatsApp notification plugin.

    Supports:
        - Message length constraints (4096 char limit)
        - Message batching with prefixes [1/2], [2/2]
        - Italic formatting for emphasis
        - Pluggable transport via send_callable

    Type Parameters:
        TContext: The context type used by the agent.

    Attributes:
        id: Plugin identifier for dependency management.
        name: Human-readable plugin name.
        version: Plugin version string.
        max_message_length: WhatsApp message length limit (default: 4096).
        batch_size: Safe batch size below limit (default: 4000).
        italics: Whether to format messages in italics (default: False).
        send_callable: Optional custom transport function.

    Example:
        >>> def my_sender(user_id, text, metadata):
        ...     print(f"Sending to {user_id}: {text}")
        >>> plugin = WhatsAppNotificationPlugin(send_callable=my_sender)
        >>> plugin.send_message("12345", "Hello!")
        Sending to 12345: Hello!
    """

    # Plugin metadata
    id: str = "whatsapp-notification"
    name: str = "WhatsApp Notification Plugin"
    version: str = "1.0.0"

    # Configuration
    max_message_length: int = 4096
    batch_size: int = 4000  # Safe margin below limit
    italics: bool = False

    # Transport
    send_callable: Optional[Callable[[str, str, Dict[str, Any]], None]] = None

    def send_message(
        self,
        user_id: str,
        text: str,
        *,
        channel: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Send message via WhatsApp with automatic batching.

        Long messages are automatically split into chunks with batch
        prefixes like [1/2], [2/2] to indicate parts.

        Args:
            user_id: Recipient phone number or identifier.
            text: Message content to send.
            channel: Channel override (default: "whatsapp").
            metadata: Additional metadata to pass to transport.
        """
        channel = channel or "whatsapp"
        metadata = metadata or {}

        chunks = self._split_message(text)
        total = len(chunks)

        for idx, chunk in enumerate(chunks, start=1):
            payload = chunk
            if total > 1:
                payload = f"[{idx}/{total}] {payload}"
            if self.italics:
                payload = self._format_italics(payload)

            self._dispatch(
                user_id=user_id,
                text=payload,
                channel=channel,
                metadata=metadata,
            )

    def _split_message(self, text: str) -> List[str]:
        """Split message into chunks respecting batch_size.

        Args:
            text: The message text to split.

        Returns:
            List of message chunks. Empty text returns [""].
        """
        if not text:
            return [""]
        max_len = max(1, self.batch_size)
        return [text[i : i + max_len] for i in range(0, len(text), max_len)]

    def _format_italics(self, text: str) -> str:
        """Apply WhatsApp italic formatting.

        WhatsApp uses underscores for italics. Multi-line messages
        have each line formatted separately.

        Args:
            text: Text to format.

        Returns:
            Text with WhatsApp italic formatting applied.
        """
        lines = text.split("\n")
        return "\n".join([f"_{line}_" for line in lines])

    def _dispatch(
        self,
        *,
        user_id: str,
        text: str,
        channel: str,
        metadata: Dict[str, Any],
    ) -> None:
        """Dispatch message to transport layer.

        If send_callable is provided, calls it with the message data.
        Otherwise, logs the message for debugging.

        Args:
            user_id: Recipient identifier.
            text: Message text.
            channel: Notification channel.
            metadata: Additional metadata.
        """
        if self.send_callable is not None:
            try:
                self.send_callable(user_id, text, {**metadata, "channel": channel})
            except Exception:
                logger.exception("Error in WhatsApp send_callable")
        else:
            logger.info(
                "WhatsAppNotificationPlugin sending message",
                extra={
                    "user_id": user_id,
                    "channel": channel,
                    "text": text[:100] if len(text) > 100 else text,
                    "metadata": metadata,
                },
            )

    async def send_message_async(
        self,
        user_id: str,
        text: str,
        *,
        channel: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Async version of send_message.

        Currently delegates to sync implementation. Override in subclass
        for true async transport.

        Args:
            user_id: Recipient phone number or identifier.
            text: Message content to send.
            channel: Channel override (default: "whatsapp").
            metadata: Additional metadata to pass to transport.
        """
        self.send_message(user_id, text, channel=channel, metadata=metadata)

    def on_booking_confirmed(
        self,
        context: TContext,
        booking: Any,
    ) -> None:
        """Hook called when a booking is confirmed.

        Sends a WhatsApp notification to the user about their booking.
        This method is called by booking plugins when a booking is created.

        Args:
            context: The agent context containing user_id.
            booking: The booking object with booking details.
        """
        # Extract user_id from context if available
        user_id = getattr(context, "user_id", None)
        if not user_id:
            logger.warning("Cannot send booking confirmation: no user_id in context")
            return

        # Extract booking details
        booking_id = getattr(booking, "id", "unknown")
        start = getattr(booking, "start", None)
        service_id = getattr(booking, "service_id", "unknown")

        start_str = start.isoformat() if start else "unknown"

        message = (
            f"Tu turno {booking_id} está confirmado para "
            f"{start_str} (servicio {service_id})."
        )

        channel = getattr(context, "channel", "whatsapp") or "whatsapp"

        self.send_message(
            user_id=user_id,
            text=message,
            channel=channel,
            metadata={"booking_id": booking_id},
        )
