"""WhatsApp plugin module for the contextwise agent.

This module provides generic, agent-agnostic notification and WhatsApp
Business API integration following the plugin-system-implementation-patterns-specs.md.

Exports:
    - NotificationPlugin: Generic base for notification channels
    - WhatsAppNotificationPlugin: WhatsApp-specific notification implementation
    - WhatsAppAPIPlugin: WhatsApp Business API webhook integration
    - Security utilities: validate_webhook_signature, is_development_mode, get_app_secret
    - Router utilities: create_whatsapp_router, create_agent_message_handler
    - API utilities: typing_indicator, get_media, upload_media, send_image_message, send_text_message
"""

from .base import NotificationPlugin
from .whatsapp_plugin import WhatsAppNotificationPlugin
from .api_plugin import WhatsAppAPIPlugin
from .security import (
    is_development_mode,
    get_app_secret,
    validate_webhook_signature,
)
from .router import (
    create_whatsapp_router,
    create_agent_message_handler,
)
from .utils import (
    # Config
    get_access_token,
    get_phone_number_id,
    # Typing indicator
    typing_indicator,
    typing_indicator_async,
    # Media
    get_media,
    get_media_async,
    upload_media,
    upload_media_async,
    # Messages
    send_text_message,
    send_text_message_async,
    send_image_message,
    send_image_message_async,
    # Message chunking
    split_message_into_chunks,
    WHATSAPP_MAX_TEXT_LENGTH,
)
from .voice_bridge import WhatsAppVoiceBridge, ActiveCallSession, LiveKitAgentConnector

__all__ = [
    # Base notification
    "NotificationPlugin",
    # WhatsApp plugins
    "WhatsAppNotificationPlugin",
    "WhatsAppAPIPlugin",
    # Voice bridge
    "WhatsAppVoiceBridge",
    "ActiveCallSession",
    "LiveKitAgentConnector",
    # Security utilities
    "is_development_mode",
    "get_app_secret",
    "validate_webhook_signature",
    # Router utilities
    "create_whatsapp_router",
    "create_agent_message_handler",
    # API utilities
    "get_access_token",
    "get_phone_number_id",
    "typing_indicator",
    "typing_indicator_async",
    "get_media",
    "get_media_async",
    "upload_media",
    "upload_media_async",
    "send_text_message",
    "send_text_message_async",
    "send_image_message",
    "send_image_message_async",
    # Message utilities
    "split_message_into_chunks",
    "WHATSAPP_MAX_TEXT_LENGTH",
]
