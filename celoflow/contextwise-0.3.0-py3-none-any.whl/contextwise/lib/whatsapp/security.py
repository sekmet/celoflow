"""Security utilities for WhatsApp webhook validation.

This module provides functions for validating WhatsApp Business API
webhook signatures using HMAC-SHA256. It supports development mode
bypassing for easier local testing.

Functions:
    - is_development_mode: Check if APP_ENV is set to development
    - get_app_secret: Retrieve WHATSAPP_APP_SECRET from environment
    - validate_webhook_signature: Validate webhook payload signature
"""

from __future__ import annotations

import hashlib
import hmac
import os
from typing import Optional


def is_development_mode() -> bool:
    """Check if the application is running in development mode.

    Development mode is determined by the APP_ENV environment variable.
    If not set, defaults to "development".

    Returns:
        True if APP_ENV is "development" (case-insensitive), False otherwise.

    Example:
        >>> import os
        >>> os.environ["APP_ENV"] = "production"
        >>> is_development_mode()
        False
    """
    return os.getenv("APP_ENV", "development").lower() == "development"


def get_app_secret() -> str:
    """Get the WhatsApp app secret from environment variables.

    Returns:
        The WHATSAPP_APP_SECRET environment variable value.

    Raises:
        ValueError: If WHATSAPP_APP_SECRET is not set.

    Example:
        >>> import os
        >>> os.environ["WHATSAPP_APP_SECRET"] = "my_secret"
        >>> get_app_secret()
        'my_secret'
    """
    app_secret = os.getenv("WHATSAPP_APP_SECRET")

    if not app_secret:
        raise ValueError("WHATSAPP_APP_SECRET environment variable is not set")

    return app_secret


def validate_webhook_signature(
    payload: bytes,
    signature_header: Optional[str],
) -> bool:
    """Validate the webhook payload using SHA256 signature.

    In development mode, signature validation is bypassed to allow
    easier local testing without full API setup.

    Args:
        payload: The raw request payload bytes.
        signature_header: The X-Hub-Signature-256 header value.
            Expected format: "sha256=<hex_signature>"

    Returns:
        True if signature is valid or in development mode.
        False if signature is invalid or missing (in production).

    Security Notes:
        - Uses constant-time comparison to prevent timing attacks.
        - Development mode bypass should only be used for local testing.

    Example:
        >>> import os
        >>> os.environ["APP_ENV"] = "development"
        >>> validate_webhook_signature(b"test", None)
        True
    """
    # In development mode, bypass signature validation
    if is_development_mode():
        return True

    if not signature_header or not signature_header.startswith("sha256="):
        return False

    app_secret = get_app_secret()
    expected_signature = signature_header.split("sha256=")[1]

    # Calculate signature using HMAC-SHA256
    hmac_obj = hmac.new(
        app_secret.encode("utf-8"),
        payload,
        hashlib.sha256,
    )
    calculated_signature = hmac_obj.hexdigest()

    # Compare signatures using constant-time comparison to prevent timing attacks
    return hmac.compare_digest(calculated_signature, expected_signature)
