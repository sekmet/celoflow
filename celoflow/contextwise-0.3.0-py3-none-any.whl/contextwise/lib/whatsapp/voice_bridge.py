"""WhatsApp voice call WebRTC bridging to LiveKit agents.

Handles WebRTC peer connections, SDP negotiation, and audio bridging
for WhatsApp voice calls.

Architecture:
    The system requires 4 SEPARATE processes running:
    
    1. LiveKit Server    → livekit-server --dev
    2. WhatsApp Server   → uv run agent_server.py (webhooks, this bridge)
    3. Go Bridge         → ./whatsapp-bridge (WebRTC to LiveKit)
    4. LiveKit Worker    → uv run livekit_agent.py dev (VOICE PROCESSING)
    
    Flow:
    1. WhatsApp sends call (WebRTC offer)
    2. This bridge receives webhook, forwards to Go Bridge
    3. Go Bridge creates WebRTC peer + LiveKit room, returns SDP answer
    4. This bridge sends pre_accept/accept to WhatsApp
    5. LiveKit Worker (separate process!) is auto-dispatched to the room
    6. Worker provides STT → LLM → TTS voice processing
    
IMPORTANT:
    Voice processing is handled by a SEPARATE LiveKit worker process that
    registers with the LiveKit server using `cli.run_app()`. The worker is
    automatically dispatched to rooms when participants join.
    
    See: contextwise.livekit_worker or examples/voice/livekit_agent.py
"""

from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from livekit import rtc
    from livekit.agents import AgentSession

logger = logging.getLogger(__name__)

# WhatsApp Graph API version
GRAPH_API_VERSION = "v22.0"
GRAPH_API_BASE = f"https://graph.facebook.com/{GRAPH_API_VERSION}"


@dataclass
class ActiveCallSession:
    """Represents an active WhatsApp voice call session."""

    call_id: str
    whatsapp_id: str
    livekit_room: str = ""
    sdp_offer: Optional[str] = None
    sdp_answer: Optional[str] = None
    ice_state: str = "new"
    status: str = "connecting"
    peer_connection: Optional[Any] = None
    agent_session: Optional[Any] = None
    audio_bridge_task: Optional[asyncio.Task] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def update_ice_state(self, state: str) -> None:
        """Update ICE connection state."""
        self.ice_state = state
        if state in ("connected", "completed"):
            self.status = "connected"
        elif state in ("failed", "disconnected", "closed"):
            self.status = "disconnected"

    def to_status_dict(self) -> Dict[str, Any]:
        """Convert to status dictionary."""
        return {
            "call_id": self.call_id,
            "whatsapp_id": self.whatsapp_id,
            "livekit_room": self.livekit_room,
            "ice_state": self.ice_state,
            "status": self.status,
        }


class LiveKitAgentConnector:
    """DEPRECATED: Direct room connection doesn't work with LiveKit Agents SDK.
    
    This class attempted to connect to LiveKit rooms directly from the FastAPI
    process, but the LiveKit Agents SDK uses a worker registration model.
    
    The correct approach is to run a separate LiveKit worker process that:
    1. Uses AgentServer() and @server.rtc_session() decorator
    2. Registers with LiveKit server via cli.run_app(server)
    3. Gets auto-dispatched to rooms when participants join
    
    See: contextwise.livekit_worker or examples/voice/livekit_agent.py
    
    This class is kept for backwards compatibility but will log a warning
    and return False for connect_agent_to_room().
    """

    def __init__(
        self,
        agent: Any,
        livekit_url: str,
        livekit_api_key: str,
        livekit_api_secret: str,
        voice_config: Optional[Dict[str, Any]] = None,
    ):
        """Initialize the agent connector.

        Args:
            agent: Agent instance for LLM processing
            livekit_url: LiveKit server URL
            livekit_api_key: LiveKit API key
            livekit_api_secret: LiveKit API secret
            voice_config: Optional voice configuration dict
        """
        self.agent = agent
        self.livekit_url = livekit_url
        self.livekit_api_key = livekit_api_key
        self.livekit_api_secret = livekit_api_secret
        self.voice_config = voice_config or {}
        self.logger = logging.getLogger(__name__)
        self._active_sessions: Dict[str, Any] = {}

    async def connect_agent_to_room(
        self,
        room_name: str,
        call_id: str,
        participant_identity: str = "agent",
    ) -> bool:
        """Connect agent to a LiveKit room.
        
        NOTE: With the integrated LiveKit worker (spawned by server.serve()),
        the worker automatically handles voice sessions via @server.rtc_session().
        This method just logs and returns True since the worker handles it.

        Args:
            room_name: LiveKit room name
            call_id: Call ID for tracking
            participant_identity: Agent's identity in the room (unused)

        Returns:
            True - the LiveKit worker handles the session automatically
        """
        self.logger.info(
            f"Agent session will be handled by LiveKit worker for room {room_name} "
            f"(call {call_id})"
        )
        # The LiveKit worker (spawned as subprocess) automatically handles
        # voice sessions when participants join rooms via @server.rtc_session()
        return True

    def _create_stt(self) -> Any:
        """Create STT (Speech-to-Text) plugin."""
        stt_config = self.voice_config.get("stt", "groq/whisper-large-v3-turbo")
        stt_language = self.voice_config.get("stt_language", "en")

        if "/" in stt_config:
            provider, model = stt_config.split("/", 1)
        else:
            provider, model = "groq", stt_config

        if provider == "groq":
            from livekit.plugins import groq
            return groq.STT(model=model, language=stt_language)
        elif provider == "openai":
            from livekit.plugins import openai
            return openai.STT(model=model, language=stt_language)
        elif provider == "deepgram":
            from livekit.plugins import deepgram
            return deepgram.STT(model=model, language=stt_language)
        else:
            # Default to Groq
            from livekit.plugins import groq
            return groq.STT(model="whisper-large-v3-turbo", language=stt_language)

    def _create_llm(self) -> Any:
        """Create LLM plugin."""
        llm_model = self.voice_config.get("model", "gpt-4o-mini")

        # Extract provider from model string if present
        if "/" in llm_model:
            provider, model = llm_model.split("/", 1)
        else:
            provider, model = "openai", llm_model

        if provider == "groq":
            from livekit.plugins import openai
            return openai.LLM(
                model=model,
                base_url="https://api.groq.com/openai/v1",
                api_key=os.getenv("GROQ_API_KEY"),
            )
        elif provider == "openai":
            from livekit.plugins import openai
            return openai.LLM(model=model)
        else:
            # Default to OpenAI
            from livekit.plugins import openai
            return openai.LLM(model="gpt-4o-mini")

    def _create_tts(self) -> Any:
        """Create TTS (Text-to-Speech) plugin."""
        tts_config = self.voice_config.get("tts", "inworld/lupita")
        tts_voice = self.voice_config.get("tts_voice")

        if "/" in tts_config:
            provider, voice = tts_config.split("/", 1)
        else:
            provider, voice = "inworld", tts_config

        if tts_voice:
            voice = tts_voice

        if provider == "inworld":
            from livekit.plugins import inworld
            return inworld.TTS(voice=voice, speaking_rate=1.2)
        elif provider == "openai":
            from livekit.plugins import openai
            return openai.TTS(voice=voice)
        elif provider == "cartesia":
            from livekit.plugins import cartesia
            return cartesia.TTS(voice=voice)
        elif provider == "elevenlabs":
            from livekit.plugins import elevenlabs
            return elevenlabs.TTS(voice=voice)
        else:
            # Default to Inworld
            from livekit.plugins import inworld
            return inworld.TTS(voice="Lupita", speaking_rate=1.2)

    async def _run_agent_session(
        self,
        call_id: str,
        room: "rtc.Room",
        session: "AgentSession",
    ) -> None:
        """Run the agent session until disconnected."""
        try:
            # Get agent instructions
            instructions = self.voice_config.get("instructions", "")
            if not instructions and hasattr(self.agent, "instructions"):
                instructions = self.agent.instructions or ""

            # Create a simple agent wrapper for the session
            from livekit.agents import Agent

            class VoiceAgent(Agent):
                def __init__(self, instructions: str):
                    super().__init__(instructions=instructions)

            voice_agent = VoiceAgent(instructions)

            # Start the session
            await session.start(agent=voice_agent, room=room)

            self.logger.info(f"Agent session started for call {call_id}")

            # Wait for disconnect
            @room.on("disconnected")
            async def on_disconnect():
                self.logger.info(f"Room disconnected for call {call_id}")
                if call_id in self._active_sessions:
                    del self._active_sessions[call_id]

        except Exception as e:
            self.logger.exception(f"Error in agent session for call {call_id}: {e}")
            if call_id in self._active_sessions:
                del self._active_sessions[call_id]

    async def disconnect_from_room(self, call_id: str) -> bool:
        """Disconnect agent from a room.

        Args:
            call_id: Call ID

        Returns:
            True if disconnected
        """
        if call_id not in self._active_sessions:
            return False

        try:
            session_info = self._active_sessions[call_id]
            room = session_info.get("room")

            if room:
                await room.disconnect()

            del self._active_sessions[call_id]
            self.logger.info(f"Agent disconnected from room for call {call_id}")
            return True

        except Exception as e:
            self.logger.error(f"Error disconnecting agent: {e}")
            return False


class WhatsAppVoiceBridge:
    """Handles WhatsApp voice call WebRTC bridging to LiveKit agents.

    Manages WebRTC peer connections, SDP negotiation, and audio forwarding.
    When a call connects, this bridge:
    1. Delegates SDP negotiation to the Go bridge
    2. Sends pre_accept/accept to WhatsApp
    3. Starts a LiveKit agent that joins the room to process audio
    """

    def __init__(
        self,
        agent: Any,
        phone_number_id: Optional[str] = None,
        access_token: Optional[str] = None,
        livekit_url: Optional[str] = None,
        livekit_api_key: Optional[str] = None,
        livekit_api_secret: Optional[str] = None,
        bridge_url: Optional[str] = None,
        voice_config: Optional[Dict[str, Any]] = None,
    ):
        """Initialize voice bridge.

        Args:
            agent: Agent instance for voice processing
            phone_number_id: WhatsApp phone number ID
            access_token: WhatsApp API access token
            livekit_url: LiveKit server URL
            livekit_api_key: LiveKit API key
            livekit_api_secret: LiveKit API secret
            bridge_url: Optional external WhatsApp-LiveKit bridge URL
            voice_config: Optional voice configuration dict
        """
        self.agent = agent
        self.phone_number_id = phone_number_id or os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
        self.access_token = access_token or os.getenv("WHATSAPP_ACCESS_TOKEN", "")
        self.livekit_url = livekit_url or os.getenv("LIVEKIT_URL", "")
        self.livekit_api_key = livekit_api_key or os.getenv("LIVEKIT_API_KEY", "")
        self.livekit_api_secret = livekit_api_secret or os.getenv("LIVEKIT_API_SECRET", "")

        # Optional external WhatsApp-LiveKit bridge (Go implementation)
        self.bridge_url = bridge_url or os.getenv("WHATSAPP_BRIDGE_URL", "")

        # Voice configuration
        self.voice_config = voice_config or {}

        # Create agent connector for LiveKit
        self._agent_connector: Optional[LiveKitAgentConnector] = None
        if self.livekit_url and self.livekit_api_key and self.livekit_api_secret:
            self._agent_connector = LiveKitAgentConnector(
                agent=agent,
                livekit_url=self.livekit_url,
                livekit_api_key=self.livekit_api_key,
                livekit_api_secret=self.livekit_api_secret,
                voice_config=self.voice_config,
            )

        self.active_calls: Dict[str, ActiveCallSession] = {}
        self.logger = logging.getLogger(__name__)

    async def handle_call_connect(self, call_data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle incoming WhatsApp call connection (SDP offer).

        Args:
            call_data: Call event data with SDP offer

        Returns:
            Result dict with SDP answer or error
        """
        call_id = call_data.get("id", "")
        whatsapp_id = call_data.get("from", "")

        if not call_id or not whatsapp_id:
            return {"error": "Missing call_id or whatsapp_id"}

        try:
            # Create LiveKit room for this call
            room_name = f"whatsapp-voice-{call_id[:20].replace('_', '-')}"

            # Create call session
            call_session = ActiveCallSession(
                call_id=call_id,
                whatsapp_id=whatsapp_id,
                livekit_room=room_name,
            )

            # Store SDP offer
            sdp_offer = call_data.get("session", {}).get("sdp")
            call_session.sdp_offer = sdp_offer

            # Establish WebRTC connection and generate answer
            sdp_answer = await self._establish_webrtc_connection(call_session, call_data)

            call_session.sdp_answer = sdp_answer
            self.active_calls[call_id] = call_session

            # Pre-accept call with SDP answer
            await self._whatsapp_call_action("pre_accept", call_id, sdp_answer)

            # Accept call
            await self._whatsapp_call_action("accept", call_id, sdp_answer)

            self.logger.info(f"Call connected: {call_id} from {whatsapp_id}")

            # Start LiveKit agent to process voice in the room
            if self._agent_connector and call_session.livekit_room:
                asyncio.create_task(
                    self._start_livekit_agent(call_id, call_session.livekit_room)
                )

            return {
                "call_id": call_id,
                "sdp_answer": sdp_answer,
                "status": "connected",
            }

        except Exception as e:
            self.logger.exception(f"Failed to handle call connect {call_id}: {e}")
            return {"error": str(e)}

    async def handle_call_terminate(self, call_id: str) -> Dict[str, Any]:
        """Handle call termination.

        Args:
            call_id: Call ID to terminate

        Returns:
            Result dict
        """
        if call_id not in self.active_calls:
            return {"status": "not_found"}

        call_session = self.active_calls[call_id]

        try:
            # Stop audio bridge
            if call_session.audio_bridge_task:
                call_session.audio_bridge_task.cancel()
                try:
                    await call_session.audio_bridge_task
                except asyncio.CancelledError:
                    pass

            # Close agent session
            if call_session.agent_session:
                try:
                    await call_session.agent_session.close()
                except Exception as e:
                    self.logger.warning(f"Error closing agent session: {e}")

            # Close WebRTC connection
            if call_session.peer_connection:
                try:
                    await call_session.peer_connection.close()
                except Exception as e:
                    self.logger.warning(f"Error closing peer connection: {e}")

            # Notify external bridge if configured
            if self.bridge_url:
                await self._notify_bridge_terminate(call_id)

            # Disconnect LiveKit agent
            if self._agent_connector:
                await self._agent_connector.disconnect_from_room(call_id)

            # Cleanup
            del self.active_calls[call_id]

            self.logger.info(f"Call terminated: {call_id}")
            return {"status": "terminated"}

        except Exception as e:
            self.logger.exception(f"Error terminating call {call_id}: {e}")
            return {"error": str(e)}

    async def _establish_webrtc_connection(
        self,
        call_session: ActiveCallSession,
        call_data: Dict[str, Any],
    ) -> str:
        """Establish WebRTC peer connection with WhatsApp's SDP offer.

        Args:
            call_session: Active call session
            call_data: Call data with SDP offer

        Returns:
            SDP answer string
        """
        whatsapp_offer = call_data.get("session", {}).get("sdp")
        if not whatsapp_offer:
            raise ValueError("Missing SDP offer from WhatsApp")

        # If external bridge is configured, delegate SDP negotiation
        if self.bridge_url:
            return await self._get_answer_from_bridge(call_session, call_data, whatsapp_offer)

        # Try local WebRTC via LiveKit
        try:
            from livekit import rtc

            # Check if WebRTC primitives are available
            if not all(
                hasattr(rtc, name)
                for name in ["RtcConfiguration", "IceServer", "PeerConnection", "SessionDescription"]
            ):
                raise ImportError("LiveKit rtc WebRTC primitives not available")

            # Create WebRTC peer connection
            config = rtc.RtcConfiguration(
                ice_servers=[rtc.IceServer(urls=["stun:stun.l.google.com:19302"])]
            )

            pc = rtc.PeerConnection(configuration=config)
            call_session.peer_connection = pc

            # Handle ICE connection state changes
            @pc.on("iceconnectionstatechange")
            async def on_ice_state_change():
                state = pc.iceConnectionState
                self.logger.info(f"ICE connection state: {state}")
                call_session.update_ice_state(state)

            # Set remote description (WhatsApp's offer)
            offer = rtc.SessionDescription(sdp=whatsapp_offer, type="offer")
            await pc.set_remote_description(offer)

            # Create answer
            answer = await pc.create_answer()
            await pc.set_local_description(answer)

            local_desc = pc.local_description
            return local_desc.sdp if local_desc else ""

        except ImportError:
            self.logger.warning("LiveKit RTC not available, using mock SDP answer")
            return self._create_mock_sdp_answer(whatsapp_offer)

    async def _get_answer_from_bridge(
        self,
        call_session: ActiveCallSession,
        call_data: Dict[str, Any],
        offer_sdp: str,
    ) -> str:
        """Get SDP answer from external WhatsApp-LiveKit bridge.

        Args:
            call_session: Active call session
            call_data: Call data
            offer_sdp: SDP offer from WhatsApp

        Returns:
            SDP answer string
        """
        payload = {
            "call_id": call_session.call_id,
            "from_number": call_session.whatsapp_id,
            "to_number": self.phone_number_id,
            "offer_sdp": offer_sdp,
            "sdp_type": "offer",
            "direction": call_data.get("direction", "inbound"),
        }

        url = self.bridge_url.rstrip("/") + "/whatsapp/create-answer"

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()
            data = response.json()

        sdp_answer = data.get("sdp") or data.get("answer_sdp")
        if not sdp_answer:
            raise ValueError("Bridge response missing SDP answer")

        # Store room info if provided
        room_name = data.get("room_name")
        if room_name:
            call_session.livekit_room = room_name

        self.logger.info(f"Received SDP answer from bridge for call {call_session.call_id}")
        return sdp_answer

    def _create_mock_sdp_answer(self, offer: str) -> str:
        """Create mock SDP answer for testing.

        Args:
            offer: SDP offer string

        Returns:
            Mock SDP answer
        """
        return """v=0
o=- 0 0 IN IP4 127.0.0.1
s=-
t=0 0
m=audio 9 UDP/TLS/RTP/SAVPF 111
c=IN IP4 0.0.0.0
a=rtcp:9 IN IP4 0.0.0.0
a=ice-ufrag:mock
a=ice-pwd:mockmockmockmockmock
a=fingerprint:sha-256 00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00
a=setup:active
a=mid:0
a=recvonly
a=rtpmap:111 opus/48000/2
"""

    async def _whatsapp_call_action(
        self,
        action: str,
        call_id: str,
        sdp_answer: Optional[str] = None,
    ) -> None:
        """Make WhatsApp Calling API request.

        Args:
            action: API action (pre_accept, accept, terminate)
            call_id: Call ID
            sdp_answer: SDP answer (for pre_accept/accept)
        """
        if not self.phone_number_id or not self.access_token:
            self.logger.warning("WhatsApp credentials not configured for call action")
            return

        url = f"{GRAPH_API_BASE}/{self.phone_number_id}/calls"
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
        }

        payload: Dict[str, Any] = {
            "messaging_product": "whatsapp",
            "call_id": call_id,
            "action": action,
        }

        # Include SDP answer for pre_accept/accept
        if action in ("pre_accept", "accept") and sdp_answer:
            payload["session"] = {
                "sdp_type": "answer",
                "sdp": sdp_answer,
            }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                self.logger.info(f"WhatsApp {action} action succeeded for call {call_id}")

        except httpx.HTTPStatusError as e:
            self.logger.error(f"WhatsApp {action} failed for call {call_id}: {e}")
        except Exception as e:
            self.logger.exception(f"Error in WhatsApp {action} for call {call_id}: {e}")

    async def _notify_bridge_terminate(self, call_id: str) -> None:
        """Notify external bridge of call termination."""
        if not self.bridge_url:
            return

        try:
            url = self.bridge_url.rstrip("/") + "/whatsapp/terminate-call"
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(url, json={"call_id": call_id})
                response.raise_for_status()
            self.logger.info(f"Notified bridge of call termination: {call_id}")
        except Exception as e:
            self.logger.error(f"Error notifying bridge: {e}")

    async def _start_livekit_agent(
        self,
        call_id: str,
        room_name: str,
    ) -> None:
        """Start a LiveKit agent to process voice in the room.

        Args:
            call_id: Call ID
            room_name: LiveKit room name
        """
        if not self._agent_connector:
            self.logger.warning(
                f"Cannot start LiveKit agent for call {call_id}: "
                "Agent connector not initialized (missing LiveKit credentials)"
            )
            return

        try:
            success = await self._agent_connector.connect_agent_to_room(
                room_name=room_name,
                call_id=call_id,
                participant_identity=f"agent-{call_id[:8]}",
            )

            if success:
                self.logger.info(
                    f"LiveKit agent started for call {call_id} in room {room_name}"
                )
            else:
                self.logger.error(
                    f"Failed to start LiveKit agent for call {call_id}"
                )

        except Exception as e:
            self.logger.exception(
                f"Error starting LiveKit agent for call {call_id}: {e}"
            )

    def get_active_call_count(self) -> int:
        """Get count of active calls."""
        return len(self.active_calls)

    async def cleanup(self) -> None:
        """Cleanup all resources."""
        for call_id in list(self.active_calls.keys()):
            await self.handle_call_terminate(call_id)
