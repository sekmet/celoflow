"""Generic notification plugin base class.

This module defines the NotificationPlugin abstract base class that provides
a generic interface for sending notifications through any channel (WhatsApp,
email, SMS, push notifications, etc.).

The plugin follows the generic plugin pattern defined in
plugin-system-implementation-patterns-specs.md and works with any agent
context type (Agent[TContext]).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, Optional, Protocol, TypeVar

from agents import Agent

from ..base import AgentPlugin


TContext = TypeVar("TContext")


class HasUserIdProtocol(Protocol):
    """Protocol for contexts that provide user identification."""

    user_id: str


class NotificationPlugin(AgentPlugin[TContext], ABC, Generic[TContext]):
    """Base plugin for sending user notifications.

    This abstraction supports different channels (WhatsApp, email, SMS, push)
    and works with any agent context that provides user identification.

    Type Parameters:
        TContext: The context type used by the agent. Should implement
                  HasUserIdProtocol for user identification.

    Example:
        >>> class EmailNotificationPlugin(NotificationPlugin[MyContext]):
        ...     def send_message(self, user_id, text, **kwargs):
        ...         # Send email
        ...         pass
    """

    @abstractmethod
    def send_message(
        self,
        user_id: str,
        text: str,
        *,
        channel: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Send a notification message to the given user.

        Args:
            user_id: Unique identifier for the recipient.
            text: The message content to send.
            channel: Optional channel override (e.g., "whatsapp", "sms", "email").
            metadata: Optional additional data for the notification.

        Implementations are responsible for applying channel-specific
        behavior (for example, message splitting or formatting).
        """
        ...

    def configure_agent(self, agent: Agent[TContext]) -> Agent[TContext]:
        """Default: no agent modifications for notification plugins.

        Notification plugins typically don't modify the agent configuration.
        They provide side-effect capabilities (sending messages) rather than
        adding tools or guardrails.

        Subclasses can override this to add notification-related tools.

        Args:
            agent: The agent to configure.

        Returns:
            The agent unchanged (default behavior).
        """
        return agent

    async def send_message_async(
        self,
        user_id: str,
        text: str,
        *,
        channel: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Async version of send_message.

        Default implementation calls the sync version. Subclasses can
        override for true async behavior.

        Args:
            user_id: Unique identifier for the recipient.
            text: The message content to send.
            channel: Optional channel override.
            metadata: Optional additional data.
        """
        self.send_message(user_id, text, channel=channel, metadata=metadata)
