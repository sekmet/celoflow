"""WhatsApp API utility functions.

This module provides low-level utilities for interacting with the WhatsApp
Business API, including media handling, typing indicators, and image messages.

All functions use environment variables for configuration:
    - WHATSAPP_ACCESS_TOKEN: API access token
    - WHATSAPP_PHONE_NUMBER_ID: Phone number ID for sending messages
"""

from __future__ import annotations

import logging
import os
from io import BytesIO
from typing import Any, Dict, Optional, Union

import httpx

logger = logging.getLogger(__name__)

# API version
GRAPH_API_VERSION = "v22.0"
GRAPH_API_BASE = f"https://graph.facebook.com/{GRAPH_API_VERSION}"

# WhatsApp message limits
WHATSAPP_MAX_TEXT_LENGTH = 4096  # Maximum characters per text message


def split_message_into_chunks(
    text: str,
    max_length: int = WHATSAPP_MAX_TEXT_LENGTH,
    split_on: str = "\n\n",
) -> list[str]:
    """Split a long message into chunks that fit WhatsApp's character limit.

    Attempts to split on paragraph boundaries first, then sentences,
    then falls back to hard character splits.

    Args:
        text: The text to split.
        max_length: Maximum characters per chunk (default: 4096).
        split_on: Preferred split delimiter (default: paragraph break).

    Returns:
        List of text chunks, each within max_length.
    """
    # Handle empty or whitespace-only text
    text = text.strip()
    if not text:
        return []

    if len(text) <= max_length:
        return [text]

    chunks = []
    remaining = text

    while remaining:
        if len(remaining) <= max_length:
            chunks.append(remaining)
            break

        # Try to find a good break point
        chunk = remaining[:max_length]

        # Try paragraph break first
        break_pos = chunk.rfind(split_on)
        if break_pos == -1 or break_pos < max_length // 2:
            # Try sentence break
            for delimiter in [". ", "! ", "? ", "\n"]:
                pos = chunk.rfind(delimiter)
                if pos > max_length // 2:
                    break_pos = pos + len(delimiter)
                    break

        if break_pos == -1 or break_pos < max_length // 2:
            # Hard split at max_length
            break_pos = max_length

        chunks.append(remaining[:break_pos].strip())
        remaining = remaining[break_pos:].strip()

    return [c for c in chunks if c]  # Filter empty chunks


def get_access_token() -> str:
    """Get WhatsApp access token from environment.

    Returns:
        The WHATSAPP_ACCESS_TOKEN value.

    Raises:
        ValueError: If WHATSAPP_ACCESS_TOKEN is not set.
    """
    access_token = os.getenv("WHATSAPP_ACCESS_TOKEN")
    if not access_token:
        raise ValueError("WHATSAPP_ACCESS_TOKEN is not set")
    return access_token


def get_phone_number_id() -> str:
    """Get WhatsApp phone number ID from environment.

    Returns:
        The WHATSAPP_PHONE_NUMBER_ID value.

    Raises:
        ValueError: If WHATSAPP_PHONE_NUMBER_ID is not set.
    """
    phone_number_id = os.getenv("WHATSAPP_PHONE_NUMBER_ID")
    if not phone_number_id:
        raise ValueError("WHATSAPP_PHONE_NUMBER_ID is not set")
    return phone_number_id


# ============================================================================
# Media Functions
# ============================================================================

def get_media(media_id: str) -> Union[bytes, Dict[str, Any]]:
    """Retrieve media content from WhatsApp.

    Args:
        media_id: The ID of the media to retrieve.

    Returns:
        The media content as bytes, or an error dict on failure.
    """
    url = f"{GRAPH_API_BASE}/{media_id}"
    access_token = get_access_token()
    headers = {"Authorization": f"Bearer {access_token}"}

    try:
        response = httpx.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        media_url = data.get("url")

        if not media_url:
            return {"error": "Media URL not found in response"}

        # Download the actual media
        media_response = httpx.get(media_url, headers=headers)
        media_response.raise_for_status()
        return media_response.content

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to get media: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error getting media: {e}")
        return {"error": str(e)}


async def get_media_async(media_id: str) -> Union[bytes, Dict[str, Any]]:
    """Retrieve media content from WhatsApp (async).

    Args:
        media_id: The ID of the media to retrieve.

    Returns:
        The media content as bytes, or an error dict on failure.
    """
    url = f"{GRAPH_API_BASE}/{media_id}"
    access_token = get_access_token()
    headers = {"Authorization": f"Bearer {access_token}"}

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            media_url = data.get("url")

            if not media_url:
                return {"error": "Media URL not found in response"}

            # Download the actual media
            media_response = await client.get(media_url, headers=headers)
            media_response.raise_for_status()
            return media_response.content

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to get media: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error getting media: {e}")
        return {"error": str(e)}


def upload_media(
    media_data: bytes,
    mime_type: str,
    filename: str = "file",
) -> Union[str, Dict[str, Any]]:
    """Upload media to WhatsApp for sending.

    Args:
        media_data: The media content as bytes.
        mime_type: The MIME type of the media (e.g., "image/png").
        filename: The filename for the upload.

    Returns:
        The media ID string on success, or an error dict on failure.
    """
    phone_number_id = get_phone_number_id()
    url = f"{GRAPH_API_BASE}/{phone_number_id}/media"
    access_token = get_access_token()
    headers = {"Authorization": f"Bearer {access_token}"}

    data = {"messaging_product": "whatsapp", "type": mime_type}
    file_data = BytesIO(media_data)
    files = {"file": (filename, file_data, mime_type)}

    try:
        response = httpx.post(url, headers=headers, data=data, files=files)
        response.raise_for_status()
        json_resp = response.json()
        media_id = json_resp.get("id")

        if not media_id:
            return {"error": "Media ID not found in response", "response": json_resp}
        return media_id

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to upload media: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error uploading media: {e}")
        return {"error": str(e)}


async def upload_media_async(
    media_data: bytes,
    mime_type: str,
    filename: str = "file",
) -> Union[str, Dict[str, Any]]:
    """Upload media to WhatsApp for sending (async).

    Args:
        media_data: The media content as bytes.
        mime_type: The MIME type of the media (e.g., "image/png").
        filename: The filename for the upload.

    Returns:
        The media ID string on success, or an error dict on failure.
    """
    phone_number_id = get_phone_number_id()
    url = f"{GRAPH_API_BASE}/{phone_number_id}/media"
    access_token = get_access_token()
    headers = {"Authorization": f"Bearer {access_token}"}

    data = {"messaging_product": "whatsapp", "type": mime_type}
    file_data = BytesIO(media_data)
    files = {"file": (filename, file_data, mime_type)}

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(url, headers=headers, data=data, files=files)
            response.raise_for_status()
            json_resp = response.json()
            media_id = json_resp.get("id")

            if not media_id:
                return {"error": "Media ID not found in response", "response": json_resp}
            return media_id

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to upload media: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error uploading media: {e}")
        return {"error": str(e)}


# ============================================================================
# Typing Indicator
# ============================================================================

def typing_indicator(message_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Send a typing indicator and mark message as read.

    This shows the user that the bot is "typing" and marks their
    message as read.

    Args:
        message_id: The ID of the message to mark as read.
            If None, does nothing.

    Returns:
        None on success, or an error dict on failure.
    """
    if not message_id:
        return None

    phone_number_id = get_phone_number_id()
    url = f"{GRAPH_API_BASE}/{phone_number_id}/messages"
    access_token = get_access_token()
    headers = {"Authorization": f"Bearer {access_token}"}

    data = {
        "messaging_product": "whatsapp",
        "status": "read",
        "message_id": message_id,
        "typing_indicator": {"type": "text"},
    }

    try:
        response = httpx.post(url, headers=headers, data=data)
        response.raise_for_status()
        return None

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send typing indicator: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending typing indicator: {e}")
        return {"error": str(e)}


async def typing_indicator_async(message_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Send a typing indicator and mark message as read (async).

    This shows the user that the bot is "typing" and marks their
    message as read.

    Args:
        message_id: The ID of the message to mark as read.
            If None, does nothing.

    Returns:
        None on success, or an error dict on failure.
    """
    if not message_id:
        return None

    phone_number_id = get_phone_number_id()
    url = f"{GRAPH_API_BASE}/{phone_number_id}/messages"
    access_token = get_access_token()
    headers = {"Authorization": f"Bearer {access_token}"}

    data = {
        "messaging_product": "whatsapp",
        "status": "read",
        "message_id": message_id,
        "typing_indicator": {"type": "text"},
    }

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(url, headers=headers, data=data)
            response.raise_for_status()
            return None

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send typing indicator: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending typing indicator: {e}")
        return {"error": str(e)}


# ============================================================================
# Image Messages
# ============================================================================

def send_image_message(
    media_id: str,
    recipient: str,
    caption: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Send an image message to a WhatsApp user.

    Args:
        media_id: The media ID of the uploaded image.
        recipient: Recipient's phone number (e.g., "+5491155551234").
        caption: Optional caption for the image.

    Returns:
        None on success, or an error dict on failure.
    """
    phone_number_id = get_phone_number_id()
    url = f"{GRAPH_API_BASE}/{phone_number_id}/messages"
    access_token = get_access_token()
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    data = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": recipient,
        "type": "image",
        "image": {"id": media_id},
    }

    if caption:
        data["image"]["caption"] = caption

    try:
        response = httpx.post(url, headers=headers, json=data)
        response.raise_for_status()
        logger.debug(f"Image message sent to {recipient}")
        return None

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send image message: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending image message: {e}")
        return {"error": str(e)}


async def send_image_message_async(
    media_id: str,
    recipient: str,
    caption: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Send an image message to a WhatsApp user (async).

    Args:
        media_id: The media ID of the uploaded image.
        recipient: Recipient's phone number (e.g., "+5491155551234").
        caption: Optional caption for the image.

    Returns:
        None on success, or an error dict on failure.
    """
    phone_number_id = get_phone_number_id()
    url = f"{GRAPH_API_BASE}/{phone_number_id}/messages"
    access_token = get_access_token()
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    data = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": recipient,
        "type": "image",
        "image": {"id": media_id},
    }

    if caption:
        data["image"]["caption"] = caption

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(url, headers=headers, json=data)
            response.raise_for_status()
            logger.debug(f"Image message sent to {recipient}")
            return None

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send image message: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending image message: {e}")
        return {"error": str(e)}


# ============================================================================
# Text Messages
# ============================================================================

def send_text_message(
    recipient: str,
    text: str,
) -> Optional[Dict[str, Any]]:
    """Send a text message to a WhatsApp user.

    Args:
        recipient: Recipient's phone number (e.g., "+5491155551234").
        text: The message text to send.

    Returns:
        None on success, or an error dict on failure.
    """
    phone_number_id = get_phone_number_id()
    url = f"{GRAPH_API_BASE}/{phone_number_id}/messages"
    access_token = get_access_token()
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    data = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": recipient,
        "type": "text",
        "text": {"body": text},
    }

    try:
        response = httpx.post(url, headers=headers, json=data)
        response.raise_for_status()
        logger.debug(f"Text message sent to {recipient}")
        return None

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send text message: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending text message: {e}")
        return {"error": str(e)}


async def send_text_message_async(
    recipient: str,
    text: str,
) -> Optional[Dict[str, Any]]:
    """Send a text message to a WhatsApp user (async).

    Automatically splits long messages into chunks if they exceed
    WhatsApp's 4096 character limit.

    Args:
        recipient: Recipient's phone number (e.g., "+5491155551234").
        text: The message text to send.

    Returns:
        None on success, or an error dict on failure.
    """
    # Split long messages into chunks
    chunks = split_message_into_chunks(text)

    phone_number_id = get_phone_number_id()
    url = f"{GRAPH_API_BASE}/{phone_number_id}/messages"
    access_token = get_access_token()
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient() as client:
            for i, chunk in enumerate(chunks):
                data = {
                    "messaging_product": "whatsapp",
                    "recipient_type": "individual",
                    "to": recipient,
                    "type": "text",
                    "text": {"body": chunk},
                }

                response = await client.post(url, headers=headers, json=data)
                response.raise_for_status()

                if len(chunks) > 1:
                    logger.debug(f"Text message chunk {i+1}/{len(chunks)} sent to {recipient}")
                else:
                    logger.debug(f"Text message sent to {recipient}")

            return None

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send text message: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending text message: {e}")
        return {"error": str(e)}
