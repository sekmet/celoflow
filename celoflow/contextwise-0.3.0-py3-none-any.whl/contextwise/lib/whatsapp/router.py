"""FastAPI router for WhatsApp Business API webhooks.

This module provides a factory function to create FastAPI routers for
handling WhatsApp Business API webhooks. It supports both sync and async
message processing with proper signature validation.

The router integrates utils functions for:
- typing_indicator: Show typing status on message receipt
- get_media: Download media attachments
- upload_media: Upload media for sending
- send_image_message: Send image responses
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional, TYPE_CHECKING

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request
from fastapi.responses import PlainTextResponse

from .security import validate_webhook_signature
from .api_plugin import WhatsAppAPIPlugin
from .utils import (
    typing_indicator,
    typing_indicator_async,
    get_media,
    get_media_async,
    upload_media,
    upload_media_async,
    send_text_message,
    send_text_message_async,
    send_image_message,
    send_image_message_async,
)


if TYPE_CHECKING:
    from agents import Agent, Runner


logger = logging.getLogger(__name__)


def create_whatsapp_router(
    api_plugin: WhatsAppAPIPlugin,
    *,
    message_handler: Optional[Callable[[Dict[str, Any]], None]] = None,
    async_message_handler: Optional[Callable[[Dict[str, Any]], Any]] = None,
    call_handler: Optional[Callable[[Dict[str, Any]], Any]] = None,
    prefix: str = "",
) -> APIRouter:
    """Create a FastAPI router for WhatsApp webhook endpoints.

    The router provides the following endpoints:
        - GET /status: Health check endpoint
        - GET /webhook: Webhook verification endpoint
        - POST /webhook: Message processing endpoint

    Args:
        api_plugin: The WhatsApp API plugin instance with configuration.
        message_handler: Optional sync handler for processing messages.
        async_message_handler: Optional async handler for processing messages.
        call_handler: Optional async handler for processing WhatsApp voice calls.
        prefix: Optional URL prefix for all routes.

    Returns:
        Configured FastAPI APIRouter instance.
    """
    router = APIRouter(prefix=prefix)

    @router.get("/status")
    async def status() -> Dict[str, str]:
        """Health check endpoint."""
        return {"status": "available"}

    @router.get("/webhook")
    async def verify_webhook(request: Request) -> PlainTextResponse:
        """Handle WhatsApp webhook verification."""
        mode = request.query_params.get("hub.mode")
        token = request.query_params.get("hub.verify_token")
        challenge = request.query_params.get("hub.challenge")

        result = api_plugin.validate_webhook(mode, token, challenge)

        if result is not None:
            return PlainTextResponse(content=result)

        raise HTTPException(status_code=403, detail="Invalid verify token or mode")

    @router.post("/webhook")
    async def webhook(request: Request, background_tasks: BackgroundTasks) -> Dict[str, str]:
        """Handle incoming WhatsApp messages with typing indicator."""
        try:
            payload = await request.body()
            signature = request.headers.get("X-Hub-Signature-256")

            if not validate_webhook_signature(payload, signature):
                logger.warning("Invalid webhook signature")
                raise HTTPException(status_code=403, detail="Invalid signature")

            body = await request.json()
            parsed = api_plugin.parse_webhook_message(body)

            if parsed is None:
                # Check if this is a call webhook instead of a message
                if hasattr(api_plugin, 'parse_webhook_call'):
                    call_data = api_plugin.parse_webhook_call(body)
                    if call_data:
                        logger.info(
                            f"Received WhatsApp call event: {call_data.get('event')}",
                            extra={
                                "from": call_data.get("from"),
                                "event": call_data.get("event"),
                                "direction": call_data.get("direction"),
                            },
                        )
                        # Process call if handler is available
                        if call_handler:
                            background_tasks.add_task(call_handler, call_data)
                        return {"status": "call_received"}
                return {"status": "ignored"}

            # Send typing indicator when message is received
            message_id = parsed.get("id")
            if message_id:
                try:
                    await typing_indicator_async(message_id)
                except Exception as e:
                    logger.warning(f"Failed to send typing indicator: {e}")

            # Process message
            if async_message_handler:
                background_tasks.add_task(async_message_handler, parsed)
            elif message_handler:
                background_tasks.add_task(message_handler, parsed)
            else:
                logger.info(
                    "Received WhatsApp message",
                    extra={
                        "from": parsed.get("from"),
                        "type": parsed.get("type"),
                        "content": parsed.get("content", "")[:100],
                    },
                )

            return {"status": "processing"}

        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Error processing webhook")
            raise HTTPException(status_code=500, detail=str(e))

    return router


def create_agent_message_handler(
    agent: "Agent",
    notification_plugin: Optional[Any] = None,
    *,
    use_typing_indicator: bool = True,
) -> Callable[[Dict[str, Any]], None]:
    """Create a message handler that runs the agent and sends response.

    This handler integrates:
        - typing_indicator: Shows typing before processing
        - get_media: Downloads media attachments
        - send_text_message: Sends text responses directly via API

    Args:
        agent: The OpenAI Agents SDK agent to run.
        notification_plugin: Plugin for sending responses (uses send_text_message if None).
        use_typing_indicator: Whether to show typing indicator (default: True).

    Returns:
        Message handler function.
    """
    from agents import Runner

    def handler(message: Dict[str, Any]) -> None:
        phone_number = message.get("from", "")
        content = message.get("content", "")
        message_id = message.get("id")
        message_type = message.get("type", "text")

        try:
            # Show typing indicator
            if use_typing_indicator and message_id:
                try:
                    typing_indicator(message_id)
                except Exception as e:
                    logger.warning(f"Typing indicator failed: {e}")

            # Handle media messages
            media_content = None
            if message_type in ("image", "video", "audio", "document"):
                raw = message.get("raw", {})
                media_id = raw.get(message_type, {}).get("id")
                if media_id:
                    try:
                        media_content = get_media(media_id)
                        if isinstance(media_content, dict) and "error" in media_content:
                            logger.warning(f"Failed to get media: {media_content}")
                            media_content = None
                    except Exception as e:
                        logger.warning(f"Failed to download media: {e}")

            # Run the agent
            result = Runner.run_sync(
                starting_agent=agent,
                input=content,
            )

            # Send response
            response_text = str(result.final_output) if result.final_output else ""

            if response_text:
                if notification_plugin:
                    notification_plugin.send_message(
                        user_id=phone_number,
                        text=response_text,
                        channel="whatsapp",
                    )
                else:
                    # Use direct API call
                    error = send_text_message(phone_number, response_text)
                    if error:
                        logger.error(f"Failed to send message: {error}")

        except Exception:
            logger.exception("Error processing message")
            # Send error message
            error_msg = "Sorry, there was an error processing your message."
            try:
                if notification_plugin:
                    notification_plugin.send_message(
                        user_id=phone_number,
                        text=error_msg,
                        channel="whatsapp",
                    )
                else:
                    send_text_message(phone_number, error_msg)
            except Exception:
                logger.exception("Failed to send error message")

    return handler


async def create_agent_message_handler_async(
    agent: "Agent",
    notification_plugin: Optional[Any] = None,
    *,
    use_typing_indicator: bool = True,
) -> Callable[[Dict[str, Any]], Any]:
    """Create an async message handler that runs the agent and sends response.

    This handler integrates:
        - typing_indicator_async: Shows typing before processing
        - get_media_async: Downloads media attachments
        - send_text_message_async: Sends text responses directly via API

    Args:
        agent: The OpenAI Agents SDK agent to run.
        notification_plugin: Plugin for sending responses.
        use_typing_indicator: Whether to show typing indicator (default: True).

    Returns:
        Async message handler function.
    """
    from agents import Runner

    async def handler(message: Dict[str, Any]) -> None:
        phone_number = message.get("from", "")
        content = message.get("content", "")
        message_id = message.get("id")
        message_type = message.get("type", "text")

        try:
            # Show typing indicator
            if use_typing_indicator and message_id:
                try:
                    await typing_indicator_async(message_id)
                except Exception as e:
                    logger.warning(f"Typing indicator failed: {e}")

            # Handle media messages
            media_content = None
            if message_type in ("image", "video", "audio", "document"):
                raw = message.get("raw", {})
                media_id = raw.get(message_type, {}).get("id")
                if media_id:
                    try:
                        media_content = await get_media_async(media_id)
                        if isinstance(media_content, dict) and "error" in media_content:
                            logger.warning(f"Failed to get media: {media_content}")
                            media_content = None
                    except Exception as e:
                        logger.warning(f"Failed to download media: {e}")

            # Run the agent
            result = await Runner.run(
                starting_agent=agent,
                input=content,
            )

            # Send response
            response_text = str(result.final_output) if result.final_output else ""

            if response_text:
                if notification_plugin:
                    await notification_plugin.send_message_async(
                        user_id=phone_number,
                        text=response_text,
                        channel="whatsapp",
                    )
                else:
                    # Use direct API call
                    error = await send_text_message_async(phone_number, response_text)
                    if error:
                        logger.error(f"Failed to send message: {error}")

        except Exception:
            logger.exception("Error processing message")
            # Send error message
            error_msg = "Sorry, there was an error processing your message."
            try:
                if notification_plugin:
                    notification_plugin.send_message(
                        user_id=phone_number,
                        text=error_msg,
                        channel="whatsapp",
                    )
                else:
                    await send_text_message_async(phone_number, error_msg)
            except Exception:
                logger.exception("Failed to send error message")

    return handler


def create_media_message_handler(
    agent: "Agent",
    notification_plugin: Optional[Any] = None,
) -> Callable[[Dict[str, Any]], None]:
    """Create a message handler with full media support.

    This handler supports:
        - Media downloads (images, videos, audio, documents)
        - Image response generation and upload
        - Typing indicators

    Args:
        agent: The OpenAI Agents SDK agent to run.
        notification_plugin: Plugin for sending responses.

    Returns:
        Message handler function with media support.
    """
    from agents import Runner
    import base64

    def handler(message: Dict[str, Any]) -> None:
        phone_number = message.get("from", "")
        content = message.get("content", "")
        message_id = message.get("id")
        message_type = message.get("type", "text")

        try:
            # Show typing indicator
            if message_id:
                typing_indicator(message_id)

            # Download media if present
            media_bytes = None
            if message_type in ("image", "video", "audio", "document"):
                raw = message.get("raw", {})
                media_id = raw.get(message_type, {}).get("id")
                if media_id:
                    media_result = get_media(media_id)
                    if isinstance(media_result, bytes):
                        media_bytes = media_result

            # Run agent
            result = Runner.run_sync(
                starting_agent=agent,
                input=content,
            )

            response_text = str(result.final_output) if result.final_output else ""

            # Check if result contains images (for agents that generate images)
            images = getattr(result, "images", None)
            if images:
                for img in images:
                    img_content = getattr(img, "content", None)
                    if img_content:
                        # Convert to bytes if needed
                        if isinstance(img_content, str):
                            img_bytes = base64.b64decode(img_content)
                        elif isinstance(img_content, bytes):
                            try:
                                img_bytes = base64.b64decode(img_content.decode("utf-8"))
                            except (UnicodeDecodeError, ValueError):
                                img_bytes = img_content
                        else:
                            continue

                        # Upload and send image
                        media_id = upload_media(img_bytes, "image/png", "image.png")
                        if isinstance(media_id, str):
                            send_image_message(media_id, phone_number, response_text)
                            return  # Image sent with caption
            
            # Send text response
            if response_text:
                if notification_plugin:
                    notification_plugin.send_message(
                        user_id=phone_number,
                        text=response_text,
                        channel="whatsapp",
                    )
                else:
                    send_text_message(phone_number, response_text)

        except Exception:
            logger.exception("Error processing message")
            try:
                send_text_message(
                    phone_number,
                    "Sorry, there was an error processing your message.",
                )
            except Exception:
                logger.exception("Failed to send error message")

    return handler
