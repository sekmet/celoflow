"""WhatsApp Business API plugin implementation.

This module provides the WhatsAppAPIPlugin class for integrating with
the WhatsApp Business API, including webhook handling, message processing,
and tool integration with the OpenAI Agents SDK.

The plugin follows the generic plugin pattern and works with any agent
context type (Agent[TContext]).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Generic, List, Optional, TypeVar

from agents import Agent, Tool, function_tool, RunContextWrapper

from ..base import AgentPlugin
from .whatsapp_plugin import WhatsAppNotificationPlugin


TContext = TypeVar("TContext")

logger = logging.getLogger(__name__)


@dataclass
class WhatsAppAPIPlugin(AgentPlugin[TContext], Generic[TContext]):
    """Plugin that provides WhatsApp Business API integration.

    This plugin integrates with the WhatsApp Business API for:
        - Receiving incoming messages via webhook
        - Processing text, image, video, audio, document messages
        - Sending responses back via WhatsApp
        - Adding WhatsApp tools to the agent

    Type Parameters:
        TContext: The context type used by the agent.

    Attributes:
        id: Plugin identifier for dependency management.
        name: Human-readable plugin name.
        version: Plugin version string.
        verify_token: Webhook verification token.
        app_secret: App secret for signature validation.
        phone_number_id: WhatsApp phone number ID.
        access_token: WhatsApp API access token.
        notification_plugin: Optional notification plugin for sending messages.

    Example:
        >>> notification = WhatsAppNotificationPlugin(send_callable=my_sender)
        >>> api_plugin = WhatsAppAPIPlugin(
        ...     notification_plugin=notification,
        ...     verify_token="my_token",
        ... )
        >>> agent = api_plugin.configure_agent(base_agent)
    """

    # Plugin metadata
    id: str = "whatsapp-api"
    name: str = "WhatsApp Business API Plugin"
    version: str = "1.0.0"

    # Configuration
    verify_token: str = ""
    app_secret: str = ""
    phone_number_id: str = ""
    access_token: str = ""

    # Dependencies
    notification_plugin: Optional[WhatsAppNotificationPlugin[TContext]] = None

    def dependencies(self) -> List[str]:
        """Return plugin ids that must be loaded before this plugin.

        WhatsApp API plugin depends on the notification plugin if provided.

        Returns:
            List of dependency plugin IDs.
        """
        if self.notification_plugin:
            return [self.notification_plugin.id]
        return []

    def configure_agent(self, agent: Agent[TContext]) -> Agent[TContext]:
        """Add WhatsApp tools to the agent.

        Adds the following tools:
            - send_whatsapp_message: Send a text message via WhatsApp
            - send_whatsapp_image: Send an image via WhatsApp (if supported)

        Args:
            agent: The agent to configure.

        Returns:
            A new agent with WhatsApp tools added.
        """
        tools = self._create_tools()
        if not tools:
            return agent
        return agent.clone(tools=[*agent.tools, *tools])

    def _create_tools(self) -> List[Tool]:
        """Create WhatsApp-specific tools.

        Returns:
            List of FunctionTool instances for WhatsApp operations.
        """
        notification_plugin = self.notification_plugin

        @function_tool
        def send_whatsapp_message(
            ctx: RunContextWrapper[TContext],
            recipient: str,
            message: str,
        ) -> str:
            """Send a WhatsApp message to a recipient.

            Use this tool to send text messages to users via WhatsApp.
            The message will be delivered to the recipient's WhatsApp number.

            Args:
                recipient: Phone number in international format (e.g., +5491155551234).
                message: Text message to send. Will be automatically split if too long.

            Returns:
                Confirmation message indicating the message was sent.
            """
            if notification_plugin:
                notification_plugin.send_message(
                    user_id=recipient,
                    text=message,
                    channel="whatsapp",
                    metadata={"source": "agent_tool"},
                )
                return f"Message sent to {recipient}"
            else:
                logger.warning("No notification plugin configured, message not sent")
                return f"Message not sent: no notification plugin configured"

        @function_tool
        def get_whatsapp_user_info(
            ctx: RunContextWrapper[TContext],
        ) -> str:
            """Get information about the current WhatsApp user from context.

            Returns:
                User information string including user_id and channel.
            """
            user_id = getattr(ctx.context, "user_id", "unknown")
            channel = getattr(ctx.context, "channel", "unknown")
            return f"User ID: {user_id}, Channel: {channel}"

        return [send_whatsapp_message, get_whatsapp_user_info]

    def validate_webhook(
        self,
        mode: Optional[str],
        token: Optional[str],
        challenge: Optional[str],
    ) -> Optional[str]:
        """Validate WhatsApp webhook verification request.

        Args:
            mode: The hub.mode query parameter (should be "subscribe").
            token: The hub.verify_token query parameter.
            challenge: The hub.challenge query parameter to echo back.

        Returns:
            The challenge string if validation succeeds, None otherwise.

        Example:
            >>> plugin = WhatsAppAPIPlugin(verify_token="my_token")
            >>> plugin.validate_webhook("subscribe", "my_token", "challenge123")
            'challenge123'
        """
        if mode == "subscribe" and token == self.verify_token:
            return challenge
        return None

    def parse_webhook_message(self, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Parse incoming webhook payload to extract message data.

        Args:
            body: The webhook payload from WhatsApp.

        Returns:
            Parsed message dict with keys: type, content, from, id.
            None if no valid message found.

        Example:
            >>> body = {
            ...     "object": "whatsapp_business_account",
            ...     "entry": [{
            ...         "changes": [{
            ...             "value": {
            ...                 "messages": [{
            ...                     "type": "text",
            ...                     "text": {"body": "Hello"},
            ...                     "from": "12345",
            ...                     "id": "msg123"
            ...                 }]
            ...             }
            ...         }]
            ...     }]
            ... }
            >>> plugin.parse_webhook_message(body)
            {'type': 'text', 'content': 'Hello', 'from': '12345', 'id': 'msg123'}
        """
        if body.get("object") != "whatsapp_business_account":
            return None

        for entry in body.get("entry", []):
            for change in entry.get("changes", []):
                messages = change.get("value", {}).get("messages", [])
                if not messages:
                    continue

                message = messages[0]
                msg_type = message.get("type")
                msg_id = message.get("id")
                msg_from = message.get("from")

                # Extract content based on type
                content = None
                if msg_type == "text":
                    content = message.get("text", {}).get("body")
                elif msg_type == "image":
                    content = message.get("image", {}).get("caption", "Image received")
                elif msg_type == "video":
                    content = message.get("video", {}).get("caption", "Video received")
                elif msg_type == "audio":
                    content = "Audio received"
                elif msg_type == "document":
                    content = "Document received"

                if content is not None:
                    return {
                        "type": msg_type,
                        "content": content,
                        "from": msg_from,
                        "id": msg_id,
                        "raw": message,
                    }

        return None
