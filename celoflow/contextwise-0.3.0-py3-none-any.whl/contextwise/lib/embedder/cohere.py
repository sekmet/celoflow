"""Cohere embedder implementation.

This module provides embedders using Cohere's embedding models,
which are optimized for multilingual and semantic search tasks.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .base import Embedder

logger = logging.getLogger(__name__)

try:
    import cohere
    COHERE_AVAILABLE = True
except ImportError:
    COHERE_AVAILABLE = False


@dataclass
class CohereEmbedder(Embedder):
    """Cohere embeddings API embedder.

    Uses Cohere's embedding models for high-quality text embeddings.
    Cohere models are particularly strong for semantic search and
    support multiple languages.

    Attributes:
        model_name: Name of the Cohere model to use.
        api_key: Cohere API key (or set COHERE_API_KEY env var).
        dimensions: Embedding dimensions (model-specific).
        input_type: Type of input ("search_document", "search_query", "classification", "clustering").
        truncate: How to handle inputs longer than max tokens ("NONE", "START", "END").

    Available Models:
        - embed-english-v3.0: English, 1024-dim, latest model
        - embed-english-light-v3.0: English, 384-dim, faster/cheaper
        - embed-multilingual-v3.0: 100+ languages, 1024-dim
        - embed-multilingual-light-v3.0: 100+ languages, 384-dim, faster
        - embed-english-v2.0: English, 4096-dim (legacy)

    Example:
        >>> from contextwise.lib.embedder import CohereEmbedder
        >>>
        >>> embedder = CohereEmbedder(
        ...     model_name="embed-english-v3.0",
        ...     api_key="your-api-key"
        ... )
        >>>
        >>> # Document embedding
        >>> doc_embedding = embedder.get_embedding(
        ...     "Machine learning is a subset of AI",
        ... )
        >>>
        >>> # Query embedding (for search)
        >>> query_embedder = CohereEmbedder(
        ...     model_name="embed-english-v3.0",
        ...     input_type="search_query"
        ... )
        >>> query_embedding = query_embedder.get_embedding("What is machine learning?")
    """

    model_name: str = "embed-english-v3.0"
    api_key: Optional[str] = None
    dimensions: int = 1024
    input_type: str = "search_document"  # or "search_query", "classification", "clustering"
    truncate: str = "END"  # or "NONE", "START"

    _client: Optional[Any] = field(default=None, repr=False)

    def __post_init__(self):
        """Initialize Cohere client."""
        if not COHERE_AVAILABLE:
            raise ImportError(
                "cohere not installed. Install with: uv add cohere"
            )

        # Get API key from environment if not provided
        if not self.api_key:
            self.api_key = os.getenv("COHERE_API_KEY")

        if not self.api_key:
            raise ValueError(
                "Cohere API key required. Set COHERE_API_KEY environment "
                "variable or pass api_key parameter."
            )

        try:
            self._client = cohere.Client(api_key=self.api_key)
            logger.info(f"Initialized Cohere embedder: {self.model_name}")

        except Exception as e:
            logger.error(f"Failed to initialize Cohere client: {e}")
            raise

    def get_embedding(self, text: str) -> List[float]:
        """Get embedding for a single text.

        Args:
            text: Text to embed.

        Returns:
            Embedding vector as list of floats.
        """
        if not self._client:
            raise RuntimeError("Cohere client not initialized")

        try:
            response = self._client.embed(
                texts=[text],
                model=self.model_name,
                input_type=self.input_type,
                truncate=self.truncate,
            )

            # Return first (and only) embedding
            return response.embeddings[0]

        except Exception as e:
            logger.error(f"Error generating Cohere embedding: {e}")
            raise

    def get_embedding_and_usage(
        self,
        text: str,
    ) -> Tuple[List[float], Optional[Dict[str, Any]]]:
        """Get embedding and usage information.

        Args:
            text: Text to embed.

        Returns:
            Tuple of (embedding, usage_dict).
        """
        if not self._client:
            raise RuntimeError("Cohere client not initialized")

        try:
            response = self._client.embed(
                texts=[text],
                model=self.model_name,
                input_type=self.input_type,
                truncate=self.truncate,
            )

            embedding = response.embeddings[0]

            # Extract usage information
            usage = {
                "model": self.model_name,
                "input_type": self.input_type,
                "billed_units": getattr(response.meta, "billed_units", None),
            }

            return embedding, usage

        except Exception as e:
            logger.error(f"Error generating Cohere embedding: {e}")
            raise

    def get_batch_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Get embeddings for multiple texts efficiently.

        Cohere API supports batch embedding with up to 96 texts per request.

        Args:
            texts: List of texts to embed (max 96 per API call).

        Returns:
            List of embedding vectors.
        """
        if not self._client:
            raise RuntimeError("Cohere client not initialized")

        try:
            # Cohere allows up to 96 texts per request
            batch_size = 96
            all_embeddings = []

            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]

                response = self._client.embed(
                    texts=batch,
                    model=self.model_name,
                    input_type=self.input_type,
                    truncate=self.truncate,
                )

                all_embeddings.extend(response.embeddings)

            return all_embeddings

        except Exception as e:
            logger.error(f"Error generating batch Cohere embeddings: {e}")
            raise


@dataclass
class CohereLightEmbedder(CohereEmbedder):
    """Cohere light embedder (faster, smaller dimensions).

    Convenience class for using Cohere's lightweight models.

    Example:
        >>> embedder = CohereLightEmbedder()  # Uses embed-english-light-v3.0
        >>> embedding = embedder.get_embedding("Quick embedding")
        >>> len(embedding)
        384
    """

    model_name: str = "embed-english-light-v3.0"
    dimensions: int = 384


@dataclass
class CohereMultilingualEmbedder(CohereEmbedder):
    """Cohere multilingual embedder (supports 100+ languages).

    Example:
        >>> embedder = CohereMultilingualEmbedder()
        >>>
        >>> # English
        >>> en_emb = embedder.get_embedding("Hello world")
        >>>
        >>> # Spanish
        >>> es_emb = embedder.get_embedding("Hola mundo")
        >>>
        >>> # Japanese
        >>> ja_emb = embedder.get_embedding("こんにちは世界")
    """

    model_name: str = "embed-multilingual-v3.0"
    dimensions: int = 1024


@dataclass
class CohereQueryEmbedder(CohereEmbedder):
    """Cohere embedder optimized for search queries.

    Use this for embedding search queries, and CohereEmbedder
    (with input_type="search_document") for embedding documents.

    Example:
        >>> # For documents
        >>> doc_embedder = CohereEmbedder(input_type="search_document")
        >>> doc_emb = doc_embedder.get_embedding("Machine learning basics...")
        >>>
        >>> # For queries
        >>> query_embedder = CohereQueryEmbedder()
        >>> query_emb = query_embedder.get_embedding("What is machine learning?")
    """

    input_type: str = "search_query"
