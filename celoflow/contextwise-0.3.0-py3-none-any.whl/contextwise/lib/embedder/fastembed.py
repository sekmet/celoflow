"""FastEmbed embedder implementation for contextwise.

This module provides local embedding capabilities using FastEmbed.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from .base import Embedder

logger = logging.getLogger(__name__)

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

try:
    from fastembed import TextEmbedding
    FASTEMBED_AVAILABLE = True
except ImportError:
    FASTEMBED_AVAILABLE = False


@dataclass
class FastEmbedEmbedder(Embedder):
    """FastEmbed embedder using local models.
    
    This embedder uses FastEmbed for fast, local embedding generation
    without requiring external API calls.
    
    Attributes:
        id: Model identifier (e.g., "BAAI/bge-small-en-v1.5").
        dimensions: Output embedding dimensions.
    
    Example:
        >>> embedder = FastEmbedEmbedder(
        ...     id="BAAI/bge-small-en-v1.5",
        ... )
        >>> embedding = embedder.get_embedding("Hello, world!")
        >>> len(embedding)
        384
    """
    
    id: str = "BAAI/bge-small-en-v1.5"
    dimensions: int = 384
    _model: Optional[Any] = None
    
    def __post_init__(self):
        """Validate dependencies are available."""
        if not NUMPY_AVAILABLE:
            raise ImportError(
                "numpy not installed. Install with: uv add numpy"
            )
        if not FASTEMBED_AVAILABLE:
            raise ImportError(
                "fastembed not installed. Install with: uv add fastembed"
            )
    
    @property
    def model(self) -> "TextEmbedding":
        """Get or create the FastEmbed model."""
        if self._model is None:
            self._model = TextEmbedding(model_name=self.id)
        return self._model
    
    def get_embedding(self, text: str) -> List[float]:
        """Get the embedding vector for text.
        
        Args:
            text: The text to embed.
            
        Returns:
            Embedding vector as list of floats.
        """
        try:
            embeddings = self.model.embed(text)
            embedding_list = list(embeddings)[0]
            
            if isinstance(embedding_list, np.ndarray):
                return embedding_list.tolist()
            
            return list(embedding_list)
        except Exception as e:
            logger.warning(f"Error getting embedding: {e}")
            return []
    
    def get_embedding_and_usage(
        self, 
        text: str,
    ) -> Tuple[List[float], Optional[Dict[str, Any]]]:
        """Get embedding (usage not available for FastEmbed).
        
        Args:
            text: The text to embed.
            
        Returns:
            Tuple of (embedding, None).
        """
        embedding = self.get_embedding(text=text)
        return embedding, None
