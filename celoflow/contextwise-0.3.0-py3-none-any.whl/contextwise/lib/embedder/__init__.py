"""Embedder module for contextwise.

This module provides text embedding capabilities with multiple backend options:

- OpenAIEmbedder: Uses OpenAI's embedding API
- FastEmbedEmbedder: Uses FastEmbed for local embeddings
- HuggingFaceEmbedder: Uses HuggingFace sentence-transformers for local embeddings
- HuggingFaceInferenceEmbedder: Uses HuggingFace Inference API
- CohereEmbedder: Uses Cohere's embedding API
- CohereLightEmbedder: Cohere lightweight model (384-dim)
- CohereMultilingualEmbedder: Cohere multilingual model (100+ languages)
- CohereQueryEmbedder: Cohere model optimized for search queries

Example:
    >>> from contextwise.lib.embedder import OpenAIEmbedder
    >>>
    >>> embedder = OpenAIEmbedder(
    ...     id="text-embedding-3-small",
    ...     api_key="sk-...",
    ... )
    >>> embedding = embedder.get_embedding("Hello, world!")
"""

from .base import Embedder
from .openai import OpenAIEmbedder
from .fastembed import FastEmbedEmbedder
from .huggingface import HuggingFaceEmbedder, HuggingFaceInferenceEmbedder
from .cohere import (
    CohereEmbedder,
    CohereLightEmbedder,
    CohereMultilingualEmbedder,
    CohereQueryEmbedder,
)

__all__ = [
    "Embedder",
    "OpenAIEmbedder",
    "FastEmbedEmbedder",
    "HuggingFaceEmbedder",
    "HuggingFaceInferenceEmbedder",
    "CohereEmbedder",
    "CohereLightEmbedder",
    "CohereMultilingualEmbedder",
    "CohereQueryEmbedder",
]
