"""Base embedder class for contextwise.

This module provides the abstract base class for embedding implementations.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Embedder(ABC):
    """Abstract base class for text embedders.
    
    This class defines the interface for all embedder implementations.
    Embedders convert text into dense vector representations that can be
    used for similarity search, clustering, and other ML tasks.
    
    Attributes:
        dimensions: The dimensionality of the output embeddings.
    
    Example:
        >>> class MyEmbedder(Embedder):
        ...     dimensions = 768
        ...     
        ...     def get_embedding(self, text: str) -> List[float]:
        ...         # Your embedding logic here
        ...         return [0.1, 0.2, ...]
    """
    
    dimensions: Optional[int] = 1536
    
    @abstractmethod
    def get_embedding(self, text: str) -> List[float]:
        """Get the embedding vector for a text.
        
        Args:
            text: The text to embed.
            
        Returns:
            A list of floats representing the embedding vector.
            
        Raises:
            NotImplementedError: If not implemented by subclass.
        """
        raise NotImplementedError
    
    def get_embedding_and_usage(
        self, 
        text: str,
    ) -> Tuple[List[float], Optional[Dict[str, Any]]]:
        """Get the embedding and usage information.
        
        Args:
            text: The text to embed.
            
        Returns:
            A tuple containing:
                - The embedding vector as a list of floats
                - Optional usage/metadata dictionary (tokens used, etc.)
        """
        embedding = self.get_embedding(text)
        return embedding, None
    
    def get_batch_embeddings(
        self, 
        texts: List[str],
    ) -> List[List[float]]:
        """Get embeddings for multiple texts.
        
        Args:
            texts: List of texts to embed.
            
        Returns:
            List of embedding vectors.
        """
        return [self.get_embedding(text) for text in texts]
