"""HuggingFace embedder implementation.

This module provides embedders using HuggingFace's Transformers library
and sentence-transformers for high-quality embeddings.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .base import Embedder

logger = logging.getLogger(__name__)

try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False


@dataclass
class HuggingFaceEmbedder(Embedder):
    """HuggingFace Sentence Transformers embedder.

    Uses the sentence-transformers library to generate embeddings from
    pre-trained models. Supports a wide variety of models optimized for
    different tasks and languages.

    Attributes:
        model_name: Name of the HuggingFace model to use.
        dimensions: Embedding dimensions (auto-detected from model).
        device: Device to run model on ('cpu', 'cuda', 'mps', etc.).
        normalize_embeddings: Whether to L2 normalize embeddings.
        max_seq_length: Maximum sequence length for the model.
        batch_size: Batch size for encoding multiple texts.

    Popular Models:
        - all-MiniLM-L6-v2: Fast, 384-dim, good general purpose (default)
        - all-mpnet-base-v2: High quality, 768-dim, slower but better
        - paraphrase-multilingual-MiniLM-L12-v2: Multilingual, 384-dim
        - all-roberta-large-v1: Very high quality, 1024-dim, slow

    Example:
        >>> from contextwise.lib.embedder import HuggingFaceEmbedder
        >>>
        >>> # Use default model
        >>> embedder = HuggingFaceEmbedder()
        >>> embedding = embedder.get_embedding("Hello world")
        >>> len(embedding)
        384
        >>>
        >>> # Use custom model
        >>> embedder = HuggingFaceEmbedder(
        ...     model_name="all-mpnet-base-v2",
        ...     device="cuda"
        ... )
        >>> embedding = embedder.get_embedding("Machine learning is amazing")
        >>> len(embedding)
        768
    """

    model_name: str = "all-MiniLM-L6-v2"
    dimensions: Optional[int] = None
    device: Optional[str] = None
    normalize_embeddings: bool = True
    max_seq_length: Optional[int] = None
    batch_size: int = 32

    _model: Optional[Any] = field(default=None, repr=False)

    def __post_init__(self):
        """Initialize the HuggingFace model."""
        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            raise ImportError(
                "sentence-transformers not installed. "
                "Install with: uv add sentence-transformers"
            )

        try:
            # Load model
            self._model = SentenceTransformer(
                self.model_name,
                device=self.device
            )

            # Auto-detect dimensions
            if self.dimensions is None:
                self.dimensions = self._model.get_sentence_embedding_dimension()

            # Set max sequence length if specified
            if self.max_seq_length is not None:
                self._model.max_seq_length = self.max_seq_length

            logger.info(
                f"Loaded HuggingFace model: {self.model_name} "
                f"(dims={self.dimensions}, device={self._model.device})"
            )

        except Exception as e:
            logger.error(f"Failed to load HuggingFace model: {e}")
            raise

    def get_embedding(self, text: str) -> List[float]:
        """Get embedding for a single text.

        Args:
            text: Text to embed.

        Returns:
            Embedding vector as list of floats.
        """
        if not self._model:
            raise RuntimeError("Model not initialized")

        try:
            embedding = self._model.encode(
                text,
                normalize_embeddings=self.normalize_embeddings,
                convert_to_numpy=True
            )
            return embedding.tolist()

        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            raise

    def get_batch_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Get embeddings for multiple texts efficiently.

        Args:
            texts: List of texts to embed.

        Returns:
            List of embedding vectors.
        """
        if not self._model:
            raise RuntimeError("Model not initialized")

        try:
            embeddings = self._model.encode(
                texts,
                batch_size=self.batch_size,
                normalize_embeddings=self.normalize_embeddings,
                convert_to_numpy=True,
                show_progress_bar=len(texts) > 100  # Show progress for large batches
            )
            return embeddings.tolist()

        except Exception as e:
            logger.error(f"Error generating batch embeddings: {e}")
            raise


@dataclass
class HuggingFaceInferenceEmbedder(Embedder):
    """HuggingFace Inference API embedder.

    Uses HuggingFace's Inference API for serverless embedding generation.
    Requires a HuggingFace API token.

    Attributes:
        model_name: Name of the HuggingFace model to use.
        api_key: HuggingFace API token (or set HUGGINGFACE_API_KEY env var).
        dimensions: Embedding dimensions.
        api_url: Custom API URL (optional).

    Example:
        >>> import os
        >>> embedder = HuggingFaceInferenceEmbedder(
        ...     model_name="sentence-transformers/all-MiniLM-L6-v2",
        ...     api_key=os.getenv("HUGGINGFACE_API_KEY")
        ... )
        >>> embedding = embedder.get_embedding("Hello world")
    """

    model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    api_key: Optional[str] = None
    dimensions: int = 384
    api_url: Optional[str] = None

    def __post_init__(self):
        """Initialize API key from environment if not provided."""
        import os

        if not self.api_key:
            self.api_key = os.getenv("HUGGINGFACE_API_KEY")

        if not self.api_key:
            raise ValueError(
                "HuggingFace API key required. Set HUGGINGFACE_API_KEY "
                "environment variable or pass api_key parameter."
            )

        # Build API URL if not provided
        if not self.api_url:
            self.api_url = f"https://api-inference.huggingface.co/pipeline/feature-extraction/{self.model_name}"

    def get_embedding(self, text: str) -> List[float]:
        """Get embedding using HuggingFace Inference API.

        Args:
            text: Text to embed.

        Returns:
            Embedding vector as list of floats.
        """
        import httpx

        try:
            headers = {"Authorization": f"Bearer {self.api_key}"}
            payload = {"inputs": text}

            response = httpx.post(
                self.api_url,
                headers=headers,
                json=payload,
                timeout=30.0
            )
            response.raise_for_status()

            # API returns embedding directly
            embedding = response.json()

            # Handle nested response format
            if isinstance(embedding, list):
                if isinstance(embedding[0], list):
                    # Mean pooling if multiple token embeddings returned
                    import numpy as np
                    embedding = np.mean(embedding, axis=0).tolist()
                return embedding
            else:
                raise ValueError(f"Unexpected response format: {type(embedding)}")

        except Exception as e:
            logger.error(f"Error calling HuggingFace API: {e}")
            raise

    def get_batch_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Get embeddings for multiple texts.

        Note: Inference API has rate limits. For large batches,
        consider using HuggingFaceEmbedder with local models instead.

        Args:
            texts: List of texts to embed.

        Returns:
            List of embedding vectors.
        """
        import httpx
        import time

        embeddings = []
        headers = {"Authorization": f"Bearer {self.api_key}"}

        for text in texts:
            try:
                payload = {"inputs": text}
                response = httpx.post(
                    self.api_url,
                    headers=headers,
                    json=payload,
                    timeout=30.0
                )
                response.raise_for_status()

                embedding = response.json()

                # Handle nested response format
                if isinstance(embedding, list):
                    if isinstance(embedding[0], list):
                        import numpy as np
                        embedding = np.mean(embedding, axis=0).tolist()
                    embeddings.append(embedding)
                else:
                    raise ValueError(f"Unexpected response format: {type(embedding)}")

                # Rate limiting
                time.sleep(0.1)

            except Exception as e:
                logger.error(f"Error embedding text: {e}")
                raise

        return embeddings
