"""OpenAI embedder implementation for contextwise.

This module provides OpenAI-based text embedding capabilities.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .base import Embedder

logger = logging.getLogger(__name__)

try:
    from openai import OpenAI as OpenAIClient
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


@dataclass
class OpenAIEmbedder(Embedder):
    """OpenAI embedder using text-embedding models.
    
    This embedder uses OpenAI's embedding API to generate dense vector
    representations of text.
    
    Attributes:
        id: Model identifier (e.g., "text-embedding-3-small").
        dimensions: Output embedding dimensions.
        encoding_format: Format for embeddings ("float" or "base64").
        api_key: OpenAI API key.
        organization: OpenAI organization ID.
        base_url: Custom API base URL.
    
    Example:
        >>> embedder = OpenAIEmbedder(
        ...     id="text-embedding-3-small",
        ...     api_key="sk-...",
        ... )
        >>> embedding = embedder.get_embedding("Hello, world!")
        >>> len(embedding)
        1536
    """
    
    id: str = "text-embedding-3-small"
    dimensions: Optional[int] = None
    encoding_format: str = "float"
    user: Optional[str] = None
    api_key: Optional[str] = None
    organization: Optional[str] = None
    base_url: Optional[str] = None
    request_params: Optional[Dict[str, Any]] = None
    client_params: Optional[Dict[str, Any]] = None
    openai_client: Optional[Any] = None
    
    def __post_init__(self):
        """Set default dimensions based on model."""
        if not OPENAI_AVAILABLE:
            raise ImportError(
                "openai not installed. Install with: uv add openai"
            )
        
        if self.dimensions is None:
            if self.id == "text-embedding-3-large":
                self.dimensions = 3072
            else:
                self.dimensions = 1536
    
    @property
    def client(self) -> "OpenAIClient":
        """Get or create the OpenAI client."""
        if self.openai_client:
            return self.openai_client
        
        _client_params: Dict[str, Any] = {
            "api_key": self.api_key,
            "organization": self.organization,
            "base_url": self.base_url,
        }
        _client_params = {k: v for k, v in _client_params.items() if v is not None}
        
        if self.client_params:
            _client_params.update(self.client_params)
        
        self.openai_client = OpenAIClient(**_client_params)
        return self.openai_client
    
    def _response(self, text: str) -> Any:
        """Get embedding response from OpenAI.
        
        Args:
            text: Text to embed.
            
        Returns:
            OpenAI embedding response.
        """
        _request_params: Dict[str, Any] = {
            "input": text,
            "model": self.id,
            "encoding_format": self.encoding_format,
        }
        
        if self.user is not None:
            _request_params["user"] = self.user
        
        if self.id.startswith("text-embedding-3"):
            _request_params["dimensions"] = self.dimensions
        
        if self.request_params:
            _request_params.update(self.request_params)
        
        return self.client.embeddings.create(**_request_params)
    
    def get_embedding(self, text: str) -> List[float]:
        """Get the embedding vector for text.
        
        Args:
            text: The text to embed.
            
        Returns:
            Embedding vector as list of floats.
        """
        try:
            response = self._response(text=text)
            return response.data[0].embedding
        except Exception as e:
            logger.warning(f"Error getting embedding: {e}")
            return []
    
    def get_embedding_and_usage(
        self, 
        text: str,
    ) -> Tuple[List[float], Optional[Dict[str, Any]]]:
        """Get embedding and usage information.
        
        Args:
            text: The text to embed.
            
        Returns:
            Tuple of (embedding, usage_dict).
        """
        try:
            response = self._response(text=text)
            embedding = response.data[0].embedding
            usage = response.usage
            if usage:
                return embedding, usage.model_dump()
            return embedding, None
        except Exception as e:
            logger.warning(f"Error getting embedding: {e}")
            return [], None
