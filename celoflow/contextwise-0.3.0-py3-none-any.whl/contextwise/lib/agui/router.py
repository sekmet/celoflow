"""AG-UI Router - FastAPI endpoints for AG-UI protocol.

This module provides the AG-UI router for streaming agent/team execution
to rich frontend applications using the AG-UI event protocol.

Endpoints:
    - POST /agui - Main execution endpoint (streaming events)
    - GET /agui/status - Health check and metadata

Usage:
    from fastapi import FastAPI
    from contextwise import Agent
    from contextwise.lib.agui import create_agui_router
    
    app = FastAPI()
    agent = Agent("gpt-4o-mini", "You are helpful")
    app.include_router(create_agui_router(agent), prefix="/agui")
"""

from __future__ import annotations

import json
import logging
import uuid
import asyncio
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union, AsyncGenerator

from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, Field

from .events import (
    EventBuffer,
    RunStartedEvent,
    RunFinishedEvent,
    TextMessageStartEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    ToolCallStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    ErrorEvent,
)
from .utils import (
    convert_agui_messages_to_contextwise_input,
    extract_response_chunk_content,
    create_events_from_chunk,
    create_completion_events,
    format_event_for_sse,
)

if TYPE_CHECKING:
    from ...agent import Agent
    from ...team import Team

logger = logging.getLogger(__name__)


# =============================================================================
# Pydantic Models
# =============================================================================

class AGUIMessage(BaseModel):
    """AG-UI message format."""
    role: str
    content: Union[str, List[Dict[str, Any]]]
    name: Optional[str] = None
    tool_call_id: Optional[str] = None


class AGUIRequest(BaseModel):
    """AG-UI request format for the /agui endpoint.
    
    Attributes:
        messages: Conversation history and current message
        thread_id: Optional conversation thread identifier
        agent_id: Optional agent identifier (for multi-agent scenarios)
        team_id: Optional team identifier (for team execution)
        stream: Whether to stream events (default: true)
        config: Optional configuration overrides
    """
    messages: List[AGUIMessage] = Field(default_factory=list)
    thread_id: Optional[str] = None
    agent_id: Optional[str] = None
    team_id: Optional[str] = None
    stream: bool = True
    config: Dict[str, Any] = Field(default_factory=dict)

class AGUIStatusResponse(BaseModel):
    """Response for /agui/status endpoint."""
    protocol: str = "agui"
    protocol_version: int = 1
    status: str = "running"
    agent_name: str = ""
    agent_description: str = ""
    version: str = "0.2.0"
    features: Dict[str, bool] = Field(default_factory=dict)


# =============================================================================
# Router Factory
# =============================================================================

def create_agui_status_response(agent: "Agent", team: Optional["Team"] = None) -> AGUIStatusResponse:
    """Create AG-UI status response data.
    
    Args:
        agent: Agent instance
        team: Optional Team instance
        
    Returns:
        AGUIStatusResponse with agent metadata
    """
    return AGUIStatusResponse(
        protocol="agui",
        protocol_version=1,
        status="running",
        agent_name=agent.name,
        agent_description=agent.description or "",
        version="0.2.0",
        features={
            "voice": agent.voice is not None,
            "memory": agent.memory is not None,
            "mcp": len(agent.mcp) > 0 if agent.mcp else False,
            "knowledge": agent.knowledge is not None,
            "storage": agent.storage is not None,
            "team": team is not None,
        },
    )


def create_agui_status_endpoint(agent: "Agent", team: Optional["Team"] = None):
    """Create a standalone AG-UI status endpoint handler.
    
    This can be mounted at /status at the root level for standardized
    status endpoint access when enable_agui=True.
    
    Args:
        agent: Agent instance
        team: Optional Team instance
        
    Returns:
        Async function that returns AG-UI status with proper headers
    """
    async def agui_status() -> Response:
        """Get AG-UI endpoint status and agent metadata.
        
        Returns AG-UI status response with X-AGUI-Protocol header for
        wire-level auto-detection.
        """
        status_data = create_agui_status_response(agent, team)
        return JSONResponse(
            content=status_data.model_dump(),
            headers={"X-AGUI-Protocol": "1"},
        )
    
    return agui_status


def create_agui_router(
    agent: "Agent",
    team: Optional["Team"] = None,
    include_status: bool = True,
) -> APIRouter:
    """Create a FastAPI router with AG-UI endpoints.
    
    Args:
        agent: Agent instance for execution
        team: Optional Team instance for team-based execution
        include_status: Whether to include /status endpoint in router (default: True)
            Set to False when mounting status at root /status separately.
        
    Returns:
        Configured APIRouter with AG-UI endpoints
    """
    router = APIRouter(tags=["AG-UI"])
    
    # Conditionally include /status endpoint in the router
    # When include_status=False, the status endpoint should be mounted at /status root level
    if include_status:
        @router.get("/status")
        async def agui_status() -> Response:
            """Get AG-UI endpoint status and agent metadata.
            
            Returns AG-UI status response with X-AGUI-Protocol header for
            wire-level auto-detection.
            """
            status_data = create_agui_status_response(agent, team)
            return JSONResponse(
                content=status_data.model_dump(),
                headers={"X-AGUI-Protocol": "1"},
            )
    
    @router.post("")
    async def agui_execute(request: AGUIRequest):
        """Execute agent/team and stream AG-UI events.
        
        This is the main AG-UI endpoint. It accepts conversation messages,
        executes the agent or team, and streams events back to the client.
        
        The response is a Server-Sent Events (SSE) stream of AG-UI events.
        """
        try:
            # Convert messages to Contextwise input
            messages_dicts = [msg.model_dump() for msg in request.messages]
            user_message, history = convert_agui_messages_to_contextwise_input(
                messages_dicts
            )
            
            if not user_message:
                raise HTTPException(
                    status_code=400,
                    detail="No user message found in messages list"
                )
            
            # Generate run ID
            run_id = str(uuid.uuid4())
            
            # Stream events
            if request.stream:
                return StreamingResponse(
                    _stream_agui_events(
                        agent=agent,
                        team=team if request.team_id else None,
                        user_message=user_message,
                        run_id=run_id,
                        thread_id=request.thread_id,
                        config=request.config,
                    ),
                    media_type="text/event-stream",
                    headers={
                        "Cache-Control": "no-cache",
                        "Connection": "keep-alive",
                        "X-Accel-Buffering": "no",
                        "X-AGUI-Protocol": "1",
                    },
                )
            else:
                # Non-streaming mode: return all events at once with AG-UI envelope
                events = await _collect_agui_events(
                    agent=agent,
                    team=team if request.team_id else None,
                    user_message=user_message,
                    run_id=run_id,
                    thread_id=request.thread_id,
                    config=request.config,
                )
                return {
                    "protocol": "agui",
                    "version": 1,
                    "events": [e.to_dict() for e in events],
                }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("AG-UI execution error")
            raise HTTPException(status_code=500, detail=str(e))
    
    return router


async def _stream_agui_events(
    agent: "Agent",
    team: Optional["Team"],
    user_message: str,
    run_id: str,
    thread_id: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
) -> AsyncGenerator[str, None]:
    """Stream AG-UI events for agent/team execution.
    
    Yields SSE-formatted events for each stage of execution:
    1. RUN_STARTED
    2. TEXT_MESSAGE_START
    3. TEXT_MESSAGE_CONTENT (streaming chunks)
    4. TOOL_CALL_* events (if tools are used)
    5. TEXT_MESSAGE_END
    6. RUN_FINISHED
    
    Args:
        agent: Agent to execute
        team: Optional team to execute (instead of agent)
        user_message: User input message
        run_id: Unique run identifier
        thread_id: Optional thread/conversation ID
        config: Optional configuration overrides
        
    Yields:
        SSE-formatted event strings
    """
    event_buffer = EventBuffer()
    message_id = str(uuid.uuid4())
    final_output = ""
    text_content_emitted = False
    
    # Track active tool calls for proper event sequencing
    active_tool_calls: Dict[str, str] = {}  # tool_call_id -> tool_name
    
    try:
        # Emit run started
        run_started = RunStartedEvent(
            run_id=run_id,
            agent_name=agent.name,
            thread_id=thread_id,
        )
        yield format_event_for_sse(run_started)
        
        # Emit text message start
        msg_start = TextMessageStartEvent(
            message_id=message_id,
            role="assistant",
        )
        yield format_event_for_sse(msg_start)
        
        # Execute agent or team with streaming
        if team:
            # Team execution (non-streaming fallback)
            response = await team.chat_async(user_message)
            final_output = response or ""
            # Emit full content for team response
            if final_output:
                content_event = TextMessageContentEvent(
                    message_id=message_id,
                    content=final_output,
                    delta=False,
                )
                text_content_emitted = True
                yield format_event_for_sse(content_event)
        else:
            # Agent execution with streaming to capture tool calls and emit incremental text
            try:
                async for event in agent.chat_streamed(
                    message=user_message,
                    channel="agui",
                ):
                    # Debug: log all events to understand what's being yielded
                    event_type = type(event).__name__
                    event_name = getattr(event, 'name', None)
                    logger.debug(f"[AG-UI] Stream event: type={event_type} name={event_name}")
                    
                    # Handle text delta events - emit incremental TEXT_MESSAGE_CONTENT
                    text_delta = ""
                    
                    # Check for ResponseTextDeltaEvent (text deltas during streaming)
                    if hasattr(event, 'delta') and hasattr(event, 'snapshot'):
                        # This is a text delta event from the SDK
                        text_delta = event.delta if isinstance(event.delta, str) else ""
                    # Check for ResponseContentPartDeltaEvent
                    elif hasattr(event, 'delta') and hasattr(event.delta, 'text'):
                        text_delta = event.delta.text
                    # Check for other text events
                    elif hasattr(event, 'text') and not hasattr(event, 'name'):
                        text_delta = event.text
                    
                    # Emit incremental text content event if we have a delta
                    if text_delta:
                        final_output += text_delta
                        content_event = TextMessageContentEvent(
                            message_id=message_id,
                            content=text_delta,
                            delta=True,  # Incremental delta, not full content
                        )
                        text_content_emitted = True
                        yield format_event_for_sse(content_event)
                    
                    # Handle RunItemStreamEvent for tool calls
                    if hasattr(event, 'name') and hasattr(event, 'item'):
                        item = event.item
                        event_name = event.name
                        logger.debug(f"[AG-UI] RunItemStreamEvent: name={event_name} item_type={type(item).__name__}")
                        
                        if event_name == "tool_called":
                            # Extract tool call info from the item
                            tool_call_id = str(uuid.uuid4())
                            tool_name = "unknown"
                            args = None
                            
                            # Try to get info from raw_item first (ToolCallItem structure)
                            raw_item = getattr(item, 'raw_item', None)
                            if raw_item:
                                # ResponseFunctionToolCall has name, call_id, arguments
                                if hasattr(raw_item, 'name'):
                                    tool_name = raw_item.name
                                if hasattr(raw_item, 'call_id'):
                                    tool_call_id = raw_item.call_id
                                elif hasattr(raw_item, 'id'):
                                    tool_call_id = raw_item.id
                                if hasattr(raw_item, 'arguments'):
                                    args = raw_item.arguments
                            else:
                                # Fallback to direct attributes
                                tool_name = getattr(item, 'name', None) or getattr(item, 'tool_name', 'unknown')
                                if hasattr(item, 'call_id'):
                                    tool_call_id = item.call_id
                                elif hasattr(item, 'id'):
                                    tool_call_id = item.id
                                if hasattr(item, 'arguments'):
                                    args = item.arguments
                                elif hasattr(item, 'args'):
                                    args = item.args
                            
                            # Store active tool call
                            active_tool_calls[tool_call_id] = tool_name
                            
                            # Emit tool call start
                            start_event = ToolCallStartEvent(
                                tool_call_id=tool_call_id,
                                tool_name=tool_name,
                                message_id=message_id,
                            )
                            yield format_event_for_sse(start_event)
                            
                            # Emit tool call args if available
                            if args:
                                args_str = args if isinstance(args, str) else json.dumps(args)
                                args_event = ToolCallArgsEvent(
                                    tool_call_id=tool_call_id,
                                    args=args_str,
                                    delta=False,
                                )
                                yield format_event_for_sse(args_event)
                        
                        elif event_name == "tool_output":
                            # Find the tool call ID for this output
                            tool_call_id = None
                            result = None
                            
                            # Try raw_item first (ToolCallOutputItem structure)
                            raw_item = getattr(item, 'raw_item', None)
                            if raw_item:
                                if hasattr(raw_item, 'call_id'):
                                    tool_call_id = raw_item.call_id
                                elif hasattr(raw_item, 'id'):
                                    tool_call_id = raw_item.id
                                if hasattr(raw_item, 'output'):
                                    result = raw_item.output
                            
                            # Also check direct item attributes
                            if hasattr(item, 'output'):
                                result = item.output
                            
                            # Fallback for tool_call_id
                            if not tool_call_id:
                                if hasattr(item, 'call_id'):
                                    tool_call_id = item.call_id
                                elif hasattr(item, 'tool_call_id'):
                                    tool_call_id = item.tool_call_id
                                elif active_tool_calls:
                                    # Use the most recent one if we can't find a match
                                    tool_call_id = list(active_tool_calls.keys())[-1]
                            
                            if tool_call_id:
                                result_str = result if isinstance(result, str) else json.dumps(result) if result else None
                                
                                # Emit tool call end
                                end_event = ToolCallEndEvent(
                                    tool_call_id=tool_call_id,
                                    result=result_str,
                                    error=None,
                                )
                                yield format_event_for_sse(end_event)
                                
                                # Remove from active
                                if tool_call_id in active_tool_calls:
                                    del active_tool_calls[tool_call_id]
                        
                        elif event_name == "message_output_created":
                            # This is the final message output
                            # Try raw_item first (MessageOutputItem structure)
                            message_text = ""
                            raw_item = getattr(item, 'raw_item', None)
                            if raw_item:
                                if hasattr(raw_item, 'content'):
                                    content = raw_item.content
                                    if isinstance(content, list):
                                        for part in content:
                                            if hasattr(part, 'text'):
                                                message_text += part.text
                                            elif isinstance(part, dict) and 'text' in part:
                                                message_text += str(part['text'])
                                    elif isinstance(content, str):
                                        message_text = content
                                    else:
                                        message_text = str(content) if content else ""
                                elif hasattr(raw_item, 'text'):
                                    message_text = raw_item.text
                            elif hasattr(item, 'content'):
                                content = item.content
                                if isinstance(content, list):
                                    # Extract text from content list
                                    for part in content:
                                        if hasattr(part, 'text'):
                                            message_text += part.text
                                        elif isinstance(part, dict) and 'text' in part:
                                            message_text += str(part['text'])
                                elif isinstance(content, str):
                                    message_text = content
                                else:
                                    message_text = str(content) if content else ""
                            elif hasattr(item, 'text'):
                                message_text = item.text

                            if message_text:
                                final_output = message_text

                            if final_output and not text_content_emitted:
                                content_event = TextMessageContentEvent(
                                    message_id=message_id,
                                    content=final_output,
                                    delta=False,
                                )
                                text_content_emitted = True
                                yield format_event_for_sse(content_event)
                
            except Exception as stream_error:
                logger.warning(f"Streaming failed, falling back to non-streaming: {stream_error}")
                # Fallback to non-streaming if streaming fails
                response = await agent.chat_async(
                    message=user_message,
                    channel="agui",
                )
                final_output = response or ""
                # Emit full content only on fallback (no incremental streaming happened)
                if final_output:
                    content_event = TextMessageContentEvent(
                        message_id=message_id,
                        content=final_output,
                        delta=False,
                    )
                    text_content_emitted = True
                    yield format_event_for_sse(content_event)

        if final_output and not text_content_emitted:
            content_event = TextMessageContentEvent(
                message_id=message_id,
                content=final_output,
                delta=False,
            )
            text_content_emitted = True
            yield format_event_for_sse(content_event)

        # Emit text message end
        msg_end = TextMessageEndEvent(message_id=message_id)
        yield format_event_for_sse(msg_end)
        
        # Emit run finished
        run_finished = RunFinishedEvent(
            run_id=run_id,
            status="success",
            result=final_output,
        )
        yield format_event_for_sse(run_finished)
    
    except Exception as e:
        logger.exception("Error during AG-UI streaming")
        
        # Emit error event
        error_event = ErrorEvent(
            error_code="EXECUTION_ERROR",
            message=str(e),
        )
        yield format_event_for_sse(error_event)
        
        # Emit run finished with error
        run_finished = RunFinishedEvent(
            run_id=run_id,
            status="error",
            result=str(e),
        )
        yield format_event_for_sse(run_finished)


async def _collect_agui_events(
    agent: "Agent",
    team: Optional["Team"],
    user_message: str,
    run_id: str,
    thread_id: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
) -> List:
    """Collect all AG-UI events for non-streaming response.
    
    Args:
        agent: Agent to execute
        team: Optional team to execute
        user_message: User input message
        run_id: Unique run identifier
        thread_id: Optional thread/conversation ID
        config: Optional configuration overrides
        
    Returns:
        List of all AG-UI events from the execution
    """
    events = []
    message_id = str(uuid.uuid4())
    
    try:
        # Run started
        events.append(RunStartedEvent(
            run_id=run_id,
            agent_name=agent.name,
            thread_id=thread_id,
        ))
        
        # Message start
        events.append(TextMessageStartEvent(
            message_id=message_id,
            role="assistant",
        ))
        
        # Execute
        if team:
            response = await team.chat_async(user_message)
        else:
            response = await agent.chat_async(
                message=user_message,
                channel="agui",
            )
        
        # Content
        if response:
            events.append(TextMessageContentEvent(
                message_id=message_id,
                content=response,
                delta=False,
            ))
        
        # Message end
        events.append(TextMessageEndEvent(message_id=message_id))
        
        # Run finished
        events.append(RunFinishedEvent(
            run_id=run_id,
            status="success",
            result=response,
        ))
    
    except Exception as e:
        logger.exception("Error during AG-UI collection")
        events.append(ErrorEvent(
            error_code="EXECUTION_ERROR",
            message=str(e),
        ))
        events.append(RunFinishedEvent(
            run_id=run_id,
            status="error",
            result=str(e),
        ))
    
    return events


# =============================================================================
# Helper functions for advanced streaming (future use)
# =============================================================================

async def run_agent_streaming(
    agent: "Agent",
    message: str,
    run_id: str,
    event_buffer: EventBuffer,
) -> AsyncGenerator[str, None]:
    """Run agent with true streaming support.
    
    This is a placeholder for future streaming implementation
    that would yield events as the agent generates tokens.
    
    Currently, the SDK doesn't expose streaming hooks, so we
    yield the full response at once.
    """
    # TODO: Implement true streaming when SDK supports it
    message_id = str(uuid.uuid4())
    
    # Start message
    yield format_event_for_sse(TextMessageStartEvent(
        message_id=message_id,
        role="assistant",
    ))
    
    # Execute and yield response
    response = await agent.chat_async(message=message, channel="agui")
    
    if response:
        yield format_event_for_sse(TextMessageContentEvent(
            message_id=message_id,
            content=response,
            delta=False,
        ))
    
    # End message
    yield format_event_for_sse(TextMessageEndEvent(message_id=message_id))


async def run_team_streaming(
    team: "Team",
    message: str,
    run_id: str,
    event_buffer: EventBuffer,
) -> AsyncGenerator[str, None]:
    """Run team with streaming support.
    
    Similar to run_agent_streaming but for team execution.
    Can emit step events for multi-step team workflows.
    """
    # TODO: Implement step-by-step streaming for team workflows
    message_id = str(uuid.uuid4())
    
    yield format_event_for_sse(TextMessageStartEvent(
        message_id=message_id,
        role="assistant",
    ))
    
    response = await team.chat_async(message)
    
    if response:
        yield format_event_for_sse(TextMessageContentEvent(
            message_id=message_id,
            content=response,
            delta=False,
        ))
    
    yield format_event_for_sse(TextMessageEndEvent(message_id=message_id))
