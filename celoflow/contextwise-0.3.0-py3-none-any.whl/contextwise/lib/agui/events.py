"""AG-UI Event Models and Buffer.

This module defines the event types and buffer mechanism for AG-UI protocol
streaming between Contextwise agents and frontend applications.

Event Types:
    - RUN_STARTED: Emitted when a run begins
    - RUN_FINISHED: Emitted when a run completes
    - TEXT_MESSAGE_START: Start of a text message chunk
    - TEXT_MESSAGE_CONTENT: Text content chunk (streaming)
    - TEXT_MESSAGE_END: End of a text message
    - TOOL_CALL_START: Start of a tool invocation
    - TOOL_CALL_ARGS: Tool call arguments chunk
    - TOOL_CALL_END: Tool call completed
    - STEP_STARTED: Multi-step workflow step begins
    - STEP_FINISHED: Multi-step workflow step completes

EventBuffer:
    Manages event ordering and tool call blocking to ensure protocol
    compliance in streaming scenarios.
"""

from __future__ import annotations

import uuid
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class EventType(str, Enum):
    """AG-UI event types."""
    
    # Run lifecycle
    RUN_STARTED = "run_started"
    RUN_FINISHED = "run_finished"
    
    # Text messages (streaming)
    TEXT_MESSAGE_START = "text_message_start"
    TEXT_MESSAGE_CONTENT = "text_message_content"
    TEXT_MESSAGE_END = "text_message_end"
    
    # Tool calls
    TOOL_CALL_START = "tool_call_start"
    TOOL_CALL_ARGS = "tool_call_args"
    TOOL_CALL_END = "tool_call_end"
    
    # Multi-step workflows
    STEP_STARTED = "step_started"
    STEP_FINISHED = "step_finished"
    
    # Raw data (for custom payloads)
    RAW = "raw"
    
    # Errors
    ERROR = "error"


@dataclass
class BaseEvent:
    """Base class for all AG-UI events.
    
    Attributes:
        type: The event type
        id: Unique event identifier
        timestamp: Unix timestamp in milliseconds
        metadata: Optional additional metadata
    """
    type: EventType
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: float = field(default_factory=lambda: time.time() * 1000)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary for JSON serialization."""
        return {
            "type": self.type.value,
            "id": self.id,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


@dataclass
class RunStartedEvent(BaseEvent):
    """Emitted when a run begins.
    
    Attributes:
        run_id: Unique identifier for this run
        agent_name: Name of the executing agent
        thread_id: Optional conversation thread ID
    """
    type: EventType = field(default=EventType.RUN_STARTED)
    run_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_name: str = ""
    thread_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "run_id": self.run_id,
            "agent_name": self.agent_name,
            "thread_id": self.thread_id,
        })
        return d


@dataclass
class RunFinishedEvent(BaseEvent):
    """Emitted when a run completes.
    
    Attributes:
        run_id: Identifier of the completed run
        status: Completion status (success, error, cancelled)
        result: Optional final result
    """
    type: EventType = field(default=EventType.RUN_FINISHED)
    run_id: str = ""
    status: str = "success"
    result: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "run_id": self.run_id,
            "status": self.status,
            "result": self.result,
        })
        return d


@dataclass
class TextMessageStartEvent(BaseEvent):
    """Start of a text message.
    
    Attributes:
        message_id: Unique identifier for this message
        role: Message role (assistant, user, system)
    """
    type: EventType = field(default=EventType.TEXT_MESSAGE_START)
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    role: str = "assistant"
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "message_id": self.message_id,
            "role": self.role,
        })
        return d


@dataclass
class TextMessageContentEvent(BaseEvent):
    """Text content chunk (streaming).
    
    Attributes:
        message_id: Identifier of the parent message
        content: Text content chunk
        delta: Whether this is a delta (incremental) update
    """
    type: EventType = field(default=EventType.TEXT_MESSAGE_CONTENT)
    message_id: str = ""
    content: str = ""
    delta: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "message_id": self.message_id,
            "content": self.content,
            "delta": self.delta,
        })
        return d


@dataclass
class TextMessageEndEvent(BaseEvent):
    """End of a text message.
    
    Attributes:
        message_id: Identifier of the completed message
    """
    type: EventType = field(default=EventType.TEXT_MESSAGE_END)
    message_id: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "message_id": self.message_id,
        })
        return d


@dataclass
class ToolCallStartEvent(BaseEvent):
    """Start of a tool invocation.
    
    Attributes:
        tool_call_id: Unique identifier for this tool call
        tool_name: Name of the tool being called
        message_id: Parent message ID (if part of a message)
    """
    type: EventType = field(default=EventType.TOOL_CALL_START)
    tool_call_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tool_name: str = ""
    message_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "tool_call_id": self.tool_call_id,
            "tool_name": self.tool_name,
            "message_id": self.message_id,
        })
        return d


@dataclass
class ToolCallArgsEvent(BaseEvent):
    """Tool call arguments chunk.
    
    Attributes:
        tool_call_id: Identifier of the parent tool call
        args: Arguments JSON string or dictionary
        delta: Whether this is a delta (incremental) update
    """
    type: EventType = field(default=EventType.TOOL_CALL_ARGS)
    tool_call_id: str = ""
    args: str = ""
    delta: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "tool_call_id": self.tool_call_id,
            "args": self.args,
            "delta": self.delta,
        })
        return d


@dataclass
class ToolCallEndEvent(BaseEvent):
    """Tool call completed.
    
    Attributes:
        tool_call_id: Identifier of the completed tool call
        result: Tool execution result
        error: Error message if tool call failed
    """
    type: EventType = field(default=EventType.TOOL_CALL_END)
    tool_call_id: str = ""
    result: Optional[str] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "tool_call_id": self.tool_call_id,
            "result": self.result,
            "error": self.error,
        })
        return d


@dataclass
class StepStartedEvent(BaseEvent):
    """Multi-step workflow step begins.
    
    Attributes:
        step_id: Unique identifier for this step
        step_name: Name/description of the step
        step_index: Zero-based index in the workflow
    """
    type: EventType = field(default=EventType.STEP_STARTED)
    step_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    step_name: str = ""
    step_index: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "step_id": self.step_id,
            "step_name": self.step_name,
            "step_index": self.step_index,
        })
        return d


@dataclass
class StepFinishedEvent(BaseEvent):
    """Multi-step workflow step completes.
    
    Attributes:
        step_id: Identifier of the completed step
        status: Completion status (success, error, skipped)
        result: Optional step result
    """
    type: EventType = field(default=EventType.STEP_FINISHED)
    step_id: str = ""
    status: str = "success"
    result: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "step_id": self.step_id,
            "status": self.status,
            "result": self.result,
        })
        return d


@dataclass
class ErrorEvent(BaseEvent):
    """Error event.
    
    Attributes:
        error_code: Error code
        message: Error message
        details: Additional error details
    """
    type: EventType = field(default=EventType.ERROR)
    error_code: str = ""
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
        })
        return d


@dataclass
class RawEvent(BaseEvent):
    """Raw data event for custom payloads.
    
    Attributes:
        data: Arbitrary data payload
    """
    type: EventType = field(default=EventType.RAW)
    data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "data": self.data,
        })
        return d


@dataclass
class EventBuffer:
    """Event buffer for managing event ordering and tool call blocking.
    
    Ensures protocol-level ordering constraints during tool execution.
    Events are buffered when a tool call is in progress and released
    when the tool call completes.
    
    Attributes:
        buffer: FIFO queue of pending events
        blocking_tool_call_id: ID of tool call blocking emission
        active_tool_call_ids: Set of currently active tool calls
        ended_tool_call_ids: Set of completed tool calls
    """
    buffer: List[BaseEvent] = field(default_factory=list)
    blocking_tool_call_id: Optional[str] = None
    active_tool_call_ids: Set[str] = field(default_factory=set)
    ended_tool_call_ids: Set[str] = field(default_factory=set)
    
    def start_tool_call(self, tool_call_id: str) -> None:
        """Mark a tool call as started.
        
        If no tool call is currently blocking, this one becomes the blocker.
        
        Args:
            tool_call_id: The tool call ID to start
        """
        self.active_tool_call_ids.add(tool_call_id)
        if self.blocking_tool_call_id is None:
            self.blocking_tool_call_id = tool_call_id
    
    def end_tool_call(self, tool_call_id: str) -> None:
        """Mark a tool call as ended.
        
        If this was the blocking tool call, the next active one becomes
        the blocker (or None if no more active calls).
        
        Args:
            tool_call_id: The tool call ID to end
        """
        self.active_tool_call_ids.discard(tool_call_id)
        self.ended_tool_call_ids.add(tool_call_id)
        
        if self.blocking_tool_call_id == tool_call_id:
            # Find next active tool call to block, or None
            if self.active_tool_call_ids:
                self.blocking_tool_call_id = next(iter(self.active_tool_call_ids))
            else:
                self.blocking_tool_call_id = None
    
    def is_blocked(self) -> bool:
        """Check if event emission is currently blocked by a tool call."""
        return self.blocking_tool_call_id is not None
    
    def add_event(self, event: BaseEvent) -> None:
        """Add an event to the buffer."""
        self.buffer.append(event)
    
    def flush(self) -> List[BaseEvent]:
        """Flush and return all buffered events."""
        events = self.buffer.copy()
        self.buffer.clear()
        return events
    
    def clear(self) -> None:
        """Clear all buffer state."""
        self.buffer.clear()
        self.blocking_tool_call_id = None
        self.active_tool_call_ids.clear()
        self.ended_tool_call_ids.clear()
