"""AG-UI Protocol Integration for Contextwise.

This module provides AG-UI protocol support for rich frontend integration
with Contextwise agents and teams. AG-UI is an event-driven streaming
protocol designed for interactive agent UIs.

Features:
    - Event-driven streaming protocol between frontend and agents/teams
    - Standard event types (RUN_*, TEXT_MESSAGE_*, TOOL_CALL_*, STEP_*)
    - Message formats designed for rich frontends
    - Tool call sequencing and event ordering
    - Support for both Agent and Team execution

Usage:
    ```python
    from contextwise import Agent, create_app
    from contextwise.lib.agui import create_agui_router
    
    # Create agent
    agent = Agent(
        model="gpt-4o-mini",
        instructions="You are helpful",
    )
    
    # Create app with AG-UI enabled
    app = create_app(agent, enable_agui=True)
    
    # Or manually add AG-UI router
    from fastapi import FastAPI
    app = FastAPI()
    app.include_router(create_agui_router(agent), prefix="/agui")
    ```

Endpoints:
    - POST /agui - Main execution endpoint (streaming events)
    - GET /agui/status - Health check and metadata

Event Types:
    - RUN_STARTED, RUN_FINISHED - Run lifecycle events
    - TEXT_MESSAGE_START, TEXT_MESSAGE_CONTENT, TEXT_MESSAGE_END - Text streaming
    - TOOL_CALL_START, TOOL_CALL_ARGS, TOOL_CALL_END - Tool execution
    - STEP_STARTED, STEP_FINISHED - Multi-step workflows
"""

from .events import (
    EventType,
    BaseEvent,
    RunStartedEvent,
    RunFinishedEvent,
    TextMessageStartEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    ToolCallStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    StepStartedEvent,
    StepFinishedEvent,
    EventBuffer,
)

from .utils import (
    convert_agui_messages_to_contextwise_input,
    extract_response_chunk_content,
    create_events_from_chunk,
    create_completion_events,
)

from .router import (
    create_agui_router,
    create_agui_status_endpoint,
    create_agui_status_response,
    AGUIRequest,
    AGUIStatusResponse,
)

__all__ = [
    # Router
    "create_agui_router",
    "create_agui_status_endpoint",
    "create_agui_status_response",
    "AGUIRequest",
    "AGUIStatusResponse",
    # Events
    "EventType",
    "BaseEvent",
    "RunStartedEvent",
    "RunFinishedEvent",
    "TextMessageStartEvent",
    "TextMessageContentEvent",
    "TextMessageEndEvent",
    "ToolCallStartEvent",
    "ToolCallArgsEvent",
    "ToolCallEndEvent",
    "StepStartedEvent",
    "StepFinishedEvent",
    "EventBuffer",
    # Utils
    "convert_agui_messages_to_contextwise_input",
    "extract_response_chunk_content",
    "create_events_from_chunk",
    "create_completion_events",
]
