"""AG-UI Utility Functions.

This module provides conversion and mapping utilities for AG-UI protocol:
- Message conversion between AG-UI and Contextwise formats
- Event mapping from internal responses to AG-UI events
- Response chunk content extraction
- Event emission logic with ordering constraints

These utilities are used by the AG-UI router to transform agent responses
into the AG-UI streaming event format.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

from .events import (
    EventType,
    BaseEvent,
    EventBuffer,
    RunStartedEvent,
    RunFinishedEvent,
    TextMessageStartEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    ToolCallStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    StepStartedEvent,
    StepFinishedEvent,
    ErrorEvent,
)

if TYPE_CHECKING:
    from agents import RunResult

logger = logging.getLogger(__name__)


def convert_agui_messages_to_contextwise_input(
    messages: List[Dict[str, Any]],
) -> Tuple[str, List[Dict[str, Any]]]:
    """Convert AG-UI message list to Contextwise agent input.
    
    AG-UI messages follow a format with role and content fields.
    This function extracts the latest user message as the primary input
    and returns the conversation history.
    
    Args:
        messages: List of AG-UI messages with role/content
        
    Returns:
        Tuple of (user_message, history) where:
        - user_message: The latest user message string
        - history: Previous messages as conversation history
    """
    if not messages:
        return "", []
    
    # Extract the last user message as input
    user_message = ""
    history = []
    
    for i, msg in enumerate(messages):
        role = msg.get("role", "user")
        content = msg.get("content", "")
        
        # Handle different content formats
        if isinstance(content, list):
            # Content might be list of parts
            text_parts = []
            for part in content:
                if isinstance(part, dict):
                    if part.get("type") == "text":
                        text_parts.append(part.get("text", ""))
                else:
                    text_parts.append(str(part))
            content = "".join(text_parts)
        
        if role == "user":
            user_message = content
            # Add to history (excluding the last user message)
            if i < len(messages) - 1:
                history.append({"role": role, "content": content})
        else:
            history.append({"role": role, "content": content})
    
    return user_message, history


def extract_response_chunk_content(chunk: Any) -> Tuple[str, Optional[Dict[str, Any]]]:
    """Extract text content and tool call info from a response chunk.
    
    Args:
        chunk: Response chunk from agent execution
        
    Returns:
        Tuple of (text_content, tool_call_info) where:
        - text_content: Extracted text content (may be empty)
        - tool_call_info: Tool call metadata if this is a tool call chunk
    """
    text_content = ""
    tool_call_info = None
    
    if chunk is None:
        return text_content, tool_call_info
    
    # Handle string chunks directly
    if isinstance(chunk, str):
        return chunk, None
    
    # Handle dictionary chunks
    if isinstance(chunk, dict):
        # Text content
        if "content" in chunk:
            text_content = str(chunk["content"])
        elif "text" in chunk:
            text_content = str(chunk["text"])
        elif "delta" in chunk:
            delta = chunk["delta"]
            if isinstance(delta, dict) and "content" in delta:
                text_content = str(delta["content"])
            elif isinstance(delta, str):
                text_content = delta
        
        # Tool call info
        if "tool_call" in chunk:
            tool_call_info = chunk["tool_call"]
        elif "tool_calls" in chunk and chunk["tool_calls"]:
            tool_call_info = chunk["tool_calls"][0]
        elif "function_call" in chunk:
            tool_call_info = {
                "name": chunk["function_call"].get("name"),
                "arguments": chunk["function_call"].get("arguments"),
            }
    
    # Handle RunResult objects
    if hasattr(chunk, "final_output"):
        text_content = str(chunk.final_output) if chunk.final_output else ""
    
    # Handle message objects with content attribute
    if hasattr(chunk, "content"):
        text_content = str(chunk.content) if chunk.content else ""
    
    return text_content, tool_call_info


def extract_team_response_chunk_content(
    chunk: Any,
    member_name: Optional[str] = None,
) -> Tuple[str, Optional[Dict[str, Any]], Optional[str]]:
    """Extract content from a team response chunk.
    
    Similar to extract_response_chunk_content but also extracts
    member information for team-based execution.
    
    Args:
        chunk: Response chunk from team execution
        member_name: Optional override for member name
        
    Returns:
        Tuple of (text_content, tool_call_info, member_name) where:
        - text_content: Extracted text content
        - tool_call_info: Tool call metadata if present
        - member_name: Name of the team member that generated this chunk
    """
    text_content, tool_call_info = extract_response_chunk_content(chunk)
    
    # Try to extract member name from chunk
    if member_name is None and isinstance(chunk, dict):
        member_name = chunk.get("agent_name") or chunk.get("member")
    
    if member_name is None and hasattr(chunk, "agent_name"):
        member_name = chunk.agent_name
    
    return text_content, tool_call_info, member_name


def create_events_from_chunk(
    chunk: Any,
    run_id: str,
    message_id: Optional[str] = None,
    event_buffer: Optional[EventBuffer] = None,
) -> List[BaseEvent]:
    """Create AG-UI events from a response chunk.
    
    Maps internal response chunks to appropriate AG-UI event types.
    Handles text content, tool calls, and maintains event ordering.
    
    Args:
        chunk: Response chunk to convert
        run_id: The current run ID
        message_id: Optional message ID for text events
        event_buffer: Optional event buffer for tool call ordering
        
    Returns:
        List of AG-UI events created from this chunk
    """
    events: List[BaseEvent] = []
    
    text_content, tool_call_info = extract_response_chunk_content(chunk)
    
    # Create message ID if not provided and we have text content
    if text_content and message_id is None:
        message_id = str(uuid.uuid4())
    
    # Handle tool call events
    if tool_call_info:
        tool_call_id = tool_call_info.get("id") or str(uuid.uuid4())
        tool_name = tool_call_info.get("name", "unknown")
        args = tool_call_info.get("arguments", "{}")
        
        # Tool call start
        start_event = ToolCallStartEvent(
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            message_id=message_id,
        )
        events.append(start_event)
        
        if event_buffer:
            event_buffer.start_tool_call(tool_call_id)
        
        # Tool call args (if present)
        if args:
            args_str = args if isinstance(args, str) else json.dumps(args)
            args_event = ToolCallArgsEvent(
                tool_call_id=tool_call_id,
                args=args_str,
                delta=False,
            )
            events.append(args_event)
        
        # Tool call end (mark as complete)
        result = tool_call_info.get("result") or tool_call_info.get("output")
        error = tool_call_info.get("error")
        
        end_event = ToolCallEndEvent(
            tool_call_id=tool_call_id,
            result=str(result) if result else None,
            error=str(error) if error else None,
        )
        events.append(end_event)
        
        if event_buffer:
            event_buffer.end_tool_call(tool_call_id)
    
    # Handle text content events
    if text_content:
        # Only emit content event (start/end managed at higher level)
        content_event = TextMessageContentEvent(
            message_id=message_id or "",
            content=text_content,
            delta=True,
        )
        events.append(content_event)
    
    return events


def create_completion_events(
    run_id: str,
    final_output: Optional[str] = None,
    status: str = "success",
    error: Optional[str] = None,
) -> List[BaseEvent]:
    """Create run completion events.
    
    Emits the final events to signal run completion, including
    any final text content and the run finished event.
    
    Args:
        run_id: The run ID being completed
        final_output: Optional final output text
        status: Completion status (success, error, cancelled)
        error: Error message if status is error
        
    Returns:
        List of completion events
    """
    events: List[BaseEvent] = []
    
    # Run finished event
    finished_event = RunFinishedEvent(
        run_id=run_id,
        status=status,
        result=final_output,
    )
    events.append(finished_event)
    
    return events


def emit_event_logic(
    event: BaseEvent,
    event_buffer: EventBuffer,
) -> List[BaseEvent]:
    """Apply event emission logic with ordering constraints.
    
    Enforces AG-UI protocol ordering constraints:
    - Tool call events can block other events
    - Events are buffered during tool execution
    - Events are flushed when tool calls complete
    
    Args:
        event: Event to emit
        event_buffer: Event buffer for ordering
        
    Returns:
        List of events to emit (may include buffered events)
    """
    events_to_emit: List[BaseEvent] = []
    
    # Tool call start events update the buffer state
    if isinstance(event, ToolCallStartEvent):
        event_buffer.start_tool_call(event.tool_call_id)
        events_to_emit.append(event)
        return events_to_emit
    
    # Tool call end events release the buffer
    if isinstance(event, ToolCallEndEvent):
        event_buffer.end_tool_call(event.tool_call_id)
        events_to_emit.append(event)
        # Flush buffered events if no longer blocked
        if not event_buffer.is_blocked():
            events_to_emit.extend(event_buffer.flush())
        return events_to_emit
    
    # Other events may be buffered if blocked
    if event_buffer.is_blocked():
        # Allow tool call args through even when blocked
        if isinstance(event, ToolCallArgsEvent):
            events_to_emit.append(event)
        else:
            event_buffer.add_event(event)
    else:
        events_to_emit.append(event)
    
    return events_to_emit


def format_event_for_sse(event: BaseEvent) -> str:
    """Format an event for Server-Sent Events (SSE) streaming.
    
    Wraps each event with AG-UI wire-level protocol envelope containing:
    - protocol: 'agui' - AG-UI protocol identifier
    - version: 1 - AG-UI protocol version
    
    This enables clients to auto-detect AG-UI responses by checking for
    these envelope fields in addition to the X-AGUI-Protocol response header.
    
    Args:
        event: Event to format
        
    Returns:
        SSE-formatted string with AG-UI protocol envelope
    """
    event_data = event.to_dict()
    # Wrap with AG-UI protocol envelope
    envelope = {
        "protocol": "agui",
        "version": 1,
        **event_data,
    }
    data = json.dumps(envelope)
    return f"data: {data}\n\n"


def format_events_for_ndjson(events: List[BaseEvent]) -> str:
    """Format events as newline-delimited JSON.
    
    Args:
        events: Events to format
        
    Returns:
        NDJSON-formatted string
    """
    lines = [json.dumps(event.to_dict()) for event in events]
    return "\n".join(lines) + "\n" if lines else ""
