"""Main orchestrator for CodeMode system."""

import logging
from typing import Dict, Any
from .models import CodeModeOptions, CodeModeResult, Tool
from .type_generation import generate_tool_types, generate_tool_documentation

logger = logging.getLogger(__name__)


def create_codemode_prompt(
    base_prompt: str,
    type_definitions: str,
    tools: Dict[str, Tool]
) -> str:
    """
    Create enhanced system prompt with tool types and documentation.
    
    Args:
        base_prompt: Original system prompt
        type_definitions: Generated type definitions
        tools: Available tools
        
    Returns:
        Enhanced prompt with tool information
    """
    tool_names = ", ".join(tools.keys())
    
    enhanced_prompt = f"""{base_prompt}

# CodeMode Environment

You are operating in a CodeMode environment where you can generate and execute Python code
to accomplish tasks using the available tools.

## Available Tools

You have access to the following tools: {tool_names}

## Type Definitions

{type_definitions}

## Usage Instructions

1. Generate an async function named `execute_task()` that accomplishes the user's goal
2. Access tools via the `tools` object (e.g., `await tools.search({{"query": "example"}})`)
3. Handle errors appropriately with try/except blocks
4. Return a meaningful result that answers the user's question
5. Use type hints for clarity

## Example

```python
async def execute_task():
    \"\"\"Accomplish the user's task using available tools.\"\"\"
    try:
        # Use tools to get information
        result = await tools.some_tool({{"param": "value"}})
        
        # Process and return result
        return {{"status": "success", "data": result}}
    except Exception as e:
        return {{"status": "error", "message": str(e)}}
```

Remember: Only use the provided tools. Do not attempt to import external libraries or
access resources outside the sandbox."""

    return enhanced_prompt


def create_codemode_tool(
    tools: Dict[str, Tool],
    sandbox_backend: Any,
    proxy_client: Any,
    llm_client: Any
) -> Tool:
    """
    Create the unified 'codemode' tool that wraps all available tools.
    
    Args:
        tools: Original tools to wrap
        sandbox_backend: Sandbox executor instance
        proxy_client: Proxy for tool access
        llm_client: LLM client for code generation
        
    Returns:
        Codemode tool that generates and executes code
    """
    from pydantic import BaseModel, Field
    
    class CodeModeInput(BaseModel):
        """Input for codemode tool."""
        task: str = Field(description="Task description for code generation")
        max_retries: int = Field(default=3, description="Maximum retry attempts")
        validate_code: bool = Field(default=True, description="Validate before execution")
    
    class CodeModeOutput(BaseModel):
        """Output from codemode tool."""
        success: bool = Field(description="Whether task completed successfully")
        result: Any = Field(description="Task result or error message")
        generated_code: str = Field(description="Generated Python code")
        execution_time: float = Field(description="Execution time in seconds")
    
    async def execute_codemode(task: str, max_retries: int = 3, validate_code: bool = True) -> Dict[str, Any]:
        """
        Execute a task by generating and running code.
        
        Args:
            task: Task description
            max_retries: Maximum retry attempts
            validate_code: Whether to validate code before execution
            
        Returns:
            Execution result
        """
        import time
        from .type_generation import generate_tool_types
        
        start_time = time.time()
        
        # Generate type definitions
        type_defs = generate_tool_types(tools)
        
        # Generate code
        code = await llm_client.generate_code(
            prompt=task,
            available_tools=type_defs
        )
        
        # Validate if requested
        if validate_code:
            is_valid, issues = await llm_client.validate_code(code)
            if not is_valid:
                return {
                    "success": False,
                    "result": {"error": "Code validation failed", "issues": issues},
                    "generated_code": code,
                    "execution_time": time.time() - start_time
                }
        
        # Execute in sandbox
        execution_result = await sandbox_backend.execute(code, proxy_client)
        
        return {
            "success": execution_result.success,
            "result": execution_result.return_value or execution_result.output,
            "generated_code": code,
            "execution_time": time.time() - start_time
        }
    
    return Tool(
        name="codemode",
        description="Generate and execute Python code to accomplish tasks using available tools",
        input_schema=CodeModeInput,
        output_schema=CodeModeOutput,
        execute=execute_codemode,
        metadata={
            "wrapped_tools": list(tools.keys()),
            "sandbox_backend": str(type(sandbox_backend).__name__),
            "llm_provider": getattr(llm_client, 'provider', 'unknown')
        }
    )


async def experimental_codemode(options: CodeModeOptions) -> CodeModeResult:
    """
    Initialize codemode with tool wrapping and type generation.
    
    Main orchestration function that:
    1. Generates type definitions from tools
    2. Creates enhanced system prompt
    3. Wraps tools into unified codemode tool
    
    System Thinking L2 Considerations:
    - Emergent behavior: Tool composition becomes possible through code generation
    - Feedback: LLM learns from execution results via retry logic
    - Constraints: Sandbox boundaries and resource limits ensure safety
    
    Args:
        options: CodeModeOptions with all configuration
        
    Returns:
        CodeModeResult with enhanced prompt and wrapped tools
        
    Raises:
        ValueError: If configuration is invalid
    """
    logger.info(
        f"Initializing CodeMode with {len(options.tools)} tools, "
        f"backend: {type(options.sandbox_backend).__name__}"
    )
    
    try:
        # Generate type definitions for tools
        type_definitions = generate_tool_types(options.tools)
        
        # Validate generated types
        from .type_generation import validate_generated_types
        if not validate_generated_types(type_definitions):
            raise ValueError("Generated type definitions are invalid")
        
        # Create enhanced system prompt
        enhanced_prompt = create_codemode_prompt(
            options.prompt,
            type_definitions,
            options.tools
        )
        
        # Create unified codemode tool
        codemode_tool = create_codemode_tool(
            options.tools,
            options.sandbox_backend,
            options.proxy_client,
            options.llm_client
        )
        
        # Build result
        result = CodeModeResult(
            prompt=enhanced_prompt,
            tools={"codemode": codemode_tool},
            metadata={
                "tool_count": len(options.tools),
                "original_tools": list(options.tools.keys()),
                "sandbox_backend": type(options.sandbox_backend).__name__,
                "max_retries": options.max_retries,
                "timeout": options.timeout
            },
            type_definitions=type_definitions
        )
        
        logger.info("CodeMode initialization complete")
        return result
        
    except Exception as e:
        logger.error(f"CodeMode initialization failed: {e}")
        raise
