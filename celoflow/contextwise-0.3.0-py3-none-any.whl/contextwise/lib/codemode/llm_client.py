"""LLM client with support for multiple providers."""

import os
import logging
from typing import Literal, Optional, List, Dict, Any
import asyncio

logger = logging.getLogger(__name__)


class LLMClient:
    """
    Unified LLM client supporting Anthropic, OpenAI, and LiteLLM providers.
    
    System Thinking L2 Considerations:
    - Provider abstraction: Enables flexibility and cost optimization
    - Consistent interface: Simplifies testing and deployment
    - Configuration-driven: Allows runtime provider switching
    """
    
    def __init__(
        self,
        provider: Literal["anthropic", "openai", "litellm"] = "anthropic",
        model: str = "claude-sonnet-4-20250514",
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4000,
        top_p: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        **kwargs
    ):
        """
        Initialize LLM client.
        
        Args:
            provider: LLM provider ('anthropic', 'openai', 'litellm')
            model: Model identifier
            api_key: API key (falls back to environment variables)
            temperature: Sampling temperature (0=deterministic, 2=creative)
            max_tokens: Maximum tokens in response
            top_p: Nucleus sampling parameter
            frequency_penalty: Frequency penalty (-2.0 to 2.0)
            presence_penalty: Presence penalty (-2.0 to 2.0)
            **kwargs: Additional provider-specific parameters
        """
        self.provider = provider
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.top_p = top_p
        self.frequency_penalty = frequency_penalty
        self.presence_penalty = presence_penalty
        self.kwargs = kwargs
        
        # Resolve API key
        self.api_key = api_key or self._get_api_key_from_env()
        
        # Initialize provider client
        self.client = self._initialize_client()
    
    def _get_api_key_from_env(self) -> Optional[str]:
        """Get API key from environment variables."""
        env_keys = {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "litellm": "LITELLM_API_KEY"
        }
        return os.getenv(env_keys.get(self.provider, f"{self.provider.upper()}_API_KEY"))
    
    def _initialize_client(self):
        """Initialize provider-specific client."""
        try:
            if self.provider == "anthropic":
                from anthropic import AsyncAnthropic
                return AsyncAnthropic(api_key=self.api_key)
                
            elif self.provider == "openai":
                from openai import AsyncOpenAI
                return AsyncOpenAI(api_key=self.api_key)
                
            elif self.provider == "litellm":
                import litellm
                if self.api_key:
                    litellm.api_key = self.api_key
                return litellm
                
            else:
                raise ValueError(f"Unsupported provider: {self.provider}")
                
        except ImportError as e:
            raise ImportError(
                f"Required library for {self.provider} not installed. "
                f"Install with: uv add {self.provider}"
            ) from e
    
    async def generate_code(
        self,
        prompt: str,
        available_tools: str,
        system_message: Optional[str] = None,
        examples: Optional[List[Dict[str, str]]] = None
    ) -> str:
        """
        Generate Python code using configured LLM provider.
        
        Args:
            prompt: User's task description
            available_tools: Type definitions for available tools
            system_message: Optional custom system message
            examples: Optional few-shot examples
            
        Returns:
            Generated Python code
            
        Raises:
            RuntimeError: If code generation fails
        """
        if system_message is None:
            system_message = self._create_system_message(available_tools)
        
        # Add examples if provided
        messages = []
        if examples:
            for example in examples:
                messages.append({"role": "user", "content": example["user"]})
                messages.append({"role": "assistant", "content": example["assistant"]})
        
        messages.append({"role": "user", "content": prompt})
        
        try:
            if self.provider == "anthropic":
                code = await self._generate_anthropic(system_message, messages)
            elif self.provider == "openai":
                code = await self._generate_openai(system_message, messages)
            elif self.provider == "litellm":
                code = await self._generate_litellm(system_message, messages)
            else:
                raise ValueError(f"Unsupported provider: {self.provider}")
            
            # Clean up code (remove markdown if present)
            code = self._clean_code(code)
            return code
            
        except Exception as e:
            logger.error(f"Code generation failed with {self.provider}: {e}")
            raise RuntimeError(
                f"LLM generation failed with {self.provider}: {e}"
            ) from e
    
    async def _generate_anthropic(
        self,
        system_message: str,
        messages: List[Dict[str, str]]
    ) -> str:
        """Generate code using Anthropic API."""
        response = await self.client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            system=system_message,
            messages=messages,
            **self.kwargs
        )
        return response.content[0].text
    
    async def _generate_openai(
        self,
        system_message: str,
        messages: List[Dict[str, str]]
    ) -> str:
        """Generate code using OpenAI API."""
        # OpenAI includes system message in messages array
        full_messages = [{"role": "system", "content": system_message}] + messages
        
        # Build parameters
        params: Dict[str, Any] = {
            "model": self.model,
            "messages": full_messages,
        }

        is_gpt5 = self.model.startswith("gpt-5")

        # OpenAI model families differ in token limit parameter naming.
        # gpt-5* chat.completions models reject `max_tokens` and require `max_completion_tokens`.
        token_param = "max_completion_tokens" if is_gpt5 else "max_tokens"
        params[token_param] = self.max_tokens

        # gpt-5* models may restrict sampling params to defaults. Avoid sending unsupported values.
        if not is_gpt5:
            params["temperature"] = self.temperature
        
        if not is_gpt5:
            if self.top_p is not None:
                params["top_p"] = self.top_p
            if self.frequency_penalty is not None:
                params["frequency_penalty"] = self.frequency_penalty
            if self.presence_penalty is not None:
                params["presence_penalty"] = self.presence_penalty
        
        params.update(self.kwargs)
        
        response = await self.client.chat.completions.create(**params)
        return response.choices[0].message.content
    
    async def _generate_litellm(
        self,
        system_message: str,
        messages: List[Dict[str, str]]
    ) -> str:
        """Generate code using LiteLLM."""
        from litellm import acompletion
        
        # LiteLLM includes system message in messages
        full_messages = [{"role": "system", "content": system_message}] + messages
        
        params = {
            "model": self.model,
            "messages": full_messages,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
        }
        
        if self.api_key:
            params["api_key"] = self.api_key
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.frequency_penalty is not None:
            params["frequency_penalty"] = self.frequency_penalty
        if self.presence_penalty is not None:
            params["presence_penalty"] = self.presence_penalty
        
        params.update(self.kwargs)
        
        response = await acompletion(**params)
        return response.choices[0].message.content
    
    def _create_system_message(self, available_tools: str) -> str:
        """Create default system message for code generation."""
        return f"""You are a code generation AI specialized in Python.

You have access to these async functions (tools):

{available_tools}

Your task is to generate an async function that achieves the user's goal using these tools.

Requirements:
- Function name MUST be `execute_task`
- Function MUST be async (use async def)
- Function MUST return a result
- Use ONLY the provided tools (accessed via `tools.tool_name(input)`)
- Handle errors gracefully with try/except blocks
- Add type hints for clarity
- Keep code clean and well-documented

Example structure:
```python
async def execute_task():
    \"\"\"Execute the requested task.\"\"\"
    try:
        # Use tools to accomplish the task
        result = await tools.some_tool({{"param": "value"}})
        return result
    except Exception as e:
        return {{"error": str(e)}}
```

Respond with ONLY the Python code. Do NOT include markdown code blocks or explanations."""
    
    def _clean_code(self, code: str) -> str:
        """
        Remove markdown code blocks and extra whitespace from generated code.
        
        Args:
            code: Raw code from LLM
            
        Returns:
            Cleaned Python code
        """
        code = code.strip()
        
        # Remove markdown code blocks
        if code.startswith("```python"):
            code = code[len("```python"):].strip()
        elif code.startswith("```"):
            code = code[len("```"):].strip()
        
        if code.endswith("```"):
            code = code[:-len("```")].strip()
        
        return code
    
    async def validate_code(
        self,
        code: str,
        strict: bool = True
    ) -> tuple[bool, List[str]]:
        """
        Validate generated code using LLM as a code reviewer.
        
        Args:
            code: Python code to validate
            strict: If True, be conservative in validation
            
        Returns:
            Tuple of (is_valid, list of issues)
        """
        validation_prompt = f"""Analyze this Python code for potential issues:

```python
{code}
```

Check for:
1. Syntax errors
2. Security vulnerabilities (e.g., eval, exec, arbitrary file access)
3. Logic errors
4. Missing imports
5. Infinite loops or resource leaks

Respond with:
- "SAFE" if the code is acceptable
- "UNSAFE: <comma-separated list of issues>" if problems are found

Be {"very conservative" if strict else "reasonable"} in your assessment."""
        
        try:
            response = await self.generate_code(
                prompt=validation_prompt,
                available_tools="",
                system_message="You are a code security analyzer."
            )
            
            response = response.strip()
            
            if response.startswith("SAFE"):
                return True, []
            elif response.startswith("UNSAFE:"):
                issues = response.split(":", 1)[1].strip()
                issue_list = [issue.strip() for issue in issues.split(",")]
                return False, issue_list
            else:
                # Unclear response, err on the side of caution
                return False, [f"Validation unclear: {response}"]
                
        except Exception as e:
            logger.error(f"Code validation failed: {e}")
            return False, [f"Validation error: {str(e)}"]
    
    def compile_check(self, code: str) -> tuple[bool, Optional[str]]:
        """
        Check if code compiles without executing it.
        
        Args:
            code: Python code to check
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            compile(code, '<string>', 'exec')
            return True, None
        except SyntaxError as e:
            return False, f"Syntax error at line {e.lineno}: {e.msg}"
        except Exception as e:
            return False, f"Compilation error: {str(e)}"
