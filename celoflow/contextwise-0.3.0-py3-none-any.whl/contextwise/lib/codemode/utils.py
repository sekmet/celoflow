"""Utility functions for CodeMode system."""

import asyncio
import functools
import time
import logging
from typing import Callable, Any, Optional, Dict
from collections import OrderedDict

logger = logging.getLogger(__name__)


class LRUCache:
    """
    Thread-safe LRU cache for caching expensive operations.
    
    System Thinking L2:
    - Performance optimization: Reduces redundant computations
    - Resource management: Bounded memory usage via LRU eviction
    """
    
    def __init__(self, capacity: int = 100):
        """
        Initialize LRU cache.
        
        Args:
            capacity: Maximum number of items to cache
        """
        self.cache = OrderedDict()
        self.capacity = capacity
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Any]:
        """
        Get item from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found
        """
        async with self._lock:
            if key in self.cache:
                # Move to end (most recently used)
                self.cache.move_to_end(key)
                return self.cache[key]
            return None
    
    async def put(self, key: str, value: Any):
        """
        Put item in cache.
        
        Args:
            key: Cache key
            value: Value to cache
        """
        async with self._lock:
            if key in self.cache:
                self.cache.move_to_end(key)
            else:
                if len(self.cache) >= self.capacity:
                    # Remove least recently used
                    self.cache.popitem(last=False)
            self.cache[key] = value
    
    async def clear(self):
        """Clear all cached items."""
        async with self._lock:
            self.cache.clear()


def async_retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,)
):
    """
    Decorator for async functions with exponential backoff retry.
    
    Args:
        max_attempts: Maximum retry attempts
        delay: Initial delay in seconds
        backoff: Backoff multiplier
        exceptions: Tuple of exceptions to catch
        
    Example:
        ```python
        @async_retry(max_attempts=3, delay=1.0, backoff=2.0)
        async def flaky_api_call():
            # May fail intermittently
            pass
        ```
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            current_delay = delay
            last_exception = None
            
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt == max_attempts - 1:
                        raise
                    
                    logger.warning(
                        f"{func.__name__} failed (attempt {attempt + 1}/{max_attempts}): {e}. "
                        f"Retrying in {current_delay}s..."
                    )
                    await asyncio.sleep(current_delay)
                    current_delay *= backoff
            
            raise last_exception
        
        return wrapper
    return decorator


def rate_limit(calls: int, period: float):
    """
    Decorator for rate limiting async functions.
    
    Args:
        calls: Maximum number of calls
        period: Time period in seconds
        
    Example:
        ```python
        @rate_limit(calls=10, period=60.0)
        async def api_call():
            # Limited to 10 calls per 60 seconds
            pass
        ```
    """
    def decorator(func: Callable):
        timestamps = []
        lock = asyncio.Lock()
        
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            async with lock:
                now = time.time()
                
                # Remove timestamps outside the period
                while timestamps and timestamps[0] <= now - period:
                    timestamps.pop(0)
                
                # Check if we've exceeded the rate limit
                if len(timestamps) >= calls:
                    sleep_time = period - (now - timestamps[0])
                    logger.warning(
                        f"Rate limit exceeded for {func.__name__}. "
                        f"Sleeping for {sleep_time:.2f}s"
                    )
                    await asyncio.sleep(sleep_time)
                    timestamps.clear()
                
                # Record this call
                timestamps.append(time.time())
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def measure_time(func: Callable):
    """
    Decorator to measure execution time of async functions.
    
    Args:
        func: Async function to measure
        
    Example:
        ```python
        @measure_time
        async def slow_operation():
            await asyncio.sleep(1)
        ```
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        start = time.time()
        try:
            result = await func(*args, **kwargs)
            return result
        finally:
            duration = time.time() - start
            logger.info(f"{func.__name__} took {duration:.3f}s")
    
    return wrapper


class CircuitBreaker:
    """
    Circuit breaker pattern for fault tolerance.
    
    System Thinking L2:
    - Failure isolation: Prevents cascading failures
    - Self-healing: Automatically retries after timeout
    - Monitoring: Tracks failure rates for observability
    """
    
    def __init__(
        self,
        failure_threshold: int = 5,
        timeout: float = 60.0,
        expected_exception: type = Exception
    ):
        """
        Initialize circuit breaker.
        
        Args:
            failure_threshold: Number of failures before opening circuit
            timeout: Seconds to wait before attempting reset
            expected_exception: Exception type to catch
        """
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.expected_exception = expected_exception
        
        self.failure_count = 0
        self.last_failure_time = None
        self.state = "closed"  # closed, open, half-open
        self._lock = asyncio.Lock()
    
    async def call(self, func: Callable, *args, **kwargs):
        """
        Execute function through circuit breaker.
        
        Args:
            func: Async function to execute
            *args: Positional arguments
            **kwargs: Keyword arguments
            
        Returns:
            Function result
            
        Raises:
            Exception: If circuit is open or function fails
        """
        async with self._lock:
            if self.state == "open":
                if time.time() - self.last_failure_time >= self.timeout:
                    self.state = "half-open"
                    logger.info("Circuit breaker entering half-open state")
                else:
                    raise Exception("Circuit breaker is OPEN")
        
        try:
            result = await func(*args, **kwargs)
            
            async with self._lock:
                if self.state == "half-open":
                    self.state = "closed"
                    self.failure_count = 0
                    logger.info("Circuit breaker reset to CLOSED")
            
            return result
            
        except self.expected_exception as e:
            async with self._lock:
                self.failure_count += 1
                self.last_failure_time = time.time()
                
                if self.failure_count >= self.failure_threshold:
                    self.state = "open"
                    logger.error(
                        f"Circuit breaker opened after {self.failure_count} failures"
                    )
                
            raise


def setup_logging(
    level: str = "INFO",
    format_string: Optional[str] = None,
    log_file: Optional[str] = None
):
    """
    Configure logging for CodeMode.
    
    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format_string: Custom log format
        log_file: Optional file to log to
    """
    if format_string is None:
        format_string = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    handlers = [logging.StreamHandler()]
    
    if log_file:
        handlers.append(logging.FileHandler(log_file))
    
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format=format_string,
        handlers=handlers
    )
    
    logger.info(f"Logging configured at {level} level")


async def timeout_wrapper(
    coro: Callable,
    timeout_seconds: float,
    timeout_message: str = "Operation timed out"
):
    """
    Wrap coroutine with timeout.
    
    Args:
        coro: Coroutine to execute
        timeout_seconds: Timeout in seconds
        timeout_message: Message for timeout exception
        
    Returns:
        Coroutine result
        
    Raises:
        asyncio.TimeoutError: If timeout exceeded
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        logger.error(f"{timeout_message} (after {timeout_seconds}s)")
        raise asyncio.TimeoutError(timeout_message)


def validate_python_identifier(name: str) -> bool:
    """
    Validate if string is a valid Python identifier.
    
    Args:
        name: String to validate
        
    Returns:
        True if valid identifier, False otherwise
    """
    import keyword
    
    if not name:
        return False
    
    if keyword.iskeyword(name):
        return False
    
    if not name.isidentifier():
        return False
    
    return True


def sanitize_code(code: str) -> str:
    """
    Basic sanitization of generated code.
    
    Removes potentially dangerous patterns (this is NOT a security solution,
    proper sandboxing is required).
    
    Args:
        code: Python code to sanitize
        
    Returns:
        Sanitized code
    """
    dangerous_patterns = [
        "__import__",
        "eval(",
        "exec(",
        "compile(",
        "open(",
        "file(",
        "__builtins__",
        "os.system",
        "subprocess.",
        "sys.exit",
    ]
    
    for pattern in dangerous_patterns:
        if pattern in code:
            logger.warning(f"Potentially dangerous pattern found: {pattern}")
    
    return code


class MetricsCollector:
    """
    Simple metrics collector for monitoring.
    
    Tracks counts, durations, and errors for observability.
    """
    
    def __init__(self):
        """Initialize metrics collector."""
        self.metrics: Dict[str, Any] = {
            "counts": {},
            "durations": {},
            "errors": {}
        }
        self._lock = asyncio.Lock()
    
    async def increment(self, metric_name: str, value: int = 1):
        """Increment a counter metric."""
        async with self._lock:
            if metric_name not in self.metrics["counts"]:
                self.metrics["counts"][metric_name] = 0
            self.metrics["counts"][metric_name] += value
    
    async def record_duration(self, metric_name: str, duration: float):
        """Record a duration metric."""
        async with self._lock:
            if metric_name not in self.metrics["durations"]:
                self.metrics["durations"][metric_name] = []
            self.metrics["durations"][metric_name].append(duration)
    
    async def record_error(self, metric_name: str, error: str):
        """Record an error."""
        async with self._lock:
            if metric_name not in self.metrics["errors"]:
                self.metrics["errors"][metric_name] = []
            self.metrics["errors"][metric_name].append({
                "error": error,
                "timestamp": time.time()
            })
    
    async def get_metrics(self) -> Dict[str, Any]:
        """Get all collected metrics."""
        async with self._lock:
            return self.metrics.copy()
    
    async def clear(self):
        """Clear all metrics."""
        async with self._lock:
            self.metrics = {
                "counts": {},
                "durations": {},
                "errors": {}
            }
