"""Configuration and factory patterns for CodeMode library selection."""

import os
import json
from typing import Literal, Optional, Dict, Any
from pydantic import BaseModel, Field
from pathlib import Path


class LibraryConfig(BaseModel):
    """
    Configuration for library selection in CodeMode.
    
    Enables runtime choice of LLM providers, sandbox backends, and MCP frameworks
    while maintaining consistent interfaces across implementations.
    
    System Thinking L2 Considerations:
    - Emergent behavior: Different library combinations optimize for different use cases
    - Constraints: Not all combinations are compatible or equally performant
    - Feedback: Configuration choices affect performance, cost, and capabilities
    """
    
    # LLM Provider Options
    llm_provider: Literal["anthropic", "openai", "litellm"] = Field(
        default="anthropic",
        description="LLM provider for code generation"
    )
    llm_model: str = Field(
        default="claude-sonnet-4-20250514",
        description="Model identifier for the chosen provider"
    )
    llm_api_key: Optional[str] = Field(
        default=None,
        description="API key for LLM provider (falls back to environment variables)"
    )
    llm_temperature: float = Field(
        default=0.7,
        ge=0.0,
        le=2.0,
        description="Temperature for code generation (0=deterministic, 2=creative)"
    )
    llm_max_tokens: int = Field(
        default=4000,
        gt=0,
        description="Maximum tokens for LLM responses"
    )
    
    # Sandbox Backend Options
    sandbox_backend: Literal["llm-sandbox", "codejail", "docker"] = Field(
        default="llm-sandbox",
        description="Sandbox execution backend"
    )
    sandbox_timeout: int = Field(
        default=60,
        gt=0,
        description="Timeout in seconds for code execution"
    )
    sandbox_memory_limit: str = Field(
        default="512m",
        description="Memory limit for sandbox (e.g., '512m', '1g')"
    )
    sandbox_cpu_limit: float = Field(
        default=1.0,
        gt=0.0,
        description="CPU limit for sandbox (number of cores)"
    )
    sandbox_keep_template: bool = Field(
        default=False,
        description="Keep sandbox template for faster subsequent executions"
    )
    
    # MCP Framework Options
    mcp_framework: Literal["fastmcp", "mcp"] = Field(
        default="fastmcp",
        description="MCP server framework"
    )
    mcp_transport: Literal["stdio", "sse", "websocket"] = Field(
        default="stdio",
        description="MCP transport protocol"
    )
    
    # General Options
    max_retries: int = Field(
        default=3,
        ge=0,
        description="Maximum retry attempts for operations"
    )
    verbose: bool = Field(
        default=False,
        description="Enable verbose logging"
    )
    
    class Config:
        """Pydantic model configuration."""
        validate_assignment = True
        extra = "forbid"
    
    def validate_compatibility(self) -> None:
        """
        Validate that selected library combinations are compatible.
        
        Raises:
            ValueError: If incompatible libraries are selected
        """
        # Check sandbox backend compatibility
        if self.sandbox_backend == "codejail" and self.sandbox_keep_template:
            raise ValueError(
                "CodeJail backend does not support keep_template option. "
                "Use llm-sandbox or docker instead."
            )
        
        # Check MCP transport compatibility
        if self.mcp_framework == "mcp" and self.mcp_transport == "sse":
            import warnings
            warnings.warn(
                "Standard MCP framework has limited SSE support. "
                "Consider using FastMCP for SSE transport.",
                UserWarning
            )
        
        # Check LLM model compatibility with provider
        if self.llm_provider == "anthropic" and not self.llm_model.startswith("claude"):
            raise ValueError(
                f"Anthropic provider requires Claude models. Got: {self.llm_model}"
            )
        
        if self.llm_provider == "openai" and self.llm_model.startswith("claude"):
            raise ValueError(
                f"OpenAI provider cannot use Claude models. Got: {self.llm_model}"
            )
    
    def to_json(self, filepath: Optional[Path] = None) -> str:
        """
        Serialize configuration to JSON.
        
        Args:
            filepath: Optional path to save JSON file
            
        Returns:
            JSON string representation
        """
        json_str = self.model_dump_json(indent=2, exclude={"llm_api_key"})
        
        if filepath:
            filepath = Path(filepath)
            filepath.parent.mkdir(parents=True, exist_ok=True)
            filepath.write_text(json_str)
        
        return json_str
    
    @classmethod
    def from_json(cls, source: str | Path) -> "LibraryConfig":
        """
        Load configuration from JSON file or string.
        
        Args:
            source: JSON string or path to JSON file
            
        Returns:
            LibraryConfig instance
        """
        if isinstance(source, Path) or (isinstance(source, str) and Path(source).exists()):
            json_str = Path(source).read_text()
        else:
            json_str = source
        
        data = json.loads(json_str)
        instance = cls(**data)
        instance.validate_compatibility()
        return instance
    
    @classmethod
    def from_env(cls) -> "LibraryConfig":
        """
        Create configuration from environment variables.
        
        Environment variables follow the pattern: CODEMODE_<FIELD_NAME>
        Example: CODEMODE_LLM_PROVIDER=openai
        
        Returns:
            LibraryConfig instance with values from environment
        """
        config_data: Dict[str, Any] = {}
        
        # Map environment variables to config fields
        env_prefix = "CODEMODE_"
        for key in os.environ:
            if key.startswith(env_prefix):
                field_name = key[len(env_prefix):].lower()
                value = os.environ[key]
                
                # Convert boolean strings
                if value.lower() in ("true", "false"):
                    value = value.lower() == "true"
                # Convert numeric strings
                elif value.isdigit():
                    value = int(value)
                elif value.replace(".", "", 1).isdigit():
                    value = float(value)
                
                config_data[field_name] = value
        
        instance = cls(**config_data)
        instance.validate_compatibility()
        return instance


class ConfigurableCodeMode:
    """
    Factory class for creating CodeMode instances with chosen libraries.
    
    Implements lazy initialization pattern to avoid loading unused dependencies.
    Provides consistent interface while allowing runtime library selection.
    
    System Thinking L2:
    - Component isolation: Each factory method handles one library category
    - State management: Caches initialized clients to avoid redundant setup
    - Error propagation: Failures in one component don't affect others
    """
    
    def __init__(self, config: LibraryConfig):
        """
        Initialize factory with configuration.
        
        Args:
            config: LibraryConfig instance specifying library choices
        """
        self.config = config
        self.config.validate_compatibility()
        
        # Lazy initialization caches
        self._llm_client = None
        self._sandbox_executor = None
        self._mcp_server = None
    
    def get_llm_client(self):
        """
        Factory method for LLM client based on configuration.
        
        Returns:
            Configured LLM client instance
            
        Raises:
            ValueError: If unsupported provider specified
            ImportError: If required library not installed
        """
        if self._llm_client is None:
            try:
                if self.config.llm_provider == "anthropic":
                    from anthropic import AsyncAnthropic
                    api_key = self.config.llm_api_key or os.getenv("ANTHROPIC_API_KEY")
                    self._llm_client = AsyncAnthropic(api_key=api_key)
                    
                elif self.config.llm_provider == "openai":
                    from openai import AsyncOpenAI
                    api_key = self.config.llm_api_key or os.getenv("OPENAI_API_KEY")
                    self._llm_client = AsyncOpenAI(api_key=api_key)
                    
                elif self.config.llm_provider == "litellm":
                    import litellm
                    api_key = self.config.llm_api_key or os.getenv("LITELLM_API_KEY")
                    if api_key:
                        litellm.api_key = api_key
                    self._llm_client = litellm
                    
                else:
                    raise ValueError(f"Unsupported LLM provider: {self.config.llm_provider}")
                    
            except ImportError as e:
                raise ImportError(
                    f"Required library for {self.config.llm_provider} not installed. "
                    f"Install with: uv add {self.config.llm_provider}"
                ) from e
        
        return self._llm_client
    
    def get_sandbox_executor(self):
        """
        Factory method for sandbox executor based on configuration.
        
        Returns:
            Configured sandbox executor class or instance
            
        Raises:
            ValueError: If unsupported backend specified
            ImportError: If required library not installed
        """
        if self._sandbox_executor is None:
            try:
                if self.config.sandbox_backend == "llm-sandbox":
                    from llm_sandbox import SandboxSession
                    self._sandbox_executor = SandboxSession
                    
                elif self.config.sandbox_backend == "codejail":
                    from codejail import jail_code
                    self._sandbox_executor = jail_code
                    
                elif self.config.sandbox_backend == "docker":
                    import docker
                    self._sandbox_executor = docker.from_env()
                    
                else:
                    raise ValueError(f"Unsupported sandbox backend: {self.config.sandbox_backend}")
                    
            except ImportError as e:
                raise ImportError(
                    f"Required library for {self.config.sandbox_backend} not installed. "
                    f"Install with: uv add {self.config.sandbox_backend}"
                ) from e
        
        return self._sandbox_executor
    
    def get_mcp_framework(self):
        """
        Factory method for MCP framework based on configuration.
        
        Returns:
            MCP framework class reference
            
        Raises:
            ValueError: If unsupported framework specified
            ImportError: If required library not installed
        """
        if self._mcp_server is None:
            try:
                if self.config.mcp_framework == "fastmcp":
                    from fastmcp import FastMCP
                    self._mcp_server = FastMCP
                    
                elif self.config.mcp_framework == "mcp":
                    from mcp import Server
                    self._mcp_server = Server
                    
                else:
                    raise ValueError(f"Unsupported MCP framework: {self.config.mcp_framework}")
                    
            except ImportError as e:
                raise ImportError(
                    f"Required library for {self.config.mcp_framework} not installed. "
                    f"Install with: uv add {self.config.mcp_framework}"
                ) from e
        
        return self._mcp_server
    
    async def create_codemode_instance(self, tools: Dict[str, Any]) -> "CodeModeInstance":
        """
        Create a fully configured CodeMode instance.
        
        Integrates all configured components (LLM, sandbox, MCP) into a
        working CodeMode system ready for tool execution.
        
        Args:
            tools: Dictionary of available tools
            
        Returns:
            Configured CodeModeInstance
            
        Raises:
            RuntimeError: If component initialization fails
        """
        try:
            # Initialize all components
            llm_client = self.get_llm_client()
            sandbox_executor = self.get_sandbox_executor()
            mcp_framework = self.get_mcp_framework()
            
            # Import CodeModeInstance here to avoid circular imports
            from .instance import CodeModeInstance
            
            # Create integrated instance
            instance = CodeModeInstance(
                llm_client=llm_client,
                sandbox_executor=sandbox_executor,
                mcp_framework=mcp_framework,
                tools=tools,
                config=self.config
            )
            
            return instance
            
        except Exception as e:
            raise RuntimeError(
                f"Failed to create CodeMode instance: {e}"
            ) from e
