"""FastMCP server integration for CodeMode."""

import logging
from typing import Dict, Any, Optional
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)


class CodeModeFastMCPServer:
    """
    MCP server using FastMCP framework for CodeMode.
    
    System Thinking L2 Considerations:
    - Decorator-based registration: Simplifies tool development
    - Context management: Proper resource lifecycle handling
    - Error boundaries: Graceful degradation on tool failures
    """
    
    def __init__(
        self,
        name: str = "codemode-server",
        version: str = "1.0.0"
    ):
        """
        Initialize FastMCP server.
        
        Args:
            name: Server name
            version: Server version
        """
        self.name = name
        self.version = version
        self.mcp = None
        self.codemode_instance = None
    
    def create_server(self, codemode_instance: 'CodeModeInstance'):
        """
        Create FastMCP server with CodeMode integration.
        
        Args:
            codemode_instance: Initialized CodeMode instance
            
        Returns:
            FastMCP server instance
        """
        from fastmcp import FastMCP
        
        self.codemode_instance = codemode_instance
        self.mcp = FastMCP(self.name)
        
        # Register codemode execution tool
        @self.mcp.tool()
        async def execute_code_task(task: str, validate: bool = True) -> Dict[str, Any]:
            """
            Execute a task by generating and running Python code.
            
            Args:
                task: Description of the task to accomplish
                validate: Whether to validate code before execution
                
            Returns:
                Dictionary with execution results
            """
            try:
                result = await self.codemode_instance.execute_task(
                    task=task,
                    validate_code=validate
                )
                return result
            except Exception as e:
                logger.error(f"Code task execution failed: {e}")
                return {
                    "success": False,
                    "result": {"error": str(e)},
                    "generated_code": "",
                    "execution_time": 0.0
                }
        
        # Register tool listing
        @self.mcp.tool()
        async def list_available_tools() -> Dict[str, Any]:
            """
            List all available tools in the CodeMode environment.
            
            Returns:
                Dictionary mapping tool names to their descriptions and schemas
            """
            return self.codemode_instance.get_available_tools()
        
        # Register configuration retrieval
        @self.mcp.tool()
        async def get_configuration() -> Dict[str, Any]:
            """
            Get current CodeMode configuration.
            
            Returns:
                Configuration dictionary (excluding sensitive values)
            """
            return self.codemode_instance.get_config()
        
        # Register resource for type definitions
        @self.mcp.resource("types://codemode/tool-definitions")
        async def get_type_definitions() -> str:
            """
            Get type definitions for all available tools.
            
            Returns:
                Python type definitions as string
            """
            from .type_generation import generate_tool_types
            return generate_tool_types(self.codemode_instance.tools)
        
        # Register resource for documentation
        @self.mcp.resource("docs://codemode/tools")
        async def get_tool_documentation() -> str:
            """
            Get human-readable documentation for tools.
            
            Returns:
                Markdown documentation
            """
            from .type_generation import generate_tool_documentation
            return generate_tool_documentation(self.codemode_instance.tools)
        
        logger.info(f"FastMCP server '{self.name}' created with {len(self.codemode_instance.tools)} tools")
        return self.mcp
    
    async def run(
        self,
        transport: str = "stdio",
        host: Optional[str] = None,
        port: Optional[int] = None
    ):
        """
        Run the MCP server.
        
        Args:
            transport: Transport type ('stdio', 'sse', 'websocket')
            host: Host for network transports
            port: Port for network transports
        """
        if not self.mcp:
            raise RuntimeError("Server not created. Call create_server() first.")
        
        logger.info(f"Starting MCP server with {transport} transport")
        
        if transport == "stdio":
            await self.mcp.run_stdio()
        elif transport == "sse":
            if not host or not port:
                raise ValueError("Host and port required for SSE transport")
            await self.mcp.run_sse(host=host, port=port)
        elif transport == "websocket":
            if not host or not port:
                raise ValueError("Host and port required for WebSocket transport")
            # FastMCP WebSocket support
            logger.warning("WebSocket transport support depends on FastMCP version")
            await self.mcp.run_sse(host=host, port=port)  # Fallback to SSE
        else:
            raise ValueError(f"Unsupported transport: {transport}")


def create_mcp_server_from_config(config_path: str) -> CodeModeFastMCPServer:
    """
    Create MCP server from configuration file.
    
    Args:
        config_path: Path to configuration JSON file
        
    Returns:
        CodeModeFastMCPServer instance
    """
    from .config import LibraryConfig, ConfigurableCodeMode
    from pathlib import Path
    
    # Load configuration
    config = LibraryConfig.from_json(Path(config_path))
    
    # Create factory
    factory = ConfigurableCodeMode(config)
    
    # Tools would be loaded from somewhere (database, config, etc.)
    # For now, return empty dict - this is just the factory pattern
    tools = {}
    
    # Create CodeMode instance
    import asyncio
    instance = asyncio.run(factory.create_codemode_instance(tools))
    
    # Create MCP server
    server = CodeModeFastMCPServer(
        name=f"codemode-{config.llm_provider}",
        version="1.0.0"
    )
    server.create_server(instance)
    
    return server


@asynccontextmanager
async def codemode_server_context(
    tools: Dict[str, Any],
    config: Optional['LibraryConfig'] = None
):
    """
    Async context manager for CodeMode server lifecycle.
    
    Args:
        tools: Dictionary of available tools
        config: Optional LibraryConfig (uses defaults if not provided)
        
    Yields:
        CodeModeFastMCPServer instance
        
    Example:
        ```python
        async with codemode_server_context(tools, config) as server:
            await server.run(transport="stdio")
        ```
    """
    from .config import LibraryConfig, ConfigurableCodeMode
    
    if config is None:
        config = LibraryConfig()
    
    # Create factory and instance
    factory = ConfigurableCodeMode(config)
    instance = await factory.create_codemode_instance(tools)
    
    try:
        # Initialize instance
        await instance.initialize()
        
        # Create server
        server = CodeModeFastMCPServer()
        server.create_server(instance)
        
        yield server
        
    finally:
        # Cleanup
        await instance.cleanup()
        logger.info("CodeMode server context closed")
