"""Type definitions for CodeMode system."""

from typing import Dict, Any, Optional, Callable, List, TypedDict
from dataclasses import dataclass, field
from pydantic import BaseModel, Field
from abc import ABC, abstractmethod


class Tool(BaseModel):
    """
    Tool definition for CodeMode execution.
    
    Tools are functions or operations that can be invoked from generated code.
    Each tool has input/output schemas for validation and type generation.
    """
    
    name: str = Field(description="Unique tool identifier")
    description: str = Field(description="Human-readable tool description")
    input_schema: type[BaseModel] = Field(description="Pydantic model for input validation")
    output_schema: Optional[type[BaseModel]] = Field(
        default=None,
        description="Pydantic model for output validation (optional)"
    )
    execute: Optional[Callable] = Field(
        default=None,
        description="Callable that executes the tool"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional tool metadata"
    )
    
    class Config:
        """Pydantic configuration."""
        arbitrary_types_allowed = True


@dataclass
class CodeModeOptions:
    """
    Configuration options for experimental_codemode function.
    
    Specifies all components and parameters needed to initialize a CodeMode
    execution environment.
    """
    
    tools: Dict[str, Tool]
    prompt: str
    sandbox_backend: Any
    proxy_client: Any
    llm_client: Any
    max_retries: int = 3
    timeout: int = 60
    verbose: bool = False
    additional_context: Dict[str, Any] = field(default_factory=dict)


class CodeModeResult(BaseModel):
    """
    Result from codemode initialization.
    
    Contains the enhanced prompt and wrapped tools ready for LLM consumption.
    """
    
    prompt: str = Field(description="Enhanced system prompt with tool types")
    tools: Dict[str, Tool] = Field(description="Wrapped tools (typically just 'codemode')")
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata about initialization"
    )
    type_definitions: Optional[str] = Field(
        default=None,
        description="Generated type definitions for tools"
    )


@dataclass
class ExecutionResult:
    """
    Result from sandboxed code execution.
    
    Contains execution output, errors, and extracted return values.
    """
    
    success: bool
    output: str
    error: Optional[str] = None
    return_value: Optional[Any] = None
    traceback: Optional[str] = None
    execution_time: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class ProxyBackend(ABC):
    """
    Abstract protocol for proxy backends.
    
    Defines the interface that all proxy backends must implement for
    tool execution from sandboxed environments.
    """
    
    @abstractmethod
    async def call_function(
        self,
        function_name: str,
        args: List[Any],
        kwargs: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Execute a tool function.
        
        Args:
            function_name: Name of the tool to execute
            args: Positional arguments for the tool
            kwargs: Keyword arguments for the tool
            
        Returns:
            Tool execution result
            
        Raises:
            ValueError: If tool not found or invalid arguments
        """
        pass


class ToolInput(TypedDict):
    """Base type for tool inputs."""
    pass


class ToolOutput(TypedDict):
    """Base type for tool outputs."""
    pass


@dataclass
class GeneratedCode:
    """
    Container for LLM-generated code.
    
    Stores the generated code along with metadata about the generation process.
    """
    
    code: str
    language: str = "python"
    model_used: str = ""
    tokens_used: int = 0
    generation_time: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ValidationResult:
    """
    Result from code validation.
    
    Contains information about whether code passed validation and any issues found.
    """
    
    is_valid: bool
    issues: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class SandboxConfig(BaseModel):
    """Configuration for sandbox execution environment."""
    
    backend: str = Field(description="Sandbox backend identifier")
    timeout: int = Field(default=60, gt=0, description="Execution timeout in seconds")
    memory_limit: str = Field(default="512m", description="Memory limit")
    cpu_limit: float = Field(default=1.0, gt=0.0, description="CPU cores limit")
    keep_template: bool = Field(default=False, description="Keep sandbox template")
    network_enabled: bool = Field(default=False, description="Allow network access")
    allowed_imports: Optional[List[str]] = Field(
        default=None,
        description="Whitelist of allowed imports (None = all allowed)"
    )
    
    class Config:
        """Pydantic configuration."""
        validate_assignment = True


class LLMConfig(BaseModel):
    """Configuration for LLM client."""
    
    provider: str = Field(description="LLM provider name")
    model: str = Field(description="Model identifier")
    api_key: Optional[str] = Field(default=None, description="API key")
    temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="Sampling temperature")
    max_tokens: int = Field(default=4000, gt=0, description="Maximum response tokens")
    top_p: Optional[float] = Field(default=None, ge=0.0, le=1.0, description="Nucleus sampling")
    frequency_penalty: Optional[float] = Field(
        default=None,
        ge=-2.0,
        le=2.0,
        description="Frequency penalty"
    )
    presence_penalty: Optional[float] = Field(
        default=None,
        ge=-2.0,
        le=2.0,
        description="Presence penalty"
    )
    
    class Config:
        """Pydantic configuration."""
        validate_assignment = True


@dataclass
class MCPContext:
    """Context information for MCP server operations."""
    
    server_name: str
    transport: str
    tools: Dict[str, Tool]
    resources: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


class ToolRegistration(BaseModel):
    """Registration information for a tool in MCP server."""
    
    name: str
    description: str
    input_schema: Dict[str, Any]
    output_schema: Optional[Dict[str, Any]] = None
    tags: List[str] = Field(default_factory=list)
    examples: List[Dict[str, Any]] = Field(default_factory=list)
    
    class Config:
        """Pydantic configuration."""
        validate_assignment = True
