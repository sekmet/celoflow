"""Type generation utilities for CodeMode tools."""

from typing import Dict, Any, get_origin, get_args, Union
from pydantic import BaseModel
import inspect


def to_pascal_case(snake_str: str) -> str:
    """
    Convert snake_case to PascalCase.
    
    Args:
        snake_str: String in snake_case format
        
    Returns:
        String in PascalCase format
    """
    components = snake_str.split('_')
    return ''.join(x.title() for x in components)


def to_camel_case(snake_str: str) -> str:
    """
    Convert snake_case to camelCase.
    
    Args:
        snake_str: String in snake_case format
        
    Returns:
        String in camelCase format
    """
    components = snake_str.split('_')
    return components[0] + ''.join(x.title() for x in components[1:])


def get_type_string(annotation: Any) -> str:
    """
    Convert Python type annotation to string representation.
    
    Handles generic types (List, Dict, Union, Optional) and basic types.
    
    Args:
        annotation: Python type annotation
        
    Returns:
        String representation of the type
    """
    # Handle None type
    if annotation is type(None):
        return "None"
    
    # Handle generic types
    origin = get_origin(annotation)
    
    if origin is list:
        args = get_args(annotation)
        if args:
            return f"List[{get_type_string(args[0])}]"
        return "List[Any]"
    
    elif origin is dict:
        args = get_args(annotation)
        if len(args) == 2:
            return f"Dict[{get_type_string(args[0])}, {get_type_string(args[1])}]"
        return "Dict[str, Any]"
    
    elif origin is Union:
        args = get_args(annotation)
        # Check if it's Optional (Union with None)
        if len(args) == 2 and type(None) in args:
            non_none = args[0] if args[1] is type(None) else args[1]
            return f"Optional[{get_type_string(non_none)}]"
        return f"Union[{', '.join(get_type_string(a) for a in args)}]"
    
    elif origin is tuple:
        args = get_args(annotation)
        if args:
            return f"Tuple[{', '.join(get_type_string(a) for a in args)}]"
        return "Tuple"
    
    # Handle basic types
    if hasattr(annotation, '__name__'):
        return annotation.__name__
    
    # Fallback to string representation
    return str(annotation)


def pydantic_to_typing(model: type[BaseModel], class_name: str) -> str:
    """
    Convert Pydantic model to TypedDict definition string.
    
    Args:
        model: Pydantic model class
        class_name: Name for the generated TypedDict
        
    Returns:
        String containing TypedDict definition
    """
    fields = model.model_fields
    field_types = []
    
    for field_name, field_info in fields.items():
        python_type = field_info.annotation
        type_str = get_type_string(python_type)
        
        # Add field with type annotation
        if field_info.description:
            field_types.append(f'    {field_name}: {type_str}  # {field_info.description}')
        else:
            field_types.append(f'    {field_name}: {type_str}')
    
    if not field_types:
        field_types.append('    pass')
    
    return f"""class {class_name}(TypedDict):
    \"\"\"Generated type definition for {model.__name__}\"\"\"
{chr(10).join(field_types)}"""


def generate_tool_types(tools: Dict[str, Any]) -> str:
    """
    Generate Python type hints and function signatures from tools.
    
    Creates TypedDict definitions for input/output schemas and async function
    signatures that can be used in LLM-generated code.
    
    Args:
        tools: Dictionary mapping tool names to Tool objects
        
    Returns:
        String containing all type definitions and function signatures
    """
    type_definitions = [
        "from typing import TypedDict, Optional, List, Dict, Any, Union, Tuple",
        "",
        "# Tool Type Definitions",
        ""
    ]
    
    for tool_name, tool in tools.items():
        # Generate input type
        if hasattr(tool, 'input_schema') and tool.input_schema:
            input_type_def = pydantic_to_typing(
                tool.input_schema,
                f"{to_pascal_case(tool_name)}Input"
            )
            type_definitions.append(input_type_def)
            type_definitions.append("")
        
        # Generate output type
        if hasattr(tool, 'output_schema') and tool.output_schema:
            output_type_def = pydantic_to_typing(
                tool.output_schema,
                f"{to_pascal_case(tool_name)}Output"
            )
            type_definitions.append(output_type_def)
            type_definitions.append("")
    
    # Generate function signatures
    type_definitions.append("# Tool Functions")
    type_definitions.append("")
    
    for tool_name, tool in tools.items():
        input_type = f"{to_pascal_case(tool_name)}Input"
        output_type = f"{to_pascal_case(tool_name)}Output" if hasattr(tool, 'output_schema') and tool.output_schema else "Any"
        
        description = tool.description if hasattr(tool, 'description') else f"Execute {tool_name}"
        
        func_signature = f'''async def {tool_name}(input: {input_type}) -> {output_type}:
    """
    {description}
    
    Args:
        input: Tool input parameters
        
    Returns:
        Tool execution result
    """
    # This function is implemented by the proxy
    # Do not call directly - use tools.{tool_name}(input)
    pass'''
        
        type_definitions.append(func_signature)
        type_definitions.append("")
    
    return "\n".join(type_definitions)


def generate_tool_documentation(tools: Dict[str, Any]) -> str:
    """
    Generate human-readable documentation for available tools.
    
    Args:
        tools: Dictionary mapping tool names to Tool objects
        
    Returns:
        Formatted documentation string
    """
    docs = ["# Available Tools\n"]
    
    for tool_name, tool in tools.items():
        docs.append(f"## {tool_name}")
        docs.append("")
        
        if hasattr(tool, 'description'):
            docs.append(tool.description)
            docs.append("")
        
        # Input schema
        if hasattr(tool, 'input_schema') and tool.input_schema:
            docs.append("**Input:**")
            docs.append("```python")
            docs.append(pydantic_to_typing(tool.input_schema, f"{to_pascal_case(tool_name)}Input"))
            docs.append("```")
            docs.append("")
        
        # Output schema
        if hasattr(tool, 'output_schema') and tool.output_schema:
            docs.append("**Output:**")
            docs.append("```python")
            docs.append(pydantic_to_typing(tool.output_schema, f"{to_pascal_case(tool_name)}Output"))
            docs.append("```")
            docs.append("")
        
        # Example usage
        docs.append("**Example:**")
        docs.append("```python")
        docs.append(f"result = await tools.{tool_name}({{")
        
        if hasattr(tool, 'input_schema') and tool.input_schema:
            fields = tool.input_schema.model_fields
            for i, (field_name, field_info) in enumerate(fields.items()):
                type_str = get_type_string(field_info.annotation)
                example_val = get_example_value(type_str)
                comma = "," if i < len(fields) - 1 else ""
                docs.append(f"    '{field_name}': {example_val}{comma}")
        
        docs.append("})")
        docs.append("```")
        docs.append("")
    
    return "\n".join(docs)


def get_example_value(type_str: str) -> str:
    """
    Get example value for a type string.
    
    Args:
        type_str: String representation of a type
        
    Returns:
        Example value as string
    """
    if "str" in type_str.lower():
        return "'example'"
    elif "int" in type_str.lower():
        return "42"
    elif "float" in type_str.lower():
        return "3.14"
    elif "bool" in type_str.lower():
        return "True"
    elif "list" in type_str.lower():
        return "[]"
    elif "dict" in type_str.lower():
        return "{}"
    else:
        return "..."


def validate_generated_types(type_definitions: str) -> bool:
    """
    Validate that generated type definitions are syntactically correct Python.
    
    Args:
        type_definitions: String containing type definitions
        
    Returns:
        True if valid, False otherwise
    """
    try:
        compile(type_definitions, '<string>', 'exec')
        return True
    except SyntaxError:
        return False
