"""Main entry point for CodeMode MCP server."""

import asyncio
import logging
import os
import sys
from pathlib import Path

from config import LibraryConfig, ConfigurableCodeMode
from mcp_server import CodeModeFastMCPServer
from utils import setup_logging


async def create_default_tools():
    """Create a set of default tools for demonstration."""
    from pydantic import BaseModel, Field
    from models import Tool
    
    # Echo tool
    class EchoInput(BaseModel):
        message: str = Field(description="Message to echo")
    
    class EchoOutput(BaseModel):
        echo: str = Field(description="Echoed message")
    
    async def echo_tool(message: str) -> dict:
        return {"echo": message}
    
    # Math tool
    class MathInput(BaseModel):
        operation: str = Field(description="Operation: add, subtract, multiply, divide")
        a: float = Field(description="First number")
        b: float = Field(description="Second number")
    
    class MathOutput(BaseModel):
        result: float = Field(description="Result of operation")
    
    async def math_tool(operation: str, a: float, b: float) -> dict:
        ops = {
            "add": a + b,
            "subtract": a - b,
            "multiply": a * b,
            "divide": a / b if b != 0 else float('inf')
        }
        return {"result": ops.get(operation, 0.0)}
    
    return {
        "echo": Tool(
            name="echo",
            description="Echo back a message",
            input_schema=EchoInput,
            output_schema=EchoOutput,
            execute=echo_tool
        ),
        "math": Tool(
            name="math",
            description="Perform basic mathematical operations",
            input_schema=MathInput,
            output_schema=MathOutput,
            execute=math_tool
        )
    }


async def main():
    """Main function to run CodeMode MCP server."""
    # Setup logging
    log_level = os.getenv("CODEMODE_LOG_LEVEL", "INFO")
    setup_logging(level=log_level)
    
    logger = logging.getLogger(__name__)
    logger.info("Starting CodeMode MCP Server...")
    
    try:
        # Load configuration
        config_file = os.getenv("CODEMODE_CONFIG_FILE")
        if config_file and Path(config_file).exists():
            logger.info(f"Loading configuration from {config_file}")
            config = LibraryConfig.from_json(Path(config_file))
        else:
            logger.info("Using configuration from environment variables")
            config = LibraryConfig.from_env()
        
        logger.info(f"Configuration loaded:")
        logger.info(f"  LLM Provider: {config.llm_provider}")
        logger.info(f"  LLM Model: {config.llm_model}")
        logger.info(f"  Sandbox Backend: {config.sandbox_backend}")
        logger.info(f"  MCP Framework: {config.mcp_framework}")
        logger.info(f"  MCP Transport: {config.mcp_transport}")
        
        # Create default tools (or load from configuration)
        tools = await create_default_tools()
        logger.info(f"Loaded {len(tools)} tools: {list(tools.keys())}")
        
        # Create factory and instance
        logger.info("Creating CodeMode instance...")
        factory = ConfigurableCodeMode(config)
        instance = await factory.create_codemode_instance(tools)
        
        # Initialize instance
        logger.info("Initializing CodeMode...")
        await instance.initialize()
        
        # Create MCP server
        server_name = os.getenv("CODEMODE_SERVER_NAME", "codemode-server")
        server = CodeModeFastMCPServer(name=server_name, version="1.0.0")
        server.create_server(instance)
        
        logger.info(f"MCP Server '{server_name}' created successfully")
        
        # Determine transport
        transport = config.mcp_transport
        host = os.getenv("CODEMODE_HOST", "localhost")
        port = int(os.getenv("CODEMODE_PORT", "8080"))
        
        logger.info(f"Starting server with {transport} transport...")
        
        # Run server
        try:
            if transport == "stdio":
                logger.info("Running with stdio transport")
                await server.run(transport="stdio")
            elif transport == "sse":
                logger.info(f"Running with SSE transport on {host}:{port}")
                await server.run(transport="sse", host=host, port=port)
            elif transport == "websocket":
                logger.info(f"Running with WebSocket transport on {host}:{port}")
                await server.run(transport="websocket", host=host, port=port)
            else:
                logger.error(f"Unsupported transport: {transport}")
                sys.exit(1)
        finally:
            # Cleanup
            logger.info("Shutting down...")
            await instance.cleanup()
            logger.info("Shutdown complete")
    
    except KeyboardInterrupt:
        logger.info("Received interrupt signal, shutting down...")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown complete")
