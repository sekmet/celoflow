"""Proxy system for tool access from sandboxed code."""

import asyncio
import logging
from typing import Any, List, Dict, Optional
import httpx

from .models import ProxyBackend, Tool

logger = logging.getLogger(__name__)


class HTTPProxyBackend:
    """
    HTTP-based proxy for remote tool execution.
    
    System Thinking L2 Considerations:
    - Network latency: Implements retry logic and connection pooling
    - Transient failures: Exponential backoff for fault tolerance
    - Performance: Connection pooling reduces overhead
    """
    
    def __init__(
        self,
        base_url: str,
        timeout: int = 30,
        max_retries: int = 3,
        api_key: Optional[str] = None
    ):
        """
        Initialize HTTP proxy backend.
        
        Args:
            base_url: Base URL for proxy server
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts
            api_key: Optional API key for authentication
        """
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries
        self.api_key = api_key
        
        # Configure HTTP client with connection pooling
        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        
        self.client = httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            headers=headers,
            limits=httpx.Limits(
                max_connections=100,
                max_keepalive_connections=20
            )
        )
    
    async def call_function(
        self,
        function_name: str,
        args: List[Any],
        kwargs: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Call tool via HTTP with retry logic.
        
        Args:
            function_name: Name of tool to execute
            args: Positional arguments
            kwargs: Keyword arguments
            
        Returns:
            Tool execution result
            
        Raises:
            httpx.HTTPError: If all retry attempts fail
        """
        kwargs = kwargs or {}
        
        for attempt in range(self.max_retries):
            try:
                response = await self.client.post(
                    "/call",
                    json={
                        "function": function_name,
                        "args": args,
                        "kwargs": kwargs
                    }
                )
                response.raise_for_status()
                result = response.json()
                return result.get("result")
                
            except httpx.HTTPError as e:
                if attempt == self.max_retries - 1:
                    logger.error(
                        f"HTTP proxy call failed after {self.max_retries} attempts: {e}"
                    )
                    raise
                
                # Exponential backoff
                wait_time = 2 ** attempt
                logger.warning(
                    f"HTTP proxy attempt {attempt + 1} failed, retrying in {wait_time}s: {e}"
                )
                await asyncio.sleep(wait_time)
    
    async def close(self):
        """Close HTTP client."""
        await self.client.aclose()


class DirectProxyBackend:
    """
    Direct function call proxy without network overhead.
    
    Use only for trusted environments where sandboxing is not critical.
    Executes tools directly in the current process.
    """
    
    def __init__(self, tools: Dict[str, Tool]):
        """
        Initialize direct proxy backend.
        
        Args:
            tools: Dictionary of available tools
        """
        self.tools = tools
    
    async def call_function(
        self,
        function_name: str,
        args: List[Any],
        kwargs: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Execute tool directly in current process.
        
        Args:
            function_name: Name of tool to execute
            args: Positional arguments
            kwargs: Keyword arguments
            
        Returns:
            Tool execution result
            
        Raises:
            ValueError: If tool not found
        """
        kwargs = kwargs or {}
        
        if function_name not in self.tools:
            raise ValueError(
                f"Tool '{function_name}' not found. "
                f"Available: {list(self.tools.keys())}"
            )
        
        tool = self.tools[function_name]
        
        # Execute tool
        if tool.execute:
            if asyncio.iscoroutinefunction(tool.execute):
                return await tool.execute(*args, **kwargs)
            else:
                return tool.execute(*args, **kwargs)
        else:
            raise ValueError(f"Tool '{function_name}' has no execute method")


class CodeModeProxy:
    """
    Main proxy class for tool access from sandboxed code.
    
    Validates inputs against tool schemas, delegates execution to backend,
    and validates outputs for type safety.
    
    System Thinking L2:
    - Input validation: Prevents invalid data from reaching tools
    - Backend abstraction: Supports multiple execution strategies
    - Error handling: Graceful degradation on validation failures
    """
    
    def __init__(
        self,
        backend: ProxyBackend,
        tools: Dict[str, Tool],
        validate_outputs: bool = True
    ):
        """
        Initialize code mode proxy.
        
        Args:
            backend: Proxy backend for tool execution
            tools: Dictionary of available tools
            validate_outputs: Whether to validate tool outputs
        """
        self.backend = backend
        self.tools = tools
        self.validate_outputs = validate_outputs
    
    async def call_function(
        self,
        function_name: str,
        args: List[Any],
        kwargs: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Call a tool through the proxy with validation.
        
        Args:
            function_name: Name of tool to execute
            args: Positional arguments
            kwargs: Keyword arguments
            
        Returns:
            Validated tool execution result
            
        Raises:
            ValueError: If tool not found or validation fails
        """
        # Validate tool exists
        if function_name not in self.tools:
            raise ValueError(
                f"Unknown tool: {function_name}. "
                f"Available: {list(self.tools.keys())}"
            )
        
        tool = self.tools[function_name]
        
        # Validate input schema
        try:
            if len(args) == 1 and isinstance(args[0], dict):
                # Validate using Pydantic model
                if tool.input_schema:
                    validated_input = tool.input_schema(**args[0])
                    validated_args = [validated_input.model_dump()]
                else:
                    validated_args = args
            else:
                # Multiple args or non-dict arg
                validated_args = args
                
        except Exception as e:
            raise ValueError(
                f"Invalid input for tool '{function_name}': {e}"
            ) from e
        
        # Execute through backend
        try:
            result = await self.backend.call_function(
                function_name,
                validated_args,
                kwargs or {}
            )
        except Exception as e:
            logger.error(f"Tool execution failed for '{function_name}': {e}")
            raise
        
        # Validate output schema if configured
        if self.validate_outputs and tool.output_schema:
            try:
                if isinstance(result, dict):
                    validated_output = tool.output_schema(**result)
                    return validated_output.model_dump()
                else:
                    logger.warning(
                        f"Output validation skipped for '{function_name}': "
                        f"result is not a dict"
                    )
            except Exception as e:
                # Log but don't fail on output validation
                logger.warning(
                    f"Output validation failed for '{function_name}': {e}"
                )
        
        return result
    
    def get_tool_data(self) -> Dict[str, Any]:
        """
        Get serializable tool metadata for injection into sandbox.
        
        Returns:
            Dictionary with tool names and descriptions
        """
        return {
            "available_tools": list(self.tools.keys()),
            "tool_descriptions": {
                name: tool.description
                for name, tool in self.tools.items()
            },
            "tool_schemas": {
                name: {
                    "input": (
                        tool.input_schema.model_json_schema()
                        if tool.input_schema else None
                    ),
                    "output": (
                        tool.output_schema.model_json_schema()
                        if tool.output_schema else None
                    )
                }
                for name, tool in self.tools.items()
            }
        }
    
    async def close(self):
        """Clean up proxy resources."""
        if hasattr(self.backend, 'close'):
            await self.backend.close()
