"""MCP Adapter Layer for CodeMode.

This module provides conversion utilities between Contextwise MCP tools
and the lib/codemode Tool model, enabling MCP tools to be used from
within CodeMode-generated code.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional, Type, TYPE_CHECKING

from pydantic import BaseModel, Field, create_model

from .models import Tool

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def json_schema_to_pydantic_model(
    name: str,
    schema: Dict[str, Any],
) -> Type[BaseModel]:
    """Convert a JSON schema to a Pydantic model dynamically.
    
    Args:
        name: Name for the generated model
        schema: JSON schema dict with properties, required, etc.
        
    Returns:
        Dynamically created Pydantic model class
    """
    properties = schema.get("properties", {})
    required = set(schema.get("required", []))
    
    if not properties:
        class PermissiveInput(BaseModel):
            """Permissive input model when schema is not provided."""
            payload: Dict[str, Any] = Field(default_factory=dict)
            
            class Config:
                extra = "allow"
        
        return PermissiveInput
    
    field_definitions = {}
    
    for prop_name, prop_schema in properties.items():
        python_type = _json_type_to_python_type(prop_schema)
        description = prop_schema.get("description", "")
        default = prop_schema.get("default", ...)
        
        if prop_name not in required and default is ...:
            default = None
            if python_type is str:
                python_type = Optional[str]
            elif python_type is int:
                python_type = Optional[int]
            elif python_type is float:
                python_type = Optional[float]
            elif python_type is bool:
                python_type = Optional[bool]
            elif python_type is list:
                python_type = Optional[list]
            elif python_type is dict:
                python_type = Optional[dict]
            else:
                python_type = Optional[Any]
        
        field_definitions[prop_name] = (python_type, Field(default=default, description=description))
    
    try:
        model = create_model(name, **field_definitions)
        return model
    except Exception as e:
        logger.warning(f"Failed to create Pydantic model for {name}: {e}")
        
        class FallbackInput(BaseModel):
            """Fallback input model when schema conversion fails."""
            payload: Dict[str, Any] = Field(default_factory=dict)
            
            class Config:
                extra = "allow"
        
        return FallbackInput


def _json_type_to_python_type(prop_schema: Dict[str, Any]) -> type:
    """Convert JSON schema type to Python type."""
    json_type = prop_schema.get("type", "string")
    
    type_map = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
        "null": type(None),
    }
    
    if isinstance(json_type, list):
        json_type = json_type[0] if json_type else "string"
    
    return type_map.get(json_type, Any)


def tool_from_mcp_tool(
    name: str,
    mcp_tool: Any,
    mcp_server: Any,
) -> Tool:
    """Convert an MCPTool to a lib/codemode Tool.
    
    Args:
        name: Tool name
        mcp_tool: MCPTool instance from contextwise.mcp
        mcp_server: MCPServer instance that owns this tool
        
    Returns:
        Tool instance compatible with lib/codemode
    """
    description = getattr(mcp_tool, 'description', "") or ""
    input_schema_dict = getattr(mcp_tool, 'input_schema', {}) or {}
    
    input_model = json_schema_to_pydantic_model(
        f"{_to_pascal_case(name)}Input",
        input_schema_dict,
    )
    
    async def execute_mcp_tool(**kwargs) -> Any:
        """Execute the MCP tool via its server."""
        try:
            if hasattr(mcp_server, 'call_tool'):
                result = await mcp_server.call_tool(name, kwargs)
                return result
            elif callable(mcp_tool):
                result = await mcp_tool(**kwargs)
                return result
            else:
                raise ValueError(f"Cannot execute MCP tool {name}: no call method")
        except Exception as e:
            logger.error(f"Error executing MCP tool {name}: {e}")
            raise
    
    return Tool(
        name=name,
        description=description,
        input_schema=input_model,
        output_schema=None,
        execute=execute_mcp_tool,
        metadata={
            "source": "mcp",
            "server": getattr(mcp_server, 'name', 'unknown'),
            "original_schema": input_schema_dict,
        },
    )


async def tools_from_mcp_servers(mcp_servers: List[Any]) -> Dict[str, Tool]:
    """Convert all tools from MCP servers to lib/codemode Tools.
    
    Args:
        mcp_servers: List of MCPServer instances
        
    Returns:
        Dictionary mapping tool names to Tool instances
    """
    result = {}
    
    for server in mcp_servers:
        tools_dict = getattr(server, '_tools', {})
        
        for name, mcp_tool in tools_dict.items():
            try:
                tool = tool_from_mcp_tool(name, mcp_tool, server)
                result[name] = tool
                logger.debug(f"Converted MCP tool '{name}' from server '{getattr(server, 'name', 'unknown')}'")
            except Exception as e:
                logger.warning(f"Failed to convert MCP tool '{name}': {e}")
    
    return result


def tools_from_mcp_servers_sync(mcp_servers: List[Any]) -> Dict[str, Tool]:
    """Synchronous version of tools_from_mcp_servers.
    
    This is used for best-effort registration before servers connect.
    
    Args:
        mcp_servers: List of MCPServer instances
        
    Returns:
        Dictionary mapping tool names to Tool instances
    """
    result = {}
    
    for server in mcp_servers:
        tools_dict = getattr(server, '_tools', {})
        
        for name, mcp_tool in tools_dict.items():
            try:
                tool = tool_from_mcp_tool(name, mcp_tool, server)
                result[name] = tool
            except Exception as e:
                logger.warning(f"Failed to convert MCP tool '{name}': {e}")
    
    return result


def create_tool_caller_from_mcp(mcp_servers: List[Any]) -> Callable:
    """Create a _call_tool function that routes to MCP servers.
    
    This function is injected into the sandbox execution context
    to allow generated code to call MCP tools.
    
    Args:
        mcp_servers: List of MCPServer instances
        
    Returns:
        Async callable that routes tool calls to appropriate servers
    """
    server_tool_map: Dict[str, Any] = {}
    
    for server in mcp_servers:
        tools_dict = getattr(server, '_tools', {})
        for name in tools_dict:
            server_tool_map[name] = server
    
    async def _call_tool(tool_name: str, args: Dict[str, Any]) -> str:
        """Call an MCP tool by name.
        
        Args:
            tool_name: Name of the tool to call
            args: Arguments to pass to the tool
            
        Returns:
            Tool result as string
            
        Raises:
            ValueError: If tool is not found
        """
        if tool_name not in server_tool_map:
            available = list(server_tool_map.keys())
            raise ValueError(f"Unknown tool: {tool_name}. Available: {available}")
        
        server = server_tool_map[tool_name]
        
        args = {k: v for k, v in args.items() if k != "tool_name" and v is not None}
        
        try:
            result = await server.call_tool(tool_name, args)
            return str(result)
        except Exception as e:
            return f"Error calling {tool_name}: {e}"
    
    return _call_tool


def _to_pascal_case(name: str) -> str:
    """Convert snake_case or kebab-case to PascalCase."""
    parts = name.replace("-", "_").split("_")
    return "".join(part.capitalize() for part in parts)


def validate_tool_schema(tool: Tool) -> bool:
    """Validate that a Tool has a valid schema configuration.
    
    Args:
        tool: Tool instance to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not tool.name:
        return False
    
    if tool.input_schema is None:
        return False
    
    try:
        if hasattr(tool.input_schema, 'model_json_schema'):
            tool.input_schema.model_json_schema()
        return True
    except Exception:
        return False
