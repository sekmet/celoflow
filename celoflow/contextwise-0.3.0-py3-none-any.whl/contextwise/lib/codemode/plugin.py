"""CodeMode Core Plugin - Integrates CodeMode as a first-class Contextwise plugin.

This plugin provides the authoritative CodeMode implementation integrated through
the PluginManager, replacing special-case wiring in Agent._build().
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING, Union

from pydantic import BaseModel, Field

from ..base import AgentPlugin, PluginMetadata

if TYPE_CHECKING:
    from agents import Agent, RunConfig, RunResult
    from .models import Tool

logger = logging.getLogger(__name__)


class CodeModeConfig(BaseModel):
    """Configuration for CodeModeCorePlugin.
    
    This config unifies settings from both the lightweight CodeMode and
    the full lib/codemode implementation.
    """
    
    sandbox_backend: str = Field(
        default="docker",
        description="Sandbox backend: 'docker', 'llm-sandbox', 'codejail', 'none'"
    )
    timeout: int = Field(default=60, gt=0, description="Execution timeout in seconds")
    memory_limit: str = Field(default="512m", description="Memory limit for sandbox")
    cpu_limit: float = Field(default=1.0, gt=0.0, description="CPU cores limit")
    max_retries: int = Field(default=3, ge=0, description="Maximum retry attempts")
    enable_network: bool = Field(default=False, description="Allow network access in sandbox")
    validate_code: bool = Field(default=True, description="Enable LLM code validation")
    keep_template: bool = Field(default=False, description="Keep sandbox template")
    
    llm_provider: str = Field(default="openai", description="LLM provider for code generation")
    llm_model: str = Field(default="gpt-4o-mini", description="Model for code generation")
    llm_api_key: Optional[str] = Field(default=None, description="API key (falls back to env)")
    llm_temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="Sampling temperature")
    
    enable_execute_code_tool: bool = Field(
        default=True,
        description="Also expose legacy execute_code tool for compatibility"
    )
    
    class Config:
        """Pydantic configuration."""
        validate_assignment = True


@dataclass
class CodeModeCorePlugin(AgentPlugin):
    """CodeMode core plugin integrated through PluginManager.
    
    This plugin provides:
    1. `codemode(task)` tool - full task-oriented code generation + execution
    2. `execute_code(code)` tool - raw code execution (backwards compatibility)
    3. Instruction augmentation with CodeMode capabilities
    4. MCP tool registration for sandbox access
    
    Example:
        >>> from contextwise import Agent
        >>> from contextwise.lib.codemode import CodeModeCorePlugin, CodeModeConfig
        >>> 
        >>> plugin = CodeModeCorePlugin(config=CodeModeConfig(sandbox_backend="docker"))
        >>> agent = Agent(
        ...     model="gpt-4o-mini",
        ...     plugins=[plugin],
        ... )
    """
    
    id: str = "codemode"
    name: str = "CodeMode"
    version: str = "0.2.0"
    
    config: CodeModeConfig = field(default_factory=CodeModeConfig)
    
    _instance: Optional[Any] = field(default=None, repr=False, init=False)
    _proxy: Optional[Any] = field(default=None, repr=False, init=False)
    _executor: Optional[Any] = field(default=None, repr=False, init=False)
    _llm_client: Optional[Any] = field(default=None, repr=False, init=False)
    _tools: Dict[str, Any] = field(default_factory=dict, repr=False, init=False)
    _mcp_tools: Dict[str, Any] = field(default_factory=dict, repr=False, init=False)
    _initialized: bool = field(default=False, repr=False, init=False)
    
    def __post_init__(self):
        """Initialize internal components."""
        self._initialize_components()
    
    def _initialize_components(self) -> None:
        """Initialize executor, proxy, and LLM client."""
        if self._initialized:
            return
        
        try:
            from .executor import CodeExecutor
            from .proxy import CodeModeProxy, DirectProxyBackend
            from .llm_client import LLMClient
            
            self._executor = CodeExecutor(
                backend=self.config.sandbox_backend,
                timeout=self.config.timeout,
                memory_limit=self.config.memory_limit,
                cpu_limit=self.config.cpu_limit,
                keep_template=self.config.keep_template,
                verbose=False,
            )
            
            backend = DirectProxyBackend({})
            self._proxy = CodeModeProxy(
                backend=backend,
                tools={},
                validate_outputs=True,
            )
            
            self._llm_client = LLMClient(
                provider=self.config.llm_provider,
                model=self.config.llm_model,
                api_key=self.config.llm_api_key,
                temperature=self.config.llm_temperature,
            )
            
            self._initialized = True
            logger.debug("CodeModeCorePlugin components initialized")
            
        except Exception as e:
            logger.warning(f"Could not initialize full CodeMode components: {e}")
            self._initialized = False
    
    @property
    def metadata(self) -> PluginMetadata:
        """Return plugin metadata."""
        return PluginMetadata(
            id=self.id,
            name=self.name,
            version=self.version,
            description="CodeMode - LLM-powered code generation and execution",
            dependencies=[],
            tags=["codemode", "sandbox", "code-execution"],
        )
    
    def dependencies(self) -> List[str]:
        """Return plugin ids that must be loaded before this plugin."""
        return []
    
    def configure_agent(self, agent: "Agent") -> "Agent":
        """Configure agent with CodeMode tools and enhanced instructions.
        
        Args:
            agent: SDK Agent instance
            
        Returns:
            Agent with CodeMode tools added
        """
        tools = list(agent.tools) if agent.tools else []
        tools.extend(self.get_tools())
        
        enhanced_instructions = self._get_enhanced_instructions(agent.instructions)
        
        return agent.clone(
            tools=tools,
            instructions=enhanced_instructions,
        )
    
    def configure_run_config(
        self,
        context: Any,
        base_config: Optional["RunConfig"],
    ) -> Optional["RunConfig"]:
        """Optionally extend the run configuration."""
        return base_config
    
    def on_before_run(self, context: Any, input: str) -> None:
        """Hook invoked before each run starts."""
        pass
    
    def on_after_run(self, context: Any, result: "RunResult") -> None:
        """Hook invoked after each completed run."""
        pass
    
    def get_tools(self) -> List[Any]:
        """Get tools provided by this plugin.
        
        Returns:
            List containing codemode and optionally execute_code tools
        """
        from agents import function_tool
        
        tools = []
        
        @function_tool
        async def codemode(
            task: str,
            max_retries: Optional[int] = None,
            validate_code: Optional[bool] = None,
        ) -> str:
            """Generate and execute Python code to accomplish a task.
            
            Use this tool when you need to:
            - Perform complex calculations or data processing
            - Chain multiple tool calls together programmatically
            - Execute algorithms or transformations
            - Interact with MCP tools via generated code
            
            Args:
                task: Description of the task to accomplish
                max_retries: Maximum retry attempts (default: from config)
                validate_code: Whether to validate code before execution (default: from config)
            
            Returns:
                JSON string with execution result containing:
                - success: boolean indicating if task succeeded
                - result: the task output or error details
                - generated_code: the Python code that was generated
                - execution_time: how long execution took
                - attempts: number of attempts made
            """
            import json
            
            retries = max_retries if max_retries is not None else self.config.max_retries
            validate = validate_code if validate_code is not None else self.config.validate_code
            
            result = await self._execute_task(task, retries, validate)
            return json.dumps(result)
        
        tools.append(codemode)
        
        if self.config.enable_execute_code_tool:
            @function_tool
            async def execute_code(code: str) -> str:
                """Execute Python code directly in a secure sandbox.
                
                Use this tool when you have pre-written Python code to execute.
                For complex tasks, prefer the 'codemode' tool which generates code for you.
                
                Args:
                    code: Python code to execute. Store your result in a variable named 'result'.
                
                Returns:
                    JSON string with execution result containing:
                    - success: boolean indicating if execution succeeded
                    - result: the value of the 'result' variable if defined
                    - stdout: any printed output
                    - error: error message if execution failed
                """
                import json
                
                result = await self._execute_code_raw(code)
                return json.dumps(result)
            
            tools.append(execute_code)
        
        return tools
    
    async def _execute_task(
        self,
        task: str,
        max_retries: int,
        validate_code: bool,
    ) -> Dict[str, Any]:
        """Execute a task using the full codemode pattern.
        
        This implements the task -> generate code -> validate -> execute -> retry loop.
        """
        import time
        
        if not self._initialized:
            self._initialize_components()
        
        if not self._initialized:
            return {
                "success": False,
                "result": {"error": "CodeMode components not initialized"},
                "generated_code": "",
                "execution_time": 0,
                "attempts": 0,
            }
        
        from .type_generation import generate_tool_types
        
        start_time = time.time()
        last_error = None
        code = ""
        
        all_tools = {**self._tools, **self._mcp_tools}
        
        for attempt in range(max_retries):
            try:
                logger.debug(f"Executing task (attempt {attempt + 1}/{max_retries}): {task}")
                
                type_defs = generate_tool_types(all_tools) if all_tools else ""
                
                code = await self._llm_client.generate_code(
                    prompt=task,
                    available_tools=type_defs,
                )
                
                logger.debug(f"Generated code:\n{code}")
                
                is_valid, error = self._llm_client.compile_check(code)
                if not is_valid:
                    logger.warning(f"Compile check failed: {error}")
                    last_error = f"Compilation error: {error}"
                    if attempt == max_retries - 1:
                        break
                    continue
                
                if validate_code:
                    is_safe, issues = await self._llm_client.validate_code(code, strict=True)
                    if not is_safe:
                        logger.warning(f"Validation failed: {issues}")
                        last_error = f"Code validation failed: {issues}"
                        if attempt == max_retries - 1:
                            break
                        continue
                
                execution_result = await self._executor.execute(code, self._proxy)
                
                if execution_result.success:
                    logger.info(f"Task completed successfully on attempt {attempt + 1}")
                    return {
                        "success": True,
                        "result": execution_result.return_value or execution_result.output,
                        "generated_code": code,
                        "execution_time": time.time() - start_time,
                        "attempts": attempt + 1,
                        "metadata": execution_result.metadata,
                    }
                else:
                    last_error = execution_result.error
                    logger.warning(f"Execution failed on attempt {attempt + 1}: {last_error}")
                    
            except Exception as e:
                last_error = str(e)
                logger.error(f"Error on attempt {attempt + 1}: {e}")
        
        return {
            "success": False,
            "result": {"error": f"Failed after {max_retries} attempts", "last_error": last_error},
            "generated_code": code,
            "execution_time": time.time() - start_time,
            "attempts": max_retries,
        }
    
    async def _execute_code_raw(self, code: str) -> Dict[str, Any]:
        """Execute raw code in sandbox (backwards compatibility).
        
        This provides the simpler execute_code behavior from the lightweight CodeMode.
        """
        if not self._initialized:
            self._initialize_components()
        
        if not self._initialized or self._executor is None:
            from ...codemode import CodeMode
            
            legacy_config = CodeMode(
                sandbox_backend=self.config.sandbox_backend,
                timeout=self.config.timeout,
                memory_limit=self.config.memory_limit,
                max_retries=self.config.max_retries,
                enable_network=self.config.enable_network,
            )
            
            tools = {"_call_tool": self._create_tool_caller()} if self._mcp_tools else None
            return await legacy_config.execute_code(code, tools=tools)
        
        try:
            execution_result = await self._executor.execute(code, self._proxy)
            
            return {
                "success": execution_result.success,
                "stdout": execution_result.output,
                "stderr": "",
                "result": execution_result.return_value,
                "error": execution_result.error,
            }
        except Exception as e:
            logger.error(f"Code execution error: {e}")
            return {
                "success": False,
                "stdout": "",
                "stderr": "",
                "result": None,
                "error": str(e),
            }
    
    def _create_tool_caller(self) -> Callable:
        """Create a tool caller function for sandbox injection."""
        mcp_tools = self._mcp_tools
        
        async def _call_tool(tool_name: str, args: Dict[str, Any]) -> str:
            """Call an MCP tool from within the sandbox."""
            if tool_name not in mcp_tools:
                raise ValueError(f"Unknown tool: {tool_name}")
            
            args = {k: v for k, v in args.items() if k != "tool_name" and v is not None}
            
            try:
                tool = mcp_tools[tool_name]
                if hasattr(tool, 'execute') and callable(tool.execute):
                    result = await tool.execute(**args)
                elif callable(tool):
                    result = await tool(**args)
                else:
                    raise ValueError(f"Tool {tool_name} is not callable")
                return str(result)
            except Exception as e:
                return f"Error calling {tool_name}: {e}"
        
        return _call_tool
    
    def _get_enhanced_instructions(self, base_instructions: str) -> str:
        """Generate enhanced system prompt with CodeMode capabilities."""
        from .orchestrator import create_codemode_prompt
        from .type_generation import generate_tool_types
        
        all_tools = {**self._tools, **self._mcp_tools}
        type_defs = generate_tool_types(all_tools) if all_tools else ""
        
        return create_codemode_prompt(base_instructions, type_defs, all_tools)
    
    async def register_mcp_servers(self, mcp_servers: List[Any]) -> None:
        """Register MCP tools from servers for sandbox access.
        
        This method is called by server.py after MCP servers connect and
        fetch their tools. It populates the _mcp_tools registry.
        
        Args:
            mcp_servers: List of connected MCPServer instances
        """
        from .mcp_adapter import tools_from_mcp_servers
        
        try:
            adapted_tools = await tools_from_mcp_servers(mcp_servers)
            self._mcp_tools.update(adapted_tools)
            
            if self._proxy and hasattr(self._proxy, 'register_tools'):
                self._proxy.register_tools(adapted_tools)
            
            logger.info(f"Registered {len(adapted_tools)} MCP tools with CodeModeCorePlugin")
            
        except Exception as e:
            logger.error(f"Failed to register MCP tools: {e}")
    
    def register_mcp_tools_sync(self, mcp_servers: List[Any]) -> None:
        """Synchronously register MCP tools (for Agent._build).
        
        This is a best-effort registration before servers connect.
        The authoritative registration happens in register_mcp_servers().
        
        Args:
            mcp_servers: List of MCPServer instances
        """
        for server in mcp_servers:
            tools = getattr(server, '_tools', {})
            
            for name, tool in tools.items():
                self._mcp_tools[name] = tool
                
                if self._proxy and hasattr(self._proxy, 'backend'):
                    self._proxy.backend.tools[name] = tool
        
        if self._mcp_tools:
            logger.debug(f"Pre-registered {len(self._mcp_tools)} MCP tools (best-effort)")
    
    def get_config(self) -> Dict[str, Any]:
        """Get current configuration as dict."""
        return self.config.model_dump(exclude={"llm_api_key"})
    
    def get_available_tools(self) -> Dict[str, Any]:
        """Get information about available MCP tools."""
        all_tools = {**self._tools, **self._mcp_tools}
        result = {}
        
        for name, tool in all_tools.items():
            if hasattr(tool, 'description'):
                result[name] = {
                    "description": tool.description,
                    "input_schema": getattr(tool, 'input_schema', None),
                }
            else:
                result[name] = {"description": str(tool)}
        
        return result


def create_codemode_plugin_from_legacy(legacy_config: Any) -> CodeModeCorePlugin:
    """Create CodeModeCorePlugin from legacy CodeMode config.
    
    This factory function enables backwards compatibility with:
    - Agent(codemode=True)
    - Agent(codemode=CodeMode(...))
    
    Args:
        legacy_config: True or a legacy CodeMode instance
        
    Returns:
        CodeModeCorePlugin configured appropriately
    """
    if legacy_config is True:
        return CodeModeCorePlugin(config=CodeModeConfig())
    
    if hasattr(legacy_config, 'sandbox_backend'):
        config = CodeModeConfig(
            sandbox_backend=legacy_config.sandbox_backend,
            timeout=getattr(legacy_config, 'timeout', 60),
            memory_limit=getattr(legacy_config, 'memory_limit', "512m"),
            max_retries=getattr(legacy_config, 'max_retries', 3),
            enable_network=getattr(legacy_config, 'enable_network', False),
        )
        return CodeModeCorePlugin(config=config)
    
    return CodeModeCorePlugin(config=CodeModeConfig())
