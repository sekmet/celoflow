"""CodeMode - LLM-powered code generation and execution system."""

__version__ = "1.0.0"

from .config import LibraryConfig, ConfigurableCodeMode
from .models import CodeModeOptions, CodeModeResult, ExecutionResult, Tool
from .orchestrator import experimental_codemode
from .executor import CodeExecutor
from .proxy import CodeModeProxy, HTTPProxyBackend, DirectProxyBackend
from .llm_client import LLMClient
from .plugin import CodeModeCorePlugin, CodeModeConfig, create_codemode_plugin_from_legacy
from .mcp_adapter import (
    tool_from_mcp_tool,
    tools_from_mcp_servers,
    tools_from_mcp_servers_sync,
    create_tool_caller_from_mcp,
)

__all__ = [
    "LibraryConfig",
    "ConfigurableCodeMode",
    "CodeModeOptions",
    "CodeModeResult",
    "ExecutionResult",
    "Tool",
    "experimental_codemode",
    "CodeExecutor",
    "CodeModeProxy",
    "HTTPProxyBackend",
    "DirectProxyBackend",
    "LLMClient",
    "CodeModeCorePlugin",
    "CodeModeConfig",
    "create_codemode_plugin_from_legacy",
    "tool_from_mcp_tool",
    "tools_from_mcp_servers",
    "tools_from_mcp_servers_sync",
    "create_tool_caller_from_mcp",
]
