"""Multi-tool CodeMode example with data processing."""

import asyncio
from pydantic import BaseModel, Field
from typing import List, Dict, Any
import json

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import LibraryConfig, ConfigurableCodeMode
from models import Tool


# Data storage tool
class DataStoreInput(BaseModel):
    """Input for data storage."""
    key: str = Field(description="Storage key")
    value: Any = Field(description="Value to store")


class DataStoreOutput(BaseModel):
    """Output from data storage."""
    success: bool = Field(description="Whether storage succeeded")
    key: str = Field(description="Storage key")


class DataRetrieveInput(BaseModel):
    """Input for data retrieval."""
    key: str = Field(description="Storage key")


class DataRetrieveOutput(BaseModel):
    """Output from data retrieval."""
    success: bool = Field(description="Whether retrieval succeeded")
    value: Any = Field(description="Retrieved value")


# In-memory storage
data_storage: Dict[str, Any] = {}


async def store_data(key: str, value: Any) -> dict:
    """Store data in memory."""
    data_storage[key] = value
    return {"success": True, "key": key}


async def retrieve_data(key: str) -> dict:
    """Retrieve data from memory."""
    if key in data_storage:
        return {"success": True, "value": data_storage[key]}
    return {"success": False, "value": None}


# Text processing tool
class TextProcessInput(BaseModel):
    """Input for text processing."""
    text: str = Field(description="Text to process")
    operation: str = Field(description="Operation: uppercase, lowercase, reverse, word_count")


class TextProcessOutput(BaseModel):
    """Output from text processing."""
    result: str = Field(description="Processed text or result")


async def process_text(text: str, operation: str) -> dict:
    """Process text based on operation."""
    operations = {
        "uppercase": text.upper(),
        "lowercase": text.lower(),
        "reverse": text[::-1],
        "word_count": str(len(text.split()))
    }
    return {"result": operations.get(operation, text)}


# Statistics tool
class StatsInput(BaseModel):
    """Input for statistics calculation."""
    numbers: List[float] = Field(description="List of numbers")


class StatsOutput(BaseModel):
    """Output from statistics calculation."""
    mean: float
    median: float
    min: float
    max: float
    count: int


async def calculate_stats(numbers: List[float]) -> dict:
    """Calculate statistics for numbers."""
    if not numbers:
        return {"mean": 0, "median": 0, "min": 0, "max": 0, "count": 0}
    
    sorted_nums = sorted(numbers)
    n = len(numbers)
    median = sorted_nums[n // 2] if n % 2 == 1 else (sorted_nums[n // 2 - 1] + sorted_nums[n // 2]) / 2
    
    return {
        "mean": sum(numbers) / n,
        "median": median,
        "min": min(numbers),
        "max": max(numbers),
        "count": n
    }


async def main():
    """Main example with multiple tools."""
    print("CodeMode Multi-Tool Example")
    print("=" * 60)
    
    # Create tools
    tools = {
        "store_data": Tool(
            name="store_data",
            description="Store data in memory",
            input_schema=DataStoreInput,
            output_schema=DataStoreOutput,
            execute=store_data
        ),
        "retrieve_data": Tool(
            name="retrieve_data",
            description="Retrieve data from memory",
            input_schema=DataRetrieveInput,
            output_schema=DataRetrieveOutput,
            execute=retrieve_data
        ),
        "process_text": Tool(
            name="process_text",
            description="Process text with various operations",
            input_schema=TextProcessInput,
            output_schema=TextProcessOutput,
            execute=process_text
        ),
        "calculate_stats": Tool(
            name="calculate_stats",
            description="Calculate statistics for a list of numbers",
            input_schema=StatsInput,
            output_schema=StatsOutput,
            execute=calculate_stats
        )
    }
    
    # Configure CodeMode
    config = LibraryConfig(
        llm_provider="anthropic",
        sandbox_backend="llm-sandbox",
        verbose=True
    )
    
    print(f"\nTools available: {list(tools.keys())}")
    
    # Create instance
    factory = ConfigurableCodeMode(config)
    instance = await factory.create_codemode_instance(tools)
    
    async with instance:
        # Task 1: Data pipeline
        print("\n" + "=" * 60)
        print("Task 1: Data Storage and Retrieval Pipeline")
        print("=" * 60)
        
        result1 = await instance.execute_task(
            """
            Store the following data:
            - Store "user_name" as "Alice"
            - Store "user_age" as 30
            - Store "user_city" as "New York"
            Then retrieve and return all three values.
            """
        )
        
        print(f"\nSuccess: {result1['success']}")
        print(f"Result: {json.dumps(result1['result'], indent=2)}")
        
        # Task 2: Text processing
        print("\n" + "=" * 60)
        print("Task 2: Text Processing")
        print("=" * 60)
        
        result2 = await instance.execute_task(
            """
            Process the text "Hello CodeMode World":
            1. Convert to uppercase
            2. Reverse it
            3. Count the words
            Return all three results.
            """
        )
        
        print(f"\nSuccess: {result2['success']}")
        print(f"Result: {json.dumps(result2['result'], indent=2)}")
        
        # Task 3: Statistics
        print("\n" + "=" * 60)
        print("Task 3: Statistical Analysis")
        print("=" * 60)
        
        result3 = await instance.execute_task(
            """
            Calculate statistics for this list of numbers: [12, 45, 23, 67, 34, 89, 15, 56]
            Return the mean, median, min, max, and count.
            """
        )
        
        print(f"\nSuccess: {result3['success']}")
        print(f"Result: {json.dumps(result3['result'], indent=2)}")
        
        # Task 4: Complex workflow
        print("\n" + "=" * 60)
        print("Task 4: Complex Multi-Tool Workflow")
        print("=" * 60)
        
        result4 = await instance.execute_task(
            """
            Execute this workflow:
            1. Process the text "data analysis" to uppercase
            2. Store the result with key "processed_text"
            3. Calculate statistics for [10, 20, 30, 40, 50]
            4. Store the statistics with key "number_stats"
            5. Retrieve both stored values and return them
            """
        )
        
        print(f"\nSuccess: {result4['success']}")
        print(f"Result: {json.dumps(result4['result'], indent=2)}")
    
    print("\n" + "=" * 60)
    print("Example completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
