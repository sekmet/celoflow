"""Basic CodeMode example with calculator tool."""

import asyncio
from pydantic import BaseModel, Field

# Add parent directory to path for imports
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import LibraryConfig, ConfigurableCodeMode
from models import Tool


# Define calculator tool
class CalculatorInput(BaseModel):
    """Input schema for calculator."""
    operation: str = Field(description="Operation: add, subtract, multiply, divide")
    a: float = Field(description="First number")
    b: float = Field(description="Second number")


class CalculatorOutput(BaseModel):
    """Output schema for calculator."""
    result: float = Field(description="Calculation result")


async def calculate(operation: str, a: float, b: float) -> dict:
    """
    Execute mathematical operation.
    
    Args:
        operation: Operation type
        a: First number
        b: Second number
        
    Returns:
        Dictionary with result
    """
    operations = {
        "add": a + b,
        "subtract": a - b,
        "multiply": a * b,
        "divide": a / b if b != 0 else float('inf')
    }
    return {"result": operations.get(operation, 0.0)}


async def main():
    """Main example function."""
    print("CodeMode Basic Example")
    print("=" * 50)
    
    # Create calculator tool
    calculator = Tool(
        name="calculator",
        description="Perform mathematical calculations",
        input_schema=CalculatorInput,
        output_schema=CalculatorOutput,
        execute=calculate
    )
    
    # Configure CodeMode
    config = LibraryConfig(
        llm_provider="anthropic",
        llm_model="claude-sonnet-4-20250514",
        sandbox_backend="llm-sandbox",
        sandbox_timeout=30,
        max_retries=2,
        verbose=True
    )
    
    print(f"\nConfiguration:")
    print(f"  LLM Provider: {config.llm_provider}")
    print(f"  Model: {config.llm_model}")
    print(f"  Sandbox: {config.sandbox_backend}")
    
    # Create factory and instance
    factory = ConfigurableCodeMode(config)
    instance = await factory.create_codemode_instance({"calculator": calculator})
    
    # Use async context manager
    async with instance:
        print("\n" + "=" * 50)
        print("Task 1: Simple calculation")
        print("=" * 50)
        
        result1 = await instance.execute_task(
            "Calculate 15 + 27 using the calculator tool"
        )
        
        print(f"\nSuccess: {result1['success']}")
        print(f"Result: {result1['result']}")
        print(f"Execution time: {result1['execution_time']:.2f}s")
        
        print("\n" + "=" * 50)
        print("Task 2: Complex calculation")
        print("=" * 50)
        
        result2 = await instance.execute_task(
            "Calculate (25 + 15) * 2 - 10 using the calculator tool multiple times"
        )
        
        print(f"\nSuccess: {result2['success']}")
        print(f"Result: {result2['result']}")
        print(f"Execution time: {result2['execution_time']:.2f}s")
        
        print("\n" + "=" * 50)
        print("Task 3: Division")
        print("=" * 50)
        
        result3 = await instance.execute_task(
            "Calculate 100 divided by 4 using the calculator tool"
        )
        
        print(f"\nSuccess: {result3['success']}")
        print(f"Result: {result3['result']}")
        print(f"Execution time: {result3['execution_time']:.2f}s")
    
    print("\n" + "=" * 50)
    print("Example completed!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())
