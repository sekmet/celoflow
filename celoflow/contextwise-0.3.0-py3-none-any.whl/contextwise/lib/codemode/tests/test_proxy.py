"""Tests for proxy system."""

import pytest
from unittest.mock import Mock, AsyncMock, patch
import httpx

from ..proxy import HTTPProxyBackend, DirectProxyBackend, CodeModeProxy
from ..models import Tool


class TestHTTPProxyBackend:
    """Test HTTP proxy backend."""
    
    def test_initialization(self):
        """Test backend initialization."""
        backend = HTTPProxyBackend(
            base_url="http://localhost:8000",
            timeout=30,
            max_retries=3
        )
        
        assert backend.base_url == "http://localhost:8000"
        assert backend.timeout == 30
        assert backend.max_retries == 3
    
    @pytest.mark.asyncio
    async def test_successful_call(self):
        """Test successful function call."""
        backend = HTTPProxyBackend(base_url="http://localhost:8000")
        
        # Mock HTTP client
        with patch.object(backend.client, 'post') as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"result": "success"}
            mock_post.return_value = mock_response
            
            result = await backend.call_function(
                "test_func",
                ["arg1", "arg2"],
                {"key": "value"}
            )
            
            assert result == "success"
            mock_post.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        """Test retry logic on failures."""
        backend = HTTPProxyBackend(
            base_url="http://localhost:8000",
            max_retries=3
        )
        
        with patch.object(backend.client, 'post') as mock_post:
            # Simulate failures then success
            mock_post.side_effect = [
                httpx.HTTPError("Connection failed"),
                httpx.HTTPError("Connection failed"),
                Mock(status_code=200, json=lambda: {"result": "success"})
            ]
            
            result = await backend.call_function("test_func", [], {})
            
            assert result == "success"
            assert mock_post.call_count == 3
    
    @pytest.mark.asyncio
    async def test_all_retries_exhausted(self):
        """Test behavior when all retries fail."""
        backend = HTTPProxyBackend(
            base_url="http://localhost:8000",
            max_retries=2
        )
        
        with patch.object(backend.client, 'post') as mock_post:
            mock_post.side_effect = httpx.HTTPError("Connection failed")
            
            with pytest.raises(httpx.HTTPError):
                await backend.call_function("test_func", [], {})


class TestDirectProxyBackend:
    """Test direct proxy backend."""
    
    @pytest.mark.asyncio
    async def test_successful_execution(self, sample_tool):
        """Test successful tool execution."""
        backend = DirectProxyBackend({"sample_tool": sample_tool})
        
        result = await backend.call_function(
            "sample_tool",
            [{"param": "test"}],
            {}
        )
        
        assert result == {"result": "Processed: test"}
    
    @pytest.mark.asyncio
    async def test_unknown_tool(self):
        """Test error on unknown tool."""
        backend = DirectProxyBackend({})
        
        with pytest.raises(ValueError, match="not found"):
            await backend.call_function("unknown_tool", [], {})
    
    @pytest.mark.asyncio
    async def test_async_tool_execution(self):
        """Test execution of async tool."""
        async def async_tool_func(value: int) -> dict:
            return {"doubled": value * 2}
        
        from pydantic import BaseModel
        
        class Input(BaseModel):
            value: int
        
        tool = Tool(
            name="async_tool",
            description="Async tool",
            input_schema=Input,
            execute=async_tool_func
        )
        
        backend = DirectProxyBackend({"async_tool": tool})
        result = await backend.call_function("async_tool", [5], {})
        
        assert result == {"doubled": 10}


class TestCodeModeProxy:
    """Test CodeModeProxy class."""
    
    def test_initialization(self, sample_tools):
        """Test proxy initialization."""
        backend = DirectProxyBackend(sample_tools)
        proxy = CodeModeProxy(backend, sample_tools)
        
        assert proxy.backend == backend
        assert proxy.tools == sample_tools
        assert proxy.validate_outputs is True
    
    @pytest.mark.asyncio
    async def test_successful_call_with_validation(self, sample_tool):
        """Test successful call with input validation."""
        backend = DirectProxyBackend({"sample_tool": sample_tool})
        proxy = CodeModeProxy(backend, {"sample_tool": sample_tool})
        
        result = await proxy.call_function(
            "sample_tool",
            [{"param": "test_value"}],
            {}
        )
        
        assert result == {"result": "Processed: test_value"}
    
    @pytest.mark.asyncio
    async def test_unknown_tool_error(self, sample_tool):
        """Test error when calling unknown tool."""
        backend = DirectProxyBackend({"sample_tool": sample_tool})
        proxy = CodeModeProxy(backend, {"sample_tool": sample_tool})
        
        with pytest.raises(ValueError, match="Unknown tool"):
            await proxy.call_function("unknown_tool", [], {})
    
    @pytest.mark.asyncio
    async def test_invalid_input_validation(self, sample_tool):
        """Test input validation failure."""
        backend = DirectProxyBackend({"sample_tool": sample_tool})
        proxy = CodeModeProxy(backend, {"sample_tool": sample_tool})
        
        # Missing required field
        with pytest.raises(ValueError, match="Invalid input"):
            await proxy.call_function("sample_tool", [{}], {})
    
    def test_get_tool_data(self, sample_tools):
        """Test getting tool metadata."""
        backend = DirectProxyBackend(sample_tools)
        proxy = CodeModeProxy(backend, sample_tools)
        
        tool_data = proxy.get_tool_data()
        
        assert "available_tools" in tool_data
        assert "tool_descriptions" in tool_data
        assert "tool_schemas" in tool_data
        
        assert set(tool_data["available_tools"]) == set(sample_tools.keys())
        assert "sample_tool" in tool_data["tool_descriptions"]
    
    @pytest.mark.asyncio
    async def test_output_validation_warning(self, sample_tool):
        """Test that output validation warnings don't fail execution."""
        # Create tool with mismatched output
        async def bad_output_func(param: str) -> dict:
            return {"wrong_field": "value"}
        
        tool = Tool(
            name="bad_output",
            description="Tool with wrong output",
            input_schema=sample_tool.input_schema,
            output_schema=sample_tool.output_schema,
            execute=bad_output_func
        )
        
        backend = DirectProxyBackend({"bad_output": tool})
        proxy = CodeModeProxy(backend, {"bad_output": tool}, validate_outputs=True)
        
        # Should not raise, just warn
        result = await proxy.call_function("bad_output", [{"param": "test"}], {})
        
        assert result == {"wrong_field": "value"}
    
    @pytest.mark.asyncio
    async def test_disabled_output_validation(self, sample_tool):
        """Test with output validation disabled."""
        proxy = CodeModeProxy(
            DirectProxyBackend({"sample_tool": sample_tool}),
            {"sample_tool": sample_tool},
            validate_outputs=False
        )
        
        result = await proxy.call_function(
            "sample_tool",
            [{"param": "test"}],
            {}
        )
        
        assert result == {"result": "Processed: test"}
