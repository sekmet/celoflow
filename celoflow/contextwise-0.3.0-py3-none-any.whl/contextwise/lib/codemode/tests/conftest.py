"""Pytest configuration and fixtures."""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock
from pydantic import BaseModel, Field

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import LibraryConfig
from models import Tool


@pytest.fixture
def event_loop():
    """Create an event loop for async tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def default_config():
    """Provide default LibraryConfig for tests."""
    return LibraryConfig(
        llm_provider="anthropic",
        llm_model="claude-sonnet-4-20250514",
        sandbox_backend="llm-sandbox",
        sandbox_timeout=30,
        max_retries=2,
        verbose=False
    )


@pytest.fixture
def mock_llm_client():
    """Provide a mock LLM client."""
    client = AsyncMock()
    client.generate_code = AsyncMock(return_value="async def execute_task():\n    return {'result': 'test'}")
    client.validate_code = AsyncMock(return_value=(True, []))
    client.compile_check = Mock(return_value=(True, None))
    client.provider = "anthropic"
    return client


@pytest.fixture
def mock_sandbox_executor():
    """Provide a mock sandbox executor."""
    from models import ExecutionResult
    
    executor = AsyncMock()
    executor.execute = AsyncMock(return_value=ExecutionResult(
        success=True,
        output="__RESULT__:{'result': 'test'}",
        error=None,
        return_value={"result": "test"},
        execution_time=0.1
    ))
    executor.cleanup = AsyncMock()
    return executor


@pytest.fixture
def mock_proxy():
    """Provide a mock proxy."""
    proxy = AsyncMock()
    proxy.call_function = AsyncMock(return_value={"status": "success"})
    proxy.get_tool_data = Mock(return_value={
        "available_tools": ["test_tool"],
        "tool_descriptions": {"test_tool": "A test tool"}
    })
    proxy.close = AsyncMock()
    return proxy


@pytest.fixture
def sample_tool():
    """Provide a sample tool for testing."""
    class SampleInput(BaseModel):
        param: str = Field(description="A parameter")
    
    class SampleOutput(BaseModel):
        result: str = Field(description="A result")
    
    async def sample_execute(param: str) -> dict:
        return {"result": f"Processed: {param}"}
    
    return Tool(
        name="sample_tool",
        description="A sample tool for testing",
        input_schema=SampleInput,
        output_schema=SampleOutput,
        execute=sample_execute
    )


@pytest.fixture
def sample_tools(sample_tool):
    """Provide a dictionary of sample tools."""
    class SecondInput(BaseModel):
        value: int = Field(description="A value")
    
    class SecondOutput(BaseModel):
        doubled: int = Field(description="Doubled value")
    
    async def second_execute(value: int) -> dict:
        return {"doubled": value * 2}
    
    second_tool = Tool(
        name="double",
        description="Double a number",
        input_schema=SecondInput,
        output_schema=SecondOutput,
        execute=second_execute
    )
    
    return {
        "sample_tool": sample_tool,
        "double": second_tool
    }


@pytest.fixture
async def mock_codemode_instance(
    mock_llm_client,
    mock_sandbox_executor,
    mock_proxy,
    sample_tools,
    default_config
):
    """Provide a mock CodeMode instance."""
    from instance import CodeModeInstance
    
    instance = CodeModeInstance(
        llm_client=mock_llm_client,
        sandbox_executor=mock_sandbox_executor,
        mcp_framework=Mock(),
        tools=sample_tools,
        config=default_config
    )
    
    # Mock internal components
    instance._executor = mock_sandbox_executor
    instance._proxy = mock_proxy
    instance._initialized = True
    
    return instance


@pytest.fixture
def temp_config_file(tmp_path):
    """Create a temporary configuration file."""
    config_file = tmp_path / "config.json"
    config_data = {
        "llm_provider": "openai",
        "llm_model": "gpt-4",
        "sandbox_backend": "docker",
        "sandbox_timeout": 60
    }
    
    import json
    config_file.write_text(json.dumps(config_data, indent=2))
    
    return config_file


# Markers
def pytest_configure(config):
    """Configure custom pytest markers."""
    config.addinivalue_line(
        "markers", "integration: mark test as integration test"
    )
    config.addinivalue_line(
        "markers", "unit: mark test as unit test"
    )
    config.addinivalue_line(
        "markers", "slow: mark test as slow"
    )


# Test data
@pytest.fixture
def sample_code():
    """Provide sample Python code for testing."""
    return """
async def execute_task():
    result = await tools.sample_tool({'param': 'test'})
    return result
"""


@pytest.fixture
def invalid_code():
    """Provide invalid Python code for testing."""
    return """
async def execute_task()
    # Missing colon
    result = await tools.sample_tool({'param': 'test'}
    return result
"""
