"""Tests for code executor."""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

from ..executor import CodeExecutor
from ..models import ExecutionResult


class TestCodeExecutor:
    """Test CodeExecutor class."""
    
    def test_initialization(self):
        """Test executor initialization with default values."""
        executor = CodeExecutor()
        
        assert executor.backend == "docker"
        assert executor.timeout == 60
        assert executor.memory_limit == "512m"
        assert executor.cpu_limit == 1.0
        assert executor.verbose is False
    
    def test_custom_initialization(self):
        """Test executor initialization with custom values."""
        executor = CodeExecutor(
            backend="llm-sandbox",
            timeout=120,
            memory_limit="1g",
            cpu_limit=2.0,
            verbose=True
        )
        
        assert executor.backend == "llm-sandbox"
        assert executor.timeout == 120
        assert executor.memory_limit == "1g"
        assert executor.cpu_limit == 2.0
        assert executor.verbose is True


class TestCodeWrapping:
    """Test code wrapping functionality."""
    
    def test_wrap_code_structure(self):
        """Test that wrapped code has correct structure."""
        executor = CodeExecutor()
        mock_proxy = Mock()
        mock_proxy.get_tool_data.return_value = {
            "available_tools": ["test_tool"],
            "tool_descriptions": {"test_tool": "A test tool"}
        }
        
        user_code = "result = await tools.test_tool({'param': 'value'})\nreturn result"
        wrapped = executor._wrap_code(user_code, mock_proxy)
        
        # Check components are present
        assert "import asyncio" in wrapped
        assert "import json" in wrapped
        assert "class ToolsProxy:" in wrapped
        assert "async def _user_code():" in wrapped
        assert "asyncio.run(_user_code())" in wrapped
        
        # Check user code is indented
        assert "    result = await tools.test_tool" in wrapped
    
    def test_indent_code(self):
        """Test code indentation."""
        executor = CodeExecutor()
        
        code = "line1\nline2\nline3"
        indented = executor._indent_code(code, 4)
        
        lines = indented.split("\n")
        assert lines[0] == "    line1"
        assert lines[1] == "    line2"
        assert lines[2] == "    line3"
    
    def test_indent_empty_lines(self):
        """Test that empty lines are handled correctly."""
        executor = CodeExecutor()
        
        code = "line1\n\nline3"
        indented = executor._indent_code(code, 4)
        
        lines = indented.split("\n")
        assert lines[0] == "    line1"
        assert lines[1] == ""  # Empty line should remain empty
        assert lines[2] == "    line3"


class TestReturnValueExtraction:
    """Test return value extraction from output."""
    
    def test_extract_json_result(self):
        """Test extraction of JSON result."""
        executor = CodeExecutor()
        
        stdout = '__RESULT__:{"status": "success", "value": 42}'
        result = executor._extract_return_value(stdout)
        
        assert result == {"status": "success", "value": 42}
    
    def test_extract_null_result(self):
        """Test extraction of null result."""
        executor = CodeExecutor()
        
        stdout = '__RESULT__:null'
        result = executor._extract_return_value(stdout)
        
        assert result is None
    
    def test_extract_string_result(self):
        """Test extraction when JSON parsing fails."""
        executor = CodeExecutor()
        
        stdout = '__RESULT__:not valid json'
        result = executor._extract_return_value(stdout)
        
        assert result == 'not valid json'
    
    def test_no_result_marker(self):
        """Test when no result marker present."""
        executor = CodeExecutor()
        
        stdout = 'Some output without marker'
        result = executor._extract_return_value(stdout)
        
        assert result is None
    
    def test_multiline_output(self):
        """Test extraction from multiline output."""
        executor = CodeExecutor()
        
        stdout = """Line 1
Line 2
__RESULT__:{"data": "found"}
Line 4"""
        result = executor._extract_return_value(stdout)
        
        assert result == {"data": "found"}


@pytest.mark.asyncio
class TestExecutorExecution:
    """Test code execution methods."""
    
    async def test_timeout_handling(self):
        """Test that timeout is properly enforced."""
        executor = CodeExecutor(timeout=1)
        mock_proxy = Mock()
        mock_proxy.get_tool_data.return_value = {"available_tools": []}
        
        # Code that would sleep longer than timeout
        slow_code = "import time\ntime.sleep(5)"
        
        # Execution should timeout
        result = await executor.execute(slow_code, mock_proxy)
        
        assert result.success is False
        assert "timeout" in result.error.lower()
    
    async def test_unsupported_backend_error(self):
        """Test error handling for unsupported backend."""
        executor = CodeExecutor(backend="invalid_backend")
        mock_proxy = Mock()
        mock_proxy.get_tool_data.return_value = {"available_tools": []}
        
        result = await executor.execute("print('test')", mock_proxy)
        
        assert result.success is False
        assert "Unsupported backend" in result.error


@pytest.mark.asyncio
class TestCleanup:
    """Test resource cleanup."""
    
    async def test_cleanup_when_no_session(self):
        """Test cleanup when no session exists."""
        executor = CodeExecutor()
        
        # Should not raise error
        await executor.cleanup()
        
        assert executor.session is None
    
    async def test_cleanup_clears_session(self):
        """Test cleanup clears session."""
        executor = CodeExecutor()
        executor.session = Mock()
        executor.session.close = AsyncMock()
        
        await executor.cleanup()
        
        assert executor.session is None
