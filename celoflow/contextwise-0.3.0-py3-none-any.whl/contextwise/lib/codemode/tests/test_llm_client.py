"""Tests for LLM client."""

import pytest
from unittest.mock import Mock, AsyncMock, patch
import os

from ..llm_client import LLMClient


class TestLLMClientInitialization:
    """Test LLM client initialization."""
    
    def test_default_initialization(self):
        """Test initialization with defaults."""
        client = LLMClient()
        
        assert client.provider == "anthropic"
        assert client.model == "claude-sonnet-4-20250514"
        assert client.temperature == 0.7
        assert client.max_tokens == 4000
    
    def test_custom_initialization(self):
        """Test initialization with custom values."""
        client = LLMClient(
            provider="openai",
            model="gpt-4",
            temperature=0.5,
            max_tokens=3000
        )
        
        assert client.provider == "openai"
        assert client.model == "gpt-4"
        assert client.temperature == 0.5
        assert client.max_tokens == 3000
    
    def test_api_key_from_parameter(self):
        """Test API key from parameter."""
        client = LLMClient(api_key="test-key-123")
        assert client.api_key == "test-key-123"
    
    def test_api_key_from_env(self, monkeypatch):
        """Test API key from environment variable."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "env-key-456")
        client = LLMClient()
        assert client.api_key == "env-key-456"
    
    def test_unsupported_provider(self):
        """Test error on unsupported provider."""
        with pytest.raises(ValueError, match="Unsupported provider"):
            LLMClient(provider="unsupported")


class TestCodeGeneration:
    """Test code generation methods."""
    
    @pytest.mark.asyncio
    async def test_generate_code_success(self):
        """Test successful code generation."""
        client = LLMClient()
        
        # Mock the internal method
        client._generate_anthropic = AsyncMock(
            return_value="async def execute_task():\n    return 42"
        )
        
        code = await client.generate_code(
            prompt="Create a function that returns 42",
            available_tools=""
        )
        
        assert "async def execute_task():" in code
        assert "return 42" in code
    
    @pytest.mark.asyncio
    async def test_code_cleaning_python_markers(self):
        """Test removal of markdown code blocks."""
        client = LLMClient()
        
        raw_code = "```python\nasync def test():\n    pass\n```"
        cleaned = client._clean_code(raw_code)
        
        assert "```" not in cleaned
        assert "async def test():" in cleaned
    
    @pytest.mark.asyncio
    async def test_code_cleaning_generic_markers(self):
        """Test removal of generic markdown code blocks."""
        client = LLMClient()
        
        raw_code = "```\nasync def test():\n    pass\n```"
        cleaned = client._clean_code(raw_code)
        
        assert "```" not in cleaned
        assert "async def test():" in cleaned
    
    def test_system_message_creation(self):
        """Test creation of default system message."""
        client = LLMClient()
        
        tools_def = "async def search(query: str) -> dict: ..."
        message = client._create_system_message(tools_def)
        
        assert "code generation AI" in message.lower()
        assert tools_def in message
        assert "execute_task" in message
        assert "async def" in message


class TestCodeValidation:
    """Test code validation methods."""
    
    @pytest.mark.asyncio
    async def test_validate_code_safe(self):
        """Test validation of safe code."""
        client = LLMClient()
        client.generate_code = AsyncMock(return_value="SAFE")
        
        is_valid, issues = await client.validate_code("async def test(): pass")
        
        assert is_valid is True
        assert issues == []
    
    @pytest.mark.asyncio
    async def test_validate_code_unsafe(self):
        """Test validation of unsafe code."""
        client = LLMClient()
        client.generate_code = AsyncMock(
            return_value="UNSAFE: uses eval, contains os.system"
        )
        
        is_valid, issues = await client.validate_code("async def test(): eval('x')")
        
        assert is_valid is False
        assert len(issues) == 2
        assert "eval" in issues[0]
        assert "os.system" in issues[1]
    
    @pytest.mark.asyncio
    async def test_validate_code_unclear_response(self):
        """Test handling of unclear validation response."""
        client = LLMClient()
        client.generate_code = AsyncMock(return_value="I'm not sure about this code")
        
        is_valid, issues = await client.validate_code("async def test(): pass")
        
        assert is_valid is False
        assert len(issues) > 0
    
    def test_compile_check_valid(self):
        """Test compile check with valid code."""
        client = LLMClient()
        
        valid_code = "async def test():\n    return 42"
        is_valid, error = client.compile_check(valid_code)
        
        assert is_valid is True
        assert error is None
    
    def test_compile_check_syntax_error(self):
        """Test compile check with syntax error."""
        client = LLMClient()
        
        invalid_code = "async def test()\n    return 42"  # Missing colon
        is_valid, error = client.compile_check(invalid_code)
        
        assert is_valid is False
        assert "Syntax error" in error
    
    def test_compile_check_other_error(self):
        """Test compile check with other compilation error."""
        client = LLMClient()
        
        # Test with code that has indentation issues
        bad_code = "  async def test():\nreturn 42"
        is_valid, error = client.compile_check(bad_code)
        
        assert is_valid is False
        assert error is not None


@pytest.mark.integration
class TestProviderIntegration:
    """Integration tests for different providers."""
    
    @pytest.mark.asyncio
    async def test_anthropic_generation_flow(self):
        """Test Anthropic code generation flow."""
        client = LLMClient(provider="anthropic")
        
        # Mock Anthropic client
        mock_response = Mock()
        mock_response.content = [Mock(text="async def execute_task():\n    return 'test'")]
        
        with patch.object(client.client.messages, 'create', new=AsyncMock(return_value=mock_response)):
            code = await client._generate_anthropic(
                "Test system message",
                [{"role": "user", "content": "Generate code"}]
            )
            
            assert "async def execute_task():" in code
    
    @pytest.mark.asyncio
    async def test_openai_generation_flow(self):
        """Test OpenAI code generation flow."""
        client = LLMClient(provider="openai", model="gpt-4")
        
        # Mock OpenAI client
        mock_response = Mock()
        mock_response.choices = [Mock(message=Mock(content="async def execute_task():\n    return 'test'"))]
        
        with patch.object(client.client.chat.completions, 'create', new=AsyncMock(return_value=mock_response)):
            code = await client._generate_openai(
                "Test system message",
                [{"role": "user", "content": "Generate code"}]
            )
            
            assert "async def execute_task():" in code
