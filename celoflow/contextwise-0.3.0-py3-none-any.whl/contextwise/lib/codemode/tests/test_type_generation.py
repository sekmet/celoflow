"""Tests for type generation utilities."""

import pytest
from pydantic import BaseModel, Field
from typing import List, Dict, Optional

from ..type_generation import (
    to_pascal_case,
    to_camel_case,
    get_type_string,
    pydantic_to_typing,
    generate_tool_types,
    validate_generated_types
)
from ..models import Tool


class TestStringConversion:
    """Test string case conversion utilities."""
    
    def test_to_pascal_case(self):
        """Test snake_case to PascalCase conversion."""
        assert to_pascal_case("hello_world") == "HelloWorld"
        assert to_pascal_case("test_case") == "TestCase"
        assert to_pascal_case("single") == "Single"
        assert to_pascal_case("multi_word_test") == "MultiWordTest"
    
    def test_to_camel_case(self):
        """Test snake_case to camelCase conversion."""
        assert to_camel_case("hello_world") == "helloWorld"
        assert to_camel_case("test_case") == "testCase"
        assert to_camel_case("single") == "single"
        assert to_camel_case("multi_word_test") == "multiWordTest"


class TestTypeStringGeneration:
    """Test type string generation from annotations."""
    
    def test_basic_types(self):
        """Test basic type conversion."""
        assert get_type_string(str) == "str"
        assert get_type_string(int) == "int"
        assert get_type_string(float) == "float"
        assert get_type_string(bool) == "bool"
    
    def test_list_types(self):
        """Test List type conversion."""
        assert get_type_string(List[str]) == "List[str]"
        assert get_type_string(List[int]) == "List[int]"
    
    def test_dict_types(self):
        """Test Dict type conversion."""
        assert get_type_string(Dict[str, int]) == "Dict[str, int]"
        assert get_type_string(Dict[str, str]) == "Dict[str, str]"
    
    def test_optional_types(self):
        """Test Optional type conversion."""
        assert get_type_string(Optional[str]) == "Optional[str]"
        assert get_type_string(Optional[int]) == "Optional[int]"
    
    def test_none_type(self):
        """Test None type conversion."""
        assert get_type_string(type(None)) == "None"


class TestPydanticToTyping:
    """Test Pydantic model to TypedDict conversion."""
    
    def test_simple_model(self):
        """Test conversion of simple Pydantic model."""
        class SimpleModel(BaseModel):
            name: str
            age: int
        
        result = pydantic_to_typing(SimpleModel, "SimpleInput")
        
        assert "class SimpleInput(TypedDict):" in result
        assert "name: str" in result
        assert "age: int" in result
    
    def test_model_with_optional(self):
        """Test conversion with Optional fields."""
        class ModelWithOptional(BaseModel):
            required: str
            optional: Optional[int] = None
        
        result = pydantic_to_typing(ModelWithOptional, "TestInput")
        
        assert "required: str" in result
        assert "optional: Optional[int]" in result
    
    def test_model_with_list(self):
        """Test conversion with List fields."""
        class ModelWithList(BaseModel):
            items: List[str]
        
        result = pydantic_to_typing(ModelWithList, "TestInput")
        
        assert "items: List[str]" in result
    
    def test_model_with_descriptions(self):
        """Test that field descriptions are included as comments."""
        class ModelWithDocs(BaseModel):
            field: str = Field(description="A test field")
        
        result = pydantic_to_typing(ModelWithDocs, "TestInput")
        
        assert "# A test field" in result
    
    def test_empty_model(self):
        """Test conversion of empty model."""
        class EmptyModel(BaseModel):
            pass
        
        result = pydantic_to_typing(EmptyModel, "EmptyInput")
        
        assert "class EmptyInput(TypedDict):" in result
        assert "pass" in result


class TestGenerateToolTypes:
    """Test tool type generation."""
    
    def test_single_tool(self):
        """Test type generation for single tool."""
        class SearchInput(BaseModel):
            query: str
        
        class SearchOutput(BaseModel):
            results: List[str]
        
        tool = Tool(
            name="search",
            description="Search for items",
            input_schema=SearchInput,
            output_schema=SearchOutput
        )
        
        result = generate_tool_types({"search": tool})
        
        # Check imports
        assert "from typing import" in result
        
        # Check input type
        assert "class SearchInput(TypedDict):" in result
        assert "query: str" in result
        
        # Check output type
        assert "class SearchOutput(TypedDict):" in result
        assert "results: List[str]" in result
        
        # Check function signature
        assert "async def search(input: SearchInput) -> SearchOutput:" in result
        assert "Search for items" in result
    
    def test_multiple_tools(self):
        """Test type generation for multiple tools."""
        class Input1(BaseModel):
            param: str
        
        class Input2(BaseModel):
            value: int
        
        tools = {
            "tool_one": Tool(
                name="tool_one",
                description="First tool",
                input_schema=Input1
            ),
            "tool_two": Tool(
                name="tool_two",
                description="Second tool",
                input_schema=Input2
            )
        }
        
        result = generate_tool_types(tools)
        
        # Both tools should be present
        assert "async def tool_one" in result
        assert "async def tool_two" in result
        
        # Both input types should be present
        assert "class ToolOneInput(TypedDict):" in result
        assert "class ToolTwoInput(TypedDict):" in result


class TestValidateGeneratedTypes:
    """Test validation of generated type definitions."""
    
    def test_valid_types(self):
        """Test validation of syntactically correct types."""
        valid_code = """
from typing import TypedDict

class TestInput(TypedDict):
    field: str

async def test_func(input: TestInput) -> str:
    pass
"""
        assert validate_generated_types(valid_code) is True
    
    def test_invalid_types(self):
        """Test validation catches syntax errors."""
        invalid_code = """
class TestInput(TypedDict)
    field: str  # Missing colon
"""
        assert validate_generated_types(invalid_code) is False
    
    def test_empty_string(self):
        """Test validation of empty string."""
        assert validate_generated_types("") is True


@pytest.mark.integration
class TestTypeGenerationIntegration:
    """Integration tests for type generation."""
    
    def test_full_tool_workflow(self):
        """Test complete workflow from tool to executable types."""
        class WeatherInput(BaseModel):
            city: str = Field(description="City name")
            units: Optional[str] = Field(default="metric", description="Temperature units")
        
        class WeatherOutput(BaseModel):
            temperature: float
            conditions: str
            humidity: int
        
        tool = Tool(
            name="get_weather",
            description="Get weather information for a city",
            input_schema=WeatherInput,
            output_schema=WeatherOutput
        )
        
        # Generate types
        type_defs = generate_tool_types({"get_weather": tool})
        
        # Validate
        assert validate_generated_types(type_defs)
        
        # Check all components present
        assert "class GetWeatherInput(TypedDict):" in type_defs
        assert "class GetWeatherOutput(TypedDict):" in type_defs
        assert "city: str" in type_defs
        assert "units: Optional[str]" in type_defs
        assert "temperature: float" in type_defs
        assert "async def get_weather" in type_defs
        
        # Check descriptions
        assert "City name" in type_defs
        assert "Temperature units" in type_defs
