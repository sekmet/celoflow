"""Tests for configuration and factory patterns."""

import pytest
import json
from pathlib import Path
import tempfile

from ..config import LibraryConfig, ConfigurableCodeMode


class TestLibraryConfig:
    """Test LibraryConfig model."""
    
    def test_default_values(self):
        """Test that default values match specification."""
        config = LibraryConfig()
        
        assert config.llm_provider == "anthropic"
        assert config.llm_model == "claude-sonnet-4-20250514"
        assert config.sandbox_backend == "llm-sandbox"
        assert config.mcp_framework == "fastmcp"
        assert config.sandbox_timeout == 60
        assert config.max_retries == 3
    
    def test_custom_values(self):
        """Test creation with custom values."""
        config = LibraryConfig(
            llm_provider="openai",
            llm_model="gpt-4",
            sandbox_backend="docker",
            sandbox_timeout=120
        )
        
        assert config.llm_provider == "openai"
        assert config.llm_model == "gpt-4"
        assert config.sandbox_backend == "docker"
        assert config.sandbox_timeout == 120
    
    def test_validation_constraints(self):
        """Test that validation constraints are enforced."""
        # Invalid temperature
        with pytest.raises(Exception):
            LibraryConfig(llm_temperature=3.0)
        
        # Invalid timeout
        with pytest.raises(Exception):
            LibraryConfig(sandbox_timeout=-1)
    
    def test_compatibility_validation_codejail(self):
        """Test compatibility validation for CodeJail."""
        config = LibraryConfig(
            sandbox_backend="codejail",
            sandbox_keep_template=True
        )
        
        with pytest.raises(ValueError, match="CodeJail.*keep_template"):
            config.validate_compatibility()
    
    def test_compatibility_validation_anthropic(self):
        """Test compatibility validation for Anthropic."""
        config = LibraryConfig(
            llm_provider="anthropic",
            llm_model="gpt-4"  # Wrong model for Anthropic
        )
        
        with pytest.raises(ValueError, match="Claude"):
            config.validate_compatibility()
    
    def test_json_serialization(self):
        """Test JSON serialization and deserialization."""
        config = LibraryConfig(
            llm_provider="openai",
            llm_model="gpt-4",
            llm_temperature=0.5
        )
        
        # Serialize
        json_str = config.to_json()
        data = json.loads(json_str)
        
        # Check values
        assert data["llm_provider"] == "openai"
        assert data["llm_model"] == "gpt-4"
        assert data["llm_temperature"] == 0.5
        
        # API key should be excluded
        assert "llm_api_key" not in data
    
    def test_json_file_persistence(self):
        """Test saving and loading from JSON file."""
        config = LibraryConfig(
            llm_provider="openai",
            sandbox_timeout=90
        )
        
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.json') as f:
            temp_path = Path(f.name)
        
        try:
            # Save to file
            config.to_json(temp_path)
            
            # Load from file
            loaded_config = LibraryConfig.from_json(temp_path)
            
            assert loaded_config.llm_provider == "openai"
            assert loaded_config.sandbox_timeout == 90
        finally:
            temp_path.unlink()
    
    def test_from_json_string(self):
        """Test loading from JSON string."""
        json_str = '{"llm_provider": "litellm", "llm_model": "gpt-3.5-turbo"}'
        config = LibraryConfig.from_json(json_str)
        
        assert config.llm_provider == "litellm"
        assert config.llm_model == "gpt-3.5-turbo"


class TestConfigurableCodeMode:
    """Test ConfigurableCodeMode factory."""
    
    def test_initialization(self):
        """Test factory initialization."""
        config = LibraryConfig()
        factory = ConfigurableCodeMode(config)
        
        assert factory.config == config
        assert factory._llm_client is None
        assert factory._sandbox_executor is None
        assert factory._mcp_server is None
    
    def test_lazy_initialization(self):
        """Test that components are lazily initialized."""
        config = LibraryConfig()
        factory = ConfigurableCodeMode(config)
        
        # Components should not be initialized yet
        assert factory._llm_client is None
        
        # This would initialize if dependencies are available
        # We can't test actual initialization without dependencies
    
    def test_config_validation_on_init(self):
        """Test that config is validated on factory init."""
        config = LibraryConfig(
            llm_provider="anthropic",
            llm_model="gpt-4"  # Invalid for Anthropic
        )
        
        with pytest.raises(ValueError):
            ConfigurableCodeMode(config)
    
    @pytest.mark.asyncio
    async def test_create_instance_signature(self):
        """Test that create_codemode_instance has correct signature."""
        config = LibraryConfig()
        factory = ConfigurableCodeMode(config)
        
        # Should accept tools dict
        # Actual test would require mocking dependencies
        import inspect
        sig = inspect.signature(factory.create_codemode_instance)
        
        assert 'tools' in sig.parameters


@pytest.mark.integration
class TestConfigurationIntegration:
    """Integration tests for configuration system."""
    
    def test_environment_variable_loading(self, monkeypatch):
        """Test loading configuration from environment variables."""
        # Set environment variables
        monkeypatch.setenv("CODEMODE_LLM_PROVIDER", "openai")
        monkeypatch.setenv("CODEMODE_LLM_MODEL", "gpt-4")
        monkeypatch.setenv("CODEMODE_SANDBOX_TIMEOUT", "90")
        monkeypatch.setenv("CODEMODE_VERBOSE", "true")
        
        config = LibraryConfig.from_env()
        
        assert config.llm_provider == "openai"
        assert config.llm_model == "gpt-4"
        assert config.sandbox_timeout == 90
        assert config.verbose is True
    
    def test_full_configuration_workflow(self):
        """Test complete configuration workflow."""
        # Create config
        config = LibraryConfig(
            llm_provider="openai",
            llm_model="gpt-4",
            sandbox_backend="docker",
            sandbox_timeout=120,
            max_retries=5
        )
        
        # Validate
        config.validate_compatibility()
        
        # Serialize
        json_str = config.to_json()
        
        # Deserialize
        loaded = LibraryConfig.from_json(json_str)
        
        # Verify
        assert loaded.llm_provider == config.llm_provider
        assert loaded.llm_model == config.llm_model
        assert loaded.sandbox_backend == config.sandbox_backend
        assert loaded.sandbox_timeout == config.sandbox_timeout
        assert loaded.max_retries == config.max_retries
