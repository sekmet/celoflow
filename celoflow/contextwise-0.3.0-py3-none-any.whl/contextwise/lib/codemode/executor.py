"""Code execution with sandboxing support."""

import asyncio
import contextlib
import json
import traceback as tb
import time
from typing import Any, Dict, Optional
from .models import ExecutionResult


class CodeExecutor:
    """
    Manages sandboxed Python code execution.
    
    System Thinking L2 Considerations:
    - Isolation: Each execution in separate container/process
    - Resource limits: CPU, memory, timeout constraints  
    - State: Can maintain session for iterative debugging
    - Security: Prevents sandbox escape and resource abuse
    """
    
    def __init__(
        self,
        backend: str = "docker",
        keep_template: bool = False,
        timeout: int = 60,
        memory_limit: str = "512m",
        cpu_limit: float = 1.0,
        verbose: bool = False
    ):
        """
        Initialize code executor with configuration.
        
        Args:
            backend: Sandbox backend ('llm-sandbox', 'codejail', 'docker')
            keep_template: Keep sandbox template for faster reuse
            timeout: Execution timeout in seconds
            memory_limit: Memory limit (e.g., '512m', '1g')
            cpu_limit: CPU limit in cores
            verbose: Enable verbose logging
        """
        self.backend = backend
        self.keep_template = keep_template
        self.timeout = timeout
        self.memory_limit = memory_limit
        self.cpu_limit = cpu_limit
        self.verbose = verbose
        self.session: Optional[Any] = None
    
    async def execute(
        self,
        code: str,
        tools_proxy: 'CodeModeProxy',
        env_vars: Optional[Dict[str, str]] = None
    ) -> ExecutionResult:
        """
        Execute code in sandboxed environment.
        
        Args:
            code: Python code to execute
            tools_proxy: Proxy for tool access
            env_vars: Optional environment variables
            
        Returns:
            ExecutionResult with output, errors, and return value
        """
        start_time = time.time()
        
        try:
            if self.backend == "llm-sandbox":
                result = await self._execute_llm_sandbox(code, tools_proxy, env_vars)
            elif self.backend == "codejail":
                result = await self._execute_codejail(code, tools_proxy, env_vars)
            elif self.backend == "docker":
                result = await self._execute_docker(code, tools_proxy, env_vars)
            else:
                raise ValueError(f"Unsupported backend: {self.backend}")
            
            result.execution_time = time.time() - start_time
            return result
            
        except asyncio.TimeoutError:
            return ExecutionResult(
                success=False,
                output="",
                error=f"Execution timeout after {self.timeout}s",
                execution_time=time.time() - start_time
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                output="",
                error=str(e),
                traceback=tb.format_exc(),
                execution_time=time.time() - start_time
            )
    
    async def _execute_llm_sandbox(
        self,
        code: str,
        tools_proxy: Any,
        env_vars: Optional[Dict[str, str]]
    ) -> ExecutionResult:
        """Execute using llm-sandbox backend."""
        from llm_sandbox import SandboxSession
        
        # Wrap code with proxy injection
        wrapped_code = self._wrap_code(code, tools_proxy)
        
        llm_sandbox_backend = "docker"
        try:
            from llm_sandbox.const import SandboxBackend

            llm_sandbox_backend = SandboxBackend.DOCKER.value
        except Exception:
            llm_sandbox_backend = "docker"

        session_obj = SandboxSession(
            lang="python",
            backend=llm_sandbox_backend,
            keep_template=self.keep_template,
            verbose=self.verbose,
        )

        async def _run_in_session():
            # llm_sandbox sessions are synchronous context managers.
            # Run them in a worker thread to avoid blocking the event loop.
            def _sync_run():
                with contextlib.closing(session_obj):
                    with session_obj as session:
                        result = session.run(wrapped_code)
                        if asyncio.iscoroutine(result):
                            return asyncio.run(result)
                        return result

            return await asyncio.to_thread(_sync_run)

        # Execute with timeout
        result = await asyncio.wait_for(
            _run_in_session(),
            timeout=self.timeout,
        )
            
        return ExecutionResult(
            success=result.exit_code == 0,
            output=result.stdout or "",
            error=result.stderr if result.stderr else None,
            return_value=self._extract_return_value(result.stdout or ""),
            metadata={
                "exit_code": result.exit_code,
                "backend": self.backend,
            },
        )
    
    async def _execute_codejail(
        self,
        code: str,
        tools_proxy: Any,
        env_vars: Optional[Dict[str, str]]
    ) -> ExecutionResult:
        """Execute using codejail backend."""
        from codejail import jail_code
        
        # Wrap code with proxy injection
        wrapped_code = self._wrap_code(code, tools_proxy)
        
        # CodeJail uses synchronous execution, wrap in executor
        loop = asyncio.get_event_loop()

        def _run():
            import os
            import resource
            import shutil
            import sys

            from codejail.subproc import run_subprocess
            from codejail.util import temp_directory

            python_bin = sys.executable or shutil.which("python3") or shutil.which("python")
            jail_code.configure("python", python_bin)

            with temp_directory() as homedir:
                os.chmod(homedir, 0o775)

                tmptmp = os.path.join(homedir, "tmp")
                os.mkdir(tmptmp)
                os.chmod(tmptmp, 0o777)

                with open(os.path.join(homedir, "jailed_code"), "wb") as jailed:
                    jailed.write(bytes(wrapped_code, "utf8"))

                cmd = []
                cmd.extend(jail_code.COMMANDS["python"]["cmdline_start"])
                cmd.append("jailed_code")

                cpu = max(1, int(self.timeout))
                rlimits = [
                    (resource.RLIMIT_CPU, (cpu, cpu + 1)),
                    (resource.RLIMIT_FSIZE, (0, 0)),
                ]

                status, stdout, stderr = run_subprocess(
                    cmd=cmd,
                    cwd=homedir,
                    env={"TMPDIR": "tmp"},
                    rlimits=rlimits,
                    realtime=self.timeout,
                    slug="codemode",
                )

                stdout_s = stdout.decode("utf-8", errors="replace") if isinstance(stdout, (bytes, bytearray)) else str(stdout)
                stderr_s = stderr.decode("utf-8", errors="replace") if isinstance(stderr, (bytes, bytearray)) else str(stderr)

                return {
                    "stdout": stdout_s,
                    "stderr": stderr_s,
                    "success": status == 0,
                }
        
        result_dict = await asyncio.wait_for(
            loop.run_in_executor(None, _run),
            timeout=self.timeout
        )
        
        return ExecutionResult(
            success=result_dict["success"],
            output=result_dict["stdout"],
            error=result_dict.get("stderr") or None,
            return_value=self._extract_return_value(result_dict["stdout"]),
            metadata={"backend": "codejail"}
        )
    
    async def _execute_docker(
        self,
        code: str,
        tools_proxy: Any,
        env_vars: Optional[Dict[str, str]]
    ) -> ExecutionResult:
        """Execute using Docker SDK backend."""
        import docker
        
        client = docker.from_env()
        wrapped_code = self._wrap_code(code, tools_proxy)
        
        # Create temporary container
        container = client.containers.run(
            "python:3.11-slim",
            f"python -c '{wrapped_code.replace("'", "'\"'\"'")}'",
            detach=True,
            mem_limit=self.memory_limit,
            cpu_quota=int(self.cpu_limit * 100000),
            environment=env_vars or {},
            network_disabled=True
        )
        
        try:
            # Wait for completion with timeout
            result = container.wait(timeout=self.timeout)
            logs = container.logs().decode('utf-8')
            
            # Separate stdout and stderr
            output_lines = logs.split('\n')
            stdout = '\n'.join(
                line for line in output_lines 
                if not line.startswith('ERROR:')
            )
            stderr = '\n'.join(
                line for line in output_lines 
                if line.startswith('ERROR:')
            )
            
            return ExecutionResult(
                success=result['StatusCode'] == 0,
                output=stdout,
                error=stderr if stderr else None,
                return_value=self._extract_return_value(stdout),
                metadata={
                    "backend": "docker",
                    "exit_code": result['StatusCode']
                }
            )
        finally:
            container.remove(force=True)
    
    def _wrap_code(
        self,
        code: str,
        proxy: Any
    ) -> str:
        """
        Wrap user code with proxy injection and error handling.
        
        Args:
            code: User's Python code
            proxy: Tools proxy instance
            
        Returns:
            Wrapped code with proxy and error handling
        """
        # Get tool data for proxy initialization
        tool_data = proxy.get_tool_data() if hasattr(proxy, 'get_tool_data') else {}

        indented_user_code = self._indent_code(code, 4)
        if not indented_user_code.strip():
            indented_user_code = " " * 4 + "pass"
        
        return f"""
import asyncio
import json
import sys
from typing import Any, Dict

class ToolsProxy:
    \"\"\"Proxy for accessing tools from sandbox.\"\"\"
    
    def __init__(self, tool_data: Dict[str, Any]):
        self._tool_data = tool_data
        self._available_tools = tool_data.get('available_tools', [])
    
    def __getattr__(self, name: str):
        \"\"\"Dynamic tool access.\"\"\"
        if name.startswith('_'):
            raise AttributeError(f"Cannot access private attribute: {{name}}")
        
        if name not in self._available_tools:
            raise AttributeError(
                f"Tool '{{name}}' not found. Available: {{self._available_tools}}"
            )
        
        async def call_tool(**kwargs):
            # In real implementation, this would call the proxy
            # For now, return a placeholder
            print(f"__TOOL_CALL__:{{name}}:{{json.dumps(kwargs)}}", file=sys.stderr)
            return {{"status": "executed", "tool": name, "args": kwargs}}
        
        return call_tool

# Initialize tools proxy
tool_data = {json.dumps(tool_data)}
tools = ToolsProxy(tool_data)

# User code execution wrapper
async def _user_code():
{indented_user_code}

# Execute and capture result
try:
    result = asyncio.run(_user_code())
    if result is not None:
        print(f"__RESULT__:{{json.dumps(result, default=str)}}")
    else:
        print("__RESULT__:null")
except Exception as e:
    import traceback
    print(f"__ERROR__:{{str(e)}}", file=sys.stderr)
    traceback.print_exc(file=sys.stderr)
    sys.exit(1)
"""
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """
        Indent code block.
        
        Args:
            code: Code to indent
            spaces: Number of spaces for indentation
            
        Returns:
            Indented code
        """
        indent = " " * spaces
        lines = code.split("\n")
        return "\n".join(indent + line if line.strip() else "" for line in lines)
    
    def _extract_return_value(self, stdout: str) -> Any:
        """
        Extract return value from stdout.
        
        Args:
            stdout: Standard output from execution
            
        Returns:
            Extracted return value or None
        """
        for line in stdout.split("\n"):
            if line.startswith("__RESULT__:"):
                try:
                    json_str = line.split(":", 1)[1]
                    if json_str == "null":
                        return None
                    return json.loads(json_str)
                except (json.JSONDecodeError, IndexError):
                    # Return raw string if JSON parsing fails
                    return line.split(":", 1)[1] if ":" in line else None
        return None
    
    async def cleanup(self):
        """Clean up sandbox resources."""
        if self.session:
            try:
                await self.session.close()
            except Exception:
                pass
            finally:
                self.session = None
