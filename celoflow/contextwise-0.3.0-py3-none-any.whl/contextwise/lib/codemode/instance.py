"""CodeMode instance integration."""

import logging
from typing import Dict, Any, Optional
from .models import Tool
from .config import LibraryConfig
from .orchestrator import experimental_codemode
from .models import CodeModeOptions, CodeModeResult

logger = logging.getLogger(__name__)


class CodeModeInstance:
    """
    Fully configured CodeMode instance ready for execution.
    
    Integrates LLM client, sandbox executor, and MCP framework into a
    cohesive system for code generation and execution.
    """
    
    def __init__(
        self,
        llm_client: Any,
        sandbox_executor: Any,
        mcp_framework: Any,
        tools: Dict[str, Tool],
        config: LibraryConfig
    ):
        """
        Initialize CodeMode instance.
        
        Args:
            llm_client: Configured LLM client
            sandbox_executor: Configured sandbox executor
            mcp_framework: MCP framework class
            tools: Available tools
            config: Library configuration
        """
        self.llm_client = llm_client
        self.sandbox_executor = sandbox_executor
        self.mcp_framework = mcp_framework
        self.tools = tools
        self.config = config
        
        # Initialize components
        self._executor = None
        self._proxy = None
        self._initialized = False
    
    async def initialize(self) -> CodeModeResult:
        """
        Initialize the CodeMode system.
        
        Sets up executor, proxy, and generates tool wrappers.
        
        Returns:
            CodeModeResult with initialization details
        """
        if self._initialized:
            logger.warning("CodeMode already initialized")
            return
        
        logger.info("Initializing CodeMode instance")
        
        try:
            # Initialize executor
            from .executor import CodeExecutor
            self._executor = CodeExecutor(
                backend=self.config.sandbox_backend,
                keep_template=self.config.sandbox_keep_template,
                timeout=self.config.sandbox_timeout,
                memory_limit=self.config.sandbox_memory_limit,
                cpu_limit=self.config.sandbox_cpu_limit,
                verbose=self.config.verbose
            )
            
            # Initialize proxy
            from .proxy import CodeModeProxy, DirectProxyBackend
            backend = DirectProxyBackend(self.tools)
            self._proxy = CodeModeProxy(
                backend=backend,
                tools=self.tools,
                validate_outputs=True
            )
            
            # Run experimental_codemode to set up environment
            options = CodeModeOptions(
                tools=self.tools,
                prompt="You are a helpful AI assistant that can write and execute Python code.",
                sandbox_backend=self._executor,
                proxy_client=self._proxy,
                llm_client=self.llm_client,
                max_retries=self.config.max_retries,
                timeout=self.config.sandbox_timeout,
                verbose=self.config.verbose
            )
            
            result = await experimental_codemode(options)
            
            self._initialized = True
            logger.info("CodeMode instance initialized successfully")
            
            return result
            
        except Exception as e:
            logger.error(f"Failed to initialize CodeMode: {e}")
            raise
    
    async def execute_task(
        self,
        task: str,
        max_retries: Optional[int] = None,
        validate_code: bool = True
    ) -> Dict[str, Any]:
        """
        Execute a task by generating and running code.
        
        Args:
            task: Task description
            max_retries: Override default max_retries
            validate_code: Whether to validate code before execution
            
        Returns:
            Task execution result
            
        Raises:
            RuntimeError: If not initialized
        """
        if not self._initialized:
            raise RuntimeError("CodeMode not initialized. Call initialize() first.")
        
        max_retries = max_retries or self.config.max_retries
        
        from .type_generation import generate_tool_types
        import time
        
        start_time = time.time()
        last_error = None
        
        for attempt in range(max_retries):
            try:
                logger.info(f"Executing task (attempt {attempt + 1}/{max_retries}): {task}")
                
                # Generate type definitions
                type_defs = generate_tool_types(self.tools)
                
                # Generate code
                code = await self.llm_client.generate_code(
                    prompt=task,
                    available_tools=type_defs
                )
                
                logger.debug(f"Generated code:\n{code}")
                
                # Compile check
                is_valid, error = self.llm_client.compile_check(code)
                if not is_valid:
                    logger.warning(f"Compile check failed: {error}")
                    if attempt == max_retries - 1:
                        return {
                            "success": False,
                            "result": {"error": f"Compilation error: {error}"},
                            "generated_code": code,
                            "execution_time": time.time() - start_time,
                            "attempts": attempt + 1
                        }
                    continue
                
                # LLM validation if requested
                if validate_code:
                    is_safe, issues = await self.llm_client.validate_code(code, strict=True)
                    if not is_safe:
                        logger.warning(f"Validation failed: {issues}")
                        if attempt == max_retries - 1:
                            return {
                                "success": False,
                                "result": {"error": "Code validation failed", "issues": issues},
                                "generated_code": code,
                                "execution_time": time.time() - start_time,
                                "attempts": attempt + 1
                            }
                        continue
                
                # Execute in sandbox
                execution_result = await self._executor.execute(
                    code,
                    self._proxy
                )
                
                if execution_result.success:
                    logger.info(f"Task completed successfully on attempt {attempt + 1}")
                    return {
                        "success": True,
                        "result": execution_result.return_value or execution_result.output,
                        "generated_code": code,
                        "execution_time": time.time() - start_time,
                        "attempts": attempt + 1,
                        "metadata": execution_result.metadata
                    }
                else:
                    last_error = execution_result.error
                    logger.warning(
                        f"Execution failed on attempt {attempt + 1}: {last_error}"
                    )
                    
            except Exception as e:
                last_error = str(e)
                logger.error(f"Error on attempt {attempt + 1}: {e}")
        
        # All retries exhausted
        return {
            "success": False,
            "result": {"error": f"Failed after {max_retries} attempts", "last_error": last_error},
            "generated_code": code if 'code' in locals() else "",
            "execution_time": time.time() - start_time,
            "attempts": max_retries
        }
    
    async def cleanup(self):
        """Clean up resources."""
        if self._executor:
            await self._executor.cleanup()
        if self._proxy:
            await self._proxy.close()
        
        self._initialized = False
        logger.info("CodeMode instance cleaned up")
    
    def get_available_tools(self) -> Dict[str, Any]:
        """
        Get information about available tools.
        
        Returns:
            Dictionary with tool names and descriptions
        """
        return {
            name: {
                "description": tool.description,
                "input_schema": tool.input_schema.model_json_schema() if tool.input_schema else None,
                "output_schema": tool.output_schema.model_json_schema() if tool.output_schema else None
            }
            for name, tool in self.tools.items()
        }
    
    def get_config(self) -> Dict[str, Any]:
        """
        Get current configuration.
        
        Returns:
            Configuration dictionary
        """
        return self.config.model_dump(exclude={"llm_api_key"})
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.cleanup()
