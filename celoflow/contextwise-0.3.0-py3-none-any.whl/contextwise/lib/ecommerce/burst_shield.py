"""Elastic Burst Shield Plugin.

This plugin provides:
- Edge rate limiting per customer/IP
- Load-based request shedding and queueing
- Request timeouts
- Connection pooling hints
- Autoscaling triggers (hooks for external systems)
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

from fastapi import Request, Response, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from ..base import AgentPlugin
from .defaults import CoreSkillsUsage, get_ecommerce_defaults

if TYPE_CHECKING:
    from agents import Agent
    from fastapi import FastAPI


@dataclass
class RateLimitConfig:
    """Rate limiting configuration."""

    per_customer_rps: int = 10  # Requests per second per customer
    per_ip_rps: int = 100  # Requests per second per IP
    window_seconds: int = 1  # Sliding window size


@dataclass
class LoadSheddingConfig:
    """Load shedding configuration."""

    enabled: bool = True
    threshold: float = 0.8  # Shed when at 80% capacity
    queue_overload: bool = True  # Queue instead of rejecting
    queue_max_size: int = 1000
    queue_timeout_seconds: float = 30.0


class RateLimiter:
    """Token bucket rate limiter with sliding window."""

    def __init__(self, config: RateLimitConfig):
        """Initialize rate limiter.

        Args:
            config: Rate limiting configuration.
        """
        self.config = config
        self._buckets: Dict[str, List[float]] = defaultdict(list)  # Key -> timestamps
        self._lock = asyncio.Lock()

    async def check_rate_limit(
        self,
        key: str,
        limit: int,
        window: int = 1,
    ) -> tuple[bool, Optional[float]]:
        """Check if request is within rate limit.

        Args:
            key: Identifier (customer_id, IP, etc.).
            limit: Maximum requests per window.
            window: Time window in seconds.

        Returns:
            Tuple of (allowed, retry_after_seconds).
        """
        async with self._lock:
            now = time.time()
            cutoff = now - window

            # Clean old timestamps
            if key in self._buckets:
                self._buckets[key] = [ts for ts in self._buckets[key] if ts > cutoff]

            # Check limit
            request_count = len(self._buckets[key])

            if request_count >= limit:
                # Rate limited
                oldest = min(self._buckets[key])
                retry_after = oldest + window - now
                return False, retry_after

            # Allow request
            self._buckets[key].append(now)
            return True, None

    async def clear(self, key: str) -> None:
        """Clear rate limit for a key.

        Args:
            key: Identifier to clear.
        """
        async with self._lock:
            if key in self._buckets:
                del self._buckets[key]


class LoadShedder:
    """Load-based request shedding and queueing."""

    def __init__(self, config: LoadSheddingConfig):
        """Initialize load shedder.

        Args:
            config: Load shedding configuration.
        """
        self.config = config
        self._active_requests = 0
        self._max_capacity = 1000  # TODO: Make configurable
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=config.queue_max_size)
        self._lock = asyncio.Lock()

    async def acquire(self) -> bool:
        """Acquire permission to process request.

        Returns:
            True if allowed, False if shed.
        """
        async with self._lock:
            load = self._active_requests / self._max_capacity

            if load >= self.config.threshold:
                if self.config.queue_overload:
                    # Try to queue
                    try:
                        await asyncio.wait_for(
                            self._queue.put(None),
                            timeout=self.config.queue_timeout_seconds,
                        )
                        self._active_requests += 1
                        return True
                    except asyncio.TimeoutError:
                        # Queue full
                        return False
                else:
                    # Shed request
                    return False

            # Below threshold
            self._active_requests += 1
            return True

    async def release(self) -> None:
        """Release request slot."""
        async with self._lock:
            self._active_requests = max(0, self._active_requests - 1)
            # Process queued request if any
            if not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass

    def get_load(self) -> float:
        """Get current load factor.

        Returns:
            Load as fraction (0.0 to 1.0+).
        """
        return self._active_requests / self._max_capacity


class BurstShieldMiddleware(BaseHTTPMiddleware):
    """FastAPI middleware for burst protection."""

    def __init__(
        self,
        app: "FastAPI",
        rate_limiter: RateLimiter,
        load_shedder: LoadShedder,
        timeout_seconds: float = 30.0,
        get_customer_id: Optional[Callable[[Request], Optional[str]]] = None,
    ):
        """Initialize middleware.

        Args:
            app: FastAPI application.
            rate_limiter: Rate limiter instance.
            load_shedder: Load shedder instance.
            timeout_seconds: Request timeout.
            get_customer_id: Function to extract customer ID from request.
        """
        super().__init__(app)
        self.rate_limiter = rate_limiter
        self.load_shedder = load_shedder
        self.timeout_seconds = timeout_seconds
        self.get_customer_id = get_customer_id or self._default_get_customer_id

    def _default_get_customer_id(self, request: Request) -> Optional[str]:
        """Extract customer ID from request.

        Args:
            request: HTTP request.

        Returns:
            Customer ID if found, None otherwise.
        """
        # Try query param
        if "customer_id" in request.query_params:
            return request.query_params["customer_id"]

        # Try header
        if "X-Customer-ID" in request.headers:
            return request.headers["X-Customer-ID"]

        # Try JWT claims (if decoded)
        if hasattr(request.state, "user") and hasattr(request.state.user, "customer_id"):
            return request.state.user.customer_id

        return None

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request through burst shield.

        Args:
            request: HTTP request.
            call_next: Next middleware in chain.

        Returns:
            HTTP response.
        """
        # Extract identifiers
        customer_id = self.get_customer_id(request)
        client_ip = request.client.host if request.client else "unknown"

        # Check rate limits
        if customer_id:
            allowed, retry_after = await self.rate_limiter.check_rate_limit(
                f"customer:{customer_id}",
                self.rate_limiter.config.per_customer_rps,
                self.rate_limiter.config.window_seconds,
            )
            if not allowed:
                return JSONResponse(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content={
                        "error": {
                            "message": "Rate limit exceeded for customer",
                            "code": "RATE_LIMIT_EXCEEDED",
                            "details": {"retry_after": retry_after},
                        }
                    },
                    headers={"Retry-After": str(int(retry_after or 1))},
                )

        # Check IP rate limit
        allowed, retry_after = await self.rate_limiter.check_rate_limit(
            f"ip:{client_ip}",
            self.rate_limiter.config.per_ip_rps,
            self.rate_limiter.config.window_seconds,
        )
        if not allowed:
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={
                    "error": {
                        "message": "Rate limit exceeded for IP",
                        "code": "RATE_LIMIT_EXCEEDED",
                        "details": {"retry_after": retry_after},
                    }
                },
                headers={"Retry-After": str(int(retry_after or 1))},
            )

        # Check load shedding
        acquired = await self.load_shedder.acquire()
        if not acquired:
            return JSONResponse(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                content={
                    "error": {
                        "message": "Service overloaded, please retry",
                        "code": "SERVICE_OVERLOADED",
                        "details": {"load": self.load_shedder.get_load()},
                    }
                },
                headers={"Retry-After": "5"},
            )

        try:
            # Process request with timeout
            response = await asyncio.wait_for(
                call_next(request),
                timeout=self.timeout_seconds,
            )
            return response

        except asyncio.TimeoutError:
            return JSONResponse(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                content={
                    "error": {
                        "message": "Request timeout",
                        "code": "REQUEST_TIMEOUT",
                        "details": {"timeout_seconds": self.timeout_seconds},
                    }
                },
            )

        finally:
            # Release slot
            await self.load_shedder.release()


@dataclass
class BurstShieldConfig:
    """Configuration for Elastic Burst Shield plugin."""

    enabled: bool = True
    per_customer_rps: int = 10
    per_ip_rps: int = 100
    timeout_seconds: float = 30.0
    shed_overload_threshold: float = 0.8
    queue_overload: bool = True
    queue_max_size: int = 1000
    queue_timeout_seconds: float = 30.0
    core_skills: Optional[CoreSkillsUsage] = None  # Core skills usage flags


class ElasticBurstShieldPlugin(AgentPlugin):
    """Plugin for protecting server from traffic bursts.

    This plugin:
    - Rate limits requests per customer and per IP
    - Sheds load when server capacity exceeded
    - Optionally queues requests during overload
    - Enforces request timeouts
    - Provides middleware for FastAPI servers

    Usage:
        config = BurstShieldConfig(
            per_customer_rps=20,
            shed_overload_threshold=0.9,
        )
        plugin = ElasticBurstShieldPlugin(config=config)
        agent = Agent(
            model="gpt-4o-mini",
            plugins=[defaults_plugin, plugin],
        )

        # In server setup:
        app = create_app(agent)
        # Middleware is automatically installed if plugin present
    """

    id: str = "elastic_burst_shield"
    name: str = "Elastic Burst Shield"
    version: str = "0.2.0"

    def __init__(self, config: Optional[BurstShieldConfig] = None):
        """Initialize plugin with configuration.

        Args:
            config: Plugin configuration. Falls back to defaults.
        """
        self.config = config or BurstShieldConfig()

        # Initialize components
        rate_limit_config = RateLimitConfig(
            per_customer_rps=self.config.per_customer_rps,
            per_ip_rps=self.config.per_ip_rps,
        )
        self.rate_limiter = RateLimiter(rate_limit_config)

        load_shedding_config = LoadSheddingConfig(
            enabled=self.config.enabled,
            threshold=self.config.shed_overload_threshold,
            queue_overload=self.config.queue_overload,
            queue_max_size=self.config.queue_max_size,
            queue_timeout_seconds=self.config.queue_timeout_seconds,
        )
        self.load_shedder = LoadShedder(load_shedding_config)

    def configure_agent(self, agent: "Agent") -> "Agent":
        """Configure agent (no-op for server plugin).

        Args:
            agent: Agent to configure.

        Returns:
            Unmodified agent.
        """
        # Get defaults if available
        defaults = get_ecommerce_defaults(agent)
        if defaults:
            # Apply defaults if not explicitly configured
            pass

        # Burst shield doesn't add agent tools
        return agent

    def get_fastapi_middleware(self) -> List[Callable]:
        """Get FastAPI middleware to install.

        Returns:
            List of middleware factories.
        """
        if not self.config.enabled:
            return []

        def middleware_factory(app: "FastAPI") -> BurstShieldMiddleware:
            return BurstShieldMiddleware(
                app=app,
                rate_limiter=self.rate_limiter,
                load_shedder=self.load_shedder,
                timeout_seconds=self.config.timeout_seconds,
            )

        return [middleware_factory]

    def dependencies(self) -> List[str]:
        """Burst shield loads after defaults."""
        return ["ecommerce_defaults"]

    def __repr__(self) -> str:
        """String representation."""
        return f"ElasticBurstShieldPlugin(enabled={self.config.enabled}, per_customer_rps={self.config.per_customer_rps})"
