"""Inventory-Aware Guardrails Plugin.

This plugin provides:
- Pre-flight validation on inventory-sensitive commerce actions
- Multi-source ATS (Available to Sell) aggregation
- Tiered caching with velocity-based TTL
- Deterministic fallback behaviors (preorder, alternatives, block)
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Protocol, TYPE_CHECKING

from ..base import AgentPlugin
from .contracts import CommerceAction, CommerceActionType, CommerceOutcome, SideEffect
from .defaults import CacheBackend, CoreSkillsUsage, get_ecommerce_defaults

if TYPE_CHECKING:
    from agents import Agent
    from ..storage import Storage


@dataclass
class InventoryLevel:
    """Inventory availability for a SKU."""

    sku: str
    available: int
    reserved: int = 0
    on_order: int = 0
    source: str = "unknown"
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class InventoryCheckResult:
    """Result of inventory availability check."""

    sku: str
    requested_quantity: int
    available: bool
    current_level: int
    can_fulfill: bool
    preorder_available: bool = False
    alternatives: List[str] = field(default_factory=list)
    message: str = ""


class InventorySource(Protocol):
    """Protocol for inventory data sources."""

    async def get_inventory(self, sku: str) -> Optional[InventoryLevel]:
        """Get inventory level for a SKU.

        Args:
            sku: Stock keeping unit identifier.

        Returns:
            InventoryLevel if found, None otherwise.
        """
        ...

    async def get_inventory_batch(self, skus: List[str]) -> Dict[str, InventoryLevel]:
        """Get inventory levels for multiple SKUs.

        Args:
            skus: List of SKU identifiers.

        Returns:
            Dictionary mapping SKU to InventoryLevel.
        """
        ...


class MockInventorySource:
    """Mock inventory source for development/testing."""

    def __init__(self):
        """Initialize mock inventory data."""
        self._inventory: Dict[str, InventoryLevel] = {
            "SKU001": InventoryLevel(sku="SKU001", available=100, source="mock"),
            "SKU002": InventoryLevel(sku="SKU002", available=5, source="mock"),
            "SKU003": InventoryLevel(sku="SKU003", available=0, on_order=50, source="mock"),
        }

    async def get_inventory(self, sku: str) -> Optional[InventoryLevel]:
        """Get mock inventory."""
        return self._inventory.get(sku)

    async def get_inventory_batch(self, skus: List[str]) -> Dict[str, InventoryLevel]:
        """Get mock inventory batch."""
        return {sku: level for sku, level in self._inventory.items() if sku in skus}


class InventoryCache:
    """Tiered cache for inventory levels with velocity-based TTL."""

    def __init__(
        self,
        backend: str = "memory",
        ttl_fast: int = 60,
        ttl_default: int = 300,
        ttl_slow: int = 3600,
    ):
        """Initialize cache.

        Args:
            backend: Cache backend type (memory, redis, storage).
            ttl_fast: TTL for fast-moving SKUs (seconds).
            ttl_default: Default TTL (seconds).
            ttl_slow: TTL for slow-moving SKUs (seconds).
        """
        self.backend = backend
        self.ttl_fast = ttl_fast
        self.ttl_default = ttl_default
        self.ttl_slow = ttl_slow
        self._cache: Dict[str, tuple[InventoryLevel, float]] = {}  # SKU -> (level, expiry)
        self._velocity: Dict[str, int] = {}  # SKU -> check count (for velocity tracking)

    def _get_ttl(self, sku: str) -> int:
        """Determine TTL based on SKU velocity.

        Args:
            sku: Stock keeping unit.

        Returns:
            TTL in seconds.
        """
        checks = self._velocity.get(sku, 0)
        if checks > 100:  # High velocity
            return self.ttl_fast
        elif checks < 10:  # Low velocity
            return self.ttl_slow
        else:
            return self.ttl_default

    async def get(self, sku: str) -> Optional[InventoryLevel]:
        """Get cached inventory level.

        Args:
            sku: Stock keeping unit.

        Returns:
            Cached level if valid, None if expired/missing.
        """
        if sku in self._cache:
            level, expiry = self._cache[sku]
            if time.time() < expiry:
                # Track velocity
                self._velocity[sku] = self._velocity.get(sku, 0) + 1
                return level
            else:
                # Expired
                del self._cache[sku]
        return None

    async def set(self, sku: str, level: InventoryLevel) -> None:
        """Cache inventory level.

        Args:
            sku: Stock keeping unit.
            level: Inventory level to cache.
        """
        ttl = self._get_ttl(sku)
        expiry = time.time() + ttl
        self._cache[sku] = (level, expiry)

    async def invalidate(self, sku: str) -> None:
        """Invalidate cached inventory.

        Args:
            sku: Stock keeping unit.
        """
        if sku in self._cache:
            del self._cache[sku]


class InventoryAggregator:
    """Aggregates inventory from multiple sources."""

    def __init__(
        self,
        sources: List[InventorySource],
        cache: Optional[InventoryCache] = None,
    ):
        """Initialize aggregator.

        Args:
            sources: List of inventory data sources.
            cache: Optional cache layer.
        """
        self.sources = sources
        self.cache = cache or InventoryCache()

    async def get_inventory(self, sku: str) -> Optional[InventoryLevel]:
        """Get aggregated inventory for a SKU.

        Args:
            sku: Stock keeping unit.

        Returns:
            Aggregated inventory level.
        """
        # Check cache first
        cached = await self.cache.get(sku)
        if cached:
            return cached

        # Query all sources
        tasks = [source.get_inventory(sku) for source in self.sources]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Aggregate results
        levels = [r for r in results if isinstance(r, InventoryLevel)]
        if not levels:
            return None

        # Sum available across sources
        aggregated = InventoryLevel(
            sku=sku,
            available=sum(l.available for l in levels),
            reserved=sum(l.reserved for l in levels),
            on_order=sum(l.on_order for l in levels),
            source="aggregated",
        )

        # Cache result
        await self.cache.set(sku, aggregated)

        return aggregated


class GuardrailInterceptor:
    """Intercepts and validates inventory-sensitive actions."""

    def __init__(
        self,
        aggregator: InventoryAggregator,
        allow_preorder: bool = True,
    ):
        """Initialize interceptor.

        Args:
            aggregator: Inventory aggregator.
            allow_preorder: Whether to allow preorder fallback.
        """
        self.aggregator = aggregator
        self.allow_preorder = allow_preorder

    async def check_action(self, action: CommerceAction) -> InventoryCheckResult:
        """Check if action can be fulfilled.

        Args:
            action: Commerce action to validate.

        Returns:
            Inventory check result.
        """
        # Extract SKUs and quantities from action
        skus_needed = self._extract_skus(action)
        if not skus_needed:
            # No inventory validation needed
            return InventoryCheckResult(
                sku="N/A",
                requested_quantity=0,
                available=True,
                current_level=0,
                can_fulfill=True,
                message="No inventory check required",
            )

        # Check each SKU
        for sku, quantity in skus_needed.items():
            level = await self.aggregator.get_inventory(sku)

            if not level:
                return InventoryCheckResult(
                    sku=sku,
                    requested_quantity=quantity,
                    available=False,
                    current_level=0,
                    can_fulfill=False,
                    message=f"SKU {sku} not found",
                )

            if level.available < quantity:
                # Check if preorder is available
                preorder_available = self.allow_preorder and level.on_order > 0

                return InventoryCheckResult(
                    sku=sku,
                    requested_quantity=quantity,
                    available=False,
                    current_level=level.available,
                    can_fulfill=False,
                    preorder_available=preorder_available,
                    message=f"Insufficient inventory: {level.available} available, {quantity} requested",
                )

        # All checks passed
        return InventoryCheckResult(
            sku=list(skus_needed.keys())[0],
            requested_quantity=list(skus_needed.values())[0],
            available=True,
            current_level=level.available if level else 0,
            can_fulfill=True,
            message="Inventory available",
        )

    def _extract_skus(self, action: CommerceAction) -> Dict[str, int]:
        """Extract SKUs and quantities from action payload.

        Args:
            action: Commerce action.

        Returns:
            Dictionary mapping SKU to quantity needed.
        """
        skus: Dict[str, int] = {}

        # Handle different action types
        if action.type in [
            CommerceActionType.RECOMMENDATION,
            CommerceActionType.PRODUCT_SUGGESTION,
        ]:
            # Recommendations might include SKUs
            if "skus" in action.payload:
                for sku in action.payload["skus"]:
                    skus[sku] = 1

        elif action.type == CommerceActionType.INVENTORY_RESERVE:
            # Direct inventory reservation
            if "sku" in action.payload:
                skus[action.payload["sku"]] = action.payload.get("quantity", 1)

        elif action.type in [CommerceActionType.REPLACEMENT, CommerceActionType.ORDER_CREATE]:
            # Orders and replacements need inventory
            if "items" in action.payload:
                for item in action.payload["items"]:
                    sku = item.get("sku")
                    quantity = item.get("quantity", 1)
                    if sku:
                        skus[sku] = quantity

        return skus


@dataclass
class InventoryConfig:
    """Configuration for Inventory Guardrails plugin."""

    enabled: bool = True
    cache_backend: str = "memory"
    ttl_fast: int = 60
    ttl_default: int = 300
    ttl_slow: int = 3600
    sources: List[InventorySource] = field(default_factory=list)
    allow_preorder_fallback: bool = True
    core_skills: Optional[CoreSkillsUsage] = None  # Core skills usage flags


class InventoryGuardrailsPlugin(AgentPlugin):
    """Plugin for inventory-aware validation of commerce actions.

    This plugin:
    - Validates inventory availability before commerce actions
    - Aggregates inventory from multiple sources
    - Caches inventory with velocity-based TTL
    - Provides preorder fallback when configured
    - Blocks or modifies actions when inventory insufficient

    Usage:
        sources = [ShopifyInventorySource(), ERPInventorySource()]
        config = InventoryConfig(
            sources=sources,
            allow_preorder_fallback=True,
        )
        plugin = InventoryGuardrailsPlugin(config=config)
        agent = Agent(
            model="gpt-4o-mini",
            plugins=[defaults_plugin, policy_plugin, plugin],
        )
    """

    id: str = "inventory_guardrails"
    name: str = "Inventory Guardrails"
    version: str = "0.2.0"

    def __init__(self, config: Optional[InventoryConfig] = None):
        """Initialize plugin with configuration.

        Args:
            config: Plugin configuration. Falls back to defaults.
        """
        self.config = config or InventoryConfig()

        # Use mock source if no sources provided
        if not self.config.sources:
            self.config.sources = [MockInventorySource()]

        # Initialize cache
        cache = InventoryCache(
            backend=self.config.cache_backend,
            ttl_fast=self.config.ttl_fast,
            ttl_default=self.config.ttl_default,
            ttl_slow=self.config.ttl_slow,
        )

        # Initialize aggregator and interceptor
        self.aggregator = InventoryAggregator(sources=self.config.sources, cache=cache)
        self.interceptor = GuardrailInterceptor(
            aggregator=self.aggregator,
            allow_preorder=self.config.allow_preorder_fallback,
        )

    def configure_agent(self, agent: "Agent") -> "Agent":
        """Add inventory check tool to agent.

        Discovers core skill plugins (HMLR, Scheduler, Acontext) from agent.plugin_index
        and uses them based on config.core_skills flags.

        Args:
            agent: Agent to configure.

        Returns:
            Agent with inventory tools added.
        """
        # Get defaults if available
        defaults = get_ecommerce_defaults(agent)
        if defaults:
            if not self.config.sources:
                # Apply defaults
                pass  # Would configure from defaults here

            # Use defaults for core skills if not explicitly set
            if self.config.core_skills is None and defaults.inventory.core_skills:
                self.config.core_skills = defaults.inventory.core_skills

        # Discover core skill plugins from agent registry
        plugin_index = getattr(agent, "plugin_index", {}) or {}
        hmlr_plugin = plugin_index.get("hmlr_memory")
        scheduler_plugin = plugin_index.get("apscheduler")
        acontext_plugin = plugin_index.get("acontext")

        # Schedule cache warmup jobs if scheduler is enabled
        if self.config.core_skills and self.config.core_skills.use_scheduler_jobs and scheduler_plugin:
            try:
                from ...lib.scheduler import JobConfig

                # Schedule daily cache warmup for high-velocity SKUs
                scheduler_plugin.create_job(JobConfig(
                    job_id=f"{self.id}_inventory_cache_warmup",
                    name="Inventory Cache Warmup",
                    schedule="0 6 * * *",  # Daily at 6 AM
                    target=self._warmup_high_velocity_skus,
                    metadata={"plugin_id": self.id}
                ))
            except Exception as e:
                print(f"Failed to schedule inventory cache warmup job: {e}")

        # Create inventory check tool
        from agents import function_tool

        @function_tool(strict_mode=False)
        async def check_inventory_availability(sku: str, quantity: int = 1) -> dict:
            """Check if inventory is available for a SKU.

            Args:
                sku: Stock keeping unit identifier.
                quantity: Quantity needed (default 1).

            Returns:
                Availability information with current levels.
            """
            level = await self.aggregator.get_inventory(sku)

            if not level:
                return {
                    "sku": sku,
                    "available": False,
                    "message": f"SKU {sku} not found",
                }

            can_fulfill = level.available >= quantity

            return {
                "sku": sku,
                "requested_quantity": quantity,
                "available_quantity": level.available,
                "reserved": level.reserved,
                "on_order": level.on_order,
                "can_fulfill": can_fulfill,
                "preorder_available": not can_fulfill and level.on_order > 0,
                "message": f"{'Available' if can_fulfill else 'Insufficient'} inventory for {sku}",
            }

        @function_tool(strict_mode=False)
        async def validate_commerce_action_inventory(action_dict: dict) -> dict:
            """Validate inventory for a commerce action before execution.

            Args:
                action_dict: Commerce action as dictionary.

            Returns:
                Validation result with inventory status.
            """
            from .contracts import CommerceAction

            action = CommerceAction.from_dict(action_dict)
            result = await self.interceptor.check_action(action)

            return {
                "can_fulfill": result.can_fulfill,
                "sku": result.sku,
                "requested": result.requested_quantity,
                "available": result.current_level,
                "preorder_available": result.preorder_available,
                "message": result.message,
            }

        # Add tools to agent
        tools = list(getattr(agent, "tools", []))
        tools.extend([check_inventory_availability, validate_commerce_action_inventory])

        return agent.clone(tools=tools)

    def _warmup_high_velocity_skus(self, context_dict: dict) -> dict:
        """Warm up cache for high-velocity SKUs (placeholder).

        This would pre-fetch inventory for frequently checked SKUs.

        Args:
            context_dict: Context dictionary from scheduler

        Returns:
            Result dictionary with warmup status
        """
        # TODO: Implement actual cache warmup logic
        # Would query high-velocity SKUs and pre-populate cache
        return {
            "success": True,
            "message": "Cache warmup completed",
            "skus_warmed": 0,
        }

    def dependencies(self) -> List[str]:
        """Inventory guardrails should load after policy shield."""
        return ["ecommerce_defaults", "policy_ledger_shield"]

    def __repr__(self) -> str:
        """String representation."""
        return f"InventoryGuardrailsPlugin(sources={len(self.config.sources)}, enabled={self.config.enabled})"
