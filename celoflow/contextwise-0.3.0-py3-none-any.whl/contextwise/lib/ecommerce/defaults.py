"""E-commerce defaults plugin for config resolution and fallback.

This plugin implements the config fallback contract, providing default
configurations that other e-commerce plugins can inherit from.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from ..base import AgentPlugin

if TYPE_CHECKING:
    from agents import Agent


class PolicyMode(str, Enum):
    """Policy enforcement modes."""

    ENFORCE = "enforce"  # Block non-compliant actions
    LOG_ONLY = "log_only"  # Log but allow all actions
    OFF = "off"  # No policy validation


class RulesSource(str, Enum):
    """Sources for policy rules."""

    INLINE = "inline"  # Rules defined in config
    STORAGE = "storage"  # Rules from storage backend
    FILE = "file"  # Rules from file


class CacheBackend(str, Enum):
    """Cache backend types."""

    REDIS = "redis"
    STORAGE = "storage"
    MEMORY = "memory"


class StorageBackend(str, Enum):
    """Storage backend types."""

    STORAGE = "storage"  # Use Contextwise Storage
    POSTGRES = "postgres"
    SQLITE = "sqlite"
    REDIS = "redis"
    S3 = "s3"


class CapabilityDegradeMode(str, Enum):
    """Channel capability degradation modes."""

    GRACEFUL = "graceful"  # Adapt content to channel limits
    STRICT = "strict"  # Fail if channel doesn't support features


@dataclass
class CoreSkillsUsage:
    """Core skills usage flags for ecommerce plugins.

    These flags control whether an ecommerce plugin uses core skills
    (HMLR, Scheduler, Acontext) that must be configured at the agent level.

    All flags default to False to preserve backward compatibility.
    The agent must have the relevant core skill plugin configured
    for these flags to have any effect.
    """

    use_hmlr_context: bool = False  # Retrieve context from HMLR memory
    use_scheduler_jobs: bool = False  # Create and manage scheduler jobs
    use_acontext_search: bool = False  # Search and learn from Acontext skills


@dataclass
class PolicyDefaults:
    """Default policy configuration."""

    mode: PolicyMode = PolicyMode.LOG_ONLY
    rules_source: RulesSource = RulesSource.INLINE
    event_store_backend: StorageBackend = StorageBackend.STORAGE
    pattern_monitoring_enabled: bool = False
    max_refund_amount_auto: float = 500.0
    require_approval_threshold: float = 1000.0
    core_skills: Optional[CoreSkillsUsage] = None


@dataclass
class InventoryDefaults:
    """Default inventory configuration."""

    cache_backend: CacheBackend = CacheBackend.MEMORY
    ttl_seconds_fast: int = 60  # Fast-moving SKUs
    ttl_seconds_default: int = 300  # Default TTL
    ttl_seconds_slow: int = 3600  # Slow-moving SKUs
    allow_preorder_fallback: bool = True
    sources: List[str] = field(default_factory=list)  # Inventory sources
    core_skills: Optional[CoreSkillsUsage] = None


@dataclass
class RMADefaults:
    """Default RMA configuration."""

    return_window_days: int = 30
    max_auto_refund_amount: float = 500.0
    require_approval_over_amount: float = 1000.0
    structured_decision_temperature: float = 0.2
    enable_auto_processing: bool = True
    core_skills: Optional[CoreSkillsUsage] = None


@dataclass
class BurstShieldDefaults:
    """Default burst shield configuration."""

    enabled: bool = True
    per_customer_rps: int = 10  # Requests per second per customer
    per_ip_rps: int = 100  # Requests per second per IP
    timeout_seconds: float = 30.0
    shed_overload_threshold: float = 0.8  # Shed when at 80% capacity
    queue_overload: bool = True
    core_skills: Optional[CoreSkillsUsage] = None


@dataclass
class DocVisionDefaults:
    """Default document vision configuration."""

    enabled: bool = True
    allowed_mime_types: List[str] = field(
        default_factory=lambda: [
            "image/jpeg",
            "image/png",
            "image/webp",
            "application/pdf",
        ]
    )
    retention_days: int = 90
    storage_backend: StorageBackend = StorageBackend.S3
    max_file_size_mb: float = 10.0
    core_skills: Optional[CoreSkillsUsage] = None


@dataclass
class ChannelBuilderDefaults:
    """Default channel builder configuration."""

    default_flow_id: str = "default"
    capability_degrade_mode: CapabilityDegradeMode = CapabilityDegradeMode.GRACEFUL
    max_chunks: int = 5  # Max message chunks
    flow_source: str = "file"  # file, storage, inline
    core_skills: Optional[CoreSkillsUsage] = None


@dataclass
class EcommerceDefaults:
    """Unified e-commerce defaults for all plugins.

    This class provides the fallback configuration that ecommerce plugins
    use when explicit configuration is not provided.

    Config resolution order:
    1. Explicit plugin instance config
    2. Agent-level ecommerce defaults (this class)
    3. Environment variables (for secrets)
    4. Hard-coded plugin defaults
    """

    policy: PolicyDefaults = field(default_factory=PolicyDefaults)
    inventory: InventoryDefaults = field(default_factory=InventoryDefaults)
    rma: RMADefaults = field(default_factory=RMADefaults)
    burst_shield: BurstShieldDefaults = field(default_factory=BurstShieldDefaults)
    doc_vision: DocVisionDefaults = field(default_factory=DocVisionDefaults)
    channel_builder: ChannelBuilderDefaults = field(default_factory=ChannelBuilderDefaults)

    # Global settings
    enable_audit_logging: bool = True
    enable_telemetry: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "policy": {
                "mode": self.policy.mode.value,
                "rules_source": self.policy.rules_source.value,
                "event_store_backend": self.policy.event_store_backend.value,
                "pattern_monitoring_enabled": self.policy.pattern_monitoring_enabled,
                "max_refund_amount_auto": self.policy.max_refund_amount_auto,
                "require_approval_threshold": self.policy.require_approval_threshold,
            },
            "inventory": {
                "cache_backend": self.inventory.cache_backend.value,
                "ttl_seconds_fast": self.inventory.ttl_seconds_fast,
                "ttl_seconds_default": self.inventory.ttl_seconds_default,
                "ttl_seconds_slow": self.inventory.ttl_seconds_slow,
                "allow_preorder_fallback": self.inventory.allow_preorder_fallback,
                "sources": self.inventory.sources,
            },
            "rma": {
                "return_window_days": self.rma.return_window_days,
                "max_auto_refund_amount": self.rma.max_auto_refund_amount,
                "require_approval_over_amount": self.rma.require_approval_over_amount,
                "structured_decision_temperature": self.rma.structured_decision_temperature,
                "enable_auto_processing": self.rma.enable_auto_processing,
            },
            "burst_shield": {
                "enabled": self.burst_shield.enabled,
                "per_customer_rps": self.burst_shield.per_customer_rps,
                "per_ip_rps": self.burst_shield.per_ip_rps,
                "timeout_seconds": self.burst_shield.timeout_seconds,
                "shed_overload_threshold": self.burst_shield.shed_overload_threshold,
                "queue_overload": self.burst_shield.queue_overload,
            },
            "doc_vision": {
                "enabled": self.doc_vision.enabled,
                "allowed_mime_types": self.doc_vision.allowed_mime_types,
                "retention_days": self.doc_vision.retention_days,
                "storage_backend": self.doc_vision.storage_backend.value,
                "max_file_size_mb": self.doc_vision.max_file_size_mb,
            },
            "channel_builder": {
                "default_flow_id": self.channel_builder.default_flow_id,
                "capability_degrade_mode": self.channel_builder.capability_degrade_mode.value,
                "max_chunks": self.channel_builder.max_chunks,
                "flow_source": self.channel_builder.flow_source,
            },
            "enable_audit_logging": self.enable_audit_logging,
            "enable_telemetry": self.enable_telemetry,
            "metadata": self.metadata,
        }


class EcommerceDefaultsPlugin(AgentPlugin):
    """Plugin that provides default e-commerce configurations.

    This plugin should be loaded first in the plugin chain so other
    ecommerce plugins can access the defaults.

    Usage:
        defaults = EcommerceDefaults(
            rma=RMADefaults(return_window_days=45),
        )
        plugin = EcommerceDefaultsPlugin(defaults=defaults)
        agent = Agent(
            model="gpt-4o-mini",
            plugins=[plugin, ...other_ecommerce_plugins],
        )
    """

    id: str = "ecommerce_defaults"
    name: str = "E-commerce Defaults"
    version: str = "0.2.0"

    def __init__(self, defaults: Optional[EcommerceDefaults] = None):
        """Initialize with optional custom defaults.

        Args:
            defaults: Custom default configuration. If not provided,
                uses safe development defaults.
        """
        self.defaults = defaults or EcommerceDefaults()

    def get_defaults(self) -> EcommerceDefaults:
        """Get the defaults configuration.

        Returns:
            EcommerceDefaults instance.
        """
        return self.defaults

    def configure_agent(self, agent: "Agent") -> "Agent":
        """Configure agent (no-op for defaults plugin).

        The defaults plugin doesn't modify the agent; it just provides
        configuration that other plugins can access.

        Args:
            agent: The agent to configure.

        Returns:
            Unmodified agent.
        """
        return agent

    def __repr__(self) -> str:
        """String representation."""
        return f"EcommerceDefaultsPlugin(id={self.id}, version={self.version})"


def get_ecommerce_defaults(agent: "Agent") -> Optional[EcommerceDefaults]:
    """Helper to extract ecommerce defaults from an agent's plugins.

    Args:
        agent: Agent instance with plugins.

    Returns:
        EcommerceDefaults if found, None otherwise.
    """
    # Check if agent has plugins attribute
    if not hasattr(agent, "plugins"):
        return None

    # Find the defaults plugin
    for plugin in agent.plugins:
        if isinstance(plugin, EcommerceDefaultsPlugin):
            return plugin.get_defaults()

    return None
