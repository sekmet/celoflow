"""E-commerce plugins for Contextwise v0.3.0.

This package provides a comprehensive set of plugins for building AI-powered
e-commerce agents with capabilities including:

- Policy compliance and audit logging
- Inventory-aware guardrails
- Rate limiting and burst protection
- Channel-agnostic flow execution
- Autonomous RMA processing
- Document vision and evidence extraction

All plugins follow Contextwise plugin patterns and can be composed together
or used independently.
"""

from .contracts import (
    CommerceAction,
    CommerceActionType,
    CommerceContext,
    CommerceOutcome,
)
from .defaults import (
    CapabilityDegradeMode,
    CoreSkillsUsage,
    EcommerceDefaults,
    EcommerceDefaultsPlugin,
    InventoryDefaults,
    PolicyDefaults,
    RMADefaults,
)
from .policy_shield import (
    ComplianceResult,
    ComplianceStatus,
    PolicyLedgerShieldPlugin,
    PolicyMode,
    PolicyRule,
    PolicyShieldConfig,
)
from .inventory_guardrails import InventoryGuardrailsPlugin, InventoryConfig
from .burst_shield import ElasticBurstShieldPlugin, BurstShieldConfig
from .channel_builder import UniversalChannelBuilderPlugin, FlowConfig
from .rma_agent import AgenticRMAPlugin, RMAConfig, RMADecision
from .document_vision import PostPurchaseDocumentVisionPlugin, VisionConfig

__all__ = [
    # Contracts
    "CommerceAction",
    "CommerceActionType",
    "CommerceContext",
    "CommerceOutcome",
    # Defaults
    "EcommerceDefaults",
    "EcommerceDefaultsPlugin",
    "InventoryDefaults",
    "RMADefaults",
    "PolicyDefaults",
    "CapabilityDegradeMode",
    "CoreSkillsUsage",
    # Plugins
    "PolicyLedgerShieldPlugin",
    "PolicyMode",
    "PolicyShieldConfig",
    "PolicyRule",
    "ComplianceStatus",
    "ComplianceResult",
    "InventoryGuardrailsPlugin",
    "InventoryConfig",
    "ElasticBurstShieldPlugin",
    "BurstShieldConfig",
    "UniversalChannelBuilderPlugin",
    "FlowConfig",
    "AgenticRMAPlugin",
    "RMAConfig",
    "RMADecision",
    "PostPurchaseDocumentVisionPlugin",
    "VisionConfig",
]

__version__ = "0.2.0"
