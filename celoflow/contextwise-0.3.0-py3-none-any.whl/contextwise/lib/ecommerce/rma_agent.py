"""Agentic RMA Agent Plugin.

This plugin provides:
- Autonomous RMA processing with structured decisions
- SLA eligibility checks
- Multi-system orchestration (shop, ERP, shipping)
- Policy-compliant execution
- Inventory-aware replacement handling
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from ..base import AgentPlugin
from ..context import AgentContext
from .contracts import CommerceAction, CommerceActionType, CommerceContext, CommerceOutcome, SideEffect
from .defaults import CoreSkillsUsage, get_ecommerce_defaults

if TYPE_CHECKING:
    from agents import Agent


class RMADecisionAction(str, Enum):
    """Possible RMA decision actions."""

    RETURN = "return"  # Accept return, provide label
    REPLACEMENT = "replacement"  # Send replacement item
    REFUND = "refund"  # Issue refund
    STORE_CREDIT = "store_credit"  # Provide store credit
    REPAIR = "repair"  # Repair and return
    ESCALATE = "escalate"  # Escalate to human
    REJECT = "reject"  # Reject RMA request


@dataclass
class RMADecision:
    """Structured RMA decision output."""

    action: RMADecisionAction
    reason: str
    requires_approval: bool
    estimated_cost: float
    confidence: float = 0.0  # 0.0 to 1.0
    alternative_actions: List[RMADecisionAction] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "action": self.action.value,
            "reason": self.reason,
            "requires_approval": self.requires_approval,
            "estimated_cost": self.estimated_cost,
            "confidence": self.confidence,
            "alternative_actions": [a.value for a in self.alternative_actions],
            "metadata": self.metadata,
        }


@dataclass
class OrderInfo:
    """Order information for RMA processing."""

    order_id: str
    order_number: str
    order_date: datetime
    customer_id: str
    items: List[Dict[str, Any]] = field(default_factory=list)
    total_amount: float = 0.0
    status: str = "unknown"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CustomerTier:
    """Customer tier information."""

    tier: str  # "standard", "premium", "vip"
    lifetime_value: float = 0.0
    return_history_count: int = 0
    account_age_days: int = 0
    is_high_value: bool = False


class RMAOrchestrator:
    """Orchestrates RMA processing across multiple systems."""

    def __init__(
        self,
        return_window_days: int = 30,
        max_auto_refund: float = 500.0,
        require_approval_threshold: float = 1000.0,
    ):
        """Initialize orchestrator.

        Args:
            return_window_days: Return window in days.
            max_auto_refund: Maximum auto-refund amount.
            require_approval_threshold: Amount requiring approval.
        """
        self.return_window_days = return_window_days
        self.max_auto_refund = max_auto_refund
        self.require_approval_threshold = require_approval_threshold

    async def check_sla_eligibility(self, order: OrderInfo) -> tuple[bool, str]:
        """Check if order is eligible for RMA based on SLA.

        Args:
            order: Order information.

        Returns:
            Tuple of (eligible, reason).
        """
        # Check return window
        now = datetime.utcnow()
        order_age = (now - order.order_date).days

        if order_age > self.return_window_days:
            return False, f"Order is {order_age} days old, exceeds {self.return_window_days} day return window"

        # Check order status
        if order.status in ["cancelled", "refunded"]:
            return False, f"Order status is {order.status}, not eligible for RMA"

        return True, "Order eligible for RMA"

    async def get_customer_tier(self, customer_id: str) -> CustomerTier:
        """Get customer tier information.

        Args:
            customer_id: Customer identifier.

        Returns:
            Customer tier information.
        """
        # Mock implementation - would query CRM/customer database
        return CustomerTier(
            tier="standard",
            lifetime_value=1000.0,
            return_history_count=2,
            account_age_days=365,
            is_high_value=False,
        )

    async def estimate_cost(self, action: RMADecisionAction, order: OrderInfo) -> float:
        """Estimate cost of RMA action.

        Args:
            action: RMA action to take.
            order: Order information.

        Returns:
            Estimated cost in dollars.
        """
        if action == RMADecisionAction.REFUND:
            return order.total_amount

        elif action == RMADecisionAction.REPLACEMENT:
            # Cost of item + shipping
            return order.total_amount + 15.0  # Assume $15 shipping

        elif action == RMADecisionAction.RETURN:
            # Cost of return shipping label
            return 15.0

        elif action == RMADecisionAction.STORE_CREDIT:
            # No immediate cost
            return 0.0

        else:
            return 0.0

    async def make_decision(
        self,
        order: OrderInfo,
        reason: str,
        customer: CustomerTier,
        llm_recommendation: Optional[str] = None,
    ) -> RMADecision:
        """Make RMA decision based on context.

        Args:
            order: Order information.
            reason: Customer's return reason.
            customer: Customer tier information.
            llm_recommendation: Optional LLM-generated recommendation.

        Returns:
            RMA decision.
        """
        # Check SLA eligibility first
        eligible, eligibility_reason = await self.check_sla_eligibility(order)
        if not eligible:
            return RMADecision(
                action=RMADecisionAction.REJECT,
                reason=eligibility_reason,
                requires_approval=False,
                estimated_cost=0.0,
                confidence=1.0,
            )

        # Determine action based on rules and context
        if "defective" in reason.lower() or "damaged" in reason.lower():
            action = RMADecisionAction.REPLACEMENT
            confidence = 0.9
        elif "wrong item" in reason.lower():
            action = RMADecisionAction.REPLACEMENT
            confidence = 0.95
        elif "not as expected" in reason.lower():
            action = RMADecisionAction.RETURN
            confidence = 0.8
        elif "changed mind" in reason.lower():
            action = RMADecisionAction.STORE_CREDIT
            confidence = 0.7
        else:
            action = RMADecisionAction.ESCALATE
            confidence = 0.5

        # Estimate cost
        cost = await self.estimate_cost(action, order)

        # Check if requires approval
        requires_approval = (
            cost > self.require_approval_threshold
            or confidence < 0.7
            or action == RMADecisionAction.ESCALATE
        )

        # Override for high-value customers
        if customer.is_high_value and cost <= self.max_auto_refund * 2:
            requires_approval = False

        return RMADecision(
            action=action,
            reason=f"Based on reason '{reason}' and customer tier '{customer.tier}'",
            requires_approval=requires_approval,
            estimated_cost=cost,
            confidence=confidence,
            alternative_actions=[RMADecisionAction.REFUND, RMADecisionAction.STORE_CREDIT],
        )

    async def execute_decision(
        self,
        decision: RMADecision,
        order: OrderInfo,
        customer: CustomerTier,
    ) -> CommerceOutcome:
        """Execute RMA decision.

        Args:
            decision: RMA decision to execute.
            order: Order information.
            customer: Customer tier information.

        Returns:
            Execution outcome.
        """
        if decision.requires_approval:
            return CommerceOutcome(
                approved=False,
                success=False,
                reason=f"RMA requires approval: {decision.reason}",
            )

        side_effects: List[SideEffect] = []

        # Execute action
        if decision.action == RMADecisionAction.REFUND:
            # Would call payment processor API
            side_effects.append(
                SideEffect(
                    type="refund_issued",
                    id=f"refund_{order.order_id}",
                    details={"amount": order.total_amount, "order_id": order.order_id},
                )
            )

        elif decision.action == RMADecisionAction.REPLACEMENT:
            # Would call fulfillment API
            side_effects.append(
                SideEffect(
                    type="replacement_order_created",
                    id=f"repl_{order.order_id}",
                    details={"original_order": order.order_id},
                )
            )

        elif decision.action == RMADecisionAction.RETURN:
            # Would call shipping API for label
            side_effects.append(
                SideEffect(
                    type="return_label_created",
                    id=f"label_{order.order_id}",
                    details={"tracking_number": "MOCK123456"},
                )
            )

        elif decision.action == RMADecisionAction.STORE_CREDIT:
            # Would create store credit
            side_effects.append(
                SideEffect(
                    type="store_credit_issued",
                    id=f"credit_{order.order_id}",
                    details={"amount": order.total_amount, "customer_id": customer.tier},
                )
            )

        return CommerceOutcome(
            approved=True,
            success=True,
            reason=f"RMA {decision.action.value} processed successfully",
            side_effects=side_effects,
        )


@dataclass
class RMAConfig:
    """Configuration for Agentic RMA plugin."""

    return_window_days: int = 30
    max_auto_refund_amount: float = 500.0
    require_approval_over_amount: float = 1000.0
    structured_decision_temperature: float = 0.2
    enable_auto_processing: bool = True
    core_skills: Optional[CoreSkillsUsage] = None  # Core skills usage flags


class AgenticRMAPlugin(AgentPlugin):
    """Plugin for autonomous RMA processing.

    This plugin:
    - Processes RMA requests autonomously
    - Checks SLA eligibility
    - Makes structured decisions using context
    - Integrates with policy and inventory guardrails
    - Orchestrates actions across multiple systems
    - Handles approvals for high-value cases

    Usage:
        config = RMAConfig(
            return_window_days=45,
            max_auto_refund_amount=750.0,
        )
        plugin = AgenticRMAPlugin(config=config)
        agent = Agent(
            model="gpt-4o-mini",
            plugins=[
                defaults_plugin,
                policy_plugin,
                inventory_plugin,
                plugin,
            ],
        )
    """

    id: str = "agentic_rma"
    name: str = "Agentic RMA Agent"
    version: str = "0.2.0"

    def __init__(self, config: Optional[RMAConfig] = None):
        """Initialize plugin with configuration.

        Args:
            config: Plugin configuration. Falls back to defaults.
        """
        self.config = config or RMAConfig()
        self.orchestrator = RMAOrchestrator(
            return_window_days=self.config.return_window_days,
            max_auto_refund=self.config.max_auto_refund_amount,
            require_approval_threshold=self.config.require_approval_over_amount,
        )

    def configure_agent(self, agent: "Agent") -> "Agent":
        """Add RMA processing tool to agent.

        Discovers core skill plugins (HMLR, Scheduler, Acontext) from agent.plugin_index
        and uses them based on config.core_skills flags.

        Args:
            agent: Agent to configure.

        Returns:
            Agent with RMA tool added.
        """
        # Get defaults if available
        defaults = get_ecommerce_defaults(agent)
        if defaults:
            # Apply defaults
            if self.config.return_window_days == 30:
                self.config.return_window_days = defaults.rma.return_window_days
            if self.config.max_auto_refund_amount == 500.0:
                self.config.max_auto_refund_amount = defaults.rma.max_auto_refund_amount

            # Use defaults for core skills if not explicitly set
            if self.config.core_skills is None and defaults.rma.core_skills:
                self.config.core_skills = defaults.rma.core_skills

        # Discover core skill plugins from agent registry
        plugin_index = getattr(agent, "plugin_index", {}) or {}
        hmlr_plugin = plugin_index.get("hmlr_memory")
        scheduler_plugin = plugin_index.get("apscheduler")
        acontext_plugin = plugin_index.get("acontext")

        # Create RMA tool
        from agents import function_tool

        @function_tool(strict_mode=False)
        async def process_rma_request(
            order_id: str,
            reason: str,
            customer_id: str,
            context: Optional[AgentContext] = None,
        ) -> dict:
            """Process an RMA (Return Merchandise Authorization) request.

            This tool autonomously evaluates RMA eligibility, makes a decision,
            and executes the appropriate action (refund, replacement, etc.).

            Args:
                order_id: Order identifier.
                reason: Customer's reason for return.
                customer_id: Customer identifier.
                context: Optional agent context.

            Returns:
                RMA processing result with decision and outcome.
            """
            # Fetch order info (mock implementation)
            order = OrderInfo(
                order_id=order_id,
                order_number=f"ORD-{order_id}",
                order_date=datetime.utcnow() - timedelta(days=10),
                customer_id=customer_id,
                items=[{"sku": "PROD001", "quantity": 1, "price": 99.99}],
                total_amount=99.99,
                status="delivered",
            )

            # Use HMLR to retrieve customer RMA history if enabled
            hmlr_context = None
            if self.config.core_skills and self.config.core_skills.use_hmlr_context and hmlr_plugin and context:
                try:
                    query = f"Customer {customer_id} RMA history and past return decisions for order {order_id}"
                    hmlr_context = await hmlr_plugin.get_hmlr_context(context, query=query)
                    if hmlr_context:
                        order.metadata["hmlr_history"] = hmlr_context[:1500]  # Cap at 1500 chars
                except Exception as e:
                    print(f"HMLR context retrieval failed: {e}")

            # Use Acontext to learn optimal RMA decisions if enabled
            acontext_patterns = None
            if self.config.core_skills and self.config.core_skills.use_acontext_search and acontext_plugin:
                try:
                    query = f"Optimal RMA decisions for {reason} by product category"
                    acontext_result = acontext_plugin.search_skills_with_context(
                        query=query,
                        mode="fast",
                        limit=3,
                        build_prompt=False
                    )
                    if acontext_result and acontext_result.get("skills"):
                        acontext_patterns = [s.get("content", "") for s in acontext_result["skills"][:3]]
                        order.metadata["learned_patterns"] = acontext_patterns
                except Exception as e:
                    print(f"Acontext skill search failed: {e}")

            # Get customer tier
            customer = await self.orchestrator.get_customer_tier(customer_id)

            # Make decision
            decision = await self.orchestrator.make_decision(
                order=order,
                reason=reason,
                customer=customer,
            )

            # Execute if enabled
            if self.config.enable_auto_processing and not decision.requires_approval:
                outcome = await self.orchestrator.execute_decision(
                    decision=decision,
                    order=order,
                    customer=customer,
                )
            else:
                outcome = CommerceOutcome(
                    approved=False,
                    success=False,
                    reason="Auto-processing disabled or approval required",
                )

            # Schedule follow-up survey if scheduler is enabled
            if (self.config.core_skills and self.config.core_skills.use_scheduler_jobs
                and scheduler_plugin and not decision.requires_approval):
                try:
                    from ...lib.scheduler import JobConfig
                    from datetime import datetime, timedelta

                    # Schedule follow-up 7 days after RMA processing
                    follow_up_time = datetime.utcnow() + timedelta(days=7)
                    scheduler_plugin.create_job(JobConfig(
                        job_id=f"{self.id}_followup_{order_id}",
                        name=f"RMA Follow-up Survey for {order_id}",
                        schedule=follow_up_time.strftime("%Y-%m-%d %H:%M:%S"),
                        target=self._send_followup_survey,
                        metadata={"plugin_id": self.id, "order_id": order_id, "customer_id": customer_id}
                    ))
                except Exception as e:
                    print(f"Failed to schedule RMA follow-up job: {e}")

            return {
                "order_id": order_id,
                "decision": decision.to_dict(),
                "outcome": outcome.to_dict(),
                "customer_tier": customer.tier,
            }

        @function_tool(strict_mode=False)
        async def check_rma_eligibility(order_id: str) -> dict:
            """Check if an order is eligible for RMA.

            Args:
                order_id: Order identifier.

            Returns:
                Eligibility status and details.
            """
            # Mock order fetch
            order = OrderInfo(
                order_id=order_id,
                order_number=f"ORD-{order_id}",
                order_date=datetime.utcnow() - timedelta(days=10),
                customer_id="CUST001",
                total_amount=99.99,
                status="delivered",
            )

            eligible, reason = await self.orchestrator.check_sla_eligibility(order)

            return {
                "order_id": order_id,
                "eligible": eligible,
                "reason": reason,
                "return_window_days": self.config.return_window_days,
                "order_age_days": (datetime.utcnow() - order.order_date).days,
            }

        # Add tools to agent
        tools = list(getattr(agent, "tools", []))
        tools.extend([process_rma_request, check_rma_eligibility])

        return agent.clone(tools=tools)

    def _send_followup_survey(self, context_dict: dict) -> dict:
        """Send follow-up survey after RMA processing (placeholder).

        This would send a customer satisfaction survey via email/SMS.

        Args:
            context_dict: Context dictionary from scheduler

        Returns:
            Result dictionary with survey status
        """
        order_id = context_dict.get("order_id")
        customer_id = context_dict.get("customer_id")
        # TODO: Implement actual survey sending logic
        return {
            "success": True,
            "message": f"Follow-up survey sent for order {order_id}",
            "customer_id": customer_id,
        }

    def dependencies(self) -> List[str]:
        """RMA agent depends on policy and inventory plugins."""
        return ["ecommerce_defaults", "policy_ledger_shield", "inventory_guardrails"]

    def __repr__(self) -> str:
        """String representation."""
        return f"AgenticRMAPlugin(return_window={self.config.return_window_days}d, auto_process={self.config.enable_auto_processing})"
