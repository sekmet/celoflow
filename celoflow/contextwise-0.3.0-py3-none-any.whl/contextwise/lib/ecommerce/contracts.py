"""Shared contracts for e-commerce plugins.

These contracts define the integration seam between all e-commerce plugins,
enabling guardrails, policy validation, and ledger logging.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class CommerceActionType(str, Enum):
    """Types of commerce actions that can be performed."""

    # Recommendations
    RECOMMENDATION = "recommendation"
    PRODUCT_SUGGESTION = "product_suggestion"

    # Pricing & Discounts
    DISCOUNT = "discount"
    COUPON = "coupon"
    PRICE_OVERRIDE = "price_override"

    # Returns & Refunds
    REFUND = "refund"
    REPLACEMENT = "replacement"
    RETURN_LABEL = "return_label"
    RMA_CREATE = "rma_create"

    # Orders & Fulfillment
    ORDER_CREATE = "order_create"
    ORDER_CANCEL = "order_cancel"
    ORDER_MODIFY = "order_modify"
    SHIPPING_LABEL = "shipping_label"

    # Claims & Support
    CLAIM = "claim"
    WARRANTY_CLAIM = "warranty_claim"
    DAMAGE_REPORT = "damage_report"

    # Inventory
    INVENTORY_RESERVE = "inventory_reserve"
    INVENTORY_RELEASE = "inventory_release"
    PREORDER = "preorder"

    # Customer
    CUSTOMER_UPDATE = "customer_update"
    LOYALTY_POINTS = "loyalty_points"


@dataclass
class CommerceContext:
    """Context information for a commerce action.

    This provides traceability and audit trail for all commerce operations.
    """

    # Identity
    agent_id: str
    customer_id: Optional[str] = None
    user_id: Optional[str] = None

    # Session tracking
    session_id: Optional[str] = None
    channel_id: Optional[str] = None

    # Order context
    order_id: Optional[str] = None
    order_number: Optional[str] = None

    # Additional metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Timestamps
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class CommerceAction:
    """Normalized representation of a commerce action.

    This is the shared contract used by:
    - Policy Shield (validation)
    - Inventory Guardrails (availability checks)
    - Policy Ledger (audit logging)
    - RMA Agent (decision execution)
    """

    # Action classification
    type: CommerceActionType

    # Action payload (structure depends on type)
    payload: Dict[str, Any] = field(default_factory=dict)

    # Context for traceability
    context: CommerceContext = field(default_factory=lambda: CommerceContext(agent_id="unknown"))

    # Reasoning (for audit trail)
    reason: Optional[str] = None

    # Risk assessment
    risk_level: str = "medium"  # low, medium, high
    requires_approval: bool = False

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "type": self.type.value,
            "payload": self.payload,
            "context": {
                "agent_id": self.context.agent_id,
                "customer_id": self.context.customer_id,
                "user_id": self.context.user_id,
                "session_id": self.context.session_id,
                "channel_id": self.context.channel_id,
                "order_id": self.context.order_id,
                "order_number": self.context.order_number,
                "metadata": self.context.metadata,
                "timestamp": self.context.timestamp.isoformat(),
            },
            "reason": self.reason,
            "risk_level": self.risk_level,
            "requires_approval": self.requires_approval,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CommerceAction":
        """Create from dictionary."""
        context_data = data.get("context", {})
        timestamp_str = context_data.get("timestamp")

        context = CommerceContext(
            agent_id=context_data.get("agent_id", "unknown"),
            customer_id=context_data.get("customer_id"),
            user_id=context_data.get("user_id"),
            session_id=context_data.get("session_id"),
            channel_id=context_data.get("channel_id"),
            order_id=context_data.get("order_id"),
            order_number=context_data.get("order_number"),
            metadata=context_data.get("metadata", {}),
            timestamp=datetime.fromisoformat(timestamp_str) if timestamp_str else datetime.utcnow(),
        )

        return cls(
            type=CommerceActionType(data["type"]),
            payload=data.get("payload", {}),
            context=context,
            reason=data.get("reason"),
            risk_level=data.get("risk_level", "medium"),
            requires_approval=data.get("requires_approval", False),
            metadata=data.get("metadata", {}),
        )


@dataclass
class SideEffect:
    """Record of a side effect from executing a commerce action."""

    type: str  # e.g., "order_created", "label_created", "refund_issued"
    id: Optional[str] = None  # External system ID
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class CommerceOutcome:
    """Result of executing a commerce action.

    Includes success/failure status, side effects, and audit trail.
    """

    # Execution result
    approved: bool
    success: bool = False

    # Explanation
    reason: str = ""
    error: Optional[str] = None

    # Side effects (orders created, labels generated, etc.)
    side_effects: List[SideEffect] = field(default_factory=list)

    # Audit trail
    ledger_event_id: Optional[str] = None
    policy_validation_id: Optional[str] = None

    # Modified action (e.g., converted to preorder by inventory guardrails)
    modified_action: Optional[CommerceAction] = None

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "approved": self.approved,
            "success": self.success,
            "reason": self.reason,
            "error": self.error,
            "side_effects": [
                {
                    "type": se.type,
                    "id": se.id,
                    "details": se.details,
                    "timestamp": se.timestamp.isoformat(),
                }
                for se in self.side_effects
            ],
            "ledger_event_id": self.ledger_event_id,
            "policy_validation_id": self.policy_validation_id,
            "modified_action": self.modified_action.to_dict() if self.modified_action else None,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CommerceOutcome":
        """Create from dictionary."""
        side_effects = [
            SideEffect(
                type=se["type"],
                id=se.get("id"),
                details=se.get("details", {}),
                timestamp=datetime.fromisoformat(se["timestamp"]) if se.get("timestamp") else datetime.utcnow(),
            )
            for se in data.get("side_effects", [])
        ]

        modified_action = None
        if data.get("modified_action"):
            modified_action = CommerceAction.from_dict(data["modified_action"])

        return cls(
            approved=data["approved"],
            success=data.get("success", False),
            reason=data.get("reason", ""),
            error=data.get("error"),
            side_effects=side_effects,
            ledger_event_id=data.get("ledger_event_id"),
            policy_validation_id=data.get("policy_validation_id"),
            modified_action=modified_action,
            metadata=data.get("metadata", {}),
            timestamp=datetime.fromisoformat(data["timestamp"]) if data.get("timestamp") else datetime.utcnow(),
        )
