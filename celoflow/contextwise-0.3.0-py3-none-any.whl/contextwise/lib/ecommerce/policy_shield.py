"""Policy Compliance Ledger and Shield Plugin.

This plugin provides:
- Pre-execution policy validation of commerce actions
- Immutable audit logging for all attempted/approved actions
- Pattern monitoring for fraud/abuse detection
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

from ..base import AgentPlugin
from ..context import AgentContext
from .contracts import CommerceAction, CommerceOutcome, CommerceActionType
from .defaults import CoreSkillsUsage, PolicyMode, get_ecommerce_defaults

if TYPE_CHECKING:
    from agents import Agent, RunResult
    from ..storage import Storage


class ComplianceStatus(str, Enum):
    """Compliance validation statuses."""

    APPROVED = "approved"
    BLOCKED = "blocked"
    REQUIRES_APPROVAL = "requires_approval"
    WARNING = "warning"


@dataclass
class PolicyRule:
    """Individual policy rule."""

    id: str
    name: str
    action_types: List[CommerceActionType]  # Actions this rule applies to
    condition: Callable[[CommerceAction], bool]  # Validation function
    status: ComplianceStatus = ComplianceStatus.APPROVED
    message: str = ""
    priority: int = 0  # Higher priority rules evaluated first


@dataclass
class ComplianceResult:
    """Result of policy validation."""

    status: ComplianceStatus
    action: CommerceAction
    matched_rules: List[PolicyRule] = field(default_factory=list)
    message: str = ""
    validation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "status": self.status.value,
            "action": self.action.to_dict(),
            "matched_rules": [
                {"id": r.id, "name": r.name, "status": r.status.value, "message": r.message}
                for r in self.matched_rules
            ],
            "message": self.message,
            "validation_id": self.validation_id,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


@dataclass
class LedgerEvent:
    """Immutable audit log event."""

    event_id: str
    event_type: str  # "action_attempted", "action_approved", "action_blocked", "action_executed"
    action: CommerceAction
    compliance_result: Optional[ComplianceResult]
    outcome: Optional[CommerceOutcome]
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "event_id": self.event_id,
            "event_type": self.event_type,
            "action": self.action.to_dict(),
            "compliance_result": self.compliance_result.to_dict() if self.compliance_result else None,
            "outcome": self.outcome.to_dict() if self.outcome else None,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


class PolicyComplianceEngine:
    """Engine for validating commerce actions against policies."""

    def __init__(self, rules: Optional[List[PolicyRule]] = None):
        """Initialize with policy rules.

        Args:
            rules: List of policy rules to enforce.
        """
        self.rules = rules or self._get_default_rules()
        # Sort by priority (higher first)
        self.rules.sort(key=lambda r: r.priority, reverse=True)

    def _get_default_rules(self) -> List[PolicyRule]:
        """Get default policy rules."""
        return [
            # High-value refund requires approval
            PolicyRule(
                id="high_value_refund",
                name="High Value Refund Approval",
                action_types=[CommerceActionType.REFUND],
                condition=lambda action: action.payload.get("amount", 0) > 1000,
                status=ComplianceStatus.REQUIRES_APPROVAL,
                message="Refunds over $1000 require manual approval",
                priority=100,
            ),
            # Block excessive discounts
            PolicyRule(
                id="max_discount_limit",
                name="Maximum Discount Limit",
                action_types=[CommerceActionType.DISCOUNT, CommerceActionType.COUPON],
                condition=lambda action: action.payload.get("discount_percent", 0) > 50,
                status=ComplianceStatus.BLOCKED,
                message="Discounts over 50% are not allowed",
                priority=90,
            ),
            # Warn on inventory reservations without order
            PolicyRule(
                id="inventory_reservation_warning",
                name="Inventory Reservation Warning",
                action_types=[CommerceActionType.INVENTORY_RESERVE],
                condition=lambda action: not action.context.order_id,
                status=ComplianceStatus.WARNING,
                message="Inventory reservation without order_id",
                priority=50,
            ),
        ]

    def validate_action(self, action: CommerceAction) -> ComplianceResult:
        """Validate a commerce action against policy rules.

        Args:
            action: The commerce action to validate.

        Returns:
            ComplianceResult with validation outcome.
        """
        matched_rules: List[PolicyRule] = []
        highest_status = ComplianceStatus.APPROVED

        # Evaluate all applicable rules
        for rule in self.rules:
            if action.type in rule.action_types:
                try:
                    if rule.condition(action):
                        matched_rules.append(rule)
                        # Track most restrictive status
                        if self._is_more_restrictive(rule.status, highest_status):
                            highest_status = rule.status
                except Exception as e:
                    # Rule evaluation failed - log and continue
                    print(f"Policy rule {rule.id} evaluation failed: {e}")

        # Build result message
        if matched_rules:
            messages = [f"{r.name}: {r.message}" for r in matched_rules]
            message = "; ".join(messages)
        else:
            message = "No policy violations"

        return ComplianceResult(
            status=highest_status,
            action=action,
            matched_rules=matched_rules,
            message=message,
        )

    def _is_more_restrictive(self, status1: ComplianceStatus, status2: ComplianceStatus) -> bool:
        """Check if status1 is more restrictive than status2."""
        order = {
            ComplianceStatus.APPROVED: 0,
            ComplianceStatus.WARNING: 1,
            ComplianceStatus.REQUIRES_APPROVAL: 2,
            ComplianceStatus.BLOCKED: 3,
        }
        return order[status1] > order[status2]


class PolicyLedger:
    """Append-only audit ledger for commerce actions."""

    def __init__(self, storage: Optional["Storage"] = None):
        """Initialize ledger with storage backend.

        Args:
            storage: Storage backend for persisting events.
        """
        self.storage = storage
        self._events: List[LedgerEvent] = []  # In-memory fallback

    async def log_event(
        self,
        event_type: str,
        action: CommerceAction,
        compliance_result: Optional[ComplianceResult] = None,
        outcome: Optional[CommerceOutcome] = None,
    ) -> str:
        """Log an immutable event to the ledger.

        Args:
            event_type: Type of event (attempted, approved, blocked, executed).
            action: The commerce action.
            compliance_result: Optional compliance validation result.
            outcome: Optional execution outcome.

        Returns:
            Event ID.
        """
        event_id = str(uuid.uuid4())
        event = LedgerEvent(
            event_id=event_id,
            event_type=event_type,
            action=action,
            compliance_result=compliance_result,
            outcome=outcome,
        )

        # Store event
        if self.storage:
            try:
                await self.storage.save(
                    f"policy_ledger:{event_id}",
                    json.dumps(event.to_dict()),
                )
            except Exception as e:
                print(f"Failed to persist ledger event: {e}")

        # Also keep in memory
        self._events.append(event)

        return event_id

    async def get_events(
        self,
        agent_id: Optional[str] = None,
        customer_id: Optional[str] = None,
        action_type: Optional[CommerceActionType] = None,
        limit: int = 100,
    ) -> List[LedgerEvent]:
        """Query ledger events.

        Args:
            agent_id: Filter by agent ID.
            customer_id: Filter by customer ID.
            action_type: Filter by action type.
            limit: Maximum number of events to return.

        Returns:
            List of matching events.
        """
        events = self._events

        # Apply filters
        if agent_id:
            events = [e for e in events if e.action.context.agent_id == agent_id]
        if customer_id:
            events = [e for e in events if e.action.context.customer_id == customer_id]
        if action_type:
            events = [e for e in events if e.action.type == action_type]

        # Return most recent first
        events.sort(key=lambda e: e.timestamp, reverse=True)
        return events[:limit]


@dataclass
class PolicyShieldConfig:
    """Configuration for Policy Shield plugin."""

    mode: PolicyMode = PolicyMode.LOG_ONLY
    rules: Optional[List[PolicyRule]] = None
    enable_pattern_monitoring: bool = False
    storage: Optional["Storage"] = None
    core_skills: Optional[CoreSkillsUsage] = None  # Core skills usage flags


class PolicyLedgerShieldPlugin(AgentPlugin):
    """Plugin for policy compliance validation and audit logging.

    This plugin:
    - Validates commerce actions against configurable policies
    - Logs all action attempts to an immutable ledger
    - Optionally monitors for fraud/abuse patterns
    - Provides execute_commerce_action tool for validated execution

    Usage:
        config = PolicyShieldConfig(
            mode=PolicyMode.ENFORCE,
            rules=[custom_rule1, custom_rule2],
        )
        plugin = PolicyLedgerShieldPlugin(config=config)
        agent = Agent(
            model="gpt-4o-mini",
            plugins=[defaults_plugin, plugin],
        )
    """

    id: str = "policy_ledger_shield"
    name: str = "Policy Ledger & Shield"
    version: str = "0.2.0"

    def __init__(self, config: Optional[PolicyShieldConfig] = None):
        """Initialize plugin with configuration.

        Args:
            config: Plugin configuration. Falls back to defaults.
        """
        self.config = config or PolicyShieldConfig()
        self.engine = PolicyComplianceEngine(rules=self.config.rules)
        self.ledger = PolicyLedger(storage=self.config.storage)

    def configure_agent(self, agent: "Agent") -> "Agent":
        """Add policy-wrapped commerce action tool to agent.

        Discovers core skill plugins (HMLR, Scheduler, Acontext) from agent.plugin_index
        and uses them based on config.core_skills flags.

        Args:
            agent: Agent to configure.

        Returns:
            Agent with commerce action tool added.
        """
        # Get defaults if available
        defaults = get_ecommerce_defaults(agent)
        if defaults and not self.config.rules:
            # Use defaults for mode if not explicitly set
            if self.config.mode == PolicyMode.LOG_ONLY and defaults.policy.mode != PolicyMode.LOG_ONLY:
                self.config.mode = defaults.policy.mode

            # Use defaults for core skills if not explicitly set
            if self.config.core_skills is None and defaults.policy.core_skills:
                self.config.core_skills = defaults.policy.core_skills

        # Discover core skill plugins from agent registry
        plugin_index = getattr(agent, "plugin_index", {}) or {}
        hmlr_plugin = plugin_index.get("hmlr_memory")
        scheduler_plugin = plugin_index.get("apscheduler")
        acontext_plugin = plugin_index.get("acontext")

        # Create the execute_commerce_action tool
        from agents import function_tool

        @function_tool(strict_mode=False)
        async def execute_commerce_action(
            action_type: str,
            payload: dict,
            context: AgentContext,
        ) -> dict:
            """Execute a validated commerce action.

            Args:
                action_type: Type of commerce action (e.g., "refund", "discount").
                payload: Action-specific data (amount, order_id, etc.).
                context: Agent context with user/session info.

            Returns:
                Execution result with success status and details.
            """
            from .contracts import CommerceContext, CommerceAction

            # Build commerce action
            action = CommerceAction(
                type=CommerceActionType(action_type),
                payload=payload,
                context=CommerceContext(
                    agent_id=getattr(context, "agent_id", "unknown"),
                    customer_id=getattr(context, "customer_id", None),
                    user_id=getattr(context, "user_id", None),
                    session_id=getattr(context, "session_id", None),
                    channel_id=getattr(context, "channel_id", None),
                    order_id=payload.get("order_id"),
                ),
            )

            # Use HMLR to retrieve past policy decisions if enabled
            hmlr_context = None
            if self.config.core_skills and self.config.core_skills.use_hmlr_context and hmlr_plugin:
                try:
                    customer_id = action.context.customer_id
                    query = f"Has customer {customer_id} been blocked before? Past policy decisions for {action_type}"
                    hmlr_context = await hmlr_plugin.get_hmlr_context(context, query=query)
                    if hmlr_context:
                        action.metadata["hmlr_context"] = hmlr_context[:1500]  # Cap at 1500 chars
                except Exception as e:
                    print(f"HMLR context retrieval failed: {e}")

            # Use Acontext to learn approval patterns if enabled
            acontext_skills = None
            if self.config.core_skills and self.config.core_skills.use_acontext_search and acontext_plugin:
                try:
                    query = f"Policy approval patterns for {action_type} actions"
                    acontext_result = acontext_plugin.search_skills_with_context(
                        query=query,
                        mode="fast",
                        limit=3,
                        build_prompt=False
                    )
                    if acontext_result and acontext_result.get("skills"):
                        acontext_skills = acontext_result["skills"][:3]
                        action.metadata["acontext_patterns"] = [s.get("content", "") for s in acontext_skills]
                except Exception as e:
                    print(f"Acontext skill search failed: {e}")

            # Validate action
            result = self.engine.validate_action(action)

            # Log attempted action
            await self.ledger.log_event("action_attempted", action, compliance_result=result)

            # Check mode
            if self.config.mode == PolicyMode.OFF:
                # Skip validation
                outcome = CommerceOutcome(
                    approved=True,
                    success=True,
                    reason="Policy validation disabled",
                )
            elif self.config.mode == PolicyMode.LOG_ONLY:
                # Log but allow
                outcome = CommerceOutcome(
                    approved=True,
                    success=True,
                    reason="Logged only (not enforced)",
                    policy_validation_id=result.validation_id,
                )
            elif result.status == ComplianceStatus.BLOCKED:
                # Block action
                outcome = CommerceOutcome(
                    approved=False,
                    success=False,
                    reason=f"Blocked by policy: {result.message}",
                    policy_validation_id=result.validation_id,
                )
                await self.ledger.log_event("action_blocked", action, compliance_result=result, outcome=outcome)
            elif result.status == ComplianceStatus.REQUIRES_APPROVAL:
                # Requires manual approval
                outcome = CommerceOutcome(
                    approved=False,
                    success=False,
                    reason=f"Requires approval: {result.message}",
                    policy_validation_id=result.validation_id,
                )
                await self.ledger.log_event("action_approval_required", action, compliance_result=result, outcome=outcome)
            else:
                # Approved - would execute here with real integrations
                outcome = CommerceOutcome(
                    approved=True,
                    success=True,
                    reason="Policy validation passed",
                    policy_validation_id=result.validation_id,
                )
                await self.ledger.log_event("action_approved", action, compliance_result=result)
                # TODO: Execute actual commerce action via integrations
                await self.ledger.log_event("action_executed", action, outcome=outcome)

            outcome.ledger_event_id = await self.ledger.log_event("action_outcome", action, outcome=outcome)

            return outcome.to_dict()

        # Schedule rule refresh jobs if scheduler is enabled
        if self.config.core_skills and self.config.core_skills.use_scheduler_jobs and scheduler_plugin:
            try:
                from ...lib.scheduler import JobConfig

                # Schedule daily policy rule refresh
                scheduler_plugin.create_job(JobConfig(
                    job_id=f"{self.id}_policy_refresh",
                    name="Policy Rules Refresh",
                    schedule="0 0 * * *",  # Daily at midnight
                    target=self._refresh_policy_rules,
                    metadata={"plugin_id": self.id}
                ))
            except Exception as e:
                print(f"Failed to schedule policy refresh job: {e}")

        # Add tool to agent
        tools = list(getattr(agent, "tools", []))
        tools.append(execute_commerce_action)

        # Return modified agent
        return agent.clone(tools=tools)

    def _refresh_policy_rules(self, context_dict: dict) -> dict:
        """Refresh policy rules from external source (placeholder).

        This would fetch updated rules from an external policy service.

        Args:
            context_dict: Context dictionary from scheduler

        Returns:
            Result dictionary with refresh status
        """
        # TODO: Implement actual rule refresh from external service
        return {
            "success": True,
            "message": "Policy rules refreshed",
            "rules_count": len(self.engine.rules),
        }

    def dependencies(self) -> List[str]:
        """Policy shield should load after defaults."""
        return ["ecommerce_defaults"]

    def __repr__(self) -> str:
        """String representation."""
        return f"PolicyLedgerShieldPlugin(mode={self.config.mode}, rules={len(self.engine.rules)})"
