"""Post-Purchase Document Vision Plugin.

This plugin provides:
- Document upload and evidence storage
- Vision AI for document parsing (receipts, damage photos, POD)
- Structured JSON extraction from visual evidence
- Downstream automation triggers (claims, RMA, refunds)
- Retention and compliance controls
"""

from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from fastapi import APIRouter, File, Form, UploadFile, HTTPException, status
from fastapi.responses import FileResponse, JSONResponse

from ..base import AgentPlugin
from ..context import AgentContext
from .contracts import CommerceAction, CommerceActionType, CommerceContext
from .defaults import CoreSkillsUsage, get_ecommerce_defaults

if TYPE_CHECKING:
    from agents import Agent
    from ..storage import Storage


class DocumentType(str, Enum):
    """Types of documents that can be processed."""

    RECEIPT = "receipt"
    INVOICE = "invoice"
    DAMAGE_PHOTO = "damage_photo"
    PROOF_OF_DELIVERY = "proof_of_delivery"
    CUSTOMS_FORM = "customs_form"
    WARRANTY_CARD = "warranty_card"
    PRODUCT_PHOTO = "product_photo"
    OTHER = "other"


@dataclass
class DocumentMetadata:
    """Metadata for uploaded document."""

    document_id: str
    document_type: DocumentType
    filename: str
    content_type: str
    size_bytes: int
    uploaded_at: datetime
    uploaded_by: str  # customer_id or user_id
    order_id: Optional[str] = None
    claim_id: Optional[str] = None
    retention_until: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExtractedData:
    """Structured data extracted from document."""

    document_id: str
    document_type: DocumentType
    extracted_fields: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    extraction_model: str = "unknown"
    extracted_at: datetime = field(default_factory=datetime.utcnow)


class EvidenceStore:
    """Storage for document evidence."""

    def __init__(
        self,
        storage_path: str = "./evidence_store",
        retention_days: int = 90,
    ):
        """Initialize evidence store.

        Args:
            storage_path: Path to store documents.
            retention_days: Default retention period in days.
        """
        self.storage_path = Path(storage_path)
        self.retention_days = retention_days
        self.storage_path.mkdir(parents=True, exist_ok=True)

    async def store_document(
        self,
        file_content: bytes,
        filename: str,
        content_type: str,
        document_type: DocumentType,
        uploaded_by: str,
        order_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> DocumentMetadata:
        """Store a document.

        Args:
            file_content: Document bytes.
            filename: Original filename.
            content_type: MIME type.
            document_type: Type of document.
            uploaded_by: Uploader identifier.
            order_id: Optional order ID.
            metadata: Optional metadata.

        Returns:
            Document metadata.
        """
        # Generate document ID
        doc_hash = hashlib.sha256(file_content).hexdigest()[:16]
        document_id = f"doc_{doc_hash}"

        # Determine retention
        retention_until = datetime.utcnow() + timedelta(days=self.retention_days)

        # Store file
        doc_path = self.storage_path / document_id
        doc_path.write_bytes(file_content)

        # Store metadata
        doc_metadata = DocumentMetadata(
            document_id=document_id,
            document_type=document_type,
            filename=filename,
            content_type=content_type,
            size_bytes=len(file_content),
            uploaded_at=datetime.utcnow(),
            uploaded_by=uploaded_by,
            order_id=order_id,
            retention_until=retention_until,
            metadata=metadata or {},
        )

        # Store metadata as JSON
        metadata_path = self.storage_path / f"{document_id}.json"
        metadata_path.write_text(json.dumps(doc_metadata.__dict__, default=str))

        return doc_metadata

    async def get_document(self, document_id: str) -> Optional[bytes]:
        """Retrieve document bytes.

        Args:
            document_id: Document identifier.

        Returns:
            Document bytes if found.
        """
        doc_path = self.storage_path / document_id
        if doc_path.exists():
            return doc_path.read_bytes()
        return None

    async def get_metadata(self, document_id: str) -> Optional[DocumentMetadata]:
        """Retrieve document metadata.

        Args:
            document_id: Document identifier.

        Returns:
            Document metadata if found.
        """
        metadata_path = self.storage_path / f"{document_id}.json"
        if metadata_path.exists():
            data = json.loads(metadata_path.read_text())
            return DocumentMetadata(**data)
        return None

    async def cleanup_expired(self) -> int:
        """Clean up expired documents.

        Returns:
            Number of documents deleted.
        """
        now = datetime.utcnow()
        deleted = 0

        for metadata_file in self.storage_path.glob("*.json"):
            try:
                metadata = await self.get_metadata(metadata_file.stem)
                if metadata and metadata.retention_until and metadata.retention_until < now:
                    # Delete document and metadata
                    doc_path = self.storage_path / metadata.document_id
                    if doc_path.exists():
                        doc_path.unlink()
                    metadata_file.unlink()
                    deleted += 1
            except Exception as e:
                print(f"Failed to cleanup {metadata_file}: {e}")

        return deleted


class DocumentParser:
    """Parses documents using vision AI."""

    def __init__(self, model: str = "gpt-4o-mini"):
        """Initialize parser.

        Args:
            model: Model to use for vision parsing.
        """
        self.model = model

    async def parse_document(
        self,
        document_content: bytes,
        document_type: DocumentType,
        content_type: str,
    ) -> ExtractedData:
        """Parse document and extract structured data.

        Args:
            document_content: Document bytes.
            document_type: Type of document.
            content_type: MIME type.

        Returns:
            Extracted structured data.
        """
        # Mock extraction - in production would use vision model
        extracted_fields: Dict[str, Any] = {}

        if document_type == DocumentType.RECEIPT:
            extracted_fields = {
                "merchant": "Mock Store",
                "total_amount": 99.99,
                "date": "2024-01-15",
                "items": ["Product A", "Product B"],
            }
        elif document_type == DocumentType.DAMAGE_PHOTO:
            extracted_fields = {
                "damage_type": "scratch",
                "severity": "moderate",
                "location": "top-right corner",
                "confidence": 0.85,
            }
        elif document_type == DocumentType.PROOF_OF_DELIVERY:
            extracted_fields = {
                "delivery_date": "2024-01-20",
                "signature_present": True,
                "delivery_location": "front door",
            }

        return ExtractedData(
            document_id="mock",
            document_type=document_type,
            extracted_fields=extracted_fields,
            confidence=0.85,
            extraction_model=self.model,
        )


class AutomationRouter:
    """Routes extracted evidence to downstream automations."""

    def __init__(self):
        """Initialize automation router."""
        self.handlers: Dict[DocumentType, List] = {}

    async def route_evidence(
        self,
        extracted: ExtractedData,
        metadata: DocumentMetadata,
    ) -> List[CommerceAction]:
        """Route evidence to appropriate automations.

        Args:
            extracted: Extracted document data.
            metadata: Document metadata.

        Returns:
            List of commerce actions to execute.
        """
        actions: List[CommerceAction] = []

        # Route based on document type
        if extracted.document_type == DocumentType.DAMAGE_PHOTO:
            if extracted.extracted_fields.get("severity") in ["moderate", "severe"]:
                # Trigger damage claim
                actions.append(
                    CommerceAction(
                        type=CommerceActionType.DAMAGE_REPORT,
                        payload={
                            "document_id": metadata.document_id,
                            "severity": extracted.extracted_fields.get("severity"),
                            "damage_type": extracted.extracted_fields.get("damage_type"),
                            "order_id": metadata.order_id,
                        },
                        context=CommerceContext(
                            agent_id="document_vision",
                            customer_id=metadata.uploaded_by,
                            order_id=metadata.order_id,
                        ),
                        reason="Damage detected in uploaded photo",
                    )
                )

        elif extracted.document_type == DocumentType.RECEIPT:
            # Could trigger price match, warranty registration, etc.
            pass

        elif extracted.document_type == DocumentType.PROOF_OF_DELIVERY:
            if not extracted.extracted_fields.get("signature_present"):
                # Trigger delivery investigation
                pass

        return actions


@dataclass
class VisionConfig:
    """Configuration for Document Vision plugin."""

    enabled: bool = True
    allowed_mime_types: List[str] = field(
        default_factory=lambda: [
            "image/jpeg",
            "image/png",
            "image/webp",
            "application/pdf",
        ]
    )
    max_file_size_mb: float = 10.0
    retention_days: int = 90
    storage_path: str = "./evidence_store"
    vision_model: str = "gpt-4o-mini"
    enable_auto_routing: bool = True
    core_skills: Optional[CoreSkillsUsage] = None  # Core skills usage flags


class PostPurchaseDocumentVisionPlugin(AgentPlugin):
    """Plugin for document vision and evidence processing.

    This plugin:
    - Accepts document uploads (images, PDFs)
    - Stores evidence with retention controls
    - Extracts structured data using vision AI
    - Routes to downstream automations (RMA, claims)
    - Provides upload API endpoints
    - Integrates with policy shield for action validation

    Usage:
        config = VisionConfig(
            retention_days=120,
            max_file_size_mb=15.0,
        )
        plugin = PostPurchaseDocumentVisionPlugin(config=config)
        agent = Agent(
            model="gpt-4o-mini",
            plugins=[
                defaults_plugin,
                policy_plugin,
                plugin,
            ],
        )
    """

    id: str = "post_purchase_document_vision"
    name: str = "Post-Purchase Document Vision"
    version: str = "0.2.0"

    def __init__(self, config: Optional[VisionConfig] = None):
        """Initialize plugin with configuration.

        Args:
            config: Plugin configuration. Falls back to defaults.
        """
        self.config = config or VisionConfig()
        self.evidence_store = EvidenceStore(
            storage_path=self.config.storage_path,
            retention_days=self.config.retention_days,
        )
        self.parser = DocumentParser(model=self.config.vision_model)
        self.router = AutomationRouter()

    def configure_agent(self, agent: "Agent") -> "Agent":
        """Add document processing tools to agent.

        Args:
            agent: Agent to configure.

        Returns:
            Agent with document tools added.
        """
        # Get defaults if available
        defaults = get_ecommerce_defaults(agent)
        if defaults:
            # Apply defaults
            if self.config.retention_days == 90:
                self.config.retention_days = defaults.doc_vision.retention_days

        # Create document tools
        from agents import function_tool

        @function_tool(strict_mode=False)
        async def parse_uploaded_document(
            document_id: str,
            context: Optional[AgentContext] = None,
        ) -> dict:
            """Parse an uploaded document and extract structured data.

            Args:
                document_id: Document identifier.
                context: Optional agent context.

            Returns:
                Extracted data from document.
            """
            # Get document
            content = await self.evidence_store.get_document(document_id)
            metadata = await self.evidence_store.get_metadata(document_id)

            if not content or not metadata:
                return {"error": f"Document {document_id} not found"}

            # Parse document
            extracted = await self.parser.parse_document(
                document_content=content,
                document_type=metadata.document_type,
                content_type=metadata.content_type,
            )

            # Route to automations if enabled
            actions = []
            if self.config.enable_auto_routing:
                actions = await self.router.route_evidence(extracted, metadata)

            return {
                "document_id": document_id,
                "document_type": metadata.document_type.value,
                "extracted_fields": extracted.extracted_fields,
                "confidence": extracted.confidence,
                "triggered_actions": [a.to_dict() for a in actions],
            }

        # Add tools to agent
        tools = list(getattr(agent, "tools", []))
        tools.append(parse_uploaded_document)

        return agent.clone(tools=tools)

    def get_fastapi_routers(self) -> List[APIRouter]:
        """Get FastAPI routers for document upload endpoints.

        Returns:
            List of API routers.
        """
        if not self.config.enabled:
            return []

        router = APIRouter(prefix="/documents", tags=["documents"])

        @router.post("/upload")
        async def upload_document(
            file: UploadFile = File(...),
            document_type: str = Form(...),
            uploaded_by: str = Form(...),
            order_id: Optional[str] = Form(None),
        ) -> JSONResponse:
            """Upload a document for processing.

            Args:
                file: Document file.
                document_type: Type of document.
                uploaded_by: Uploader identifier.
                order_id: Optional order ID.

            Returns:
                Upload result with document ID.
            """
            # Validate file type
            if file.content_type not in self.config.allowed_mime_types:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"File type {file.content_type} not allowed",
                )

            # Read file
            content = await file.read()

            # Check size
            size_mb = len(content) / (1024 * 1024)
            if size_mb > self.config.max_file_size_mb:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"File size {size_mb:.1f}MB exceeds limit of {self.config.max_file_size_mb}MB",
                )

            # Store document
            try:
                doc_type = DocumentType(document_type)
            except ValueError:
                doc_type = DocumentType.OTHER

            metadata = await self.evidence_store.store_document(
                file_content=content,
                filename=file.filename or "unknown",
                content_type=file.content_type or "application/octet-stream",
                document_type=doc_type,
                uploaded_by=uploaded_by,
                order_id=order_id,
            )

            return JSONResponse(
                status_code=status.HTTP_201_CREATED,
                content={
                    "document_id": metadata.document_id,
                    "document_type": metadata.document_type.value,
                    "size_bytes": metadata.size_bytes,
                    "uploaded_at": metadata.uploaded_at.isoformat(),
                },
            )

        @router.get("/{document_id}")
        async def get_document(document_id: str) -> FileResponse:
            """Download a document.

            Args:
                document_id: Document identifier.

            Returns:
                Document file.
            """
            metadata = await self.evidence_store.get_metadata(document_id)
            if not metadata:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Document not found",
                )

            doc_path = self.evidence_store.storage_path / document_id
            if not doc_path.exists():
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Document file not found",
                )

            return FileResponse(
                path=str(doc_path),
                media_type=metadata.content_type,
                filename=metadata.filename,
            )

        return [router]

    def dependencies(self) -> List[str]:
        """Document vision depends on policy shield."""
        return ["ecommerce_defaults", "policy_ledger_shield"]

    def __repr__(self) -> str:
        """String representation."""
        return f"PostPurchaseDocumentVisionPlugin(enabled={self.config.enabled}, retention={self.config.retention_days}d)"
