"""Universal Channel Builder Plugin.

This plugin provides:
- Channel-agnostic conversation flow execution
- Capability negotiation and graceful degradation
- Flow definition DSL (YAML/JSON)
- Content adaptation to channel limits (buttons, chunking, etc.)
"""

from __future__ import annotations

import asyncio
import yaml
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Protocol, TYPE_CHECKING, Union

from ..base import AgentPlugin
from ..context import AgentContext
from .defaults import CapabilityDegradeMode, CoreSkillsUsage, get_ecommerce_defaults

if TYPE_CHECKING:
    from agents import Agent


class FlowNodeType(str, Enum):
    """Types of flow nodes."""

    MESSAGE = "message"  # Send a message
    AGENT = "agent"  # Invoke an agent
    TOOL = "tool"  # Call a tool
    CONDITION = "condition"  # Conditional branch
    INPUT = "input"  # Wait for user input
    END = "end"  # End the flow


@dataclass
class ChannelCapabilities:
    """Capabilities and limits of a communication channel."""

    channel_id: str
    supports_rich_media: bool = False
    supports_buttons: bool = False
    supports_carousel: bool = False
    supports_quick_replies: bool = False
    supports_voice: bool = False
    supports_video: bool = False
    max_message_length: int = 4096
    max_buttons: int = 0
    max_quick_replies: int = 0
    rate_limits: Optional[Dict[str, int]] = None  # {"per_second": 10, "per_hour": 1000}


@dataclass
class FlowButton:
    """Button in a flow message."""

    text: str
    action: str  # "next_node", "url", "call_tool"
    value: Optional[str] = None  # Node ID, URL, or tool name


@dataclass
class FlowNode:
    """Node in a conversation flow."""

    id: str
    type: FlowNodeType
    config: Dict[str, Any] = field(default_factory=dict)

    # For MESSAGE nodes
    content: Optional[str] = None
    buttons: List[FlowButton] = field(default_factory=list)

    # For AGENT nodes
    agent_id: Optional[str] = None

    # For TOOL nodes
    tool_name: Optional[str] = None
    tool_args: Dict[str, Any] = field(default_factory=dict)

    # For CONDITION nodes
    condition: Optional[str] = None  # Expression to evaluate

    # Navigation
    next_node: Optional[str] = None
    fallback_node: Optional[str] = None


@dataclass
class Flow:
    """Conversation flow definition."""

    id: str
    name: str
    description: str = ""
    entry_point: str = "start"
    nodes: Dict[str, FlowNode] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Flow":
        """Create flow from dictionary.

        Args:
            data: Flow definition as dictionary.

        Returns:
            Flow instance.
        """
        nodes = {}
        for node_data in data.get("nodes", []):
            buttons = [
                FlowButton(
                    text=b["text"],
                    action=b.get("action", "next_node"),
                    value=b.get("value"),
                )
                for b in node_data.get("buttons", [])
            ]

            node = FlowNode(
                id=node_data["id"],
                type=FlowNodeType(node_data.get("type", "message")),
                config=node_data.get("config", {}),
                content=node_data.get("content"),
                buttons=buttons,
                agent_id=node_data.get("agent_id"),
                tool_name=node_data.get("tool_name"),
                tool_args=node_data.get("tool_args", {}),
                condition=node_data.get("condition"),
                next_node=node_data.get("next_node"),
                fallback_node=node_data.get("fallback_node"),
            )
            nodes[node.id] = node

        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            entry_point=data.get("entry_point", "start"),
            nodes=nodes,
            metadata=data.get("metadata", {}),
        )

    @classmethod
    def from_yaml(cls, yaml_str: str) -> "Flow":
        """Create flow from YAML string.

        Args:
            yaml_str: Flow definition as YAML.

        Returns:
            Flow instance.
        """
        data = yaml.safe_load(yaml_str)
        return cls.from_dict(data)

    @classmethod
    def from_file(cls, path: Union[str, Path]) -> "Flow":
        """Load flow from file.

        Args:
            path: Path to flow definition file (YAML or JSON).

        Returns:
            Flow instance.
        """
        path = Path(path)
        with open(path) as f:
            if path.suffix in [".yaml", ".yml"]:
                data = yaml.safe_load(f)
            else:
                import json
                data = json.load(f)
        return cls.from_dict(data)


class ContentAdapter:
    """Adapts content to channel capabilities."""

    def __init__(self, mode: CapabilityDegradeMode = CapabilityDegradeMode.GRACEFUL):
        """Initialize adapter.

        Args:
            mode: Degradation mode (graceful or strict).
        """
        self.mode = mode

    def adapt_message(
        self,
        content: str,
        buttons: List[FlowButton],
        capabilities: ChannelCapabilities,
    ) -> List[Dict[str, Any]]:
        """Adapt message to channel capabilities.

        Args:
            content: Message content.
            buttons: Message buttons.
            capabilities: Channel capabilities.

        Returns:
            List of adapted messages (may be split into chunks).
        """
        messages: List[Dict[str, Any]] = []

        # Handle content length
        if len(content) > capabilities.max_message_length:
            # Split into chunks
            chunks = self._chunk_content(content, capabilities.max_message_length)
            for i, chunk in enumerate(chunks):
                # Only add buttons to last chunk
                chunk_buttons = buttons if i == len(chunks) - 1 else []
                messages.append(self._adapt_single_message(chunk, chunk_buttons, capabilities))
        else:
            messages.append(self._adapt_single_message(content, buttons, capabilities))

        return messages

    def _adapt_single_message(
        self,
        content: str,
        buttons: List[FlowButton],
        capabilities: ChannelCapabilities,
    ) -> Dict[str, Any]:
        """Adapt a single message.

        Args:
            content: Message content.
            buttons: Message buttons.
            capabilities: Channel capabilities.

        Returns:
            Adapted message.
        """
        message: Dict[str, Any] = {"content": content}

        if buttons:
            if capabilities.supports_buttons and len(buttons) <= capabilities.max_buttons:
                # Use native buttons
                message["buttons"] = [
                    {"text": b.text, "action": b.action, "value": b.value}
                    for b in buttons
                ]
            elif capabilities.supports_quick_replies and len(buttons) <= capabilities.max_quick_replies:
                # Use quick replies
                message["quick_replies"] = [b.text for b in buttons]
            elif self.mode == CapabilityDegradeMode.GRACEFUL:
                # Degrade to numbered text options
                button_text = "\n".join([f"{i+1}. {b.text}" for i, b in enumerate(buttons)])
                message["content"] = f"{content}\n\n{button_text}"
            else:
                # Strict mode - fail if buttons not supported
                raise ValueError(f"Channel {capabilities.channel_id} does not support buttons")

        return message

    def _chunk_content(self, content: str, max_length: int) -> List[str]:
        """Split content into chunks respecting max length.

        Args:
            content: Content to chunk.
            max_length: Maximum chunk length.

        Returns:
            List of content chunks.
        """
        if len(content) <= max_length:
            return [content]

        chunks: List[str] = []
        current_chunk = ""

        # Split on sentences/paragraphs
        parts = content.split("\n\n")
        for part in parts:
            if len(current_chunk) + len(part) + 2 <= max_length:
                current_chunk += part + "\n\n"
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = part + "\n\n"

        if current_chunk:
            chunks.append(current_chunk.strip())

        return chunks


class FlowExecutionContext:
    """Context for flow execution."""

    def __init__(
        self,
        flow: Flow,
        agent_context: AgentContext,
        channel_capabilities: ChannelCapabilities,
    ):
        """Initialize execution context.

        Args:
            flow: Flow being executed.
            agent_context: Agent context.
            channel_capabilities: Channel capabilities.
        """
        self.flow = flow
        self.agent_context = agent_context
        self.channel_capabilities = channel_capabilities
        self.variables: Dict[str, Any] = {}
        self.history: List[str] = []  # Node IDs visited


class FlowEngine:
    """Engine for executing conversation flows."""

    def __init__(self, adapter: Optional[ContentAdapter] = None):
        """Initialize flow engine.

        Args:
            adapter: Content adapter for capability degradation.
        """
        self.adapter = adapter or ContentAdapter()

    async def execute_flow(
        self,
        flow: Flow,
        context: FlowExecutionContext,
        start_node: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Execute a conversation flow.

        Args:
            flow: Flow to execute.
            context: Execution context.
            start_node: Optional starting node (defaults to entry_point).

        Returns:
            List of messages generated during flow execution.
        """
        messages: List[Dict[str, Any]] = []
        current_node_id = start_node or flow.entry_point

        while current_node_id:
            node = flow.nodes.get(current_node_id)
            if not node:
                break

            # Track history
            context.history.append(current_node_id)

            # Execute node
            if node.type == FlowNodeType.MESSAGE:
                # Send message
                adapted = self.adapter.adapt_message(
                    content=node.content or "",
                    buttons=node.buttons,
                    capabilities=context.channel_capabilities,
                )
                messages.extend(adapted)
                current_node_id = node.next_node

            elif node.type == FlowNodeType.INPUT:
                # Wait for user input (flow pauses)
                messages.append({"type": "input_required", "node_id": node.id})
                break

            elif node.type == FlowNodeType.END:
                # End flow
                break

            else:
                # Other node types would be implemented here
                current_node_id = node.next_node

        return messages


class FlowRegistry:
    """Registry for conversation flows."""

    def __init__(self):
        """Initialize flow registry."""
        self._flows: Dict[str, Flow] = {}

    def register(self, flow: Flow) -> None:
        """Register a flow.

        Args:
            flow: Flow to register.
        """
        self._flows[flow.id] = flow

    def get(self, flow_id: str) -> Optional[Flow]:
        """Get a flow by ID.

        Args:
            flow_id: Flow identifier.

        Returns:
            Flow if found, None otherwise.
        """
        return self._flows.get(flow_id)

    def list(self) -> List[Flow]:
        """List all registered flows.

        Returns:
            List of flows.
        """
        return list(self._flows.values())


@dataclass
class FlowConfig:
    """Configuration for Universal Channel Builder plugin."""

    flow_source: str = "file"  # file, storage, inline
    default_flow_id: str = "default"
    capability_degrade_mode: CapabilityDegradeMode = CapabilityDegradeMode.GRACEFUL
    max_chunks: int = 5
    flows_directory: Optional[str] = None
    core_skills: Optional[CoreSkillsUsage] = None  # Core skills usage flags


class UniversalChannelBuilderPlugin(AgentPlugin):
    """Plugin for channel-agnostic conversation flow execution.

    This plugin:
    - Executes conversation flows across any channel
    - Adapts content to channel capabilities
    - Degrades gracefully (buttons → numbered options)
    - Chunks long messages
    - Provides flow execution tools

    Usage:
        config = FlowConfig(
            flows_directory="./flows",
            capability_degrade_mode=CapabilityDegradeMode.GRACEFUL,
        )
        plugin = UniversalChannelBuilderPlugin(config=config)
        agent = Agent(
            model="gpt-4o-mini",
            plugins=[defaults_plugin, plugin],
            channels=["whatsapp", "slack"],
        )
    """

    id: str = "universal_channel_builder"
    name: str = "Universal Channel Builder"
    version: str = "0.2.0"

    def __init__(self, config: Optional[FlowConfig] = None):
        """Initialize plugin with configuration.

        Args:
            config: Plugin configuration. Falls back to defaults.
        """
        self.config = config or FlowConfig()
        self.registry = FlowRegistry()
        self.adapter = ContentAdapter(mode=self.config.capability_degrade_mode)
        self.engine = FlowEngine(adapter=self.adapter)

        # Load flows if directory specified
        if self.config.flows_directory:
            self._load_flows_from_directory(self.config.flows_directory)

    def _load_flows_from_directory(self, directory: str) -> None:
        """Load flows from directory.

        Args:
            directory: Path to flows directory.
        """
        path = Path(directory)
        if not path.exists():
            return

        for flow_file in path.glob("*.{yaml,yml,json}"):
            try:
                flow = Flow.from_file(flow_file)
                self.registry.register(flow)
            except Exception as e:
                print(f"Failed to load flow from {flow_file}: {e}")

    def configure_agent(self, agent: "Agent") -> "Agent":
        """Add flow execution tools to agent.

        Args:
            agent: Agent to configure.

        Returns:
            Agent with flow tools added.
        """
        # Get defaults if available
        defaults = get_ecommerce_defaults(agent)
        if defaults:
            # Apply defaults
            pass

        # Create flow tools
        from agents import function_tool

        @function_tool(strict_mode=False)
        async def list_flows() -> dict:
            """List available conversation flows.

            Returns:
                Dictionary with flow list.
            """
            flows = self.registry.list()
            return {
                "flows": [
                    {
                        "id": f.id,
                        "name": f.name,
                        "description": f.description,
                        "entry_point": f.entry_point,
                    }
                    for f in flows
                ]
            }

        @function_tool(strict_mode=False)
        async def run_flow(
            flow_id: str,
            user_id: str,
            channel_id: str = "api",
            start_node: Optional[str] = None,
            context: Optional[AgentContext] = None,
        ) -> dict:
            """Execute a conversation flow.

            Args:
                flow_id: ID of the flow to execute.
                user_id: User identifier.
                channel_id: Channel identifier (default "api").
                start_node: Optional starting node.
                context: Optional agent context.

            Returns:
                Flow execution result with messages.
            """
            flow = self.registry.get(flow_id)
            if not flow:
                return {"error": f"Flow {flow_id} not found"}

            # Get channel capabilities (default to API)
            capabilities = self._get_channel_capabilities(channel_id)

            # Create execution context
            if not context:
                context = AgentContext()
                context.user_id = user_id

            exec_context = FlowExecutionContext(
                flow=flow,
                agent_context=context,
                channel_capabilities=capabilities,
            )

            # Execute flow
            messages = await self.engine.execute_flow(flow, exec_context, start_node)

            return {
                "flow_id": flow_id,
                "messages": messages,
                "history": exec_context.history,
            }

        # Add tools to agent
        tools = list(getattr(agent, "tools", []))
        tools.extend([list_flows, run_flow])

        return agent.clone(tools=tools)

    def _get_channel_capabilities(self, channel_id: str) -> ChannelCapabilities:
        """Get capabilities for a channel.

        Args:
            channel_id: Channel identifier.

        Returns:
            Channel capabilities.
        """
        # Default capabilities (would query actual channel config)
        return ChannelCapabilities(
            channel_id=channel_id,
            supports_buttons=True,
            supports_quick_replies=True,
            max_message_length=4096,
            max_buttons=10,
        )

    def dependencies(self) -> List[str]:
        """Channel builder loads after defaults."""
        return ["ecommerce_defaults"]

    def __repr__(self) -> str:
        """String representation."""
        return f"UniversalChannelBuilderPlugin(flows={len(self.registry._flows)}, mode={self.config.capability_degrade_mode})"
