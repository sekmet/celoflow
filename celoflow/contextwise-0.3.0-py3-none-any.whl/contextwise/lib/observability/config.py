"""Configuration for Opik observability integration.

This module provides the OpikConfig dataclass for configuring Opik
within Contextwise agents.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class OpikConfig:
    """Configuration for Opik observability integration.

    Attributes:
        enabled: Whether observability is enabled (default True)
        project_name: Opik project name (defaults to OPIK_PROJECT_NAME env var)
        workspace: Opik workspace name (optional)
        api_key: Opik API key (defaults to OPIK_API_KEY env var)
        endpoint: Opik API endpoint URL (optional, for self-hosted)
        trace_model_calls: Whether to trace individual model calls as child spans
        trace_tool_calls: Whether to trace tool calls as child spans
        redact_inputs: Whether to redact sensitive input data
        redact_outputs: Whether to redact sensitive output data
        sensitive_fields: List of field names to redact
        metadata: Additional metadata to attach to all traces
        tags: Default tags to attach to all traces

    Examples:
        >>> config = OpikConfig()  # Use env vars and defaults
        >>> config = OpikConfig(project_name="my-project", trace_tool_calls=True)
        >>> config = OpikConfig(enabled=False)  # Disable observability
    """

    enabled: bool = True
    project_name: Optional[str] = None
    workspace: Optional[str] = None
    api_key: Optional[str] = None
    endpoint: Optional[str] = None
    url_override: Optional[str] = None
    
    # Tracing options
    trace_model_calls: bool = True
    trace_tool_calls: bool = True
    
    # Redaction options
    redact_inputs: bool = False
    redact_outputs: bool = False
    sensitive_fields: List[str] = field(default_factory=lambda: [
        "api_key", "password", "secret", "token", "authorization",
        "credit_card", "ssn", "social_security",
    ])
    
    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Resolve configuration from environment variables if not provided."""
        # Resolve project_name from env if not provided
        if self.project_name is None:
            self.project_name = os.environ.get("OPIK_PROJECT_NAME", "contextwise")
        
        # Resolve workspace from env if not provided
        if self.workspace is None:
            self.workspace = os.environ.get("OPIK_WORKSPACE", "default")
        
        # Resolve api_key from env if not provided
        if self.api_key is None:
            self.api_key = os.environ.get("OPIK_API_KEY")
        
        # Resolve endpoint from env if not provided
        if self.endpoint is None:
            self.endpoint = os.environ.get("OPIK_URL_OVERRIDE")

    def to_opik_kwargs(self) -> Dict[str, Any]:
        """Convert config to kwargs for opik.configure().

        Returns:
            Dictionary of keyword arguments for opik.configure()
        """
        kwargs: Dict[str, Any] = {}
        
        if self.api_key:
            kwargs["api_key"] = self.api_key
        
        if self.workspace:
            kwargs["workspace"] = self.workspace
        
        if self.endpoint:
            kwargs["url"] = self.endpoint
            
            kwargs["use_local"] = True
        
        return kwargs

    def should_redact(self, field_name: str) -> bool:
        """Check if a field should be redacted.

        Args:
            field_name: The name of the field to check

        Returns:
            True if the field should be redacted
        """
        field_lower = field_name.lower()
        return any(
            sensitive.lower() in field_lower
            for sensitive in self.sensitive_fields
        )

    def redact_dict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Redact sensitive fields from a dictionary.

        Args:
            data: Dictionary to redact

        Returns:
            Dictionary with sensitive fields masked as "[REDACTED]"
        """
        if not data:
            return data
        
        result = {}
        for key, value in data.items():
            if self.should_redact(key):
                result[key] = "[REDACTED]"
            elif isinstance(value, dict):
                result[key] = self.redact_dict(value)
            elif isinstance(value, list):
                result[key] = [
                    self.redact_dict(item) if isinstance(item, dict) else item
                    for item in value
                ]
            else:
                result[key] = value
        
        return result
