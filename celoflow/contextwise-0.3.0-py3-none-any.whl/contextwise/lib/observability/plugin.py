"""Opik Observability Plugin for Contextwise agents.

This module provides the OpikObservabilityPlugin which integrates
Opik tracing into the Contextwise agent lifecycle.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from agents import Agent, RunConfig, RunResult

from ..base import AgentPlugin
from ..context import AgentContext
from .config import OpikConfig
from .opik_integration import (
    create_trace,
    create_span,
    is_opik_enabled,
    OpikTraceHandle,
    OpikSpanHandle,
)

if TYPE_CHECKING:
    from contextwise.agent import Agent as ContextwiseAgent

logger = logging.getLogger(__name__)


@dataclass
class OpikObservabilityPlugin(AgentPlugin[AgentContext]):
    """Plugin that adds Opik observability to Contextwise agents.

    This plugin wraps agent runs with Opik traces, tracking:
    - Agent run inputs and outputs
    - Session/conversation threading via group_id
    - Model and tool calls as child spans (when enabled)
    - Token usage, latency, and cost metrics

    Attributes:
        config: OpikConfig for customizing observability behavior
        _active_traces: Map of context to active trace handles
        _active_spans: Map of trace_id to active span handles

    Examples:
        >>> from contextwise import Agent, OpikObservabilityPlugin
        >>> agent = Agent(
        ...     model="gpt-4o-mini",
        ...     instructions="You are helpful",
        ...     plugins=[OpikObservabilityPlugin()],
        ... )
        >>> response = agent.chat("Hello!")  # Traced automatically

        >>> # With custom config
        >>> config = OpikConfig(project_name="my-project", trace_tool_calls=True)
        >>> agent = Agent(
        ...     model="gpt-4o-mini",
        ...     instructions="You are helpful",
        ...     plugins=[OpikObservabilityPlugin(config=config)],
        ... )
    """

    # Plugin identity
    id: str = "opik_observability"
    name: str = "Opik Observability"
    version: str = "0.2.0"

    # Configuration
    config: OpikConfig = field(default_factory=OpikConfig)

    # Internal state for tracking active traces
    _active_traces: Dict[str, OpikTraceHandle] = field(
        default_factory=dict, repr=False
    )
    _active_spans: Dict[str, List[OpikSpanHandle]] = field(
        default_factory=dict, repr=False
    )

    def dependencies(self) -> List[str]:
        """Return plugin dependencies.

        Observability has no dependencies on other plugins.

        Returns:
            Empty list
        """
        return []

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Configure the agent with observability hooks.

        This method is called during agent initialization to set up
        observability. The actual tracing happens in on_before_run
        and on_after_run hooks.

        Args:
            agent: The SDK agent to configure

        Returns:
            The agent (unchanged, tracing happens via hooks)
        """
        if not self.config.enabled:
            logger.debug("Opik observability disabled, skipping agent configuration")
            return agent

        logger.debug(f"Configuring Opik observability for agent: {agent.name}")
        
        # No agent modifications needed - we use lifecycle hooks
        return agent

    def configure_run_config(
        self,
        context: AgentContext,
        base_config: Optional[RunConfig],
    ) -> Optional[RunConfig]:
        """Optionally extend the run configuration.

        Currently does not modify the run config, but could be extended
        to add tracing processors if needed.

        Args:
            context: The agent context
            base_config: The base run configuration

        Returns:
            The run configuration (unchanged)
        """
        return base_config

    def on_before_run(
        self,
        context: AgentContext,
        input: str,
    ) -> None:
        """Start a trace before agent run.

        Creates an Opik trace with:
        - Workflow name based on context channel
        - Group ID from session_id for conversation threading
        - Input message attached

        Args:
            context: The agent context
            input: The user input message
        """
        if not self.config.enabled:
            return

        # Generate a context key for tracking
        context_key = self._get_context_key(context)

        # Build metadata
        metadata: Dict[str, Any] = {
            "user_id": context.user_id,
            "channel": context.channel,
            "locale": context.locale,
            "modality": context.modality,
        }
        
        # Add config metadata
        metadata.update(self.config.metadata)

        # Add optional fields if present
        if context.phone_number:
            metadata["phone_number"] = context.phone_number
        if context.message_id:
            metadata["message_id"] = context.message_id
        if context.room_name:
            metadata["room_name"] = context.room_name

        # Build workflow name
        workflow_name = f"agent:{context.channel}"

        # Potentially redact input
        trace_input = input
        if self.config.redact_inputs:
            trace_input = "[REDACTED]"

        # Create trace
        trace = create_trace(
            workflow_name=workflow_name,
            group_id=context.session_id,
            input_data={"message": trace_input},
            metadata=metadata,
        )

        # Store trace handle
        self._active_traces[context_key] = trace
        self._active_spans[trace.trace_id] = []

        logger.debug(
            f"Started Opik trace {trace.trace_id} for {workflow_name} "
            f"(session={context.session_id})"
        )

    def on_after_run(
        self,
        context: AgentContext,
        result: RunResult,
    ) -> None:
        """End the trace after agent run.

        Records the final output and ends the trace with duration.

        Args:
            context: The agent context
            result: The run result from the agent
        """
        if not self.config.enabled:
            return

        context_key = self._get_context_key(context)
        trace = self._active_traces.pop(context_key, None)

        if not trace:
            logger.debug("No active trace found for context")
            return

        # End any active child spans
        spans = self._active_spans.pop(trace.trace_id, [])
        for span in spans:
            span.end()

        # Set output (potentially redacted)
        output = result.final_output or ""
        if self.config.redact_outputs:
            output = "[REDACTED]"
        
        trace.set_output({"response": output})

        # Add run result metadata
        trace.add_metadata("agent_name", result.last_agent.name if result.last_agent else "unknown")
        
        # Extract and log token usage if available
        # RunResult may contain raw responses with usage data
        if hasattr(result, 'raw_responses') and result.raw_responses:
            self._extract_usage_from_responses(trace, result.raw_responses)

        # End trace
        duration = trace.end()
        
        logger.debug(
            f"Ended Opik trace {trace.trace_id} (duration={duration:.3f}s)"
        )

    def _get_context_key(self, context: AgentContext) -> str:
        """Generate a unique key for tracking context.

        Args:
            context: The agent context

        Returns:
            A string key unique to this context
        """
        return f"{context.user_id}:{context.session_id or 'default'}:{context.channel}"

    def _extract_usage_from_responses(
        self,
        trace: OpikTraceHandle,
        raw_responses: Any,
    ) -> None:
        """Extract token usage from raw responses.

        Args:
            trace: The trace handle to update
            raw_responses: Raw model responses that may contain usage data
        """
        try:
            total_prompt_tokens = 0
            total_completion_tokens = 0
            
            # Iterate through responses looking for usage
            for response in raw_responses if isinstance(raw_responses, list) else [raw_responses]:
                if hasattr(response, 'usage') and response.usage:
                    usage = response.usage
                    if hasattr(usage, 'prompt_tokens'):
                        total_prompt_tokens += usage.prompt_tokens or 0
                    if hasattr(usage, 'completion_tokens'):
                        total_completion_tokens += usage.completion_tokens or 0

            if total_prompt_tokens or total_completion_tokens:
                trace.add_metadata("prompt_tokens", total_prompt_tokens)
                trace.add_metadata("completion_tokens", total_completion_tokens)
                trace.add_metadata("total_tokens", total_prompt_tokens + total_completion_tokens)
                
        except Exception as e:
            logger.debug(f"Failed to extract usage from responses: {e}")

    # === Phase 2: Model/Tool instrumentation methods ===

    def start_model_span(
        self,
        context: AgentContext,
        model_id: str,
        prompt: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[OpikSpanHandle]:
        """Start a span for a model call.

        Args:
            context: The agent context
            model_id: The model identifier
            prompt: Optional prompt text (may be redacted)
            metadata: Optional additional metadata

        Returns:
            OpikSpanHandle if trace is active, None otherwise
        """
        if not self.config.enabled or not self.config.trace_model_calls:
            return None

        context_key = self._get_context_key(context)
        trace = self._active_traces.get(context_key)

        if not trace:
            return None

        # Build span metadata
        span_metadata = {"model_id": model_id}
        if metadata:
            span_metadata.update(metadata)

        # Potentially redact prompt
        input_data = None
        if prompt:
            input_data = {"prompt": prompt if not self.config.redact_inputs else "[REDACTED]"}

        span = create_span(
            trace_handle=trace,
            kind="model",
            name=f"model:{model_id}",
            input_data=input_data,
            metadata=span_metadata,
        )

        # Track span
        if trace.trace_id in self._active_spans:
            self._active_spans[trace.trace_id].append(span)

        return span

    def end_model_span(
        self,
        span: OpikSpanHandle,
        response: Optional[str] = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        cost: Optional[float] = None,
        error: Optional[Exception] = None,
    ) -> None:
        """End a model span with response and usage data.

        Args:
            span: The span handle to end
            response: The model response (may be redacted)
            prompt_tokens: Number of prompt tokens
            completion_tokens: Number of completion tokens
            cost: Cost in USD
            error: Optional error if model call failed
        """
        if not span:
            return

        if error:
            span.set_error(error=error)
        else:
            # Set output (potentially redacted)
            if response:
                output = response if not self.config.redact_outputs else "[REDACTED]"
                span.set_output({"response": output})

            # Set usage
            span.set_usage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=(prompt_tokens or 0) + (completion_tokens or 0) if prompt_tokens or completion_tokens else None,
                cost=cost,
            )

        span.end()

    def start_tool_span(
        self,
        context: AgentContext,
        tool_name: str,
        arguments: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[OpikSpanHandle]:
        """Start a span for a tool call.

        Args:
            context: The agent context
            tool_name: The tool name
            arguments: Optional tool arguments (may be redacted)
            metadata: Optional additional metadata

        Returns:
            OpikSpanHandle if trace is active, None otherwise
        """
        if not self.config.enabled or not self.config.trace_tool_calls:
            return None

        context_key = self._get_context_key(context)
        trace = self._active_traces.get(context_key)

        if not trace:
            return None

        # Build span metadata
        span_metadata = {"tool_name": tool_name}
        if metadata:
            span_metadata.update(metadata)

        # Potentially redact arguments
        input_data = None
        if arguments:
            if self.config.redact_inputs:
                input_data = {"arguments": self.config.redact_dict(arguments)}
            else:
                input_data = {"arguments": arguments}

        span = create_span(
            trace_handle=trace,
            kind="tool",
            name=f"tool:{tool_name}",
            input_data=input_data,
            metadata=span_metadata,
        )

        # Track span
        if trace.trace_id in self._active_spans:
            self._active_spans[trace.trace_id].append(span)

        return span

    def end_tool_span(
        self,
        span: OpikSpanHandle,
        result: Optional[Any] = None,
        error: Optional[Exception] = None,
    ) -> None:
        """End a tool span with result.

        Args:
            span: The span handle to end
            result: The tool result (may be redacted)
            error: Optional error if tool call failed
        """
        if not span:
            return

        if error:
            span.set_error(error=error)
        else:
            # Set output (potentially redacted)
            if result is not None:
                if self.config.redact_outputs and isinstance(result, dict):
                    output = self.config.redact_dict(result)
                else:
                    output = result if not self.config.redact_outputs else "[REDACTED]"
                span.set_output({"result": output})

        span.end()

    def get_active_trace(self, context: AgentContext) -> Optional[OpikTraceHandle]:
        """Get the active trace for a context.

        Useful for manual span creation or advanced use cases.

        Args:
            context: The agent context

        Returns:
            OpikTraceHandle if a trace is active, None otherwise
        """
        context_key = self._get_context_key(context)
        return self._active_traces.get(context_key)
