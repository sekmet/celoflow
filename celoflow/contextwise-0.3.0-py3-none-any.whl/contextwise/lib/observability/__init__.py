"""Observability module for Contextwise v0.3.0.

This module provides LLM observability integration with Opik for:
- End-to-end tracing of agent runs and tools
- Token usage, cost, and latency metrics
- Conversation thread grouping via session_id

Quick start:
    >>> from contextwise import Agent, OpikObservabilityPlugin
    >>> agent = Agent(
    ...     model="gpt-4o-mini",
    ...     instructions="You are helpful",
    ...     plugins=[OpikObservabilityPlugin()],
    ... )
"""

from .config import OpikConfig
from .opik_integration import (
    initialize_opik,
    create_trace,
    create_span,
    OpikTraceHandle,
    OpikSpanHandle,
)
from .plugin import OpikObservabilityPlugin
from .test_utils import (
    OpikTestContext,
    TraceAssertion,
    assert_trace_count,
    assert_span_count,
    assert_no_errors,
    mock_opik_backend,
)

__all__ = [
    # Config
    "OpikConfig",
    # Integration
    "initialize_opik",
    "create_trace",
    "create_span",
    "OpikTraceHandle",
    "OpikSpanHandle",
    # Plugin
    "OpikObservabilityPlugin",
    # Test utilities
    "OpikTestContext",
    "TraceAssertion",
    "assert_trace_count",
    "assert_span_count",
    "assert_no_errors",
    "mock_opik_backend",
]
