"""Test utilities for Opik observability.

This module provides utilities for testing agents with Opik tracing,
including mock backends and trace assertions.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Generator, List, Optional
from unittest.mock import MagicMock, patch

from .config import OpikConfig
from .opik_integration import reset_opik

logger = logging.getLogger(__name__)


@dataclass
class MockTrace:
    """Mock trace object for testing.

    Attributes:
        id: Trace identifier
        name: Workflow name
        input: Input data
        output: Output data
        metadata: Trace metadata
        tags: Trace tags
        spans: Child spans
        ended: Whether trace has ended
        error: Error information if any
    """

    id: str
    name: str
    input: Optional[Any] = None
    output: Optional[Any] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    spans: List["MockSpan"] = field(default_factory=list)
    ended: bool = False
    error: Optional[Dict[str, Any]] = None

    def update(self, **kwargs: Any) -> None:
        """Update trace properties."""
        if "input" in kwargs:
            self.input = kwargs["input"]
        if "output" in kwargs:
            self.output = kwargs["output"]
        if "metadata" in kwargs:
            self.metadata.update(kwargs["metadata"])
        if "tags" in kwargs:
            self.tags.extend(kwargs["tags"])

    def span(self, **kwargs: Any) -> "MockSpan":
        """Create a child span."""
        span = MockSpan(
            id=f"{self.id}:span:{len(self.spans)}",
            name=kwargs.get("name", "unnamed"),
            parent_trace_id=self.id,
            input=kwargs.get("input"),
            metadata=kwargs.get("metadata", {}),
        )
        self.spans.append(span)
        return span

    def end(self) -> None:
        """End the trace."""
        self.ended = True


@dataclass
class MockSpan:
    """Mock span object for testing.

    Attributes:
        id: Span identifier
        name: Operation name
        parent_trace_id: Parent trace ID
        input: Input data
        output: Output data
        metadata: Span metadata
        usage: Token usage data
        ended: Whether span has ended
        error: Error information if any
    """

    id: str
    name: str
    parent_trace_id: str
    input: Optional[Any] = None
    output: Optional[Any] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    usage: Optional[Dict[str, Any]] = None
    ended: bool = False
    error: Optional[Dict[str, Any]] = None

    def update(self, **kwargs: Any) -> None:
        """Update span properties."""
        if "input" in kwargs:
            self.input = kwargs["input"]
        if "output" in kwargs:
            self.output = kwargs["output"]
        if "metadata" in kwargs:
            self.metadata.update(kwargs["metadata"])
        if "usage" in kwargs:
            self.usage = kwargs["usage"]

    def end(self) -> None:
        """End the span."""
        self.ended = True


@dataclass
class MockOpikClient:
    """Mock Opik client for testing.

    Captures all traces and spans for assertions.

    Attributes:
        traces: List of created traces
        project_name: Configured project name
        workspace: Configured workspace
    """

    traces: List[MockTrace] = field(default_factory=list)
    project_name: Optional[str] = None
    workspace: Optional[str] = None

    def trace(self, **kwargs: Any) -> MockTrace:
        """Create a new trace."""
        trace = MockTrace(
            id=f"trace:{len(self.traces)}",
            name=kwargs.get("name", "unnamed"),
            input=kwargs.get("input"),
            metadata=kwargs.get("metadata", {}),
            tags=kwargs.get("tags", []),
        )
        self.traces.append(trace)
        return trace

    def get_all_spans(self) -> List[MockSpan]:
        """Get all spans across all traces."""
        spans = []
        for trace in self.traces:
            spans.extend(trace.spans)
        return spans


class MockOpikModule:
    """Mock opik module for testing."""

    def __init__(self) -> None:
        self._client = MockOpikClient()
        self._configured = False

    def configure(self, **kwargs: Any) -> None:
        """Mock opik.configure()."""
        self._configured = True
        self._client.project_name = kwargs.get("project_name")
        self._client.workspace = kwargs.get("workspace")

    def Opik(self) -> MockOpikClient:
        """Mock opik.Opik() client constructor."""
        return self._client


@dataclass
class OpikTestContext:
    """Context for Opik-enabled tests.

    Provides access to mock client and utilities for assertions.

    Attributes:
        mock_module: The mock opik module
        config: OpikConfig used for the test
    """

    mock_module: MockOpikModule = field(default_factory=MockOpikModule)
    config: OpikConfig = field(default_factory=OpikConfig)

    @property
    def client(self) -> MockOpikClient:
        """Get the mock Opik client."""
        return self.mock_module._client

    @property
    def traces(self) -> List[MockTrace]:
        """Get all captured traces."""
        return self.client.traces

    @property
    def spans(self) -> List[MockSpan]:
        """Get all captured spans."""
        return self.client.get_all_spans()

    def get_trace(self, index: int = 0) -> Optional[MockTrace]:
        """Get a trace by index.

        Args:
            index: Trace index (default 0 for first trace)

        Returns:
            MockTrace or None if not found
        """
        if 0 <= index < len(self.traces):
            return self.traces[index]
        return None

    def get_spans_by_kind(self, kind: str) -> List[MockSpan]:
        """Get all spans of a specific kind.

        Args:
            kind: Span kind (e.g., "model", "tool")

        Returns:
            List of matching spans
        """
        return [
            span for span in self.spans
            if span.metadata.get("kind") == kind
        ]

    def get_model_spans(self) -> List[MockSpan]:
        """Get all model spans."""
        return self.get_spans_by_kind("model")

    def get_tool_spans(self) -> List[MockSpan]:
        """Get all tool spans."""
        return self.get_spans_by_kind("tool")


@dataclass
class TraceAssertion:
    """Fluent assertion builder for traces.

    Examples:
        >>> assertion = TraceAssertion(test_context)
        >>> assertion.has_traces(1).has_spans(2).no_errors()
    """

    context: OpikTestContext
    _errors: List[str] = field(default_factory=list)

    def has_traces(self, count: int) -> "TraceAssertion":
        """Assert the number of traces.

        Args:
            count: Expected number of traces

        Returns:
            Self for chaining
        """
        actual = len(self.context.traces)
        if actual != count:
            self._errors.append(f"Expected {count} traces, got {actual}")
        return self

    def has_spans(self, count: int) -> "TraceAssertion":
        """Assert the total number of spans.

        Args:
            count: Expected number of spans

        Returns:
            Self for chaining
        """
        actual = len(self.context.spans)
        if actual != count:
            self._errors.append(f"Expected {count} spans, got {actual}")
        return self

    def has_model_spans(self, count: int) -> "TraceAssertion":
        """Assert the number of model spans.

        Args:
            count: Expected number of model spans

        Returns:
            Self for chaining
        """
        actual = len(self.context.get_model_spans())
        if actual != count:
            self._errors.append(f"Expected {count} model spans, got {actual}")
        return self

    def has_tool_spans(self, count: int) -> "TraceAssertion":
        """Assert the number of tool spans.

        Args:
            count: Expected number of tool spans

        Returns:
            Self for chaining
        """
        actual = len(self.context.get_tool_spans())
        if actual != count:
            self._errors.append(f"Expected {count} tool spans, got {actual}")
        return self

    def no_errors(self) -> "TraceAssertion":
        """Assert no errors in traces or spans.

        Returns:
            Self for chaining
        """
        for trace in self.context.traces:
            if trace.error or trace.metadata.get("error"):
                self._errors.append(f"Trace {trace.id} has error: {trace.error or trace.metadata.get('error_message')}")
        for span in self.context.spans:
            if span.error or span.metadata.get("error"):
                self._errors.append(f"Span {span.id} has error: {span.error or span.metadata.get('error_message')}")
        return self

    def all_ended(self) -> "TraceAssertion":
        """Assert all traces and spans have ended.

        Returns:
            Self for chaining
        """
        for trace in self.context.traces:
            if not trace.ended:
                self._errors.append(f"Trace {trace.id} has not ended")
        for span in self.context.spans:
            if not span.ended:
                self._errors.append(f"Span {span.id} has not ended")
        return self

    def trace_has_metadata(self, key: str, value: Any, trace_index: int = 0) -> "TraceAssertion":
        """Assert a trace has specific metadata.

        Args:
            key: Metadata key
            value: Expected value
            trace_index: Which trace to check (default 0)

        Returns:
            Self for chaining
        """
        trace = self.context.get_trace(trace_index)
        if not trace:
            self._errors.append(f"No trace at index {trace_index}")
        elif key not in trace.metadata:
            self._errors.append(f"Trace {trace.id} missing metadata key '{key}'")
        elif trace.metadata[key] != value:
            self._errors.append(f"Trace {trace.id} metadata['{key}'] = {trace.metadata[key]}, expected {value}")
        return self

    def validate(self) -> None:
        """Validate all assertions and raise if any failed.

        Raises:
            AssertionError: If any assertions failed
        """
        if self._errors:
            raise AssertionError("\n".join(self._errors))

    def is_valid(self) -> bool:
        """Check if all assertions passed.

        Returns:
            True if all assertions passed
        """
        return len(self._errors) == 0


@contextmanager
def mock_opik_backend() -> Generator[OpikTestContext, None, None]:
    """Context manager that mocks the Opik backend for testing.

    Yields:
        OpikTestContext with mock client for assertions

    Examples:
        >>> with mock_opik_backend() as ctx:
        ...     # Run agent code that uses Opik
        ...     agent.chat("Hello")
        ...     # Assert on traces
        ...     assert len(ctx.traces) == 1
    """
    # Reset any existing Opik state
    reset_opik()

    # Create mock module
    mock_module = MockOpikModule()
    test_context = OpikTestContext(mock_module=mock_module)

    # Patch the opik module import
    with patch.dict("sys.modules", {"opik": mock_module}):
        yield test_context

    # Reset after test
    reset_opik()


def assert_trace_count(context: OpikTestContext, expected: int) -> None:
    """Assert the number of traces.

    Args:
        context: OpikTestContext
        expected: Expected number of traces

    Raises:
        AssertionError: If count doesn't match
    """
    actual = len(context.traces)
    assert actual == expected, f"Expected {expected} traces, got {actual}"


def assert_span_count(context: OpikTestContext, expected: int) -> None:
    """Assert the total number of spans.

    Args:
        context: OpikTestContext
        expected: Expected number of spans

    Raises:
        AssertionError: If count doesn't match
    """
    actual = len(context.spans)
    assert actual == expected, f"Expected {expected} spans, got {actual}"


def assert_no_errors(context: OpikTestContext) -> None:
    """Assert no errors in any traces or spans.

    Args:
        context: OpikTestContext

    Raises:
        AssertionError: If any errors are found
    """
    errors = []
    for trace in context.traces:
        if trace.error or trace.metadata.get("error"):
            errors.append(f"Trace {trace.id}: {trace.error or trace.metadata.get('error_message')}")
    for span in context.spans:
        if span.error or span.metadata.get("error"):
            errors.append(f"Span {span.id}: {span.error or span.metadata.get('error_message')}")
    
    if errors:
        raise AssertionError(f"Found errors:\n" + "\n".join(errors))
