"""Opik SDK integration module for Contextwise.

This module provides the core integration with the Opik SDK for
LLM observability. It centralizes Opik configuration and provides
helpers for creating traces and spans.
"""

from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, Generator, Optional

from .config import OpikConfig

logger = logging.getLogger(__name__)

# Global state for Opik initialization
_opik_initialized = False
_opik_config: Optional[OpikConfig] = None


def initialize_opik(config: Optional[OpikConfig] = None) -> bool:
    """Initialize the Opik SDK with configuration.

    This should be called once at process startup, typically in the
    server lifespan handler.

    Args:
        config: OpikConfig instance (uses defaults if None)

    Returns:
        True if initialization was successful, False otherwise
    """
    global _opik_initialized, _opik_config

    if _opik_initialized:
        logger.debug("Opik already initialized, skipping")
        return True

    config = config or OpikConfig()
    
    if not config.enabled:
        logger.info("Opik observability disabled by configuration")
        return False

    try:
        import opik
        
        # Configure Opik with provided settings
        kwargs = config.to_opik_kwargs()
        print(kwargs)
        opik.configure(**kwargs)
        
        _opik_initialized = True
        _opik_config = config
        
        logger.info(
            f"Opik initialized successfully "
            f"(project={config.project_name}, workspace={config.workspace}, url={config.endpoint})"
        )
        return True
        
    except ImportError:
        logger.warning("opik package not installed, observability disabled")
        return False
    except Exception as e:
        logger.error(f"Failed to initialize Opik: {e}")
        return False


def is_opik_enabled() -> bool:
    """Check if Opik is initialized and enabled.

    Returns:
        True if Opik is ready for use
    """
    return _opik_initialized


def get_opik_config() -> Optional[OpikConfig]:
    """Get the current Opik configuration.

    Returns:
        The current OpikConfig or None if not initialized
    """
    return _opik_config


@dataclass
class OpikTraceHandle:
    """Handle for an active Opik trace.

    Wraps the Opik trace context and provides methods for
    enriching the trace with metadata and creating child spans.

    Attributes:
        trace_id: Unique identifier for this trace
        workflow_name: Name of the workflow being traced
        group_id: Optional group ID for conversation threading
        start_time: Unix timestamp when trace started
        metadata: Additional metadata attached to the trace
        _opik_trace: The underlying Opik trace object
    """

    trace_id: str
    workflow_name: str
    group_id: Optional[str] = None
    start_time: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    _opik_trace: Optional[Any] = field(default=None, repr=False)

    def add_metadata(self, key: str, value: Any) -> None:
        """Add metadata to the trace.

        Args:
            key: Metadata key
            value: Metadata value
        """
        self.metadata[key] = value
        if self._opik_trace and hasattr(self._opik_trace, 'update'):
            try:
                self._opik_trace.update(metadata={key: value})
            except Exception as e:
                logger.debug(f"Failed to update trace metadata: {e}")

    def set_output(self, output: Any) -> None:
        """Set the final output of the trace.

        Args:
            output: The trace output
        """
        if self._opik_trace and hasattr(self._opik_trace, 'update'):
            try:
                self._opik_trace.update(output=output)
            except Exception as e:
                logger.debug(f"Failed to set trace output: {e}")

    def set_error(self, error: Optional[Exception] = None, message: Optional[str] = None) -> None:
        """Mark the trace as failed with an error.

        Args:
            error: The exception that occurred
            message: Optional error message
        """
        error_info = {
            "error": True,
            "error_type": type(error).__name__ if error else "Error",
            "error_message": str(error) if error else message,
        }
        self.metadata.update(error_info)
        
        if self._opik_trace and hasattr(self._opik_trace, 'update'):
            try:
                self._opik_trace.update(metadata=error_info)
            except Exception as e:
                logger.debug(f"Failed to set trace error: {e}")

    def end(self) -> float:
        """End the trace and return duration.

        Returns:
            Duration in seconds
        """
        duration = time.time() - self.start_time
        if self._opik_trace and hasattr(self._opik_trace, 'end'):
            try:
                self._opik_trace.end()
            except Exception as e:
                logger.debug(f"Failed to end trace: {e}")
        return duration


@dataclass
class OpikSpanHandle:
    """Handle for an active Opik span (child of a trace).

    Wraps the Opik span context and provides methods for
    enriching the span with metadata.

    Attributes:
        span_id: Unique identifier for this span
        kind: Type of span (model, tool, etc.)
        name: Name of the operation being traced
        start_time: Unix timestamp when span started
        metadata: Additional metadata attached to the span
        _opik_span: The underlying Opik span object
    """

    span_id: str
    kind: str
    name: str
    start_time: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    _opik_span: Optional[Any] = field(default=None, repr=False)

    def add_metadata(self, key: str, value: Any) -> None:
        """Add metadata to the span.

        Args:
            key: Metadata key
            value: Metadata value
        """
        self.metadata[key] = value
        if self._opik_span and hasattr(self._opik_span, 'update'):
            try:
                self._opik_span.update(metadata={key: value})
            except Exception as e:
                logger.debug(f"Failed to update span metadata: {e}")

    def set_input(self, input_data: Any) -> None:
        """Set the input data for this span.

        Args:
            input_data: The input data
        """
        if self._opik_span and hasattr(self._opik_span, 'update'):
            try:
                self._opik_span.update(input=input_data)
            except Exception as e:
                logger.debug(f"Failed to set span input: {e}")

    def set_output(self, output: Any) -> None:
        """Set the output of the span.

        Args:
            output: The span output
        """
        if self._opik_span and hasattr(self._opik_span, 'update'):
            try:
                self._opik_span.update(output=output)
            except Exception as e:
                logger.debug(f"Failed to set span output: {e}")

    def set_usage(
        self,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        total_tokens: Optional[int] = None,
        cost: Optional[float] = None,
    ) -> None:
        """Set token usage and cost for this span.

        Args:
            prompt_tokens: Number of prompt tokens
            completion_tokens: Number of completion tokens
            total_tokens: Total number of tokens
            cost: Cost in USD
        """
        usage = {}
        if prompt_tokens is not None:
            usage["prompt_tokens"] = prompt_tokens
        if completion_tokens is not None:
            usage["completion_tokens"] = completion_tokens
        if total_tokens is not None:
            usage["total_tokens"] = total_tokens
        if cost is not None:
            usage["cost"] = cost
        
        if usage:
            self.metadata["usage"] = usage
            if self._opik_span and hasattr(self._opik_span, 'update'):
                try:
                    self._opik_span.update(usage=usage)
                except Exception as e:
                    logger.debug(f"Failed to set span usage: {e}")

    def set_error(self, error: Optional[Exception] = None, message: Optional[str] = None) -> None:
        """Mark the span as failed with an error.

        Args:
            error: The exception that occurred
            message: Optional error message
        """
        error_info = {
            "error": True,
            "error_type": type(error).__name__ if error else "Error",
            "error_message": str(error) if error else message,
        }
        self.metadata.update(error_info)
        
        if self._opik_span and hasattr(self._opik_span, 'update'):
            try:
                self._opik_span.update(metadata=error_info)
            except Exception as e:
                logger.debug(f"Failed to set span error: {e}")

    def end(self) -> float:
        """End the span and return duration.

        Returns:
            Duration in seconds
        """
        duration = time.time() - self.start_time
        if self._opik_span and hasattr(self._opik_span, 'end'):
            try:
                self._opik_span.end()
            except Exception as e:
                logger.debug(f"Failed to end span: {e}")
        return duration


def create_trace(
    workflow_name: str,
    group_id: Optional[str] = None,
    input_data: Optional[Any] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> OpikTraceHandle:
    """Create a new Opik trace.

    Args:
        workflow_name: Name of the workflow (e.g., agent name)
        group_id: Optional group ID for threading (e.g., session_id)
        input_data: Optional input data to attach
        metadata: Optional additional metadata

    Returns:
        OpikTraceHandle for the created trace
    """
    import uuid
    
    trace_id = str(uuid.uuid4())
    trace_metadata = metadata or {}
    
    opik_trace = None
    
    if is_opik_enabled():
        try:
            import opik
            
            # Create trace with Opik
            trace_kwargs: Dict[str, Any] = {
                "name": workflow_name,
            }
            
            if group_id:
                trace_kwargs["tags"] = [f"group:{group_id}"]
            
            if input_data is not None:
                trace_kwargs["input"] = input_data
            
            if trace_metadata:
                trace_kwargs["metadata"] = trace_metadata
            
            # Use opik.trace() context manager or @track decorator pattern
            # For now, we'll use the low-level Opik client API
            client = opik.Opik()
            opik_trace = client.trace(**trace_kwargs)
            trace_id = opik_trace.id if hasattr(opik_trace, 'id') else trace_id
            
        except Exception as e:
            logger.debug(f"Failed to create Opik trace: {e}")
    
    return OpikTraceHandle(
        trace_id=trace_id,
        workflow_name=workflow_name,
        group_id=group_id,
        metadata=trace_metadata,
        _opik_trace=opik_trace,
    )


def create_span(
    trace_handle: OpikTraceHandle,
    kind: str,
    name: str,
    input_data: Optional[Any] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> OpikSpanHandle:
    """Create a new Opik span within a trace.

    Args:
        trace_handle: Parent trace handle
        kind: Type of span (model, tool, custom)
        name: Name of the operation
        input_data: Optional input data to attach
        metadata: Optional additional metadata

    Returns:
        OpikSpanHandle for the created span
    """
    import uuid
    
    span_id = str(uuid.uuid4())
    span_metadata = metadata or {}
    span_metadata["kind"] = kind
    
    opik_span = None
    
    if is_opik_enabled() and trace_handle._opik_trace:
        try:
            # Create span as child of trace
            span_kwargs: Dict[str, Any] = {
                "name": name,
                "metadata": span_metadata,
            }
            
            if input_data is not None:
                span_kwargs["input"] = input_data
            
            if hasattr(trace_handle._opik_trace, 'span'):
                opik_span = trace_handle._opik_trace.span(**span_kwargs)
                span_id = opik_span.id if hasattr(opik_span, 'id') else span_id
            
        except Exception as e:
            logger.debug(f"Failed to create Opik span: {e}")
    
    return OpikSpanHandle(
        span_id=span_id,
        kind=kind,
        name=name,
        metadata=span_metadata,
        _opik_span=opik_span,
    )


@contextmanager
def trace_context(
    workflow_name: str,
    group_id: Optional[str] = None,
    input_data: Optional[Any] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Generator[OpikTraceHandle, None, None]:
    """Context manager for creating and automatically ending a trace.

    Args:
        workflow_name: Name of the workflow (e.g., agent name)
        group_id: Optional group ID for threading (e.g., session_id)
        input_data: Optional input data to attach
        metadata: Optional additional metadata

    Yields:
        OpikTraceHandle for the created trace
    """
    trace = create_trace(
        workflow_name=workflow_name,
        group_id=group_id,
        input_data=input_data,
        metadata=metadata,
    )
    
    try:
        yield trace
    except Exception as e:
        trace.set_error(error=e)
        raise
    finally:
        trace.end()


@contextmanager
def span_context(
    trace_handle: OpikTraceHandle,
    kind: str,
    name: str,
    input_data: Optional[Any] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Generator[OpikSpanHandle, None, None]:
    """Context manager for creating and automatically ending a span.

    Args:
        trace_handle: Parent trace handle
        kind: Type of span (model, tool, custom)
        name: Name of the operation
        input_data: Optional input data to attach
        metadata: Optional additional metadata

    Yields:
        OpikSpanHandle for the created span
    """
    span = create_span(
        trace_handle=trace_handle,
        kind=kind,
        name=name,
        input_data=input_data,
        metadata=metadata,
    )
    
    try:
        yield span
    except Exception as e:
        span.set_error(error=e)
        raise
    finally:
        span.end()


def reset_opik() -> None:
    """Reset Opik initialization state.

    This is primarily for testing purposes to allow re-initialization.
    """
    global _opik_initialized, _opik_config
    _opik_initialized = False
    _opik_config = None
