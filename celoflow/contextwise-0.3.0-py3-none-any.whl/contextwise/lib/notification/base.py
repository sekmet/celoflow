from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from agents import Agent

from ..base import AgentPlugin
from ..booking import Booking
from ..context import AgentContext


class NotificationPlugin(AgentPlugin, ABC):
    """Base plugin for sending user notifications.

    This abstraction is intentionally narrow so it can be reused for
    different channels (WhatsApp, email, SMS, push) and different
    agents that adopt a `AgentContext`-like contract with
    `user_id` and `channel` fields.
    """

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        return agent

    @abstractmethod
    def send_message(
        self,
        user_id: str,
        text: str,
        *,
        channel: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Send a notification message to the given user.

        Implementations are responsible for applying channel specific
        behaviour (for example, message splitting or formatting).
        """

    def on_booking_confirmed(
        self,
        context: AgentContext,
        booking: Booking,
    ) -> None:
        """Optional hook called when a booking is confirmed.

        The booking backend can call this hook to trigger side-effectful
        notifications. The default implementation is a no-op.
        """

        return None
