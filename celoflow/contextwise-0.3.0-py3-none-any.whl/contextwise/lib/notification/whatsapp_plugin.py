from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

from .base import NotificationPlugin
from ..context import AgentContext
from ..booking import Booking

logger = logging.getLogger(__name__)


class WhatsAppNotificationPlugin(NotificationPlugin):
    """Notification plugin that models WhatsApp-style constraints.

    This implementation does not talk directly to the real WhatsApp
    Business API. Instead, it focuses on:

    - Message length constraints and batching (inspired by the WhatsApp
      implementation patterns specs).
    - A pluggable `send_callable` that can be wired to an actual
      transport in higher layers or replaced with a mock in tests.
    """

    id = "whatsapp-notification"
    name = "WhatsApp notification plugin"

    def __init__(
        self,
        *,
        max_message_length: int = 4000,
        italics: bool = False,
        send_callable: Optional[Callable[[str, str, Dict[str, Any]], None]] = None,
    ) -> None:
        self._max_message_length = max_message_length
        self._italics = italics
        self._send_callable = send_callable

    def send_message(
        self,
        user_id: str,
        text: str,
        *,
        channel: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        channel = channel or "whatsapp"
        metadata = metadata or {}
        chunks = self._split_message(text)
        total = len(chunks)
        for idx, chunk in enumerate(chunks, start=1):
            payload = chunk
            if total > 1:
                payload = f"[{idx}/{total}] {payload}"
            if self._italics:
                payload = f"_{payload}_"
            self._dispatch(user_id=user_id, text=payload, channel=channel, metadata=metadata)

    def on_booking_confirmed(
        self,
        context: AgentContext,
        booking: Booking,
    ) -> None:
        """Send a concise booking confirmation over WhatsApp.

        This method can be called by booking backends or higher level
        orchestration code when a booking is created.
        """

        message = (
            f"Tu turno {booking.id} está confirmado para "
            f"{booking.start.isoformat()} (servicio {booking.service_id})."
        )
        self.send_message(
            user_id=context.user_id,
            text=message,
            channel=context.channel or "whatsapp",
            metadata={"booking_id": booking.id},
        )

    def _split_message(self, text: str) -> List[str]:
        if not text:
            return [""]
        max_len = max(1, self._max_message_length)
        return [text[i : i + max_len] for i in range(0, len(text), max_len)]

    def _dispatch(
        self,
        *,
        user_id: str,
        text: str,
        channel: str,
        metadata: Dict[str, Any],
    ) -> None:
        if self._send_callable is not None:
            try:
                self._send_callable(user_id, text, {**metadata, "channel": channel})
            except Exception:  # pragma: no cover - defensive logging only
                logger.exception("Error while calling WhatsApp send_callable")
        else:
            logger.info(
                "WhatsAppNotificationPlugin sending message", extra={
                    "user_id": user_id,
                    "channel": channel,
                    "text": text,
                    "metadata": metadata,
                },
            )
