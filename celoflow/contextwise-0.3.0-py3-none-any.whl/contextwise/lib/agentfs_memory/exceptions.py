"""Custom exceptions for AgentFS Memory Plugin.

This module defines all exception types used by the AgentFS memory system.
"""


class AgentFSError(Exception):
    """Base exception for all AgentFS errors."""

    def __init__(self, message: str, status_code: int = 0, details: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details or {}

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AgentFSConnectionError(AgentFSError):
    """Raised when connection to AgentFS server fails."""

    def __init__(self, message: str = "Failed to connect to AgentFS server", details: dict = None):
        super().__init__(message, status_code=0, details=details)


class AgentFSAuthenticationError(AgentFSError):
    """Raised when authentication fails (401 Unauthorized)."""

    def __init__(self, message: str = "Authentication failed", details: dict = None):
        super().__init__(message, status_code=401, details=details)


class AgentFSNotFoundError(AgentFSError):
    """Raised when a requested resource is not found (404 Not Found)."""

    def __init__(self, message: str = "Resource not found", details: dict = None):
        super().__init__(message, status_code=404, details=details)


class AgentFSValidationError(AgentFSError):
    """Raised when request validation fails (422 Unprocessable Entity)."""

    def __init__(self, message: str = "Validation error", details: dict = None):
        super().__init__(message, status_code=422, details=details)


class AgentFSServerError(AgentFSError):
    """Raised when the server returns an error (500 Internal Server Error)."""

    def __init__(self, message: str = "Server error", details: dict = None):
        super().__init__(message, status_code=500, details=details)


class AgentFSTimeoutError(AgentFSError):
    """Raised when a request times out."""

    def __init__(self, message: str = "Request timed out", details: dict = None):
        super().__init__(message, status_code=0, details=details)


class AgentFSRateLimitError(AgentFSError):
    """Raised when rate limit is exceeded (429 Too Many Requests)."""

    def __init__(self, message: str = "Rate limit exceeded", details: dict = None):
        super().__init__(message, status_code=429, details=details)
