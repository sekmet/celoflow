"""HTTP client for AgentFS Memory API.

This module provides the async HTTP client for communicating with the AgentFS server.
"""

import asyncio
import logging
import time
from typing import Any, Dict, List, Optional, Union

import httpx

from .config import AgentFSMemoryConfig
from .exceptions import (
    AgentFSAuthenticationError,
    AgentFSConnectionError,
    AgentFSError,
    AgentFSNotFoundError,
    AgentFSRateLimitError,
    AgentFSServerError,
    AgentFSTimeoutError,
    AgentFSValidationError,
)
from .utils import generate_cache_key, format_timestamp

logger = logging.getLogger(__name__)


class AgentFSClient:
    """Async HTTP client for AgentFS API.

    This client handles all communication with the AgentFS server including:
    - JWT Bearer authentication
    - Request retries with exponential backoff
    - Response caching for GET requests
    - Error handling and mapping to custom exceptions
    """

    def __init__(self, config: AgentFSMemoryConfig):
        """Initialize the AgentFS client.

        Args:
            config: Configuration object with API settings.
        """
        self.config = config
        self._cache: Dict[str, tuple] = {}  # {key: (value, timestamp)}
        self._client: Optional[httpx.AsyncClient] = None

    def _get_headers(self) -> Dict[str, str]:
        """Get request headers including authentication.

        Returns:
            Dictionary of HTTP headers.
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        return headers

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client.

        Returns:
            Async HTTP client instance.
        """
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=self.config.timeout,
                headers=self._get_headers(),
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    def _check_cache(self, cache_key: str) -> Optional[Any]:
        """Check if a cached response exists and is valid.

        Args:
            cache_key: Cache key to check.

        Returns:
            Cached value if valid, None otherwise.
        """
        if not self.config.enable_caching:
            return None

        if cache_key in self._cache:
            value, timestamp = self._cache[cache_key]
            if time.time() - timestamp < self.config.cache_ttl:
                return value
            else:
                del self._cache[cache_key]
        return None

    def _set_cache(self, cache_key: str, value: Any) -> None:
        """Store a value in the cache.

        Args:
            cache_key: Cache key.
            value: Value to cache.
        """
        if self.config.enable_caching:
            self._cache[cache_key] = (value, time.time())

    def _clear_cache(self, pattern: Optional[str] = None) -> None:
        """Clear cached responses.

        Args:
            pattern: Optional pattern to match keys to clear.
        """
        if pattern:
            keys_to_remove = [k for k in self._cache if pattern in k]
            for key in keys_to_remove:
                del self._cache[key]
        else:
            self._cache.clear()

    def _handle_error_response(self, response: httpx.Response) -> None:
        """Handle error responses from the API.

        Args:
            response: HTTP response object.

        Raises:
            Appropriate AgentFSError subclass.
        """
        status_code = response.status_code
        try:
            error_data = response.json()
            message = error_data.get("detail", error_data.get("message", response.text))
        except Exception:
            message = response.text or f"HTTP {status_code}"

        if status_code == 401:
            raise AgentFSAuthenticationError(message)
        elif status_code == 404:
            raise AgentFSNotFoundError(message)
        elif status_code == 422:
            raise AgentFSValidationError(message)
        elif status_code == 429:
            raise AgentFSRateLimitError(message)
        elif status_code >= 500:
            raise AgentFSServerError(message)
        else:
            raise AgentFSError(message, status_code=status_code)

    async def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        use_cache: bool = True,
    ) -> Dict[str, Any]:
        """Make an HTTP request with retry logic.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            endpoint: API endpoint path.
            data: Request body data for POST/PUT.
            params: Query parameters.
            use_cache: Whether to use caching (for GET requests).

        Returns:
            Response data as dictionary.

        Raises:
            AgentFSError subclass on failure.
        """
        url = self.config.get_api_url(endpoint)

        # Check cache for GET requests
        if method.upper() == "GET" and use_cache:
            cache_key = generate_cache_key(method, endpoint, params)
            cached = self._check_cache(cache_key)
            if cached is not None:
                logger.debug(f"Cache hit for {endpoint}")
                return cached

        client = await self._get_client()
        last_error: Optional[Exception] = None

        for attempt in range(self.config.max_retries):
            try:
                if method.upper() == "GET":
                    response = await client.get(url, params=params)
                elif method.upper() == "POST":
                    response = await client.post(url, json=data, params=params)
                elif method.upper() == "PUT":
                    response = await client.put(url, json=data, params=params)
                elif method.upper() == "PATCH":
                    response = await client.patch(url, json=data, params=params)
                elif method.upper() == "DELETE":
                    response = await client.delete(url, params=params)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")

                if response.status_code >= 400:
                    self._handle_error_response(response)

                result = response.json() if response.text else {}

                # Cache successful GET responses
                if method.upper() == "GET" and use_cache:
                    cache_key = generate_cache_key(method, endpoint, params)
                    self._set_cache(cache_key, result)

                return result

            except httpx.TimeoutException as e:
                last_error = AgentFSTimeoutError(f"Request timed out: {e}")
                logger.warning(f"Timeout on attempt {attempt + 1}/{self.config.max_retries}: {e}")

            except httpx.ConnectError as e:
                last_error = AgentFSConnectionError(f"Connection failed: {e}")
                logger.warning(f"Connection error on attempt {attempt + 1}/{self.config.max_retries}: {e}")

            except AgentFSError:
                raise  # Don't retry on API errors

            except Exception as e:
                last_error = AgentFSError(f"Unexpected error: {e}")
                logger.warning(f"Error on attempt {attempt + 1}/{self.config.max_retries}: {e}")

            # Exponential backoff
            if attempt < self.config.max_retries - 1:
                delay = self.config.retry_delay * (2 ** attempt)
                await asyncio.sleep(delay)

        raise last_error or AgentFSError("Request failed after all retries")

    # =========================================================================
    # Health & Status
    # =========================================================================

    async def health_check(self) -> Dict[str, Any]:
        """Check server health status.

        Returns:
            Health status information.
        """
        return await self._request("GET", "/health", use_cache=False)

    async def get_status(self) -> Dict[str, Any]:
        """Get server status information.

        Returns:
            Status information.
        """
        return await self._request("GET", "/agents/v1/status", use_cache=False)

    # =========================================================================
    # HMLR Chat (Full Pipeline)
    # =========================================================================

    async def chat(
        self,
        message: str,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a message through the full HMLR conversation pipeline.

        This uses the server-side HMLR engine for:
        - Bridge block topic routing
        - Vector-based memory retrieval with LLM filtering
        - Token-budgeted context assembly
        - Parallel fact extraction
        - Embedding generation

        Args:
            message: User's message.
            session_id: Optional session ID (defaults to 'default_session').

        Returns:
            Chat response with response text, turn_id, block_id, and metadata.
        """
        data = {"message": message}
        if session_id:
            data["session_id"] = session_id

        self._clear_cache("memory")
        return await self._request("POST", "/agents/v1/chat", data=data)

    # =========================================================================
    # Memory Operations
    # =========================================================================

    async def search_memory(
        self,
        query: str,
        session_id: Optional[str] = None,
        limit: int = 10,
        tags: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Search memory for relevant entries.

        Args:
            query: Search query string.
            session_id: Optional session ID to filter by.
            limit: Maximum number of results.
            tags: Optional tags to filter by.

        Returns:
            Search results with matching memories.
        """
        data = {
            "query": query,
            "limit": limit,
        }
        if session_id:
            data["session_id"] = session_id
        if tags:
            data["tags"] = tags

        return await self._request("POST", "/agents/v1/memory/search", data=data)

    async def store_memory(
        self,
        content: str,
        session_id: str,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Store a new memory entry.

        Args:
            content: Memory content to store.
            session_id: Session ID to associate with.
            tags: Optional tags for the memory.
            metadata: Optional metadata dictionary.

        Returns:
            Store result with memory ID.
        """
        data = {
            "content": content,
            "session_id": session_id,
        }
        if tags:
            data["tags"] = tags
        if metadata:
            data["metadata"] = metadata

        # Invalidate search cache after storing
        self._clear_cache("memory/search")

        return await self._request("POST", "/agents/v1/memory/store", data=data)

    async def get_memory_context(
        self,
        session_id: str,
        query: Optional[str] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Get memory context for a session.

        Args:
            session_id: Session ID to get context for.
            query: Optional query to focus context.
            max_tokens: Maximum tokens for context.

        Returns:
            Context information.
        """
        data = {"session_id": session_id}
        if query:
            data["query"] = query
        if max_tokens:
            data["max_tokens"] = max_tokens

        return await self._request("POST", "/agents/v1/memory/context", data=data)

    # =========================================================================
    # Turn Logging
    # =========================================================================

    async def log_turn(
        self,
        session_id: str,
        user_message: str,
        assistant_message: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Log a conversation turn.

        Args:
            session_id: Session ID for the conversation.
            user_message: User's message.
            assistant_message: Assistant's response.
            metadata: Optional metadata.

        Returns:
            Log result.
        """
        data = {
            "session_id": session_id,
            "user_message": user_message,
            "assistant_response": assistant_message,
        }
        if metadata:
            data["metadata"] = metadata

        return await self._request("POST", "/agents/v1/log/turn", data=data)

    # =========================================================================
    # Facts Operations
    # =========================================================================

    async def get_fact(self, key: str, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Get a fact by key.

        Args:
            key: Fact key.
            session_id: Optional session ID.

        Returns:
            Fact data.
        """
        params = {}
        if session_id:
            params["session_id"] = session_id

        return await self._request("GET", f"/agents/v1/facts/{key}", params=params)

    async def set_fact(
        self,
        key: str,
        value: str,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Set a fact value.

        Args:
            key: Fact key.
            value: Fact value.
            session_id: Optional session ID.

        Returns:
            Set result.
        """
        data = {"key": key, "value": value}
        if session_id:
            data["session_id"] = session_id

        self._clear_cache("facts")
        return await self._request("POST", "/agents/v1/facts", data=data)

    async def list_facts(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """List all facts.

        Args:
            session_id: Optional session ID to filter.

        Returns:
            List of facts.
        """
        # Use POST with data payload as the AgentFS API requires POST for listing facts
        data = {}
        if session_id:
            data["session_id"] = session_id

        return await self._request("POST", "/agents/v1/facts/list", data=data)

    # =========================================================================
    # Profile Operations
    # =========================================================================

    async def get_profile(self, session_id: str) -> Dict[str, Any]:
        """Get profile for a session.

        Args:
            session_id: Session ID.

        Returns:
            Profile data.
        """
        return await self._request("GET", "/agents/v1/profile", params={"session_id": session_id})

    async def update_profile(
        self,
        session_id: str,
        data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update profile data.

        Args:
            session_id: Session ID.
            data: Profile data to update.

        Returns:
            Update result.
        """
        payload = {"updates": data}
        self._clear_cache("profile")
        return await self._request("PATCH", "/agents/v1/profile", data=payload)

    # =========================================================================
    # Dossier Operations
    # =========================================================================

    async def search_dossiers(
        self,
        query: str,
        session_id: Optional[str] = None,
        limit: int = 10,
    ) -> Dict[str, Any]:
        """Search dossiers.

        Args:
            query: Search query.
            session_id: Optional session filter.
            limit: Maximum results.

        Returns:
            Search results.
        """
        data = {"query": query, "limit": limit}
        if session_id:
            data["session_id"] = session_id

        return await self._request("POST", "/agents/v1/dossiers/search", data=data)

    async def list_dossiers(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """List dossiers.

        Args:
            session_id: Optional session filter.

        Returns:
            List of dossiers.
        """
        params = {}
        if session_id:
            params["session_id"] = session_id

        return await self._request("GET", "/agents/v1/dossiers", params=params)

    # =========================================================================
    # Filesystem Operations
    # =========================================================================

    async def fs_list(self, path: str = "/") -> Dict[str, Any]:
        """List files in a directory.

        Args:
            path: Directory path.

        Returns:
            Directory listing.
        """
        return await self._request("GET", "/agents/v1/list", params={"path": path})

    async def fs_read(self, path: str) -> Dict[str, Any]:
        """Read a file.

        Args:
            path: File path.

        Returns:
            File content.
        """
        return await self._request("GET", "/agents/v1/read", params={"path": path})

    async def fs_write(self, path: str, content: str) -> Dict[str, Any]:
        """Write to a file.

        Args:
            path: File path.
            content: File content.

        Returns:
            Write result.
        """
        return await self._request("POST", "/agents/v1/write", data={"path": path, "content": content})

    async def fs_cat(self, path: str) -> Dict[str, Any]:
        """Cat a file (display contents).

        Args:
            path: File path.

        Returns:
            File content.
        """
        result = await self._request("POST", "/agents/v1/cat", data={"paths": [path]})
        # Transform response to match expected format
        return {
            "content": result.get("content", ""),
            "path": path,
            "size": len(result.get("content", ""))
        }

    async def fs_head(self, path: str, lines: int = 10) -> Dict[str, Any]:
        """Get first N lines of a file.

        Args:
            path: File path.
            lines: Number of lines.

        Returns:
            File head content.
        """
        result = await self._request("POST", "/agents/v1/head", data={"path": path, "lines": lines})
        # Transform response to match expected format
        return {
            "content": result.get("content", ""),
            "path": path,
            "lines_returned": result.get("lines_returned", lines)
        }

    async def fs_tail(self, path: str, lines: int = 10) -> Dict[str, Any]:
        """Get last N lines of a file.

        Args:
            path: File path.
            lines: Number of lines.

        Returns:
            File tail content.
        """
        result = await self._request("POST", "/agents/v1/tail", data={"path": path, "lines": lines})
        # Transform response to match expected format
        return {
            "content": result.get("content", ""),
            "path": path,
            "lines_returned": result.get("lines_returned", lines)
        }

    async def fs_grep(self, pattern: str, path: str = "/") -> Dict[str, Any]:
        """Search for pattern in files.

        Args:
            pattern: Search pattern.
            path: Path to search.

        Returns:
            Search results.
        """
        result = await self._request("POST", "/agents/v1/grep", data={"pattern": pattern, "paths": [path]})
        # Transform response to match expected format
        return {
            "matches": result.get("matches", []),
            "total_count": result.get("total_count", 0),
            "pattern": pattern,
            "path": path
        }

    async def fs_wc(self, path: str) -> Dict[str, Any]:
        """Get word count for a file.

        Args:
            path: File path.

        Returns:
            Word count information.
        """
        result = await self._request("POST", "/agents/v1/wc", data={"paths": [path]})
        # Transform response to match expected format
        if result.get("totals"):
            return {
                "lines": result["totals"].get("lines", 0),
                "words": result["totals"].get("words", 0),
                "characters": result["totals"].get("chars", 0),
                "path": path
            }
        else:
            return {
                "lines": 0,
                "words": 0,
                "characters": 0,
                "path": path
            }

    # =========================================================================
    # MCP Operations
    # =========================================================================

    async def mcp_list_servers(self) -> Dict[str, Any]:
        """List available MCP servers.

        Returns:
            List of MCP servers.
        """
        return await self._request("GET", "/agents/v1/mcp/servers")

    async def mcp_list_tools(self, server: str) -> Dict[str, Any]:
        """List tools for an MCP server.

        Args:
            server: Server name.

        Returns:
            List of tools.
        """
        return await self._request("GET", f"/agents/v1/mcp/tools/{server}")

    async def mcp_execute_tool(
        self,
        server: str,
        tool: str,
        arguments: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute an MCP tool.

        Args:
            server: Server name.
            tool: Tool name.
            arguments: Tool arguments.

        Returns:
            Tool execution result.
        """
        data = {"server": server, "tool": tool}
        if arguments:
            data["arguments"] = arguments

        return await self._request("POST", "/agents/v1/mcp/exec", data=data)

    async def mcp_search_tools(self, query: str) -> Dict[str, Any]:
        """Search MCP tools.

        Args:
            query: Search query.

        Returns:
            Matching tools.
        """
        return await self._request("GET", "/agents/v1/mcp/search", params={"query": query})

    # =========================================================================
    # Context Building
    # =========================================================================

    async def build_context(
        self,
        session_id: str,
        task_description: Optional[str] = None,
        budget_total: Optional[int] = None,
        budget_memory: Optional[int] = None,
        budget_tools: Optional[int] = None,
        budget_history: Optional[int] = None,
        include_memory: bool = True,
        include_tools: bool = True,
        include_history: bool = True,
    ) -> Dict[str, Any]:
        """Build context for a task.

        Args:
            session_id: Session ID.
            task_description: Task description.
            budget_total: Total token budget.
            budget_memory: Memory token budget.
            budget_tools: Tools token budget.
            budget_history: History token budget.
            include_memory: Include memory in context.
            include_tools: Include tools in context.
            include_history: Include history in context.

        Returns:
            Built context.
        """
        data = {"session_id": session_id}
        if task_description:
            data["task_description"] = task_description
        if budget_total:
            data["budget_total"] = budget_total
        if budget_memory:
            data["budget_memory"] = budget_memory
        if budget_tools:
            data["budget_tools"] = budget_tools
        if budget_history:
            data["budget_history"] = budget_history
        
        data["include_memory"] = include_memory
        data["include_tools"] = include_tools
        data["include_history"] = include_history

        return await self._request("POST", "/agents/v1/context/build", data=data)

    async def evaluate_context(
        self,
        context: str,
        query: str,
    ) -> Dict[str, Any]:
        """Evaluate context relevance.

        Args:
            context: Context to evaluate.
            query: Query to evaluate against.

        Returns:
            Evaluation result.
        """
        data = {"context": context, "query": query}
        return await self._request("POST", "/agents/v1/context/evaluate", data=data)

    # =========================================================================
    # History Operations
    # =========================================================================

    async def append_history(
        self,
        session_id: str,
        role: str,
        content: str,
    ) -> Dict[str, Any]:
        """Append to conversation history.

        Args:
            session_id: Session ID.
            role: Message role (user, assistant).
            content: Message content.

        Returns:
            Append result.
        """
        data = {"session_id": session_id, "role": role, "content": content}
        return await self._request("POST", "/agents/v1/history/append", data=data)

    async def query_history(
        self,
        session_id: str,
        limit: int = 20,
    ) -> Dict[str, Any]:
        """Query conversation history.

        Args:
            session_id: Session ID.
            limit: Maximum messages.

        Returns:
            History messages.
        """
        return await self._request("GET", "/agents/v1/history/query", params={"session_id": session_id, "limit": limit})

    # =========================================================================
    # KV Store Operations
    # =========================================================================

    async def kv_get(self, key: str) -> Dict[str, Any]:
        """Get value from KV store.

        Args:
            key: Key to get.

        Returns:
            Value data.
        """
        return await self._request("GET", "/agents/v1/kv/get", params={"key": key})

    async def kv_set(self, key: str, value: Any) -> Dict[str, Any]:
        """Set value in KV store.

        Args:
            key: Key to set.
            value: Value to store.

        Returns:
            Set result.
        """
        data = {"key": key, "value": value}
        return await self._request("POST", "/agents/v1/kv/set", data=data)

    async def kv_keys(self, pattern: str = "*") -> Dict[str, Any]:
        """List keys in KV store.

        Args:
            pattern: Key pattern to match.

        Returns:
            List of keys.
        """
        return await self._request("GET", "/agents/v1/kv/keys", params={"pattern": pattern})
