"""Request and response models for AgentFS Memory Plugin.

This module defines Pydantic-style dataclasses for API request/response handling.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from datetime import datetime


@dataclass
class MemoryEntry:
    """A single memory entry from AgentFS."""

    id: str
    content: str
    session_id: str
    timestamp: str
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    score: float = 0.0


@dataclass
class MemorySearchResult:
    """Result from a memory search operation."""

    entries: List[MemoryEntry] = field(default_factory=list)
    total: int = 0
    query: str = ""


@dataclass
class MemoryStoreResult:
    """Result from a memory store operation."""

    id: str
    success: bool = True
    message: str = ""


@dataclass
class Fact:
    """A key-value fact entry."""

    key: str
    value: str
    session_id: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class Profile:
    """User profile information."""

    session_id: str
    data: Dict[str, Any] = field(default_factory=dict)
    updated_at: Optional[str] = None


@dataclass
class Dossier:
    """A dossier entry containing structured information."""

    id: str
    title: str
    content: str
    session_id: str
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class FileEntry:
    """A file entry in the virtual filesystem."""

    path: str
    name: str
    is_directory: bool = False
    size: int = 0
    modified_at: Optional[str] = None


@dataclass
class FileContent:
    """Content of a file from the virtual filesystem."""

    path: str
    content: str
    encoding: str = "utf-8"


@dataclass
class MCPServer:
    """An MCP server configuration."""

    name: str
    url: str
    status: str = "unknown"
    tools: List[str] = field(default_factory=list)


@dataclass
class MCPTool:
    """An MCP tool definition."""

    name: str
    description: str
    server: str
    parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MCPToolResult:
    """Result from MCP tool execution."""

    tool: str
    server: str
    result: Any = None
    success: bool = True
    error: Optional[str] = None


@dataclass
class ContextBuildResult:
    """Result from context building operation."""

    context: str
    token_count: int = 0
    sources: List[str] = field(default_factory=list)


@dataclass
class ContextEvaluateResult:
    """Result from context evaluation."""

    score: float
    feedback: str = ""
    suggestions: List[str] = field(default_factory=list)


@dataclass
class TurnLogEntry:
    """A conversation turn log entry."""

    session_id: str
    user_message: str
    assistant_message: str
    timestamp: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HealthStatus:
    """Health check status response."""

    status: str
    version: str = ""
    uptime: float = 0.0
    details: Dict[str, Any] = field(default_factory=dict)
