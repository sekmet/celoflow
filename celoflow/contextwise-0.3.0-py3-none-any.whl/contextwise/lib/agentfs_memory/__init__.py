"""AgentFS Memory Plugin for ContextWise.

This package provides the integration between ContextWise agents
and the AgentFS (Agent File System) remote memory API.

AgentFS provides:
- Remote HTTP-based memory storage and retrieval
- Virtual filesystem operations
- MCP (Model Context Protocol) integration
- Context building and evaluation
- Facts and profile management
- Dossier management
"""

from .config import AgentFSMemoryConfig, AgentFSEnvironment
from .client import AgentFSClient
from .plugin import AgentFSMemoryPlugin
from .exceptions import (
    AgentFSError,
    AgentFSConnectionError,
    AgentFSAuthenticationError,
    AgentFSNotFoundError,
    AgentFSValidationError,
    AgentFSServerError,
)

__all__ = [
    "AgentFSMemoryConfig",
    "AgentFSEnvironment",
    "AgentFSClient",
    "AgentFSMemoryPlugin",
    "AgentFSError",
    "AgentFSConnectionError",
    "AgentFSAuthenticationError",
    "AgentFSNotFoundError",
    "AgentFSValidationError",
    "AgentFSServerError",
]
