"""AgentFS Memory Plugin.

This plugin integrates the AgentFS remote memory API with ContextWise agents.
It handles:
1. Lifecycle hooks: Buffering input and logging completed turns.
2. Tool injection: Exposing memory, facts, profile, dossier, filesystem, and MCP tools.
3. Configuration: Managing AgentFS settings and authentication.

It serves as the glue between the agent framework and the AgentFS API.
"""

import logging
from typing import Optional, List, Dict, Any

from agents import Agent, RunResult, RunConfig, function_tool, RunContextWrapper

from ..base import AgentPlugin
from ..context import AgentContext
from .config import AgentFSMemoryConfig
from .client import AgentFSClient

logger = logging.getLogger(__name__)


class AgentFSMemoryPlugin(AgentPlugin[AgentContext]):
    """Plugin for AgentFS remote memory integration.

    This plugin provides robust integration between ContextWise agents
    and the AgentFS remote memory API, featuring:
    - Consistent session ID handling across lifecycle hooks
    - Input buffering for turn logging
    - On-demand memory retrieval tools
    - Facts, profile, and dossier management
    - Virtual filesystem operations
    - MCP tool integration
    - Context building capabilities

    Attributes:
        config: Configuration for the AgentFS system.
        client: The HTTP client for AgentFS API communication.
    """

    id: str = "agentfs_memory"
    name: str = "AgentFS Memory Plugin"
    version: str = "0.3.0"

    def __init__(
        self,
        config: Optional[AgentFSMemoryConfig] = None,
        client: Optional[AgentFSClient] = None,
    ):
        """Initialize the AgentFS plugin.

        Args:
            config: Configuration object. If None, defaults are used.
            client: Optional client instance. If None, one is created from config.
        """
        self.config = config or AgentFSMemoryConfig()
        self.client = client or AgentFSClient(self.config)
        # Initialize input buffer with thread-safe dict
        self._input_buffers: Dict[str, str] = {}
        # Track active session IDs for debugging
        self._active_sessions: Dict[str, str] = {}
        logger.info(f"AgentFS Plugin initialized with API: {self.config.api_base_url}")

    def dependencies(self) -> List[str]:
        """Return plugin dependencies."""
        return []

    def _resolve_session_id(self, context: AgentContext) -> str:
        """Resolve a consistent session ID from context.

        This method ensures the same session ID is used across all lifecycle
        hooks (on_before_run, on_after_run) and tools, preventing input
        buffering mismatches.

        Resolution order:
        1. context.session_id (preferred, set by API/builder)
        2. context.user_id (fallback for single-user sessions)
        3. context.metadata["_agentfs_session_id"] (stored from first call)
        4. config.fallback_session_id (last resort)

        Args:
            context: The agent context (may be None if called outside plugin hooks).

        Returns:
            A consistent session ID string.
        """
        # Handle None context (when tool is called directly without context)
        if context is None:
            # Use the last known session or default
            if self._active_sessions:
                return next(iter(self._active_sessions.keys()))
            return self.config.fallback_session_id

        # Ensure metadata dict exists
        if not hasattr(context, 'metadata') or context.metadata is None:
            context.metadata = {}

        # Check if we already resolved and stored a session ID for this context
        if context.metadata.get("_agentfs_session_id"):
            return context.metadata["_agentfs_session_id"]

        # Resolve from available sources
        session_id = (
            getattr(context, 'session_id', None) or
            getattr(context, 'user_id', None) or
            self.config.fallback_session_id
        )

        # Store in metadata for consistent access across hooks
        context.metadata["_agentfs_session_id"] = session_id

        # Track for debugging
        context_info = f"session_id={getattr(context, 'session_id', None)}, user_id={getattr(context, 'user_id', None)}"
        self._active_sessions[session_id] = context_info

        return session_id

    async def get_memory_context(self, context: AgentContext, query: str) -> str:
        """Retrieve relevant context from AgentFS memory based on the user's query.

        Args:
            context: Agent context.
            query: The user's query or a specific search term to look up.

        Returns:
            Retrieved context string.
        """
        try:
            session_id = self._resolve_session_id(context)
            result = await self.client.get_memory_context(
                session_id=session_id,
                query=query,
                max_tokens=self.config.max_context_tokens,
            )
            context_text = result.get("context", "")
            logger.debug(f"AgentFS context retrieved for session {session_id}: {len(context_text)} chars")
            return context_text
        except Exception as e:
            logger.error(f"Error in get_memory_context: {e}", exc_info=True)
            return f"Error retrieving context: {str(e)}"

    async def get_agentfs_debug(self, context: AgentContext) -> str:
        """Retrieve debug state from AgentFS memory.

        Args:
            context: Agent context.

        Returns:
            Debug state string.
        """
        try:
            session_id = self._resolve_session_id(context)
            status = await self.client.get_status()
            state = {
                "session_id": session_id,
                "api_url": self.config.api_base_url,
                "server_status": status,
                "active_sessions": list(self._active_sessions.keys()),
                "buffered_inputs": list(self._input_buffers.keys()),
            }
            return f"AgentFS Debug State: {state}"
        except Exception as e:
            logger.error(f"Error in get_agentfs_debug: {e}", exc_info=True)
            return f"Error retrieving debug state: {str(e)}"

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Injects AgentFS tools into the agent."""
        new_tools = list(agent.tools)

        # Chat tools (HMLR full pipeline)
        if self.config.enable_chat_tools:
            new_tools.extend(self._create_chat_tools())

        # Memory tools
        if self.config.enable_memory_tools:
            new_tools.extend(self._create_memory_tools())

        # Facts tools
        if self.config.enable_facts_tools:
            new_tools.extend(self._create_facts_tools())

        # Profile tools
        if self.config.enable_profile_tools:
            new_tools.extend(self._create_profile_tools())

        # Dossier tools
        if self.config.enable_dossier_tools:
            new_tools.extend(self._create_dossier_tools())

        # Filesystem tools
        if self.config.enable_filesystem_tools:
            new_tools.extend(self._create_filesystem_tools())

        # MCP tools
        if self.config.enable_mcp_tools:
            new_tools.extend(self._create_mcp_tools())

        # Context tools
        if self.config.enable_context_tools:
            new_tools.extend(self._create_context_tools())

        # Auto-inject context into instructions
        instructions = agent.instructions
        if self.config.auto_inject_context:
            context_instruction = (
                "\n\n=== MEMORY CONTEXT ===\n"
                "You have access to previous conversation history through the search_memory tool. "
                "Before responding, search your memory for relevant information about:\n"
                "- Previous conversations with this user\n"
                "- Their preferences and past requests\n"
                "- Any ongoing appointments or bookings\n"
                "- Service details discussed previously\n"
                "Use this context to provide personalized and consistent responses."
            )
            # Handle both string and callable instructions
            if callable(instructions):
                # If instructions is a function, wrap it
                original_instructions = instructions
                def enhanced_instructions(*args, **kwargs):
                    return original_instructions(*args, **kwargs) + context_instruction
                instructions = enhanced_instructions
            else:
                # If instructions is a string, concatenate directly
                instructions = instructions + context_instruction
            logger.info("AgentFS: Auto-injecting context into agent instructions")

        return agent.clone(
            tools=new_tools,
            instructions=instructions,
        )

    def _create_chat_tools(self) -> List:
        """Create HMLR chat tools for full pipeline processing."""
        plugin = self

        @function_tool
        async def hmlr_chat(
            context: RunContextWrapper[AgentContext],
            message: str,
        ) -> str:
            """Send a message through the HMLR conversation pipeline.

            This tool processes messages through the full HMLR engine:
            - Bridge block topic routing
            - Vector-based memory retrieval with LLM filtering
            - Token-budgeted context assembly
            - Parallel fact extraction
            - Embedding generation

            Use this when you want the AI memory system to process and
            respond to a message with full context awareness.

            Args:
                message: The message to process through HMLR.

            Returns:
                HMLR response with context-aware answer.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                result = await plugin.client.chat(
                    message=message,
                    session_id=session_id,
                )
                response = result.get("response", "")
                turn_id = result.get("turn_id", "")
                block_id = result.get("block_id", "")
                contexts = result.get("contexts_retrieved", 0)
                facts = result.get("facts_extracted", 0)
                ms = result.get("processing_time_ms", 0)

                meta = f"[turn={turn_id}, block={block_id}, contexts={contexts}, facts={facts}, {ms}ms]"
                return f"{response}\n\n{meta}"
            except Exception as e:
                logger.error(f"Error in hmlr_chat: {e}", exc_info=True)
                return f"Error in HMLR chat: {str(e)}"

        return [hmlr_chat]

    def _create_memory_tools(self) -> List:
        """Create memory-related tools."""
        plugin = self

        @function_tool
        async def search_memory(
            context: RunContextWrapper[AgentContext],
            query: str,
            limit: int = 10,
        ) -> str:
            """Search long-term memory for relevant information.

            Use this tool when you need to recall past conversations, facts,
            or any information stored in memory.

            Args:
                query: Search query describing what to look for.
                limit: Maximum number of results to return (default 10).

            Returns:
                Formatted search results from memory.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                result = await plugin.client.search_memory(
                    query=query,
                    session_id=session_id,
                    limit=limit,
                )
                entries = result.get("entries", result.get("results", []))
                if not entries:
                    return "No memories found matching your query."

                formatted = []
                for i, entry in enumerate(entries, 1):
                    content = entry.get("content", "")
                    score = entry.get("score", 0.0)
                    formatted.append(f"{i}. [score: {score:.2f}] {content[:200]}...")

                return "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in search_memory: {e}", exc_info=True)
                return f"Error searching memory: {str(e)}"

        @function_tool
        async def store_memory(
            context: RunContextWrapper[AgentContext],
            content: str,
            tags: str = "",
        ) -> str:
            """Store important information in long-term memory.

            Use this tool to save facts, preferences, or important details
            that should be remembered for future conversations.

            Args:
                content: The information to store in memory.
                tags: Comma-separated tags for categorization (optional).

            Returns:
                Confirmation of storage.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else None
                result = await plugin.client.store_memory(
                    content=content,
                    session_id=session_id,
                    tags=tag_list,
                )
                memory_id = result.get("id", "unknown")
                return f"Memory stored successfully (ID: {memory_id})"
            except Exception as e:
                logger.error(f"Error in store_memory: {e}", exc_info=True)
                return f"Error storing memory: {str(e)}"

        @function_tool
        async def get_memory_context(
            context: RunContextWrapper[AgentContext],
            query: str,
        ) -> str:
            """Retrieve relevant context from long-term memory.

            Use this tool when the user refers to past conversations,
            tasks, or facts that are not in the current conversation history.

            Args:
                query: The query or topic to get context for.

            Returns:
                Relevant context from memory.
            """
            return await plugin.get_memory_context(context.context, query)

        return [search_memory, store_memory, get_memory_context]

    def _create_facts_tools(self) -> List:
        """Create facts-related tools."""
        plugin = self

        @function_tool
        async def get_fact(
            context: RunContextWrapper[AgentContext],
            key: str,
        ) -> str:
            """Get a stored fact by its key.

            Use this to retrieve specific pieces of information
            that have been saved as key-value facts.

            Args:
                key: The key identifying the fact.

            Returns:
                The fact value or error message.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                result = await plugin.client.get_fact(key, session_id)
                value = result.get("value", result.get("data", ""))
                if value:
                    return f"{key}: {value}"
                return f"Fact '{key}' not found."
            except Exception as e:
                logger.error(f"Error in get_fact: {e}", exc_info=True)
                return f"Error getting fact: {str(e)}"

        @function_tool
        async def set_fact(
            context: RunContextWrapper[AgentContext],
            key: str,
            value: str,
        ) -> str:
            """Store a fact as a key-value pair.

            Use this to save specific pieces of information that
            should be easily retrievable by key.

            Args:
                key: The key to identify this fact.
                value: The value to store.

            Returns:
                Confirmation of storage.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                await plugin.client.set_fact(key, value, session_id)
                return f"Fact stored: {key} = {value}"
            except Exception as e:
                logger.error(f"Error in set_fact: {e}", exc_info=True)
                return f"Error setting fact: {str(e)}"

        @function_tool
        async def list_facts(
            context: RunContextWrapper[AgentContext],
        ) -> str:
            """List all stored facts.

            Returns a list of all key-value facts stored in memory.

            Returns:
                List of facts or message if none found.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                result = await plugin.client.list_facts(session_id)
                facts = result.get("facts", result.get("data", []))
                if not facts:
                    return "No facts stored."
                formatted = [f"- {f.get('key', 'unknown')}: {f.get('value', '')}" for f in facts]
                return "Stored facts:\n" + "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in list_facts: {e}", exc_info=True)
                return f"Error listing facts: {str(e)}"

        return [get_fact, set_fact, list_facts]

    def _create_profile_tools(self) -> List:
        """Create profile-related tools."""
        plugin = self

        @function_tool
        async def get_profile(
            context: RunContextWrapper[AgentContext],
        ) -> str:
            """Get the user's profile information.

            Retrieves stored profile data for the current user/session.

            Returns:
                Profile information or message if not found.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                result = await plugin.client.get_profile(session_id)
                data = result.get("data", result)
                if not data:
                    return "No profile data found."
                import json
                return f"Profile:\n{json.dumps(data, indent=2)}"
            except Exception as e:
                logger.error(f"Error in get_profile: {e}", exc_info=True)
                return f"Error getting profile: {str(e)}"

        @function_tool
        async def update_profile(
            context: RunContextWrapper[AgentContext],
            field: str,
            value: str,
        ) -> str:
            """Update a field in the user's profile.

            Stores or updates a piece of profile information.

            Args:
                field: The profile field to update.
                value: The new value for the field.

            Returns:
                Confirmation of update.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                update_data = [{
                    "category": "custom",
                    "key": field,
                    "action": "set",
                    "attributes": {"value": value}
                }]
                await plugin.client.update_profile(session_id, update_data)
                return f"Profile updated: {field} = {value}"
            except Exception as e:
                logger.error(f"Error in update_profile: {e}", exc_info=True)
                return f"Error updating profile: {str(e)}"

        return [get_profile, update_profile]

    def _create_dossier_tools(self) -> List:
        """Create dossier-related tools."""
        plugin = self

        @function_tool
        async def search_dossiers(
            context: RunContextWrapper[AgentContext],
            query: str,
            limit: int = 10,
        ) -> str:
            """Search dossiers for relevant information.

            Dossiers are structured documents containing detailed information.

            Args:
                query: Search query.
                limit: Maximum results to return.

            Returns:
                Matching dossiers or message if none found.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                result = await plugin.client.search_dossiers(query, session_id, limit)
                dossiers = result.get("dossiers", result.get("results", []))
                if not dossiers:
                    return "No dossiers found matching your query."

                formatted = []
                for d in dossiers:
                    title = d.get("title", "Untitled")
                    content = d.get("content", "")[:100]
                    formatted.append(f"- {title}: {content}...")

                return "Dossiers found:\n" + "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in search_dossiers: {e}", exc_info=True)
                return f"Error searching dossiers: {str(e)}"

        @function_tool
        async def list_dossiers(
            context: RunContextWrapper[AgentContext],
        ) -> str:
            """List all available dossiers.

            Returns:
                List of dossiers or message if none found.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                result = await plugin.client.list_dossiers(session_id)
                dossiers = result.get("dossiers", result.get("data", []))
                if not dossiers:
                    return "No dossiers available."

                formatted = [f"- {d.get('title', 'Untitled')} (ID: {d.get('id', 'unknown')})" for d in dossiers]
                return "Available dossiers:\n" + "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in list_dossiers: {e}", exc_info=True)
                return f"Error listing dossiers: {str(e)}"

        return [search_dossiers, list_dossiers]

    def _create_filesystem_tools(self) -> List:
        """Create filesystem-related tools."""
        plugin = self

        @function_tool
        async def fs_list(
            context: RunContextWrapper[AgentContext],
            path: str = "/",
        ) -> str:
            """List files in a virtual filesystem directory.

            Args:
                path: Directory path to list (default: root).

            Returns:
                Directory listing.
            """
            try:
                result = await plugin.client.fs_list(path)
                entries = result.get("entries", result.get("files", []))
                if not entries:
                    return f"Directory '{path}' is empty."

                formatted = []
                for entry in entries:
                    name = entry.get("name", "")
                    is_dir = entry.get("is_directory", False)
                    size = entry.get("size", 0)
                    prefix = "📁" if is_dir else "📄"
                    formatted.append(f"{prefix} {name}" + (f" ({size} bytes)" if not is_dir else ""))

                return f"Contents of {path}:\n" + "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in fs_list: {e}", exc_info=True)
                return f"Error listing directory: {str(e)}"

        @function_tool
        async def fs_read(
            context: RunContextWrapper[AgentContext],
            path: str,
        ) -> str:
            """Read contents of a file from the virtual filesystem.

            Args:
                path: Path to the file to read.

            Returns:
                File contents.
            """
            try:
                result = await plugin.client.fs_read(path)
                content = result.get("content", "")
                return f"Contents of {path}:\n{content}"
            except Exception as e:
                logger.error(f"Error in fs_read: {e}", exc_info=True)
                return f"Error reading file: {str(e)}"

        @function_tool
        async def fs_write(
            context: RunContextWrapper[AgentContext],
            path: str,
            content: str,
        ) -> str:
            """Write content to a file in the virtual filesystem.

            Args:
                path: Path to the file to write.
                content: Content to write.

            Returns:
                Confirmation of write.
            """
            try:
                await plugin.client.fs_write(path, content)
                return f"Successfully wrote to {path}"
            except Exception as e:
                logger.error(f"Error in fs_write: {e}", exc_info=True)
                return f"Error writing file: {str(e)}"

        @function_tool
        async def fs_grep(
            context: RunContextWrapper[AgentContext],
            pattern: str,
            path: str = "/",
        ) -> str:
            """Search for a pattern in files.

            Args:
                pattern: Search pattern (regex supported).
                path: Path to search in.

            Returns:
                Matching lines.
            """
            try:
                result = await plugin.client.fs_grep(pattern, path)
                matches = result.get("matches", result.get("results", []))
                if not matches:
                    return f"No matches found for '{pattern}'."

                formatted = [f"{m.get('file', '')}:{m.get('line', '')}: {m.get('content', '')}" for m in matches]
                return f"Matches for '{pattern}':\n" + "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in fs_grep: {e}", exc_info=True)
                return f"Error searching: {str(e)}"

        @function_tool
        async def fs_cat(
            context: RunContextWrapper[AgentContext],
            path: str,
        ) -> str:
            """Concatenate and display file contents.

            Args:
                path: Path to the file to display.

            Returns:
                File contents.
            """
            try:
                result = await plugin.client.fs_cat(path)
                content = result.get("content", "")
                return f"Contents of {path}:\n{content}"
            except Exception as e:
                logger.error(f"Error in fs_cat: {e}", exc_info=True)
                return f"Error displaying file: {str(e)}"

        @function_tool
        async def fs_head(
            context: RunContextWrapper[AgentContext],
            path: str,
            lines: int = 10,
        ) -> str:
            """Display first N lines of a file.

            Args:
                path: Path to the file.
                lines: Number of lines to display (default: 10).

            Returns:
                First N lines of the file.
            """
            try:
                result = await plugin.client.fs_head(path, lines)
                content = result.get("content", "")
                lines_returned = result.get("lines_returned", lines)
                return f"First {lines_returned} lines of {path}:\n{content}"
            except Exception as e:
                logger.error(f"Error in fs_head: {e}", exc_info=True)
                return f"Error reading file head: {str(e)}"

        @function_tool
        async def fs_tail(
            context: RunContextWrapper[AgentContext],
            path: str,
            lines: int = 10,
        ) -> str:
            """Display last N lines of a file.

            Args:
                path: Path to the file.
                lines: Number of lines to display (default: 10).

            Returns:
                Last N lines of the file.
            """
            try:
                result = await plugin.client.fs_tail(path, lines)
                content = result.get("content", "")
                lines_returned = result.get("lines_returned", lines)
                return f"Last {lines_returned} lines of {path}:\n{content}"
            except Exception as e:
                logger.error(f"Error in fs_tail: {e}", exc_info=True)
                return f"Error reading file tail: {str(e)}"

        @function_tool
        async def fs_wc(
            context: RunContextWrapper[AgentContext],
            path: str,
        ) -> str:
            """Count lines, words, and characters in a file.

            Args:
                path: Path to the file.

            Returns:
                Word count statistics.
            """
            try:
                result = await plugin.client.fs_wc(path)
                lines = result.get("lines", 0)
                words = result.get("words", 0)
                chars = result.get("characters", 0)
                return f"File statistics for {path}:\n  Lines: {lines}\n  Words: {words}\n  Characters: {chars}"
            except Exception as e:
                logger.error(f"Error in fs_wc: {e}", exc_info=True)
                return f"Error counting file: {str(e)}"

        return [fs_list, fs_read, fs_write, fs_grep, fs_cat, fs_head, fs_tail, fs_wc]

    def _create_mcp_tools(self) -> List:
        """Create MCP-related tools."""
        plugin = self

        @function_tool
        async def mcp_list_servers(
            context: RunContextWrapper[AgentContext],
        ) -> str:
            """List available MCP servers.

            Returns:
                List of MCP servers and their status.
            """
            try:
                result = await plugin.client.mcp_list_servers()
                servers = result.get("servers", result.get("data", []))
                if not servers:
                    return "No MCP servers available."

                formatted = [f"- {s.get('name', 'unknown')}: {s.get('status', 'unknown')}" for s in servers]
                return "MCP Servers:\n" + "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in mcp_list_servers: {e}", exc_info=True)
                return f"Error listing MCP servers: {str(e)}"

        @function_tool
        async def mcp_list_tools(
            context: RunContextWrapper[AgentContext],
            server: str,
        ) -> str:
            """List tools available on an MCP server.

            Args:
                server: Name of the MCP server.

            Returns:
                List of tools.
            """
            try:
                result = await plugin.client.mcp_list_tools(server)
                tools = result.get("tools", result.get("data", []))
                if not tools:
                    return f"No tools available on server '{server}'."

                formatted = [f"- {t.get('name', '')}: {t.get('description', '')}" for t in tools]
                return f"Tools on {server}:\n" + "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in mcp_list_tools: {e}", exc_info=True)
                return f"Error listing MCP tools: {str(e)}"

        @function_tool
        async def mcp_execute_tool(
            context: RunContextWrapper[AgentContext],
            server: str,
            tool: str,
            arguments: str = "{}",
        ) -> str:
            """Execute a tool on an MCP server.

            Args:
                server: Name of the MCP server.
                tool: Name of the tool to execute.
                arguments: JSON string of tool arguments.

            Returns:
                Tool execution result.
            """
            try:
                import json
                args = json.loads(arguments) if arguments else {}
                result = await plugin.client.mcp_execute_tool(server, tool, args)
                return f"Tool result:\n{json.dumps(result, indent=2)}"
            except Exception as e:
                logger.error(f"Error in mcp_execute_tool: {e}", exc_info=True)
                return f"Error executing MCP tool: {str(e)}"

        @function_tool
        async def mcp_search_tools(
            context: RunContextWrapper[AgentContext],
            query: str,
        ) -> str:
            """Search for MCP tools across all servers.

            Args:
                query: Search query for tool names or descriptions.

            Returns:
                Matching tools.
            """
            try:
                result = await plugin.client.mcp_search_tools(query)
                tools = result.get("tools", result.get("results", []))
                if not tools:
                    return f"No tools found matching '{query}'."

                formatted = [f"- {t.get('server', '')}::{t.get('name', '')}: {t.get('description', '')}" for t in tools]
                return f"Tools matching '{query}':\n" + "\n".join(formatted)
            except Exception as e:
                logger.error(f"Error in mcp_search_tools: {e}", exc_info=True)
                return f"Error searching MCP tools: {str(e)}"

        return [mcp_list_servers, mcp_list_tools, mcp_execute_tool, mcp_search_tools]

    def _create_context_tools(self) -> List:
        """Create context building tools."""
        plugin = self

        @function_tool
        async def build_context(
            context: RunContextWrapper[AgentContext],
            task_description: str = "",
            budget_total: int = 4000,
        ) -> str:
            """Build context from memory for a task.

            Aggregates relevant information from memory, facts,
            and other sources to build context for answering.

            Args:
                task_description: Task description for context building.
                budget_total: Total token budget for context.

            Returns:
                Built context.
            """
            try:
                session_id = plugin._resolve_session_id(context.context)
                result = await plugin.client.build_context(
                    session_id=session_id,
                    task_description=task_description,
                    budget_total=budget_total,
                )
                ctx = result.get("context", "")
                token_count = result.get("token_count", 0)
                return f"Built context ({token_count} tokens):\n{ctx}"
            except Exception as e:
                logger.error(f"Error in build_context: {e}", exc_info=True)
                return f"Error building context: {str(e)}"

        @function_tool
        async def evaluate_context(
            context: RunContextWrapper[AgentContext],
            ctx: str,
            query: str,
        ) -> str:
            """Evaluate how relevant context is for a query.

            Args:
                ctx: Context to evaluate.
                query: Query to evaluate against.

            Returns:
                Evaluation results.
            """
            try:
                result = await plugin.client.evaluate_context(ctx, query)
                score = result.get("score", 0.0)
                feedback = result.get("feedback", "")
                return f"Context relevance score: {score:.2f}\nFeedback: {feedback}"
            except Exception as e:
                logger.error(f"Error in evaluate_context: {e}", exc_info=True)
                return f"Error evaluating context: {str(e)}"

        return [build_context, evaluate_context]

    def configure_run_config(
        self,
        context: AgentContext,
        base_config: Optional[RunConfig],
    ) -> Optional[RunConfig]:
        """Optionally extend the run configuration for this request.

        Note: auto_inject_context is handled in configure_agent() by modifying
        the agent instructions directly, since RunConfig doesn't support
        custom instructions.
        """
        return base_config

    def on_before_run(self, context: AgentContext, input_text: str) -> None:
        """Buffer user input for later logging.

        This method is called by the PluginManager before the agent runs.
        It stores the user input in both the context metadata and an instance
        buffer for robust retrieval in on_after_run.

        Args:
            context: Agent context.
            input_text: User's input message.
        """
        session_id = self._resolve_session_id(context)

        # Store input in both locations for robustness
        context.metadata["_agentfs_buffered_input"] = input_text
        self._input_buffers[session_id] = input_text

        input_preview = input_text[:50] + "..." if len(input_text) > 50 else input_text
        logger.info(f"AgentFS: on_before_run buffering input for session {session_id}: '{input_preview}'")

    def on_after_run(self, context: AgentContext, result: RunResult) -> None:
        """Log the completed conversation turn to AgentFS.

        This method is called by the PluginManager after the agent runs.
        It retrieves the buffered input and logs the complete turn to the
        AgentFS memory system.

        Args:
            context: Agent context.
            result: The result of the run.
        """
        try:
            session_id = self._resolve_session_id(context)
            logger.info(f"AgentFS: on_after_run triggered for session {session_id}")

            # Try multiple sources for buffered input (most reliable first)
            user_input = (
                self._input_buffers.get(session_id) or
                context.metadata.get("_agentfs_buffered_input")
            )

            if not user_input:
                buffer_keys = list(self._input_buffers.keys())
                logger.warning(
                    f"AgentFS: No buffered input found for logging "
                    f"(session={session_id}, buffer_keys={buffer_keys})"
                )
                return

            assistant_response = result.final_output
            if not assistant_response:
                logger.debug("AgentFS: No final output (tool use?), skipping log.")
                return

            logger.info(f"AgentFS: Logging turn to API for session {session_id}")

            # Log to AgentFS asynchronously
            import asyncio
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    # Schedule as a task if we're in an async context
                    asyncio.create_task(
                        self.client.log_turn(
                            session_id=session_id,
                            user_message=user_input,
                            assistant_message=assistant_response,
                        )
                    )
                else:
                    # Run synchronously if no event loop
                    loop.run_until_complete(
                        self.client.log_turn(
                            session_id=session_id,
                            user_message=user_input,
                            assistant_message=assistant_response,
                        )
                    )
            except RuntimeError:
                # No event loop, create one
                asyncio.run(
                    self.client.log_turn(
                        session_id=session_id,
                        user_message=user_input,
                        assistant_message=assistant_response,
                    )
                )

            # Clean up buffers
            context.metadata.pop("_agentfs_buffered_input", None)
            self._input_buffers.pop(session_id, None)

            logger.debug(f"AgentFS: Turn logged successfully for session {session_id}")

        except Exception as e:
            logger.error(f"AgentFS: Failed to log turn in on_after_run: {e}", exc_info=True)
