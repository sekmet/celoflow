"""Utility functions for AgentFS Memory Plugin.

This module provides helper functions for the AgentFS memory system.
"""

import hashlib
import json
import logging
from datetime import datetime
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


def generate_cache_key(method: str, endpoint: str, params: Optional[Dict] = None) -> str:
    """Generate a cache key for an API request.

    Args:
        method: HTTP method (GET, POST, etc.).
        endpoint: API endpoint path.
        params: Optional request parameters.

    Returns:
        A unique cache key string.
    """
    key_parts = [method.upper(), endpoint]
    if params:
        # Sort keys for consistent hashing
        sorted_params = json.dumps(params, sort_keys=True)
        key_parts.append(sorted_params)

    key_string = ":".join(key_parts)
    return hashlib.md5(key_string.encode()).hexdigest()


def format_timestamp(dt: Optional[datetime] = None) -> str:
    """Format a datetime as ISO 8601 string.

    Args:
        dt: Datetime to format. Defaults to current UTC time.

    Returns:
        ISO 8601 formatted string.
    """
    if dt is None:
        dt = datetime.utcnow()
    return dt.isoformat() + "Z"


def parse_timestamp(timestamp_str: str) -> Optional[datetime]:
    """Parse an ISO 8601 timestamp string.

    Args:
        timestamp_str: Timestamp string to parse.

    Returns:
        Parsed datetime or None if parsing fails.
    """
    try:
        # Handle both with and without Z suffix
        if timestamp_str.endswith("Z"):
            timestamp_str = timestamp_str[:-1]
        return datetime.fromisoformat(timestamp_str)
    except (ValueError, AttributeError):
        return None


def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """Truncate text to a maximum length.

    Args:
        text: Text to truncate.
        max_length: Maximum length including suffix.
        suffix: Suffix to add if truncated.

    Returns:
        Truncated text.
    """
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix


def format_memory_entry(entry: Dict[str, Any]) -> str:
    """Format a memory entry for display.

    Args:
        entry: Memory entry dictionary.

    Returns:
        Formatted string representation.
    """
    content = entry.get("content", "")
    timestamp = entry.get("timestamp", "")
    tags = entry.get("tags", [])
    score = entry.get("score", 0.0)

    parts = []
    if timestamp:
        parts.append(f"[{timestamp}]")
    if score > 0:
        parts.append(f"(score: {score:.2f})")
    if tags:
        parts.append(f"tags: {', '.join(tags)}")

    header = " ".join(parts)
    if header:
        return f"{header}\n{content}"
    return content


def format_memory_results(results: List[Dict[str, Any]], include_scores: bool = True) -> str:
    """Format multiple memory results for display.

    Args:
        results: List of memory entry dictionaries.
        include_scores: Whether to include relevance scores.

    Returns:
        Formatted string with all results.
    """
    if not results:
        return "No memories found."

    formatted = []
    for i, entry in enumerate(results, 1):
        content = entry.get("content", "")
        score = entry.get("score", 0.0)

        if include_scores and score > 0:
            formatted.append(f"{i}. [score: {score:.2f}] {truncate_text(content, 200)}")
        else:
            formatted.append(f"{i}. {truncate_text(content, 200)}")

    return "\n".join(formatted)


def parse_tags(tags_str: str) -> List[str]:
    """Parse a comma-separated tags string.

    Args:
        tags_str: Comma-separated tags string.

    Returns:
        List of cleaned tag strings.
    """
    if not tags_str:
        return []
    return [tag.strip() for tag in tags_str.split(",") if tag.strip()]


def build_query_params(**kwargs) -> Dict[str, Any]:
    """Build query parameters, excluding None values.

    Args:
        **kwargs: Keyword arguments to include.

    Returns:
        Dictionary with non-None values.
    """
    return {k: v for k, v in kwargs.items() if v is not None}


def safe_json_loads(json_str: str, default: Any = None) -> Any:
    """Safely parse JSON string.

    Args:
        json_str: JSON string to parse.
        default: Default value if parsing fails.

    Returns:
        Parsed JSON or default value.
    """
    try:
        return json.loads(json_str)
    except (json.JSONDecodeError, TypeError):
        return default


def estimate_token_count(text: str, chars_per_token: float = 4.0) -> int:
    """Estimate token count for text.

    Args:
        text: Text to estimate.
        chars_per_token: Average characters per token.

    Returns:
        Estimated token count.
    """
    return int(len(text) / chars_per_token)


def sanitize_session_id(session_id: str) -> str:
    """Sanitize a session ID for safe use.

    Args:
        session_id: Raw session ID.

    Returns:
        Sanitized session ID.
    """
    # Remove potentially dangerous characters
    safe_chars = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_")
    return "".join(c if c in safe_chars else "_" for c in session_id)


@lru_cache(maxsize=100)
def extract_keywords(text: str, max_keywords: int = 10) -> Tuple[str, ...]:
    """Extract keywords from text (cached).

    Args:
        text: Text to extract keywords from.
        max_keywords: Maximum number of keywords.

    Returns:
        Tuple of keywords (for hashability).
    """
    # Simple keyword extraction - split and filter
    words = text.lower().split()
    # Filter short words and common stop words
    stop_words = {"the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
                  "have", "has", "had", "do", "does", "did", "will", "would", "could",
                  "should", "may", "might", "must", "shall", "can", "to", "of", "in",
                  "for", "on", "with", "at", "by", "from", "as", "into", "through",
                  "during", "before", "after", "above", "below", "between", "under",
                  "again", "further", "then", "once", "here", "there", "when", "where",
                  "why", "how", "all", "each", "few", "more", "most", "other", "some",
                  "such", "no", "nor", "not", "only", "own", "same", "so", "than",
                  "too", "very", "just", "and", "but", "if", "or", "because", "until",
                  "while", "it", "its", "this", "that", "these", "those", "i", "you",
                  "he", "she", "we", "they", "what", "which", "who", "whom"}

    keywords = [w for w in words if len(w) > 2 and w not in stop_words]
    # Remove duplicates while preserving order
    seen = set()
    unique = []
    for kw in keywords:
        if kw not in seen:
            seen.add(kw)
            unique.append(kw)
            if len(unique) >= max_keywords:
                break

    return tuple(unique)
