"""Configuration models for AgentFS Memory Plugin.

This module defines the configuration dataclass for the AgentFS plugin.
"""

import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class AgentFSEnvironment(Enum):
    """Environment configuration for AgentFS."""

    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


@dataclass
class AgentFSMemoryConfig:
    """Configuration for AgentFS Memory Plugin.

    Attributes:
        api_base_url: Base URL for the AgentFS API server.
                     Defaults to AGENTFS_API_URL env var or http://localhost:8300.
        api_key: JWT authentication token for the AgentFS API.
                Defaults to AGENTFS_API_KEY env var.
        environment: Environment configuration (development, staging, production).
        timeout: Request timeout in seconds.
        max_retries: Maximum number of retry attempts for failed requests.
        retry_delay: Initial delay between retries in seconds (exponential backoff).
        enable_memory_tools: Whether to expose memory tools (search_memory, store_memory).
        enable_facts_tools: Whether to expose facts tools (get_fact, set_fact).
        enable_profile_tools: Whether to expose profile tools (get_profile, update_profile).
        enable_dossier_tools: Whether to expose dossier tools (search_dossiers, list_dossiers).
        enable_filesystem_tools: Whether to expose filesystem tools (fs_read, fs_write, etc.).
        enable_mcp_tools: Whether to expose MCP tools (mcp_list_servers, mcp_execute_tool, etc.).
        enable_context_tools: Whether to expose context building tools.
        auto_inject_context: Whether to automatically inject memory context into agent instructions.
        max_context_tokens: Maximum tokens to include in context retrieval.
        session_id_source: Source for session ID resolution (context, user_id, metadata).
        fallback_session_id: Fallback session ID when none is available.
        cache_ttl: Time-to-live for cached responses in seconds.
        enable_caching: Whether to enable client-side caching.
    """

    api_base_url: Optional[str] = None
    api_key: Optional[str] = None
    environment: AgentFSEnvironment = AgentFSEnvironment.DEVELOPMENT
    timeout: float = 30.0
    max_retries: int = 3
    retry_delay: float = 1.0

    # Tool enablement flags
    enable_chat_tools: bool = True
    enable_memory_tools: bool = True
    enable_facts_tools: bool = True
    enable_profile_tools: bool = True
    enable_dossier_tools: bool = True
    enable_filesystem_tools: bool = False
    enable_mcp_tools: bool = False
    enable_context_tools: bool = False

    # Context injection
    auto_inject_context: bool = False
    max_context_tokens: int = 6000

    # Session management
    session_id_source: str = "context"
    fallback_session_id: str = "default"

    # Caching
    cache_ttl: int = 300
    enable_caching: bool = True

    def __post_init__(self):
        """Resolve configuration from environment variables."""
        if self.api_base_url is None:
            self.api_base_url = os.getenv("AGENTFS_API_URL", "http://localhost:8300")

        if self.api_key is None:
            self.api_key = os.getenv("AGENTFS_API_KEY", "")

        # Normalize base URL (remove trailing slash)
        if self.api_base_url and self.api_base_url.endswith("/"):
            self.api_base_url = self.api_base_url.rstrip("/")

    def get_api_url(self, endpoint: str) -> str:
        """Get full API URL for an endpoint.

        Args:
            endpoint: API endpoint path (e.g., '/agents/v1/memory/search').

        Returns:
            Full URL for the endpoint.
        """
        if not endpoint.startswith("/"):
            endpoint = f"/{endpoint}"
        return f"{self.api_base_url}{endpoint}"

    @property
    def has_api_key(self) -> bool:
        """Check if API key is configured."""
        return bool(self.api_key)

    @property
    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.environment == AgentFSEnvironment.PRODUCTION
