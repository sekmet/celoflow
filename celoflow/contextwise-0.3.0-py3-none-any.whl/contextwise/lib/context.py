from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class AgentContext:
    """Shared runtime context for the contextwise agent and plugins.

    Extended in v0.3.0 to support multiple modalities and channel-specific data.
    Extended with session metadata tracking for session continuity controls.
    """

    # Identity
    user_id: str
    session_id: Optional[str] = None

    # Channel info
    channel: str = "api"  # api, whatsapp, voice, cli
    modality: str = "text"  # text, voice, multimodal
    locale: str = "en"

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Channel-specific fields (v0.3.0)
    phone_number: Optional[str] = None  # WhatsApp phone number
    message_id: Optional[str] = None    # Original message ID
    room_name: Optional[str] = None     # LiveKit room for voice

    # Session metadata (session continuity controls)
    session_created_at: Optional[str] = None  # ISO format timestamp
    session_message_count: int = 0

    def is_voice(self) -> bool:
        """Check if this is a voice interaction."""
        return self.modality == "voice" or self.channel == "voice"
