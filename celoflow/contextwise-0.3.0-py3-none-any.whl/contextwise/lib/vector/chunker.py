"""Document chunking utilities for vector databases.

This module provides simple, efficient chunking strategies for preparing
documents for vector database ingestion. Designed for RAG use cases.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional
from enum import Enum

from .base import Document


class ChunkStrategy(str, Enum):
    """Chunking strategies."""
    FIXED_SIZE = "fixed_size"        # Fixed character/token count
    SENTENCE = "sentence"             # Sentence boundaries
    PARAGRAPH = "paragraph"           # Paragraph boundaries
    SLIDING_WINDOW = "sliding_window" # Overlapping windows


@dataclass
class ChunkConfig:
    """Configuration for document chunking.

    Attributes:
        strategy: Chunking strategy to use
        chunk_size: Target chunk size (characters or tokens)
        chunk_overlap: Overlap between chunks (for sliding window)
        min_chunk_size: Minimum chunk size to keep
        preserve_metadata: Copy metadata to all chunks
        add_chunk_index: Add chunk index to metadata
    """
    strategy: ChunkStrategy = ChunkStrategy.PARAGRAPH
    chunk_size: int = 1000            # characters
    chunk_overlap: int = 200          # characters
    min_chunk_size: int = 100         # characters
    preserve_metadata: bool = True
    add_chunk_index: bool = True


class DocumentChunker:
    """Chunks documents for vector database ingestion.

    Example:
        >>> chunker = DocumentChunker(ChunkConfig(
        ...     strategy=ChunkStrategy.PARAGRAPH,
        ...     chunk_size=1000
        ... ))
        >>>
        >>> doc = Document(
        ...     id="doc1",
        ...     name="Long Article",
        ...     content="Very long article text...",
        ...     metadata={"author": "Alice"}
        ... )
        >>>
        >>> chunks = chunker.chunk_document(doc)
        >>> len(chunks)  # Multiple chunks created
        5
        >>> chunks[0].metadata["chunk_index"]
        0
    """

    def __init__(self, config: Optional[ChunkConfig] = None):
        """Initialize chunker with configuration.

        Args:
            config: Chunking configuration (uses defaults if None)
        """
        self.config = config or ChunkConfig()
        if self.config.min_chunk_size > self.config.chunk_size:
            self.config.min_chunk_size = self.config.chunk_size

    def chunk_document(self, document: Document) -> List[Document]:
        """Chunk a document into smaller documents.

        Args:
            document: Document to chunk

        Returns:
            List of document chunks
        """
        if not document.content:
            return [document]

        # Choose chunking strategy
        if self.config.strategy == ChunkStrategy.FIXED_SIZE:
            text_chunks = self._chunk_fixed_size(document.content)
        elif self.config.strategy == ChunkStrategy.SENTENCE:
            text_chunks = self._chunk_sentences(document.content)
        elif self.config.strategy == ChunkStrategy.PARAGRAPH:
            text_chunks = self._chunk_paragraphs(document.content)
        elif self.config.strategy == ChunkStrategy.SLIDING_WINDOW:
            text_chunks = self._chunk_sliding_window(document.content)
        else:
            text_chunks = [document.content]

        # Filter out too-small chunks
        text_chunks = [
            chunk for chunk in text_chunks
            if len(chunk.strip()) >= self.config.min_chunk_size
        ]

        # If only one chunk, return original document
        if len(text_chunks) <= 1:
            return [document]

        # Create chunk documents
        chunks = []
        for i, text in enumerate(text_chunks):
            chunk_id = f"{document.id}_chunk_{i}"

            # Build metadata
            chunk_metadata = {}
            if self.config.preserve_metadata:
                chunk_metadata.update(document.metadata)

            if self.config.add_chunk_index:
                chunk_metadata["chunk_index"] = i
                chunk_metadata["total_chunks"] = len(text_chunks)
                chunk_metadata["parent_doc_id"] = document.id

            chunk = Document(
                id=chunk_id,
                name=f"{document.name} (Part {i+1}/{len(text_chunks)})" if document.name else None,
                content=text.strip(),
                metadata=chunk_metadata,
            )
            chunks.append(chunk)

        return chunks

    def chunk_documents(self, documents: List[Document]) -> List[Document]:
        """Chunk multiple documents.

        Args:
            documents: Documents to chunk

        Returns:
            List of all document chunks
        """
        all_chunks = []
        for doc in documents:
            chunks = self.chunk_document(doc)
            all_chunks.extend(chunks)
        return all_chunks

    def _chunk_fixed_size(self, text: str) -> List[str]:
        """Chunk text by fixed character count.

        Args:
            text: Text to chunk

        Returns:
            List of text chunks
        """
        chunks = []
        start = 0
        text_len = len(text)

        while start < text_len:
            end = start + self.config.chunk_size

            # Try to break at word boundary
            if end < text_len:
                # Look back for space
                last_space = text.rfind(' ', start, end)
                if last_space > start:
                    end = last_space

            chunk = text[start:end]
            if chunk.strip():
                chunks.append(chunk)

            start = end

        return chunks

    def _chunk_sentences(self, text: str) -> List[str]:
        """Chunk text by sentence boundaries.

        Args:
            text: Text to chunk

        Returns:
            List of text chunks
        """
        # Split into sentences using regex
        sentence_pattern = r'(?<=[.!?])\s+'
        sentences = re.split(sentence_pattern, text)

        chunks = []
        current_chunk = []
        current_size = 0

        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue

            sentence_size = len(sentence)

            # If single sentence is too large, split it
            if sentence_size > self.config.chunk_size:
                if current_chunk:
                    chunks.append(' '.join(current_chunk))
                    current_chunk = []
                    current_size = 0

                # Split large sentence by fixed size
                sub_chunks = self._chunk_fixed_size(sentence)
                chunks.extend(sub_chunks)
                continue

            # Check if adding sentence exceeds chunk size
            if current_size + sentence_size > self.config.chunk_size and current_chunk:
                chunks.append(' '.join(current_chunk))
                current_chunk = []
                current_size = 0

            current_chunk.append(sentence)
            current_size += sentence_size

        # Add remaining chunk
        if current_chunk:
            chunks.append(' '.join(current_chunk))

        return chunks

    def _chunk_paragraphs(self, text: str) -> List[str]:
        """Chunk text by paragraph boundaries.

        Args:
            text: Text to chunk

        Returns:
            List of text chunks
        """
        # Split into paragraphs (double newline or more)
        paragraph_pattern = r'\n\s*\n'
        paragraphs = re.split(paragraph_pattern, text)

        chunks = []
        current_chunk = []
        current_size = 0

        for para in paragraphs:
            para = para.strip()
            if not para:
                continue

            para_size = len(para)

            # If single paragraph is too large, split by sentences
            if para_size > self.config.chunk_size:
                if current_chunk:
                    chunks.append('\n\n'.join(current_chunk))
                    current_chunk = []
                    current_size = 0

                # Split large paragraph by sentences
                sub_chunks = self._chunk_sentences(para)
                chunks.extend(sub_chunks)
                continue

            # Check if adding paragraph exceeds chunk size
            if current_size + para_size > self.config.chunk_size and current_chunk:
                chunks.append('\n\n'.join(current_chunk))
                current_chunk = []
                current_size = 0

            current_chunk.append(para)
            current_size += para_size

        # Add remaining chunk
        if current_chunk:
            chunks.append('\n\n'.join(current_chunk))

        return chunks

    def _chunk_sliding_window(self, text: str) -> List[str]:
        """Chunk text using sliding window with overlap.

        Args:
            text: Text to chunk

        Returns:
            List of text chunks
        """
        chunks = []
        start = 0
        text_len = len(text)

        while start < text_len:
            end = start + self.config.chunk_size

            # Try to break at word boundary
            if end < text_len:
                last_space = text.rfind(' ', start, end)
                if last_space > start:
                    end = last_space

            chunk = text[start:end]
            if chunk.strip():
                chunks.append(chunk)

            # Move start by chunk_size - overlap
            start += (self.config.chunk_size - self.config.chunk_overlap)

        return chunks


def chunk_document(
    document: Document,
    strategy: ChunkStrategy = ChunkStrategy.PARAGRAPH,
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
) -> List[Document]:
    """Convenience function to chunk a document.

    Args:
        document: Document to chunk
        strategy: Chunking strategy
        chunk_size: Target chunk size in characters
        chunk_overlap: Overlap for sliding window strategy

    Returns:
        List of document chunks

    Example:
        >>> from contextwise.lib.vector import Document, chunk_document, ChunkStrategy
        >>>
        >>> doc = Document(
        ...     id="article1",
        ...     content="Very long article text..." * 100,
        ...     metadata={"source": "blog"}
        ... )
        >>>
        >>> chunks = chunk_document(doc, strategy=ChunkStrategy.PARAGRAPH)
        >>> len(chunks)
        12
    """
    config = ChunkConfig(
        strategy=strategy,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        min_chunk_size=max(10, chunk_size // 10),  # Adaptive min_chunk_size
    )
    chunker = DocumentChunker(config)
    return chunker.chunk_document(document)


def chunk_documents(
    documents: List[Document],
    strategy: ChunkStrategy = ChunkStrategy.PARAGRAPH,
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
) -> List[Document]:
    """Convenience function to chunk multiple documents.

    Args:
        documents: Documents to chunk
        strategy: Chunking strategy
        chunk_size: Target chunk size in characters
        chunk_overlap: Overlap for sliding window strategy

    Returns:
        List of all document chunks

    Example:
        >>> from contextwise.lib.vector import Document, chunk_documents
        >>>
        >>> docs = [
        ...     Document(id="1", content="Text..." * 50),
        ...     Document(id="2", content="More..." * 50),
        ... ]
        >>>
        >>> chunks = chunk_documents(docs, chunk_size=500)
        >>> len(chunks)
        20
    """
    config = ChunkConfig(
        strategy=strategy,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        min_chunk_size=max(10, chunk_size // 10),  # Adaptive min_chunk_size
    )
    chunker = DocumentChunker(config)
    return chunker.chunk_documents(documents)
