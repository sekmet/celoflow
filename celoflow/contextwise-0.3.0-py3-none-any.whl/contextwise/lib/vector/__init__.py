"""Vector database module for contextwise.

This module provides vector database capabilities for storing
and searching document embeddings.

Example:
    >>> from contextwise.lib.vector import Qdrant, PgVector, Document
    >>> from contextwise import OpenAIEmbedder
    >>> 
    >>> embedder = OpenAIEmbedder()
    >>> db = Qdrant(
    ...     collection="my_docs",
    ...     embedder=embedder,
    ... )
    >>> db.create()
    >>> db.insert([Document(id="1", content="Hello!")])
"""

from .base import Document, Distance, SearchType, VectorDb
from .qdrant import Qdrant
from .pgvector import PgVector
from .chunker import (
    DocumentChunker,
    ChunkConfig,
    ChunkStrategy,
    chunk_document,
    chunk_documents,
)
from .benchmark import (
    VectorDbBenchmark,
    BenchmarkResult,
    BenchmarkConfig,
    compare_databases,
)

__all__ = [
    "Document",
    "Distance",
    "SearchType",
    "VectorDb",
    "Qdrant",
    "PgVector",
    "DocumentChunker",
    "ChunkConfig",
    "ChunkStrategy",
    "chunk_document",
    "chunk_documents",
    "VectorDbBenchmark",
    "BenchmarkResult",
    "BenchmarkConfig",
    "compare_databases",
]
