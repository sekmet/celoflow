"""Qdrant vector database implementation for contextwise.

This module provides a vector database backend using Qdrant.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from hashlib import md5
from typing import Any, Dict, List, Optional

from .base import Distance, Document, SearchType, VectorDb

logger = logging.getLogger(__name__)

try:
    from qdrant_client import QdrantClient
    from qdrant_client.http import models
    QDRANT_AVAILABLE = True
except ImportError:
    QDRANT_AVAILABLE = False


@dataclass
class Qdrant(VectorDb):
    """Qdrant vector database backend.
    
    This implementation provides vector storage and search using Qdrant.
    
    Attributes:
        collection: Name of the Qdrant collection.
        embedder: Embedder for generating vectors.
        distance: Distance metric (cosine, l2, max_inner_product).
        url: Qdrant server URL.
        api_key: Qdrant API key (for cloud).
        host: Qdrant host.
        port: Qdrant port.
    
    Example:
        >>> from contextwise import OpenAIEmbedder
        >>> embedder = OpenAIEmbedder()
        >>> db = Qdrant(
        ...     collection="my_docs",
        ...     embedder=embedder,
        ...     url="http://localhost:6333",
        ... )
        >>> db.create()
        >>> db.insert([Document(id="1", content="Hello world")])
    """
    
    collection: str = "documents"
    embedder: Optional[Any] = None
    distance: Distance = Distance.cosine
    
    # Connection parameters
    location: Optional[str] = None
    url: Optional[str] = None
    host: Optional[str] = None
    port: int = 6333
    grpc_port: int = 6334
    prefer_grpc: bool = False
    https: Optional[bool] = None
    api_key: Optional[str] = None
    prefix: Optional[str] = None
    timeout: Optional[float] = None
    path: Optional[str] = None
    
    # Search configuration
    search_type: SearchType = SearchType.vector
    
    _client: Optional[Any] = field(default=None, repr=False)
    
    def __post_init__(self):
        """Validate dependencies."""
        if not QDRANT_AVAILABLE:
            raise ImportError(
                "qdrant-client not installed. Install with: uv add qdrant-client"
            )
    
    @property
    def dimensions(self) -> Optional[int]:
        """Get embedding dimensions from embedder."""
        if self.embedder:
            return getattr(self.embedder, "dimensions", None)
        return None
    
    @property
    def client(self) -> "QdrantClient":
        """Get or create Qdrant client."""
        if self._client is None:
            self._client = QdrantClient(
                location=self.location,
                url=self.url,
                port=self.port,
                grpc_port=self.grpc_port,
                prefer_grpc=self.prefer_grpc,
                https=self.https,
                api_key=self.api_key,
                prefix=self.prefix,
                timeout=int(self.timeout) if self.timeout else None,
                host=self.host,
                path=self.path,
            )
        return self._client
    
    def _get_distance(self) -> "models.Distance":
        """Convert Distance enum to Qdrant distance."""
        if self.distance == Distance.l2:
            return models.Distance.EUCLID
        elif self.distance == Distance.max_inner_product:
            return models.Distance.DOT
        return models.Distance.COSINE
    
    def exists(self) -> bool:
        """Check if collection exists."""
        try:
            collections = self.client.get_collections()
            return any(c.name == self.collection for c in collections.collections)
        except Exception as e:
            logger.error(f"Error checking collection: {e}")
            return False
    
    def create(self) -> None:
        """Create the collection if it doesn't exist."""
        if self.exists():
            logger.debug(f"Collection '{self.collection}' already exists")
            return
        
        if self.dimensions is None:
            raise ValueError("Embedder dimensions must be set to create collection")
        
        try:
            self.client.create_collection(
                collection_name=self.collection,
                vectors_config=models.VectorParams(
                    size=self.dimensions,
                    distance=self._get_distance(),
                ),
            )
            logger.debug(f"Created collection: {self.collection}")
        except Exception as e:
            logger.error(f"Error creating collection: {e}")
            raise
    
    def _get_id(self, document: Document) -> str:
        """Generate a unique ID for a document."""
        content = document.content or ""
        return md5(content.encode()).hexdigest()
    
    def doc_exists(self, document: Document) -> bool:
        """Check if a document exists."""
        try:
            doc_id = document.id or self._get_id(document)
            result = self.client.retrieve(
                collection_name=self.collection,
                ids=[doc_id],
            )
            return len(result) > 0
        except Exception:
            return False
    
    def insert(
        self,
        documents: List[Document],
        filters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Insert documents into the collection.
        
        Args:
            documents: Documents to insert.
            filters: Optional filter metadata to add.
        """
        if not self.embedder:
            raise ValueError("Embedder is required for insert")
        
        points = []
        for doc in documents:
            # Generate embedding if not provided
            if doc.embedding is None:
                doc.embedding = self.embedder.get_embedding(doc.content)
            
            # Build payload
            payload = {
                "name": doc.name,
                "content": doc.content,
                "metadata": doc.metadata,
            }
            if filters:
                payload["filters"] = filters
            if doc.filters:
                payload["filters"] = {**payload.get("filters", {}), **doc.filters}
            
            doc_id = doc.id or self._get_id(doc)
            
            points.append(models.PointStruct(
                id=doc_id,
                vector=doc.embedding,
                payload=payload,
            ))
        
        try:
            self.client.upsert(
                collection_name=self.collection,
                points=points,
            )
            logger.debug(f"Inserted {len(documents)} documents")
        except Exception as e:
            logger.error(f"Error inserting documents: {e}")
            raise
    
    def upsert(
        self,
        documents: List[Document],
        filters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Insert or update documents.
        
        Args:
            documents: Documents to upsert.
            filters: Optional filter metadata.
        """
        # Qdrant upsert is the same as insert
        self.insert(documents, filters)
    
    def search(
        self,
        query: str,
        limit: int = 5,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Document]:
        """Search for similar documents.
        
        Args:
            query: Search query text.
            limit: Maximum number of results.
            filters: Optional filter conditions.
            
        Returns:
            List of matching documents with scores.
        """
        if not self.embedder:
            raise ValueError("Embedder is required for search")
        
        # Generate query embedding
        query_embedding = self.embedder.get_embedding(query)
        
        # Build filter if provided
        qdrant_filter = None
        if filters:
            filter_conditions = []
            for key, value in filters.items():
                filter_conditions.append(
                    models.FieldCondition(
                        key=f"filters.{key}",
                        match=models.MatchValue(value=value),
                    )
                )
            if filter_conditions:
                qdrant_filter = models.Filter(must=filter_conditions)
        
        try:
            results = self.client.search(
                collection_name=self.collection,
                query_vector=query_embedding,
                limit=limit,
                query_filter=qdrant_filter,
            )
            
            documents = []
            for result in results:
                payload = result.payload or {}
                doc = Document(
                    id=str(result.id),
                    name=payload.get("name"),
                    content=payload.get("content", ""),
                    metadata=payload.get("metadata", {}),
                    filters=payload.get("filters", {}),
                    score=result.score,
                )
                documents.append(doc)
            
            return documents
        except Exception as e:
            logger.error(f"Error searching: {e}")
            return []
    
    def delete(self) -> bool:
        """Delete all documents in the collection."""
        try:
            # Get all point IDs and delete them
            scroll_result = self.client.scroll(
                collection_name=self.collection,
                limit=10000,
                with_payload=False,
                with_vectors=False,
            )
            
            if scroll_result[0]:
                point_ids = [p.id for p in scroll_result[0]]
                self.client.delete(
                    collection_name=self.collection,
                    points_selector=models.PointIdsList(points=point_ids),
                )
            
            logger.debug(f"Deleted all documents from {self.collection}")
            return True
        except Exception as e:
            logger.error(f"Error deleting documents: {e}")
            return False
    
    def drop(self) -> None:
        """Drop the collection."""
        try:
            self.client.delete_collection(collection_name=self.collection)
            logger.debug(f"Dropped collection: {self.collection}")
        except Exception as e:
            logger.error(f"Error dropping collection: {e}")
            raise
    
    def optimize(self) -> None:
        """Optimize the collection (trigger indexing)."""
        try:
            self.client.update_collection(
                collection_name=self.collection,
                optimizer_config=models.OptimizersConfigDiff(
                    indexing_threshold=0,
                ),
            )
            logger.debug(f"Optimized collection: {self.collection}")
        except Exception as e:
            logger.warning(f"Error optimizing collection: {e}")
