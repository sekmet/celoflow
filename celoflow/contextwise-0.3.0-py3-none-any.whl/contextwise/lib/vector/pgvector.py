"""PGVector database implementation for contextwise.

This module provides a vector database backend using PostgreSQL with pgvector.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from hashlib import md5
from typing import Any, Dict, List, Optional, Union

from .base import Distance, Document, SearchType, VectorDb

logger = logging.getLogger(__name__)

try:
    from sqlalchemy import BigInteger, String, Text, func, text
    from sqlalchemy.dialects import postgresql
    from sqlalchemy.engine import Engine, create_engine
    from sqlalchemy.inspection import inspect
    from sqlalchemy.orm import scoped_session, sessionmaker
    from sqlalchemy.schema import Column, Index, MetaData, Table
    from sqlalchemy.sql.expression import select
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False

try:
    from pgvector.sqlalchemy import Vector
    PGVECTOR_AVAILABLE = True
except ImportError:
    PGVECTOR_AVAILABLE = False


@dataclass
class PgVector(VectorDb):
    """PostgreSQL pgvector database backend.
    
    This implementation provides vector storage and search using pgvector.
    
    Attributes:
        table_name: Name of the database table.
        schema: Database schema name.
        db_url: PostgreSQL connection URL.
        embedder: Embedder for generating vectors.
        distance: Distance metric (cosine, l2, max_inner_product).
    
    Example:
        >>> from contextwise import OpenAIEmbedder
        >>> embedder = OpenAIEmbedder()
        >>> db = PgVector(
        ...     table_name="documents",
        ...     db_url="postgresql://user:pass@localhost/db",
        ...     embedder=embedder,
        ... )
        >>> db.create()
        >>> db.insert([Document(id="1", content="Hello world")])
    """
    
    table_name: str = "documents"
    schema: str = "public"
    db_url: Optional[str] = None
    db_engine: Optional[Engine] = None
    embedder: Optional[Any] = None
    distance: Distance = Distance.cosine
    search_type: SearchType = SearchType.vector
    
    _table: Optional[Any] = field(default=None, repr=False)
    _metadata: Optional[Any] = field(default=None, repr=False)
    _session: Optional[Any] = field(default=None, repr=False)
    
    def __post_init__(self):
        """Validate dependencies and initialize."""
        if not SQLALCHEMY_AVAILABLE:
            raise ImportError(
                "sqlalchemy not installed. Install with: uv add sqlalchemy psycopg2-binary"
            )
        if not PGVECTOR_AVAILABLE:
            raise ImportError(
                "pgvector not installed. Install with: uv add pgvector"
            )
        
        if self.db_engine is None and self.db_url is not None:
            self.db_engine = create_engine(self.db_url)
        
        if self.db_engine is None:
            raise ValueError("Must provide either db_url or db_engine")
        
        self._metadata = MetaData(schema=self.schema)
        self._session = scoped_session(sessionmaker(bind=self.db_engine))
    
    @property
    def dimensions(self) -> Optional[int]:
        """Get embedding dimensions from embedder."""
        if self.embedder:
            return getattr(self.embedder, "dimensions", None)
        return None
    
    @property
    def table(self) -> Table:
        """Get or create table definition."""
        if self._table is None:
            if self.dimensions is None:
                raise ValueError("Embedder dimensions must be set")
            
            self._table = Table(
                self.table_name,
                self._metadata,
                Column("id", String(255), primary_key=True),
                Column("name", String(255)),
                Column("content", Text),
                Column("embedding", Vector(self.dimensions)),
                Column("metadata", postgresql.JSONB, server_default=text("'{}'::jsonb")),
                Column("filters", postgresql.JSONB, server_default=text("'{}'::jsonb")),
                Column("created_at", BigInteger, server_default=text("EXTRACT(EPOCH FROM NOW())::bigint")),
                Column("updated_at", BigInteger),
                extend_existing=True,
            )
            
            # Add indexes
            Index(f"idx_{self.table_name}_id", self._table.c.id)
            Index(f"idx_{self.table_name}_name", self._table.c.name)
        
        return self._table
    
    def _get_content_hash(self, content: str) -> str:
        """Generate hash for content."""
        return md5(content.encode()).hexdigest()
    
    def exists(self) -> bool:
        """Check if table exists."""
        try:
            inspector = inspect(self.db_engine)
            return inspector.has_table(self.table_name, schema=self.schema)
        except Exception as e:
            logger.error(f"Error checking table: {e}")
            return False
    
    def create(self) -> None:
        """Create the table if it doesn't exist."""
        if self.exists():
            logger.debug(f"Table '{self.table_name}' already exists")
            return
        
        try:
            with self._session() as sess, sess.begin():
                # Create pgvector extension
                sess.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
                
                # Create schema if needed
                if self.schema != "public":
                    sess.execute(text(f"CREATE SCHEMA IF NOT EXISTS {self.schema}"))
            
            # Create table
            self.table.create(self.db_engine, checkfirst=True)
            logger.debug(f"Created table: {self.schema}.{self.table_name}")
        except Exception as e:
            logger.error(f"Error creating table: {e}")
            raise
    
    def doc_exists(self, document: Document) -> bool:
        """Check if a document exists."""
        try:
            with self._session() as sess:
                stmt = select(self.table.c.id).where(self.table.c.id == document.id)
                result = sess.execute(stmt).fetchone()
                return result is not None
        except Exception:
            return False
    
    def insert(
        self,
        documents: List[Document],
        filters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Insert documents into the table.
        
        Args:
            documents: Documents to insert.
            filters: Optional filter metadata to add.
        """
        if not self.embedder:
            raise ValueError("Embedder is required for insert")
        
        try:
            with self._session() as sess, sess.begin():
                for doc in documents:
                    # Generate embedding if not provided
                    if doc.embedding is None:
                        doc.embedding = self.embedder.get_embedding(doc.content)
                    
                    # Merge filters
                    doc_filters = doc.filters.copy() if doc.filters else {}
                    if filters:
                        doc_filters.update(filters)
                    
                    # Generate ID if not provided
                    doc_id = doc.id or self._get_content_hash(doc.content)
                    
                    stmt = postgresql.insert(self.table).values(
                        id=doc_id,
                        name=doc.name,
                        content=doc.content,
                        embedding=doc.embedding,
                        metadata=doc.metadata,
                        filters=doc_filters,
                    )
                    
                    # Upsert on conflict
                    stmt = stmt.on_conflict_do_update(
                        index_elements=["id"],
                        set_={
                            "name": stmt.excluded.name,
                            "content": stmt.excluded.content,
                            "embedding": stmt.excluded.embedding,
                            "metadata": stmt.excluded.metadata,
                            "filters": stmt.excluded.filters,
                            "updated_at": func.extract("epoch", func.now()),
                        },
                    )
                    sess.execute(stmt)
            
            logger.debug(f"Inserted {len(documents)} documents")
        except Exception as e:
            logger.error(f"Error inserting documents: {e}")
            raise
    
    def upsert(
        self,
        documents: List[Document],
        filters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Insert or update documents.
        
        Args:
            documents: Documents to upsert.
            filters: Optional filter metadata.
        """
        self.insert(documents, filters)
    
    def _get_distance_op(self):
        """Get the distance operator based on metric."""
        if self.distance == Distance.l2:
            return "<->"  # L2 distance
        elif self.distance == Distance.max_inner_product:
            return "<#>"  # Inner product (negative)
        return "<=>"  # Cosine distance
    
    def search(
        self,
        query: str,
        limit: int = 5,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Document]:
        """Search for similar documents.
        
        Args:
            query: Search query text.
            limit: Maximum number of results.
            filters: Optional filter conditions.
            
        Returns:
            List of matching documents with scores.
        """
        if not self.embedder:
            raise ValueError("Embedder is required for search")
        
        # Generate query embedding
        query_embedding = self.embedder.get_embedding(query)
        
        try:
            with self._session() as sess:
                # Build distance expression
                distance_op = self._get_distance_op()
                
                # Use raw SQL for vector search
                embedding_str = "[" + ",".join(str(x) for x in query_embedding) + "]"
                
                sql = f"""
                    SELECT id, name, content, metadata, filters,
                           embedding {distance_op} '{embedding_str}'::vector AS distance
                    FROM {self.schema}.{self.table_name}
                """
                
                # Add filters
                if filters:
                    filter_conditions = []
                    for key, value in filters.items():
                        if isinstance(value, str):
                            filter_conditions.append(f"filters->>'{key}' = '{value}'")
                        else:
                            filter_conditions.append(f"filters->>'{key}' = '{value}'")
                    if filter_conditions:
                        sql += " WHERE " + " AND ".join(filter_conditions)
                
                sql += f" ORDER BY distance LIMIT {limit}"
                
                results = sess.execute(text(sql)).fetchall()
                
                documents = []
                for row in results:
                    doc = Document(
                        id=row[0],
                        name=row[1],
                        content=row[2] or "",
                        metadata=row[3] or {},
                        filters=row[4] or {},
                        score=1 - row[5] if row[5] else None,  # Convert distance to similarity
                    )
                    documents.append(doc)
                
                return documents
        except Exception as e:
            logger.error(f"Error searching: {e}")
            return []
    
    def delete(self) -> bool:
        """Delete all documents in the table."""
        try:
            with self._session() as sess, sess.begin():
                sess.execute(self.table.delete())
            logger.debug(f"Deleted all documents from {self.table_name}")
            return True
        except Exception as e:
            logger.error(f"Error deleting documents: {e}")
            return False
    
    def drop(self) -> None:
        """Drop the table."""
        try:
            self.table.drop(self.db_engine, checkfirst=True)
            self._table = None
            logger.debug(f"Dropped table: {self.table_name}")
        except Exception as e:
            logger.error(f"Error dropping table: {e}")
            raise
    
    def hybrid_search(
        self,
        query: str,
        limit: int = 5,
        filters: Optional[Dict[str, Any]] = None,
        vector_weight: float = 0.5,
    ) -> List[Document]:
        """Perform hybrid search combining vector similarity and keyword matching.

        This method combines vector similarity search with PostgreSQL's full-text
        search for better retrieval quality.

        Args:
            query: Search query text.
            limit: Maximum number of results.
            filters: Optional filter conditions.
            vector_weight: Weight for vector score (0-1). Keyword weight = 1 - vector_weight.

        Returns:
            List of matching documents with combined scores.

        Example:
            >>> results = db.hybrid_search(
            ...     "machine learning algorithms",
            ...     limit=10,
            ...     vector_weight=0.7  # 70% vector, 30% keyword
            ... )
        """
        if not self.embedder:
            raise ValueError("Embedder is required for hybrid search")

        if not 0 <= vector_weight <= 1:
            raise ValueError("vector_weight must be between 0 and 1")

        keyword_weight = 1 - vector_weight

        # Generate query embedding for vector search
        query_embedding = self.embedder.get_embedding(query)

        try:
            with self._session() as sess:
                # Build distance expression
                distance_op = self._get_distance_op()

                # Format embedding for SQL
                embedding_str = "[" + ",".join(str(x) for x in query_embedding) + "]"

                # Build hybrid search query
                # Uses PostgreSQL's ts_rank for text ranking and vector distance for similarity
                sql = f"""
                    WITH vector_results AS (
                        SELECT
                            id, name, content, metadata, filters,
                            (1 - (embedding {distance_op} '{embedding_str}'::vector)) AS vector_score
                        FROM {self.schema}.{self.table_name}
                """

                # Add filters to CTE
                if filters:
                    filter_conditions = []
                    for key, value in filters.items():
                        if isinstance(value, str):
                            filter_conditions.append(f"filters->>'{key}' = '{value}'")
                        else:
                            filter_conditions.append(f"filters->>'{key}' = '{value}'")
                    if filter_conditions:
                        sql += " WHERE " + " AND ".join(filter_conditions)

                sql += f"""
                    ),
                    keyword_results AS (
                        SELECT
                            id,
                            ts_rank(to_tsvector('english', content),
                                   plainto_tsquery('english', '{query}')) AS keyword_score
                        FROM {self.schema}.{self.table_name}
                        WHERE to_tsvector('english', content) @@ plainto_tsquery('english', '{query}')
                """

                # Add filters to keyword CTE
                if filters:
                    sql += " AND " + " AND ".join(filter_conditions)

                sql += f"""
                    )
                    SELECT
                        v.id, v.name, v.content, v.metadata, v.filters,
                        (COALESCE(v.vector_score, 0) * {vector_weight} +
                         COALESCE(k.keyword_score, 0) * {keyword_weight}) AS combined_score
                    FROM vector_results v
                    LEFT JOIN keyword_results k ON v.id = k.id
                    ORDER BY combined_score DESC
                    LIMIT {limit}
                """

                results = sess.execute(text(sql)).fetchall()

                documents = []
                for row in results:
                    doc = Document(
                        id=row[0],
                        name=row[1],
                        content=row[2] or "",
                        metadata=row[3] or {},
                        filters=row[4] or {},
                        score=row[5] if row[5] else None,
                    )
                    documents.append(doc)

                return documents
        except Exception as e:
            logger.error(f"Error in hybrid search: {e}")
            # Fallback to vector-only search
            logger.info("Falling back to vector-only search")
            return self.search(query, limit, filters)

    def keyword_search(
        self,
        query: str,
        limit: int = 5,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Document]:
        """Perform keyword-only search using PostgreSQL full-text search.

        Args:
            query: Search query text.
            limit: Maximum number of results.
            filters: Optional filter conditions.

        Returns:
            List of matching documents with text relevance scores.
        """
        try:
            with self._session() as sess:
                # Build keyword search query
                sql = f"""
                    SELECT
                        id, name, content, metadata, filters,
                        ts_rank(to_tsvector('english', content),
                               plainto_tsquery('english', '{query}')) AS rank_score
                    FROM {self.schema}.{self.table_name}
                    WHERE to_tsvector('english', content) @@ plainto_tsquery('english', '{query}')
                """

                # Add filters
                if filters:
                    filter_conditions = []
                    for key, value in filters.items():
                        if isinstance(value, str):
                            filter_conditions.append(f"filters->>'{key}' = '{value}'")
                        else:
                            filter_conditions.append(f"filters->>'{key}' = '{value}'")
                    if filter_conditions:
                        sql += " AND " + " AND ".join(filter_conditions)

                sql += f" ORDER BY rank_score DESC LIMIT {limit}"

                results = sess.execute(text(sql)).fetchall()

                documents = []
                for row in results:
                    doc = Document(
                        id=row[0],
                        name=row[1],
                        content=row[2] or "",
                        metadata=row[3] or {},
                        filters=row[4] or {},
                        score=row[5] if row[5] else None,
                    )
                    documents.append(doc)

                return documents
        except Exception as e:
            logger.error(f"Error in keyword search: {e}")
            return []

    def optimize(self) -> None:
        """Create vector index for faster search."""
        try:
            with self._session() as sess, sess.begin():
                # Create IVFFlat index
                index_name = f"idx_{self.table_name}_embedding"

                if self.distance == Distance.l2:
                    ops = "vector_l2_ops"
                elif self.distance == Distance.max_inner_product:
                    ops = "vector_ip_ops"
                else:
                    ops = "vector_cosine_ops"

                sql = f"""
                    CREATE INDEX IF NOT EXISTS {index_name}
                    ON {self.schema}.{self.table_name}
                    USING ivfflat (embedding {ops})
                    WITH (lists = 100)
                """
                sess.execute(text(sql))

                # Create GIN index for full-text search
                fts_index_name = f"idx_{self.table_name}_fts"
                fts_sql = f"""
                    CREATE INDEX IF NOT EXISTS {fts_index_name}
                    ON {self.schema}.{self.table_name}
                    USING gin (to_tsvector('english', content))
                """
                sess.execute(text(fts_sql))

            logger.debug(f"Created vector index: {index_name} and FTS index: {fts_index_name}")
        except Exception as e:
            logger.warning(f"Error creating index: {e}")
    
    def close(self) -> None:
        """Close database connections."""
        try:
            if self._session:
                self._session.remove()
            if self.db_engine:
                self.db_engine.dispose()
            logger.debug("PgVector connections closed")
        except Exception as e:
            logger.warning(f"Error closing connections: {e}")
