"""Vector database benchmarking utilities.

This module provides tools for benchmarking vector database performance,
including insert speed, search latency, and memory usage.
"""

from __future__ import annotations

import time
import psutil
import os
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Callable
from statistics import mean, median, stdev

from .base import VectorDb, Document


@dataclass
class BenchmarkResult:
    """Results from a benchmark run.

    Attributes:
        operation: Name of the operation (insert, search, etc.)
        total_time: Total time in seconds
        operations_count: Number of operations performed
        ops_per_second: Operations per second
        avg_latency_ms: Average latency in milliseconds
        median_latency_ms: Median latency in milliseconds
        p95_latency_ms: 95th percentile latency in milliseconds
        p99_latency_ms: 99th percentile latency in milliseconds
        memory_mb: Peak memory usage in MB
        metadata: Additional benchmark metadata
    """
    operation: str
    total_time: float
    operations_count: int
    ops_per_second: float
    avg_latency_ms: float
    median_latency_ms: float
    p95_latency_ms: float
    p99_latency_ms: float
    memory_mb: float
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        """Format benchmark results as string."""
        return f"""
Benchmark: {self.operation}
  Operations: {self.operations_count}
  Total time: {self.total_time:.2f}s
  Throughput: {self.ops_per_second:.2f} ops/sec
  Latency (avg): {self.avg_latency_ms:.2f}ms
  Latency (median): {self.median_latency_ms:.2f}ms
  Latency (p95): {self.p95_latency_ms:.2f}ms
  Latency (p99): {self.p99_latency_ms:.2f}ms
  Memory: {self.memory_mb:.2f}MB
        """.strip()


@dataclass
class BenchmarkConfig:
    """Configuration for benchmarks.

    Attributes:
        warmup_iterations: Number of warmup iterations before measurement
        iterations: Number of iterations to measure
        document_count: Number of documents to use in tests
        search_query_count: Number of search queries to run
        search_limit: Number of results per search query
        chunk_size: Document chunk size (for chunking benchmarks)
        measure_memory: Whether to measure memory usage
    """
    warmup_iterations: int = 3
    iterations: int = 10
    document_count: int = 1000
    search_query_count: int = 100
    search_limit: int = 10
    chunk_size: int = 1000
    measure_memory: bool = True


class VectorDbBenchmark:
    """Benchmarking suite for vector databases.

    Example:
        >>> from contextwise.lib.vector import PgVector, FastEmbedEmbedder
        >>> from contextwise.lib.vector.benchmark import VectorDbBenchmark, BenchmarkConfig
        >>>
        >>> embedder = FastEmbedEmbedder()
        >>> db = PgVector("benchmark_test", embedder)
        >>>
        >>> benchmark = VectorDbBenchmark(db)
        >>> results = benchmark.run_all()
        >>>
        >>> for result in results:
        ...     print(result)
    """

    def __init__(
        self,
        vector_db: VectorDb,
        config: Optional[BenchmarkConfig] = None
    ):
        """Initialize benchmark suite.

        Args:
            vector_db: Vector database instance to benchmark
            config: Benchmark configuration
        """
        self.vector_db = vector_db
        self.config = config or BenchmarkConfig()
        self.process = psutil.Process(os.getpid())

    def _measure_memory(self) -> float:
        """Get current memory usage in MB."""
        return self.process.memory_info().rss / 1024 / 1024

    def _calculate_percentile(self, values: List[float], percentile: int) -> float:
        """Calculate percentile from a list of values."""
        if not values:
            return 0.0
        sorted_values = sorted(values)
        index = int(len(sorted_values) * percentile / 100)
        return sorted_values[min(index, len(sorted_values) - 1)]

    def benchmark_insert(
        self,
        documents: List[Document],
        batch_size: Optional[int] = None
    ) -> BenchmarkResult:
        """Benchmark document insertion performance.

        Args:
            documents: Documents to insert
            batch_size: Batch size for bulk insertion (None = all at once)

        Returns:
            Benchmark results
        """
        # Warmup
        for _ in range(self.config.warmup_iterations):
            sample = documents[:min(10, len(documents))]
            self.vector_db.insert(sample)

        # Clear for measurement
        try:
            self.vector_db.clear()
        except Exception:
            pass

        # Measure
        latencies = []
        initial_memory = self._measure_memory() if self.config.measure_memory else 0

        start_time = time.time()

        if batch_size:
            # Batch insertion
            for i in range(0, len(documents), batch_size):
                batch = documents[i:i + batch_size]
                batch_start = time.time()
                self.vector_db.insert(batch)
                batch_time = (time.time() - batch_start) * 1000
                latencies.append(batch_time)
        else:
            # Bulk insertion
            insert_start = time.time()
            self.vector_db.insert(documents)
            insert_time = (time.time() - insert_start) * 1000
            latencies.append(insert_time)

        total_time = time.time() - start_time
        peak_memory = self._measure_memory() if self.config.measure_memory else 0

        return BenchmarkResult(
            operation="insert",
            total_time=total_time,
            operations_count=len(documents),
            ops_per_second=len(documents) / total_time if total_time > 0 else 0,
            avg_latency_ms=mean(latencies) if latencies else 0,
            median_latency_ms=median(latencies) if latencies else 0,
            p95_latency_ms=self._calculate_percentile(latencies, 95),
            p99_latency_ms=self._calculate_percentile(latencies, 99),
            memory_mb=peak_memory - initial_memory,
            metadata={
                "document_count": len(documents),
                "batch_size": batch_size or len(documents),
            }
        )

    def benchmark_search(
        self,
        queries: List[str],
        limit: int = 10
    ) -> BenchmarkResult:
        """Benchmark search performance.

        Args:
            queries: Search queries to run
            limit: Number of results per query

        Returns:
            Benchmark results
        """
        # Warmup
        for _ in range(self.config.warmup_iterations):
            if queries:
                self.vector_db.search(queries[0], limit=limit)

        # Measure
        latencies = []
        initial_memory = self._measure_memory() if self.config.measure_memory else 0

        start_time = time.time()

        for query in queries:
            query_start = time.time()
            self.vector_db.search(query, limit=limit)
            query_time = (time.time() - query_start) * 1000
            latencies.append(query_time)

        total_time = time.time() - start_time
        peak_memory = self._measure_memory() if self.config.measure_memory else 0

        return BenchmarkResult(
            operation="search",
            total_time=total_time,
            operations_count=len(queries),
            ops_per_second=len(queries) / total_time if total_time > 0 else 0,
            avg_latency_ms=mean(latencies) if latencies else 0,
            median_latency_ms=median(latencies) if latencies else 0,
            p95_latency_ms=self._calculate_percentile(latencies, 95),
            p99_latency_ms=self._calculate_percentile(latencies, 99),
            memory_mb=peak_memory - initial_memory,
            metadata={
                "query_count": len(queries),
                "limit": limit,
            }
        )

    def benchmark_search_with_filter(
        self,
        queries: List[str],
        filters: List[Dict[str, Any]],
        limit: int = 10
    ) -> BenchmarkResult:
        """Benchmark filtered search performance.

        Args:
            queries: Search queries to run
            filters: Metadata filters for each query
            limit: Number of results per query

        Returns:
            Benchmark results
        """
        # Warmup
        for _ in range(self.config.warmup_iterations):
            if queries and filters:
                self.vector_db.search(
                    queries[0],
                    limit=limit,
                    filter_metadata=filters[0]
                )

        # Measure
        latencies = []
        initial_memory = self._measure_memory() if self.config.measure_memory else 0

        start_time = time.time()

        for query, filter_dict in zip(queries, filters):
            query_start = time.time()
            self.vector_db.search(
                query,
                limit=limit,
                filter_metadata=filter_dict
            )
            query_time = (time.time() - query_start) * 1000
            latencies.append(query_time)

        total_time = time.time() - start_time
        peak_memory = self._measure_memory() if self.config.measure_memory else 0

        return BenchmarkResult(
            operation="search_with_filter",
            total_time=total_time,
            operations_count=len(queries),
            ops_per_second=len(queries) / total_time if total_time > 0 else 0,
            avg_latency_ms=mean(latencies) if latencies else 0,
            median_latency_ms=median(latencies) if latencies else 0,
            p95_latency_ms=self._calculate_percentile(latencies, 95),
            p99_latency_ms=self._calculate_percentile(latencies, 99),
            memory_mb=peak_memory - initial_memory,
            metadata={
                "query_count": len(queries),
                "limit": limit,
                "has_filters": True,
            }
        )

    def run_all(
        self,
        documents: Optional[List[Document]] = None,
        queries: Optional[List[str]] = None
    ) -> List[BenchmarkResult]:
        """Run all benchmarks.

        Args:
            documents: Documents to use (generates sample if None)
            queries: Queries to use (generates sample if None)

        Returns:
            List of benchmark results
        """
        if documents is None:
            documents = self._generate_sample_documents(
                self.config.document_count
            )

        if queries is None:
            queries = self._generate_sample_queries(
                self.config.search_query_count
            )

        results = []

        # Insert benchmark
        print("Running insert benchmark...")
        results.append(self.benchmark_insert(documents))

        # Search benchmark
        print("Running search benchmark...")
        results.append(self.benchmark_search(
            queries,
            limit=self.config.search_limit
        ))

        # Filtered search benchmark
        print("Running filtered search benchmark...")
        filters = [{"category": "tech"} for _ in queries]
        results.append(self.benchmark_search_with_filter(
            queries,
            filters,
            limit=self.config.search_limit
        ))

        return results

    def _generate_sample_documents(self, count: int) -> List[Document]:
        """Generate sample documents for benchmarking."""
        documents = []
        categories = ["tech", "science", "business", "health", "sports"]

        for i in range(count):
            doc = Document(
                id=f"doc_{i}",
                name=f"Sample Document {i}",
                content=f"This is sample document {i} for benchmarking. " * 50,
                metadata={
                    "category": categories[i % len(categories)],
                    "index": i,
                }
            )
            documents.append(doc)

        return documents

    def _generate_sample_queries(self, count: int) -> List[str]:
        """Generate sample queries for benchmarking."""
        query_templates = [
            "machine learning algorithms",
            "neural network architectures",
            "data science best practices",
            "vector database performance",
            "semantic search techniques",
        ]

        queries = []
        for i in range(count):
            template = query_templates[i % len(query_templates)]
            queries.append(f"{template} query {i}")

        return queries


def compare_databases(
    databases: Dict[str, VectorDb],
    config: Optional[BenchmarkConfig] = None
) -> Dict[str, List[BenchmarkResult]]:
    """Compare performance of multiple vector databases.

    Args:
        databases: Dictionary of database name to VectorDb instance
        config: Benchmark configuration

    Returns:
        Dictionary of database name to benchmark results

    Example:
        >>> from contextwise.lib.vector import PgVector, Qdrant
        >>> from contextwise.lib.vector.benchmark import compare_databases
        >>>
        >>> databases = {
        ...     "pgvector": PgVector("test", embedder),
        ...     "qdrant": Qdrant("test", embedder)
        ... }
        >>>
        >>> results = compare_databases(databases)
        >>> for db_name, db_results in results.items():
        ...     print(f"{db_name}:")
        ...     for result in db_results:
        ...         print(f"  {result.operation}: {result.ops_per_second:.2f} ops/sec")
    """
    config = config or BenchmarkConfig()
    all_results = {}

    # Generate shared test data
    benchmark = VectorDbBenchmark(list(databases.values())[0], config)
    documents = benchmark._generate_sample_documents(config.document_count)
    queries = benchmark._generate_sample_queries(config.search_query_count)

    # Benchmark each database
    for db_name, db in databases.items():
        print(f"\nBenchmarking {db_name}...")
        benchmark = VectorDbBenchmark(db, config)
        results = benchmark.run_all(documents, queries)
        all_results[db_name] = results

    return all_results
