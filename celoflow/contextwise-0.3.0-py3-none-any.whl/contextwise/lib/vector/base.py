"""Base vector database class for contextwise.

This module provides the abstract base class and data structures
for vector database implementations.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Distance(str, Enum):
    """Distance metric for vector similarity."""
    cosine = "cosine"
    l2 = "l2"
    max_inner_product = "max_inner_product"


class SearchType(str, Enum):
    """Type of search to perform."""
    vector = "vector"
    keyword = "keyword"
    hybrid = "hybrid"


@dataclass
class Document:
    """A document with content and embedding.
    
    Attributes:
        id: Unique document identifier.
        name: Document name/title.
        content: Text content of the document.
        embedding: Vector embedding of the content.
        metadata: Additional metadata.
        filters: Filter metadata for querying.
    """
    id: str
    name: Optional[str] = None
    content: str = ""
    embedding: Optional[List[float]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    filters: Dict[str, Any] = field(default_factory=dict)
    score: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert document to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "content": self.content,
            "embedding": self.embedding,
            "metadata": self.metadata,
            "filters": self.filters,
            "score": self.score,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Document":
        """Create document from dictionary."""
        return cls(
            id=data.get("id", ""),
            name=data.get("name"),
            content=data.get("content", ""),
            embedding=data.get("embedding"),
            metadata=data.get("metadata", {}),
            filters=data.get("filters", {}),
            score=data.get("score"),
        )


class VectorDb(ABC):
    """Abstract base class for vector databases.
    
    This class defines the interface for all vector database implementations.
    Vector databases store document embeddings and enable similarity search.
    
    Example:
        >>> class MyVectorDb(VectorDb):
        ...     def create(self) -> None:
        ...         # Create collection/table
        ...         pass
        ...     
        ...     def insert(self, documents: List[Document]) -> None:
        ...         # Insert documents
        ...         pass
    """
    
    @abstractmethod
    def create(self) -> None:
        """Create the vector collection/table."""
        raise NotImplementedError
    
    async def async_create(self) -> None:
        """Async version of create."""
        self.create()
    
    @abstractmethod
    def exists(self) -> bool:
        """Check if the collection exists."""
        raise NotImplementedError
    
    async def async_exists(self) -> bool:
        """Async version of exists."""
        return self.exists()
    
    @abstractmethod
    def doc_exists(self, document: Document) -> bool:
        """Check if a document exists."""
        raise NotImplementedError
    
    async def async_doc_exists(self, document: Document) -> bool:
        """Async version of doc_exists."""
        return self.doc_exists(document)
    
    def name_exists(self, name: str) -> bool:
        """Check if a document with the given name exists."""
        raise NotImplementedError
    
    def id_exists(self, id: str) -> bool:
        """Check if a document with the given ID exists."""
        raise NotImplementedError
    
    @abstractmethod
    def insert(
        self, 
        documents: List[Document], 
        filters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Insert documents into the collection."""
        raise NotImplementedError
    
    async def async_insert(
        self, 
        documents: List[Document], 
        filters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Async version of insert."""
        self.insert(documents, filters)
    
    def upsert_available(self) -> bool:
        """Check if upsert is available."""
        return False
    
    @abstractmethod
    def upsert(
        self, 
        documents: List[Document], 
        filters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Insert or update documents."""
        raise NotImplementedError
    
    async def async_upsert(
        self, 
        documents: List[Document], 
        filters: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Async version of upsert."""
        self.upsert(documents, filters)
    
    @abstractmethod
    def search(
        self, 
        query: str, 
        limit: int = 5, 
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Document]:
        """Search for similar documents."""
        raise NotImplementedError
    
    async def async_search(
        self, 
        query: str, 
        limit: int = 5, 
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Document]:
        """Async version of search."""
        return self.search(query, limit, filters)
    
    def vector_search(
        self, 
        query: str, 
        limit: int = 5,
    ) -> List[Document]:
        """Perform vector similarity search."""
        raise NotImplementedError
    
    def keyword_search(
        self, 
        query: str, 
        limit: int = 5,
    ) -> List[Document]:
        """Perform keyword search."""
        raise NotImplementedError
    
    def hybrid_search(
        self, 
        query: str, 
        limit: int = 5,
    ) -> List[Document]:
        """Perform hybrid search (vector + keyword)."""
        raise NotImplementedError
    
    @abstractmethod
    def drop(self) -> None:
        """Drop the collection."""
        raise NotImplementedError
    
    async def async_drop(self) -> None:
        """Async version of drop."""
        self.drop()
    
    @abstractmethod
    def delete(self) -> bool:
        """Delete all documents."""
        raise NotImplementedError
    
    def optimize(self) -> None:
        """Optimize the collection (e.g., rebuild indexes)."""
        pass
