"""FastAPI application for Fragment Manager API."""

import logging
import uuid
from contextlib import asynccontextmanager
from typing import List, Optional

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from ..analytics import PromptAnalytics
from ..cloudflare_client import CloudflareEmbeddingClient
from ..config import DynamicPromptConfig
from ..models import FragmentPriority, FragmentType, InstructionFragment
from ..redis_store import RedisFragmentStore
from .schemas import (
    AnalyticsResponse,
    ErrorResponse,
    FragmentCreate,
    FragmentListResponse,
    FragmentResponse,
    FragmentUpdate,
    HealthResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/fragments", tags=["fragments"])

# Global instances (initialized by create_app)
_config: Optional[DynamicPromptConfig] = None
_store: Optional[RedisFragmentStore] = None
_embedding_client: Optional[CloudflareEmbeddingClient] = None
_analytics: Optional[PromptAnalytics] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup/shutdown events."""
    global _store, _embedding_client
    # Startup
    logger.info("Fragment Manager API starting up...")
    if _store:
        await _store.ensure_index()
    logger.info("Fragment Manager API ready")
    yield
    # Shutdown
    logger.info("Fragment Manager API shutting down...")
    if _store:
        _store.close()
    if _embedding_client:
        await _embedding_client.close()


def get_config() -> DynamicPromptConfig:
    """Get plugin configuration."""
    if _config is None:
        raise HTTPException(status_code=500, detail="Configuration not initialized")
    return _config


def get_store() -> RedisFragmentStore:
    """Get Redis fragment store."""
    if _store is None:
        raise HTTPException(status_code=500, detail="Store not initialized")
    return _store


def get_embedding_client() -> CloudflareEmbeddingClient:
    """Get embedding client."""
    if _embedding_client is None:
        raise HTTPException(status_code=500, detail="Embedding client not initialized")
    return _embedding_client


def get_analytics() -> PromptAnalytics:
    """Get analytics instance."""
    if _analytics is None:
        raise HTTPException(status_code=500, detail="Analytics not initialized")
    return _analytics


def _fragment_to_response(fragment: InstructionFragment) -> FragmentResponse:
    """Convert InstructionFragment to API response."""
    return FragmentResponse(
        fragment_id=fragment.fragment_id,
        agent_type=fragment.agent_type,
        fragment_type=fragment.fragment_type.value,
        priority=fragment.priority.value,
        version=fragment.version,
        content=fragment.content,
        variables=fragment.variables,
        tags=fragment.tags,
        keywords=fragment.keywords,
        channel_whitelist=fragment.channel_whitelist,
        modality_whitelist=fragment.modality_whitelist,
        tool_dependencies=fragment.tool_dependencies,
        mcp_dependencies=fragment.mcp_dependencies,
        requires=fragment.requires,
        conflicts_with=fragment.conflicts_with,
        merge_strategy=fragment.merge_strategy,
        section=fragment.section,
        usage_count=fragment.usage_count,
        acceptance_rate=fragment.acceptance_rate,
        avg_retry_count=fragment.avg_retry_count,
        avg_token_contribution=fragment.avg_token_contribution,
        last_used=fragment.last_used,
        created_at=fragment.created_at,
        updated_at=fragment.updated_at,
        created_by=fragment.created_by,
        is_active=fragment.is_active,
        ttl_seconds=fragment.ttl_seconds,
    )


@router.post("/", response_model=FragmentResponse, status_code=201)
async def create_fragment(
    data: FragmentCreate,
    store: RedisFragmentStore = Depends(get_store),
    embedding_client: CloudflareEmbeddingClient = Depends(get_embedding_client),
):
    """Create a new instruction fragment.

    Generates embedding for the content using Cloudflare Workers AI.
    """
    try:
        # Generate fragment ID if not provided
        fragment_id = data.fragment_id or str(uuid.uuid4())

        # Generate embedding for content
        embedding = []
        try:
            embeddings = await embedding_client.embed_texts([data.content])
            if embeddings:
                embedding = embeddings[0]
        except Exception as e:
            logger.warning(f"Failed to generate embedding: {e}")

        # Estimate token contribution
        avg_token_contribution = len(data.content.split()) + 10

        # Create fragment
        fragment = InstructionFragment(
            fragment_id=fragment_id,
            agent_type=data.agent_type,
            fragment_type=FragmentType(data.fragment_type),
            priority=FragmentPriority(data.priority),
            version=data.version,
            content=data.content,
            variables=data.variables,
            embedding=embedding,
            tags=data.tags,
            keywords=data.keywords,
            channel_whitelist=data.channel_whitelist,
            modality_whitelist=data.modality_whitelist,
            tool_dependencies=data.tool_dependencies,
            mcp_dependencies=data.mcp_dependencies,
            requires=data.requires,
            conflicts_with=data.conflicts_with,
            merge_strategy=data.merge_strategy,
            section=data.section,
            avg_token_contribution=avg_token_contribution,
            ttl_seconds=data.ttl_seconds,
        )

        await store.store_fragment(fragment)
        logger.info(f"Created fragment {fragment_id}")

        return _fragment_to_response(fragment)

    except Exception as e:
        logger.error(f"Failed to create fragment: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{fragment_id}", response_model=FragmentResponse)
async def get_fragment(
    fragment_id: str,
    agent_type: str = Query("generic", description="Agent type"),
    store: RedisFragmentStore = Depends(get_store),
):
    """Get a fragment by ID."""
    try:
        fragment = await store.get_fragment(fragment_id, agent_type)
        return _fragment_to_response(fragment)
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Fragment not found: {fragment_id}")


@router.put("/{fragment_id}", response_model=FragmentResponse)
async def update_fragment(
    fragment_id: str,
    data: FragmentUpdate,
    agent_type: str = Query("generic", description="Agent type"),
    store: RedisFragmentStore = Depends(get_store),
    embedding_client: CloudflareEmbeddingClient = Depends(get_embedding_client),
):
    """Update an existing fragment."""
    try:
        # Get existing fragment
        fragment = await store.get_fragment(fragment_id, agent_type)

        # Update fields
        if data.content is not None:
            fragment.content = data.content
            # Regenerate embedding
            try:
                embeddings = await embedding_client.embed_texts([data.content])
                if embeddings:
                    fragment.embedding = embeddings[0]
            except Exception as e:
                logger.warning(f"Failed to regenerate embedding: {e}")

        if data.priority is not None:
            fragment.priority = FragmentPriority(data.priority)
        if data.version is not None:
            fragment.version = data.version
        if data.tags is not None:
            fragment.tags = data.tags
        if data.keywords is not None:
            fragment.keywords = data.keywords
        if data.channel_whitelist is not None:
            fragment.channel_whitelist = data.channel_whitelist
        if data.modality_whitelist is not None:
            fragment.modality_whitelist = data.modality_whitelist
        if data.tool_dependencies is not None:
            fragment.tool_dependencies = data.tool_dependencies
        if data.requires is not None:
            fragment.requires = data.requires
        if data.conflicts_with is not None:
            fragment.conflicts_with = data.conflicts_with
        if data.merge_strategy is not None:
            fragment.merge_strategy = data.merge_strategy
        if data.section is not None:
            fragment.section = data.section
        if data.is_active is not None:
            fragment.is_active = data.is_active

        await store.update_fragment(fragment)
        logger.info(f"Updated fragment {fragment_id}")

        return _fragment_to_response(fragment)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update fragment: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{fragment_id}", status_code=204)
async def delete_fragment(
    fragment_id: str,
    agent_type: str = Query("generic", description="Agent type"),
    store: RedisFragmentStore = Depends(get_store),
):
    """Delete a fragment (soft delete by setting is_active=False)."""
    try:
        fragment = await store.get_fragment(fragment_id, agent_type)
        fragment.is_active = False
        await store.update_fragment(fragment)
        logger.info(f"Soft-deleted fragment {fragment_id}")
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Fragment not found: {fragment_id}")


@router.get("/", response_model=FragmentListResponse)
async def list_fragments(
    agent_type: Optional[str] = Query(None, description="Filter by agent type"),
    fragment_type: Optional[str] = Query(None, description="Filter by fragment type"),
    is_active: bool = Query(True, description="Filter by active status"),
    limit: int = Query(50, ge=1, le=500, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    store: RedisFragmentStore = Depends(get_store),
):
    """List fragments with filtering and pagination."""
    try:
        frag_type = FragmentType(fragment_type) if fragment_type else None

        fragments = await store.list_fragments(
            agent_type=agent_type,
            fragment_type=frag_type,
            is_active=is_active,
            limit=limit,
            offset=offset,
        )

        return FragmentListResponse(
            fragments=[_fragment_to_response(f) for f in fragments],
            total=len(fragments),  # In production, get actual count
            limit=limit,
            offset=offset,
        )

    except Exception as e:
        logger.error(f"Failed to list fragments: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analytics", response_model=AnalyticsResponse)
async def get_analytics(
    time_window_hours: int = Query(24, ge=1, le=168, description="Time window in hours"),
    analytics: PromptAnalytics = Depends(get_analytics),
):
    """Get fragment usage analytics."""
    try:
        usage_stats = await analytics.get_fragment_usage_stats(
            time_window_hours=time_window_hours
        )
        intent_dist = await analytics.get_intent_distribution(
            time_window_hours=time_window_hours
        )
        error_stats = await analytics.get_error_rate(
            time_window_hours=time_window_hours
        )

        return AnalyticsResponse(
            total_assemblies=usage_stats.get("total_assemblies", 0),
            cache_hits=usage_stats.get("cache_hits", 0),
            cache_hit_rate=usage_stats.get("cache_hit_rate", 0.0),
            avg_fragment_count=usage_stats.get("avg_fragment_count", 0.0),
            avg_token_count=usage_stats.get("avg_token_count", 0.0),
            avg_assembly_time_ms=usage_stats.get("avg_assembly_time_ms", 0.0),
            intent_distribution=intent_dist,
            error_rate=error_stats.get("error_rate", 0.0),
            time_window_hours=time_window_hours,
        )

    except Exception as e:
        logger.error(f"Failed to get analytics: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health", response_model=HealthResponse)
async def health_check(
    config: DynamicPromptConfig = Depends(get_config),
    store: RedisFragmentStore = Depends(get_store),
):
    """Health check endpoint."""
    try:
        # Check Redis connection
        redis_connected = False
        fragment_count = 0
        index_status = "unknown"

        try:
            store.redis.ping()
            redis_connected = True

            # Get fragment count
            fragments = await store.list_fragments(limit=1)
            fragment_count = len(fragments)

            # Check index
            try:
                store.redis.ft(config.fragment_index_name).info()
                index_status = "ready"
            except Exception:
                index_status = "not_created"

        except Exception as e:
            logger.warning(f"Health check failed: {e}")

        return HealthResponse(
            status="healthy" if redis_connected else "unhealthy",
            redis_connected=redis_connected,
            fragment_count=fragment_count,
            index_status=index_status,
            version="1.0.0",
        )

    except Exception as e:
        return HealthResponse(
            status="unhealthy",
            redis_connected=False,
            fragment_count=0,
            index_status="error",
            version="1.0.0",
        )


def create_app(config: Optional[DynamicPromptConfig] = None) -> FastAPI:
    """Create FastAPI application.

    Args:
        config: Plugin configuration.

    Returns:
        Configured FastAPI app.
    """
    global _config, _store, _embedding_client, _analytics

    _config = config or DynamicPromptConfig()
    _store = RedisFragmentStore(_config)
    _embedding_client = CloudflareEmbeddingClient(_config)
    _analytics = PromptAnalytics(_config, _store.redis)

    app = FastAPI(
        title="Fragment Manager API",
        description="API for managing instruction fragments for Dynamic Prompt Injection",
        version="1.0.0",
        lifespan=lifespan,
    )

    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include router with fragments prefix
    app.include_router(router)
    
    # Add root-level health endpoint for convenience
    @app.get("/health")
    async def root_health():
        """Root-level health check."""
        return await health_check(_config, _store)
    
    # Add root-level analytics endpoint for convenience  
    @app.get("/analytics")
    async def root_analytics(time_window_hours: int = Query(24, ge=1, le=168)):
        """Root-level analytics."""
        return await get_analytics(time_window_hours, _analytics)

    return app


def main() -> None:
    """Main entry point for running the API server."""
    import uvicorn
    app = create_app()
    uvicorn.run(app, host="0.0.0.0", port=9099)


if __name__ == "__main__":
    main()
