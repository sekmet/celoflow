"""Fragment Manager API for Dynamic Prompt Injection Plugin.

Provides FastAPI endpoints for fragment CRUD operations and analytics.

Note: When running as __main__ (e.g., with `python -m`), imports are deferred
to avoid circular import warnings.
"""

from .schemas import (
    FragmentCreate,
    FragmentUpdate,
    FragmentResponse,
    FragmentListResponse,
    AnalyticsResponse,
)

# Lazy imports to avoid RuntimeWarning when running as __main__
def get_create_app():
    """Get the create_app function (lazy import)."""
    from .api import create_app
    return create_app

def get_router():
    """Get the router (lazy import)."""
    from .api import router
    return router

# For backwards compatibility, provide direct imports
# These will only cause warnings when running the module directly
try:
    from .api import create_app, router
except ImportError:
    create_app = None
    router = None

__all__ = [
    "create_app",
    "router",
    "get_create_app",
    "get_router",
    "FragmentCreate",
    "FragmentUpdate",
    "FragmentResponse",
    "FragmentListResponse",
    "AnalyticsResponse",
]
