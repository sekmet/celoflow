"""Pydantic schemas for Fragment Manager API."""

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


class FragmentCreate(BaseModel):
    """Schema for creating a new fragment."""

    fragment_id: Optional[str] = Field(None, description="Fragment ID (auto-generated if not provided)")
    agent_type: str = Field("generic", description="Agent type this fragment applies to")
    fragment_type: Literal["core", "domain", "capability", "scenario", "correction"] = Field(
        "domain", description="Type of fragment"
    )
    priority: Literal[25, 50, 75, 100] = Field(50, description="Priority level (25=LOW, 50=MEDIUM, 75=HIGH, 100=CRITICAL)")
    version: str = Field("1.0.0", description="Fragment version")
    content: str = Field(..., description="Instruction content")
    variables: Dict[str, str] = Field(default_factory=dict, description="Template variables")
    tags: List[str] = Field(default_factory=list, description="Semantic tags")
    keywords: List[str] = Field(default_factory=list, description="Keywords for matching")
    channel_whitelist: List[str] = Field(default_factory=list, description="Allowed channels (empty=all)")
    modality_whitelist: List[str] = Field(default_factory=list, description="Allowed modalities (empty=all)")
    tool_dependencies: List[str] = Field(default_factory=list, description="Required tools")
    mcp_dependencies: List[str] = Field(default_factory=list, description="Required MCP servers")
    requires: List[str] = Field(default_factory=list, description="Required fragment IDs")
    conflicts_with: List[str] = Field(default_factory=list, description="Conflicting fragment IDs")
    merge_strategy: Literal["append", "prepend", "replace", "merge"] = Field("append", description="Merge strategy")
    section: Optional[str] = Field(None, description="Target section in prompt")
    ttl_seconds: Optional[int] = Field(None, description="Auto-expire time in seconds")

    class Config:
        json_schema_extra = {
            "example": {
                "agent_type": "finance_analyst",
                "fragment_type": "domain",
                "priority": 75,
                "content": "When analyzing financial data, always verify data sources and check for missing values.",
                "tags": ["finance", "data-analysis"],
                "keywords": ["financial", "analysis", "data"],
            }
        }


class FragmentUpdate(BaseModel):
    """Schema for updating an existing fragment."""

    content: Optional[str] = Field(None, description="Updated instruction content")
    priority: Optional[Literal[25, 50, 75, 100]] = Field(None, description="Updated priority")
    version: Optional[str] = Field(None, description="Updated version")
    tags: Optional[List[str]] = Field(None, description="Updated tags")
    keywords: Optional[List[str]] = Field(None, description="Updated keywords")
    channel_whitelist: Optional[List[str]] = Field(None, description="Updated channel whitelist")
    modality_whitelist: Optional[List[str]] = Field(None, description="Updated modality whitelist")
    tool_dependencies: Optional[List[str]] = Field(None, description="Updated tool dependencies")
    requires: Optional[List[str]] = Field(None, description="Updated required fragments")
    conflicts_with: Optional[List[str]] = Field(None, description="Updated conflicting fragments")
    merge_strategy: Optional[Literal["append", "prepend", "replace", "merge"]] = Field(None, description="Updated merge strategy")
    section: Optional[str] = Field(None, description="Updated section")
    is_active: Optional[bool] = Field(None, description="Active status")


class FragmentResponse(BaseModel):
    """Schema for fragment response."""

    fragment_id: str
    agent_type: str
    fragment_type: str
    priority: int
    version: str
    content: str
    variables: Dict[str, str]
    tags: List[str]
    keywords: List[str]
    channel_whitelist: List[str]
    modality_whitelist: List[str]
    tool_dependencies: List[str]
    mcp_dependencies: List[str]
    requires: List[str]
    conflicts_with: List[str]
    merge_strategy: str
    section: Optional[str]
    usage_count: int
    acceptance_rate: float
    avg_retry_count: float
    avg_token_contribution: int
    last_used: Optional[str]
    created_at: str
    updated_at: str
    created_by: str
    is_active: bool
    ttl_seconds: Optional[int]


class FragmentListResponse(BaseModel):
    """Schema for fragment list response."""

    fragments: List[FragmentResponse]
    total: int
    limit: int
    offset: int


class AnalyticsResponse(BaseModel):
    """Schema for analytics response."""

    total_assemblies: int
    cache_hits: int
    cache_hit_rate: float
    avg_fragment_count: float
    avg_token_count: float
    avg_assembly_time_ms: float
    intent_distribution: Dict[str, int]
    error_rate: float
    time_window_hours: int


class HealthResponse(BaseModel):
    """Schema for health check response."""

    status: str
    redis_connected: bool
    fragment_count: int
    index_status: str
    version: str


class ErrorResponse(BaseModel):
    """Schema for error response."""

    error: str
    detail: Optional[str] = None
    code: Optional[str] = None
