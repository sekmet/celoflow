"""Configuration for Dynamic Prompt Injection Plugin."""

import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List


class Environment(Enum):
    """Environment configuration."""

    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


@dataclass
class DynamicPromptConfig:
    """Configuration for Dynamic Prompt Injection Plugin.

    Attributes:
        redis_url: Redis connection URL (default: redis://localhost:6389).
        redis_password: Redis password (optional).
        redis_db: Redis database number (default: 0).

        cloudflare_api_token: Cloudflare Workers AI API token.
        cloudflare_account_id: Cloudflare account ID.
        embedding_model: Embedding model to use (default: @cf/qwen/qwen3-embedding-0.6b).
        embedding_dimensions: Embedding vector dimensions (default: 1024).

        agent_type: Agent type identifier for fragment filtering (default: generic).
        token_budget: Maximum tokens for assembled prompt (default: 2000).
        enable_prompt_cache: Enable prompt caching (default: True).
        enable_feedback_loop: Enable feedback-driven fragment reranking (default: True).
        cache_ttl: Cache time-to-live in seconds (default: 3600).

        fragment_index_name: Redis index name for fragments (default: fragment_idx).
        fragment_prefix: Redis key prefix for fragments (default: fragment:).

        core_threshold: Similarity threshold for core fragments (default: 1.0).
        domain_threshold: Similarity threshold for domain fragments (default: 0.75).
        capability_threshold: Similarity threshold for capability fragments (default: 0.70).
        scenario_threshold: Similarity threshold for scenario fragments (default: 0.65).

        enable_agentfs_integration: Enable AgentFS memory integration (default: False).
        agentfs_api_url: AgentFS API URL (optional).
        agentfs_api_key: AgentFS API key (optional).

        environment: Environment configuration (default: development).
        timeout: Request timeout in seconds (default: 30.0).
        max_retries: Maximum retry attempts (default: 3).
        retry_delay: Initial retry delay in seconds (default: 1.0).

        enable_monitoring: Enable Prometheus metrics (default: True).
        enable_ab_testing: Enable A/B testing framework (default: False).
        enable_fragment_evolution: Enable fragment evolution engine (default: False).
        enable_multi_agent_sharing: Enable multi-agent fragment sharing (default: False).
    """

    # Redis settings
    redis_url: Optional[str] = None
    redis_password: Optional[str] = None
    redis_db: int = 0

    # Cloudflare Workers AI settings
    cloudflare_api_token: Optional[str] = None
    cloudflare_account_id: Optional[str] = None
    embedding_model: str = "@cf/qwen/qwen3-embedding-0.6b"
    embedding_dimensions: int = 1024

    # Plugin behavior settings
    agent_type: str = "generic"
    token_budget: int = 2000
    enable_prompt_cache: bool = True
    enable_feedback_loop: bool = True
    cache_ttl: int = 3600

    # Fragment index settings
    fragment_index_name: str = "fragment_idx"
    fragment_prefix: str = "fragment:"

    # Similarity thresholds
    core_threshold: float = 1.0
    domain_threshold: float = 0.75
    capability_threshold: float = 0.70
    scenario_threshold: float = 0.65

    # AgentFS integration
    enable_agentfs_integration: bool = False
    agentfs_api_url: Optional[str] = None
    agentfs_api_key: Optional[str] = None

    # Environment settings
    environment: Environment = Environment.DEVELOPMENT
    timeout: float = 30.0
    max_retries: int = 3
    retry_delay: float = 1.0

    # Advanced features
    enable_monitoring: bool = True
    enable_ab_testing: bool = False
    enable_fragment_evolution: bool = False
    enable_multi_agent_sharing: bool = False

    # Feature flags for gradual rollout
    rollout_percentage: float = 100.0
    feature_flags: dict = field(default_factory=dict)

    def __post_init__(self):
        """Resolve configuration from environment variables."""
        # Redis URL
        if self.redis_url is None:
            self.redis_url = os.getenv(
                "DYNAMIC_PROMPT_REDIS_URL",
                os.getenv("REDIS_URL", "redis://localhost:6389"),
            )

        if self.redis_password is None:
            self.redis_password = os.getenv("DYNAMIC_PROMPT_REDIS_PASSWORD")

        # Cloudflare settings
        if self.cloudflare_api_token is None:
            self.cloudflare_api_token = os.getenv(
                "CLOUDFLARE_API_KEY",
                os.getenv("CLOUDFLARE_API_TOKEN"),
            )

        if self.cloudflare_account_id is None:
            self.cloudflare_account_id = os.getenv("CLOUDFLARE_ACCOUNT_ID")

        # AgentFS settings
        if self.agentfs_api_url is None:
            self.agentfs_api_url = os.getenv("AGENTFS_API_URL")

        if self.agentfs_api_key is None:
            self.agentfs_api_key = os.getenv("AGENTFS_API_KEY")

        # Normalize redis URL (remove trailing slash)
        if self.redis_url and self.redis_url.endswith("/"):
            self.redis_url = self.redis_url.rstrip("/")

    @property
    def has_cloudflare_credentials(self) -> bool:
        """Check if Cloudflare credentials are configured."""
        return bool(self.cloudflare_api_token and self.cloudflare_account_id)

    @property
    def has_agentfs_credentials(self) -> bool:
        """Check if AgentFS credentials are configured."""
        return bool(self.agentfs_api_url)

    @property
    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.environment == Environment.PRODUCTION

    def get_cloudflare_api_url(self, model: str = None) -> str:
        """Get Cloudflare Workers AI API URL for a model.

        Args:
            model: Model name (default: uses configured embedding_model).

        Returns:
            Full API URL for the model.
        """
        model = model or self.embedding_model
        return (
            f"https://api.cloudflare.com/client/v4/accounts/"
            f"{self.cloudflare_account_id}/ai/run/{model}"
        )

    def validate(self) -> List[str]:
        """Validate configuration and return list of issues.

        Returns:
            List of validation error messages (empty if valid).
        """
        issues = []

        if not self.redis_url:
            issues.append("Redis URL is required")

        if not self.has_cloudflare_credentials:
            issues.append(
                "Cloudflare credentials (api_token and account_id) are required"
            )

        if self.token_budget <= 0:
            issues.append("Token budget must be positive")

        if self.cache_ttl <= 0:
            issues.append("Cache TTL must be positive")

        if not (0.0 <= self.domain_threshold <= 1.0):
            issues.append("Domain threshold must be between 0 and 1")

        if not (0.0 <= self.rollout_percentage <= 100.0):
            issues.append("Rollout percentage must be between 0 and 100")

        return issues
