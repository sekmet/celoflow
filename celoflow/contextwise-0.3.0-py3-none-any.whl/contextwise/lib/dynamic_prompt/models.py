"""Data models for Dynamic Prompt Injection Plugin."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, List, Literal, Optional, Any
import json


class FragmentType(Enum):
    """Types of instruction fragments."""

    CORE = "core"  # Always included (role, safety)
    DOMAIN = "domain"  # Domain-specific (finance, health, tech)
    CAPABILITY = "capability"  # Tool/feature instructions
    SCENARIO = "scenario"  # Context-specific guidance
    CORRECTION = "correction"  # Error prevention patterns


class FragmentPriority(Enum):
    """Priority levels for fragments."""

    CRITICAL = 100  # Must include (safety, core role)
    HIGH = 75  # Include if relevant
    MEDIUM = 50  # Include if tokens available
    LOW = 25  # Include only if abundant tokens


@dataclass
class InstructionFragment:
    """Atomic unit of system instruction.

    Stored as RedisJSON at key: fragment:{agent_type}:{fragment_id}

    Attributes:
        fragment_id: Unique identifier (UUID).
        agent_type: Agent type this fragment applies to.
        fragment_type: Type of fragment (core, domain, capability, scenario, correction).
        priority: Priority level (CRITICAL, HIGH, MEDIUM, LOW).
        version: Fragment version.
        content: Actual instruction text.
        variables: Template variables (e.g., {company_name}, {timezone}).
        embedding: 1024-dim vector from embedding model.
        tags: Semantic tags (e.g., ["python", "pandas", "data-analysis"]).
        keywords: Keywords for matching (e.g., ["filter", "aggregate", "SQL"]).
        channel_whitelist: Channels where this fragment applies (empty = all).
        modality_whitelist: Modalities where this fragment applies (empty = all).
        tool_dependencies: Tools this fragment relates to.
        mcp_dependencies: MCP servers this fragment relates to.
        requires: Fragment IDs that must be included with this one.
        conflicts_with: Fragment IDs that cannot coexist with this one.
        merge_strategy: How to merge with other fragments.
        section: Target section in the assembled prompt.
        usage_count: Number of times this fragment has been used.
        acceptance_rate: User approval rate when this fragment included.
        avg_retry_count: Average retry count when this fragment included.
        avg_token_contribution: Estimated tokens this fragment adds.
        last_used: ISO timestamp of last use.
        created_at: ISO timestamp of creation.
        updated_at: ISO timestamp of last update.
        created_by: Creator identifier.
        is_active: Whether this fragment is active.
        ttl_seconds: Auto-expire time for session-specific fragments.
    """

    # Identity
    fragment_id: str
    agent_type: str = "generic"
    fragment_type: FragmentType = FragmentType.DOMAIN
    priority: FragmentPriority = FragmentPriority.MEDIUM
    version: str = "1.0.0"

    # Content
    content: str = ""
    variables: Dict[str, str] = field(default_factory=dict)

    # Semantic indexing
    embedding: List[float] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)

    # Context matching
    channel_whitelist: List[str] = field(default_factory=list)
    modality_whitelist: List[str] = field(default_factory=list)
    tool_dependencies: List[str] = field(default_factory=list)
    mcp_dependencies: List[str] = field(default_factory=list)

    # Composition rules
    requires: List[str] = field(default_factory=list)
    conflicts_with: List[str] = field(default_factory=list)
    merge_strategy: Literal["append", "prepend", "replace", "merge"] = "append"
    section: Optional[str] = None

    # Performance tracking
    usage_count: int = 0
    acceptance_rate: float = 0.5
    avg_retry_count: float = 1.0
    avg_token_contribution: int = 50
    last_used: Optional[str] = None

    # Lifecycle
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    created_by: str = "system"
    is_active: bool = True
    ttl_seconds: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for Redis storage."""
        return {
            "fragment_id": self.fragment_id,
            "agent_type": self.agent_type,
            "fragment_type": self.fragment_type.value,
            "priority": self.priority.value,
            "version": self.version,
            "content": self.content,
            "variables": self.variables,
            "embedding": self.embedding,
            "tags": self.tags,
            "keywords": self.keywords,
            "channel_whitelist": self.channel_whitelist,
            "modality_whitelist": self.modality_whitelist,
            "tool_dependencies": self.tool_dependencies,
            "mcp_dependencies": self.mcp_dependencies,
            "requires": self.requires,
            "conflicts_with": self.conflicts_with,
            "merge_strategy": self.merge_strategy,
            "section": self.section,
            "usage_count": self.usage_count,
            "acceptance_rate": self.acceptance_rate,
            "avg_retry_count": self.avg_retry_count,
            "avg_token_contribution": self.avg_token_contribution,
            "last_used": self.last_used,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "created_by": self.created_by,
            "is_active": self.is_active,
            "ttl_seconds": self.ttl_seconds,
        }

    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "InstructionFragment":
        """Create from dictionary."""
        # Handle enum conversion
        fragment_type = data.get("fragment_type", "domain")
        if isinstance(fragment_type, str):
            fragment_type = FragmentType(fragment_type)

        priority = data.get("priority", 50)
        if isinstance(priority, int):
            priority = FragmentPriority(priority)
        elif isinstance(priority, str):
            priority = FragmentPriority[priority.upper()]

        return cls(
            fragment_id=data["fragment_id"],
            agent_type=data.get("agent_type", "generic"),
            fragment_type=fragment_type,
            priority=priority,
            version=data.get("version", "1.0.0"),
            content=data.get("content", ""),
            variables=data.get("variables", {}),
            embedding=data.get("embedding", []),
            tags=data.get("tags", []),
            keywords=data.get("keywords", []),
            channel_whitelist=data.get("channel_whitelist", []),
            modality_whitelist=data.get("modality_whitelist", []),
            tool_dependencies=data.get("tool_dependencies", []),
            mcp_dependencies=data.get("mcp_dependencies", []),
            requires=data.get("requires", []),
            conflicts_with=data.get("conflicts_with", []),
            merge_strategy=data.get("merge_strategy", "append"),
            section=data.get("section"),
            usage_count=data.get("usage_count", 0),
            acceptance_rate=data.get("acceptance_rate", 0.5),
            avg_retry_count=data.get("avg_retry_count", 1.0),
            avg_token_contribution=data.get("avg_token_contribution", 50),
            last_used=data.get("last_used"),
            created_at=data.get("created_at", datetime.utcnow().isoformat()),
            updated_at=data.get("updated_at", datetime.utcnow().isoformat()),
            created_by=data.get("created_by", "system"),
            is_active=data.get("is_active", True),
            ttl_seconds=data.get("ttl_seconds"),
        )

    @classmethod
    def from_json(cls, json_str: str) -> "InstructionFragment":
        """Create from JSON string."""
        return cls.from_dict(json.loads(json_str))


@dataclass
class UserIntent:
    """Structured representation of user's request intent.

    Attributes:
        embedding: Embedding vector for the user message.
        task_type: Type of task (question_answering, coding, creative, analysis).
        domain_signals: Detected domains (finance, healthcare, legal, technology).
        modality: Output modality (text, voice, code).
        complexity: Task complexity (simple, medium, complex).
        requires_tools: Tools predicted to be needed.
        urgency: Urgency level (low, medium, high).
        confidence: Confidence score for the intent analysis.
        raw_message: Original user message.
    """

    embedding: List[float] = field(default_factory=list)
    task_type: str = "question_answering"
    domain_signals: List[str] = field(default_factory=list)
    modality: str = "text"
    complexity: Literal["simple", "medium", "complex"] = "simple"
    requires_tools: List[str] = field(default_factory=list)
    urgency: Literal["low", "medium", "high"] = "low"
    confidence: float = 0.5
    raw_message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "embedding": self.embedding,
            "task_type": self.task_type,
            "domain_signals": self.domain_signals,
            "modality": self.modality,
            "complexity": self.complexity,
            "requires_tools": self.requires_tools,
            "urgency": self.urgency,
            "confidence": self.confidence,
            "raw_message": self.raw_message,
        }


@dataclass
class AssemblyMetrics:
    """Metrics for prompt assembly performance.

    Attributes:
        fragment_count: Number of fragments assembled.
        total_tokens: Estimated total tokens in assembled prompt.
        cache_hit: Whether the prompt was retrieved from cache.
        retrieval_time_ms: Time spent retrieving fragments.
        assembly_time_ms: Time spent assembling prompt.
        total_time_ms: Total processing time.
        checksum: Checksum of the assembled prompt.
        fragment_ids: IDs of fragments used.
        intent_summary: Summary of detected intent.
    """

    fragment_count: int = 0
    total_tokens: int = 0
    cache_hit: bool = False
    retrieval_time_ms: float = 0.0
    assembly_time_ms: float = 0.0
    total_time_ms: float = 0.0
    checksum: str = ""
    fragment_ids: List[str] = field(default_factory=list)
    intent_summary: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "fragment_count": self.fragment_count,
            "total_tokens": self.total_tokens,
            "cache_hit": self.cache_hit,
            "retrieval_time_ms": self.retrieval_time_ms,
            "assembly_time_ms": self.assembly_time_ms,
            "total_time_ms": self.total_time_ms,
            "checksum": self.checksum,
            "fragment_ids": self.fragment_ids,
            "intent_summary": self.intent_summary,
        }


@dataclass
class FragmentScore:
    """Score for a fragment during ranking.

    Attributes:
        fragment: The instruction fragment.
        priority_score: Normalized priority score (0-1).
        acceptance_score: Acceptance rate score (0-1).
        usage_score: Usage frequency score (0-1).
        retry_score: Inverse retry count score (0-1).
        similarity_score: Vector similarity score (0-1).
        total_score: Composite score.
    """

    fragment: InstructionFragment
    priority_score: float = 0.0
    acceptance_score: float = 0.0
    usage_score: float = 0.0
    retry_score: float = 0.0
    similarity_score: float = 0.0
    total_score: float = 0.0


@dataclass
class ABTestVariant:
    """A/B test variant configuration.

    Attributes:
        variant_id: Unique identifier for the variant.
        name: Human-readable name.
        fragment_ids: Fragment IDs to use in this variant.
        weight: Weight for assignment (0-100).
        is_control: Whether this is the control variant.
    """

    variant_id: str
    name: str
    fragment_ids: List[str] = field(default_factory=list)
    weight: float = 50.0
    is_control: bool = False


@dataclass
class ABTestExperiment:
    """A/B test experiment configuration.

    Attributes:
        experiment_id: Unique identifier for the experiment.
        name: Human-readable name.
        description: Description of the experiment.
        variants: List of variants.
        start_date: Experiment start date (ISO format).
        end_date: Experiment end date (ISO format).
        is_active: Whether the experiment is active.
        metrics: Tracked metrics.
    """

    experiment_id: str
    name: str
    description: str = ""
    variants: List[ABTestVariant] = field(default_factory=list)
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    is_active: bool = True
    metrics: Dict[str, Any] = field(default_factory=dict)
