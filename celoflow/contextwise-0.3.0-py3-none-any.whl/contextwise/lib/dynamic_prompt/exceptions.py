"""Custom exceptions for Dynamic Prompt Injection Plugin."""


class DynamicPromptError(Exception):
    """Base exception for dynamic prompt injection errors."""

    pass


class FragmentNotFoundError(DynamicPromptError):
    """Raised when a fragment cannot be found in the store."""

    def __init__(self, fragment_id: str):
        self.fragment_id = fragment_id
        super().__init__(f"Fragment not found: {fragment_id}")


class EmbeddingError(DynamicPromptError):
    """Raised when embedding generation fails."""

    def __init__(self, message: str, original_error: Exception = None):
        self.original_error = original_error
        super().__init__(f"Embedding error: {message}")


class RedisConnectionError(DynamicPromptError):
    """Raised when Redis connection fails."""

    def __init__(self, message: str, original_error: Exception = None):
        self.original_error = original_error
        super().__init__(f"Redis connection error: {message}")


class CacheError(DynamicPromptError):
    """Raised when cache operations fail."""

    def __init__(self, message: str, original_error: Exception = None):
        self.original_error = original_error
        super().__init__(f"Cache error: {message}")


class IntentAnalysisError(DynamicPromptError):
    """Raised when intent analysis fails."""

    def __init__(self, message: str, original_error: Exception = None):
        self.original_error = original_error
        super().__init__(f"Intent analysis error: {message}")


class FragmentRetrievalError(DynamicPromptError):
    """Raised when fragment retrieval fails."""

    def __init__(self, message: str, original_error: Exception = None):
        self.original_error = original_error
        super().__init__(f"Fragment retrieval error: {message}")


class PromptAssemblyError(DynamicPromptError):
    """Raised when prompt assembly fails."""

    def __init__(self, message: str, original_error: Exception = None):
        self.original_error = original_error
        super().__init__(f"Prompt assembly error: {message}")


class ConfigurationError(DynamicPromptError):
    """Raised when configuration is invalid."""

    def __init__(self, message: str):
        super().__init__(f"Configuration error: {message}")
