"""Fragment Retrieval Engine for Dynamic Prompt Injection Plugin.

Multi-stage fragment retrieval with adaptive ranking.
"""

import logging
import math
from functools import reduce
from typing import Any, Dict, List, Optional, Set

from .config import DynamicPromptConfig
from .exceptions import FragmentRetrievalError
from .models import (
    FragmentPriority,
    FragmentScore,
    FragmentType,
    InstructionFragment,
    UserIntent,
)
from .redis_store import RedisFragmentStore

logger = logging.getLogger(__name__)


class FragmentRetrievalEngine:
    """Multi-stage fragment retrieval with adaptive ranking.

    Combines vector similarity, rule-based filtering, and performance metrics.

    Retrieval stages:
    1. Core fragments (mandatory) - always included
    2. Domain fragments (vector search) - semantic matching
    3. Capability fragments (tool/channel matching)
    4. Scenario fragments (session-specific guidance)
    """

    def __init__(
        self,
        config: DynamicPromptConfig,
        store: Optional[RedisFragmentStore] = None,
        agentfs_client: Optional[Any] = None,
    ):
        """Initialize the fragment retrieval engine.

        Args:
            config: Plugin configuration.
            store: Redis fragment store.
            agentfs_client: AgentFS memory client (optional).
        """
        self.config = config
        self.store = store or RedisFragmentStore(config)
        self.agentfs = agentfs_client

    async def retrieve_fragments(
        self,
        intent: UserIntent,
        context: Any,
        agent_type: str = "generic",
        token_budget: int = 2000,
    ) -> List[InstructionFragment]:
        """Multi-stage retrieval pipeline.

        Args:
            intent: User intent with embedding and signals.
            context: Agent context.
            agent_type: Agent type for filtering.
            token_budget: Maximum tokens for assembled prompt.

        Returns:
            List of selected fragments within token budget.
        """
        try:
            selected_fragments: List[InstructionFragment] = []

            # Stage 1: Core fragments (always include)
            core_fragments = await self._retrieve_core_fragments(agent_type)
            selected_fragments.extend(core_fragments)
            logger.debug(f"Retrieved {len(core_fragments)} core fragments")

            # Stage 2: Domain fragments (vector search)
            if intent.embedding:
                domain_fragments = await self._retrieve_domain_fragments(
                    intent=intent,
                    agent_type=agent_type,
                    k=10,
                )
                selected_fragments.extend(domain_fragments)
                logger.debug(f"Retrieved {len(domain_fragments)} domain fragments")

            # Stage 3: Capability fragments (tool/channel matching)
            capability_fragments = await self._retrieve_capability_fragments(
                intent=intent,
                context=context,
                agent_type=agent_type,
            )
            selected_fragments.extend(capability_fragments)
            logger.debug(f"Retrieved {len(capability_fragments)} capability fragments")

            # Stage 4: Scenario fragments (session-specific guidance)
            scenario_fragments = await self._retrieve_scenario_fragments(
                context=context,
                agent_type=agent_type,
            )
            selected_fragments.extend(scenario_fragments)
            logger.debug(f"Retrieved {len(scenario_fragments)} scenario fragments")

            # Deduplicate by fragment_id
            unique_fragments = list(
                {f.fragment_id: f for f in selected_fragments}.values()
            )

            # Rank by composite score
            ranked_fragments = self._rank_fragments(
                fragments=unique_fragments,
                intent=intent,
            )

            # Apply token budget constraint
            final_fragments = self._apply_token_budget(
                fragments=ranked_fragments,
                budget=token_budget,
            )

            logger.info(
                f"Selected {len(final_fragments)} fragments "
                f"(from {len(unique_fragments)} unique, {len(selected_fragments)} total)"
            )

            return final_fragments

        except Exception as e:
            logger.error(f"Fragment retrieval failed: {e}", exc_info=True)
            raise FragmentRetrievalError(str(e), original_error=e)

    async def _retrieve_core_fragments(
        self,
        agent_type: str,
    ) -> List[InstructionFragment]:
        """Retrieve mandatory core fragments.

        Core fragments include:
        - Agent role definition
        - Safety guidelines
        - Output format constraints

        Args:
            agent_type: Agent type filter.

        Returns:
            List of core fragments sorted by priority.
        """
        fragments = await self.store.get_fragments_by_type(
            fragment_type=FragmentType.CORE,
            agent_type=agent_type,
            limit=20,
        )

        # Sort by priority descending
        fragments.sort(key=lambda f: f.priority.value, reverse=True)

        return fragments

    async def _retrieve_domain_fragments(
        self,
        intent: UserIntent,
        agent_type: str,
        k: int = 10,
    ) -> List[InstructionFragment]:
        """Retrieve domain-specific fragments using vector similarity.

        Args:
            intent: User intent with embedding.
            agent_type: Agent type filter.
            k: Maximum results.

        Returns:
            List of domain fragments above similarity threshold.
        """
        if not intent.embedding:
            return []

        # Search with domain tags if available
        tags = intent.domain_signals if intent.domain_signals else None

        results = await self.store.search_fragments(
            query_embedding=intent.embedding,
            agent_type=agent_type,
            fragment_type=FragmentType.DOMAIN.value,
            tags=tags,
            limit=k,
            min_score=self.config.domain_threshold,
        )

        return [fragment for fragment, score in results]

    async def _retrieve_capability_fragments(
        self,
        intent: UserIntent,
        context: Any,
        agent_type: str,
    ) -> List[InstructionFragment]:
        """Retrieve capability fragments based on tools and channel.

        Args:
            intent: User intent with tool requirements.
            context: Agent context with channel info.
            agent_type: Agent type filter.

        Returns:
            List of capability fragments matching context.
        """
        fragments = await self.store.get_fragments_by_type(
            fragment_type=FragmentType.CAPABILITY,
            agent_type=agent_type,
            limit=50,
        )

        # Post-filter by tool dependencies and channel/modality whitelist
        filtered = []
        channel = getattr(context, "channel", "api") if context else "api"

        for fragment in fragments:
            # Check tool dependencies
            if fragment.tool_dependencies:
                if not any(
                    tool in intent.requires_tools
                    for tool in fragment.tool_dependencies
                ):
                    continue

            # Check channel whitelist
            if fragment.channel_whitelist:
                if channel not in fragment.channel_whitelist:
                    continue

            # Check modality whitelist
            if fragment.modality_whitelist:
                if intent.modality not in fragment.modality_whitelist:
                    continue

            filtered.append(fragment)

        return filtered

    async def _retrieve_scenario_fragments(
        self,
        context: Any,
        agent_type: str,
    ) -> List[InstructionFragment]:
        """Retrieve session-specific scenario fragments.

        Args:
            context: Agent context.
            agent_type: Agent type filter.

        Returns:
            List of scenario/correction fragments.
        """
        fragments: List[InstructionFragment] = []

        # Get scenario fragments
        scenario_frags = await self.store.get_fragments_by_type(
            fragment_type=FragmentType.SCENARIO,
            agent_type=agent_type,
            limit=20,
        )
        fragments.extend(scenario_frags)

        # Get correction fragments
        correction_frags = await self.store.get_fragments_by_type(
            fragment_type=FragmentType.CORRECTION,
            agent_type=agent_type,
            limit=20,
        )
        fragments.extend(correction_frags)

        # Query AgentFS for session-specific guidance if available
        if self.agentfs and context:
            try:
                session_id = getattr(context, "session_id", None)
                user_id = getattr(context, "user_id", None)

                if session_id or user_id:
                    guidance = await self.agentfs.search_memory(
                        query="error corrections user preferences guidance",
                        session_id=session_id,
                        limit=5,
                    )
                    # Could create dynamic fragments from guidance here
                    logger.debug(f"Retrieved {len(guidance or [])} guidance items from AgentFS")
            except Exception as e:
                logger.warning(f"Failed to get AgentFS guidance: {e}")

        return fragments

    def _rank_fragments(
        self,
        fragments: List[InstructionFragment],
        intent: UserIntent,
    ) -> List[InstructionFragment]:
        """Rank fragments by composite score.

        Score = (
            0.3 * priority_score +
            0.3 * acceptance_rate +
            0.2 * usage_frequency_score +
            0.2 * (1 - normalized_retry_count)
        )

        Args:
            fragments: Fragments to rank.
            intent: User intent for context.

        Returns:
            Fragments sorted by score descending.
        """
        if not fragments:
            return []

        # Calculate normalization factors
        max_usage = max(f.usage_count for f in fragments) or 1
        max_retry = max(f.avg_retry_count for f in fragments) or 1

        scored_fragments: List[FragmentScore] = []

        for fragment in fragments:
            # Normalize priority to [0, 1]
            priority_score = fragment.priority.value / 100.0

            # Acceptance rate is already [0, 1]
            acceptance_score = fragment.acceptance_rate

            # Normalize usage count (log scale)
            usage_score = math.log1p(fragment.usage_count) / math.log1p(max_usage)

            # Invert retry count (lower is better)
            retry_score = 1 - (fragment.avg_retry_count / max_retry)

            # Composite score
            total_score = (
                0.3 * priority_score
                + 0.3 * acceptance_score
                + 0.2 * usage_score
                + 0.2 * retry_score
            )

            scored_fragments.append(
                FragmentScore(
                    fragment=fragment,
                    priority_score=priority_score,
                    acceptance_score=acceptance_score,
                    usage_score=usage_score,
                    retry_score=retry_score,
                    total_score=total_score,
                )
            )

        # Sort by total score descending
        scored_fragments.sort(key=lambda x: x.total_score, reverse=True)

        return [sf.fragment for sf in scored_fragments]

    def _apply_token_budget(
        self,
        fragments: List[InstructionFragment],
        budget: int,
    ) -> List[InstructionFragment]:
        """Select fragments within token budget.

        Respects:
        1. Critical priority fragments (must include)
        2. Fragment dependencies (requires)
        3. Fragment conflicts (conflicts_with)

        Args:
            fragments: Ranked fragments.
            budget: Token budget.

        Returns:
            Selected fragments within budget.
        """
        selected: List[InstructionFragment] = []
        selected_ids: Set[str] = set()
        token_count = 0

        # First pass: include all CRITICAL priority fragments
        for fragment in fragments:
            if fragment.priority == FragmentPriority.CRITICAL:
                selected.append(fragment)
                selected_ids.add(fragment.fragment_id)
                token_count += fragment.avg_token_contribution

        # Second pass: include fragments with available budget
        for fragment in fragments:
            if fragment.fragment_id in selected_ids:
                continue

            # Check token budget
            if token_count + fragment.avg_token_contribution > budget:
                continue

            # Check dependencies
            if fragment.requires:
                missing_deps = set(fragment.requires) - selected_ids
                if missing_deps:
                    # Try to include dependencies first
                    deps_included = True
                    for dep_id in missing_deps:
                        dep_fragment = next(
                            (f for f in fragments if f.fragment_id == dep_id),
                            None,
                        )
                        if (
                            dep_fragment
                            and token_count + dep_fragment.avg_token_contribution <= budget
                        ):
                            selected.append(dep_fragment)
                            selected_ids.add(dep_id)
                            token_count += dep_fragment.avg_token_contribution
                        else:
                            # Can't satisfy dependency
                            deps_included = False
                            break

                    if not deps_included:
                        continue

            # Check conflicts
            if fragment.conflicts_with:
                if any(
                    conflict_id in selected_ids
                    for conflict_id in fragment.conflicts_with
                ):
                    continue

            # Add fragment
            selected.append(fragment)
            selected_ids.add(fragment.fragment_id)
            token_count += fragment.avg_token_contribution

        logger.debug(
            f"Token budget: {token_count}/{budget}, "
            f"selected {len(selected)} fragments"
        )

        return selected
