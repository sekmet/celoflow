"""Dynamic Prompt Injection Plugin main implementation.

Integrates all components to provide dynamic system instruction assembly.
"""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from agents import Agent, RunResult, function_tool, RunContextWrapper

from ..base import AgentPlugin
from ..context import AgentContext
from .cloudflare_client import CloudflareEmbeddingClient
from .config import DynamicPromptConfig
from .fragment_retrieval import FragmentRetrievalEngine
from .intent_analyzer import IntentAnalyzer
from .models import AssemblyMetrics, InstructionFragment
from .prompt_builder import DynamicPromptBuilder
from .redis_store import RedisFragmentStore

logger = logging.getLogger(__name__)


class DynamicPromptInjectionPlugin(AgentPlugin[AgentContext]):
    """Plugin that dynamically injects system instructions based on context.

    Integrates with Redis fragment store and Cloudflare Workers AI for embeddings.

    Attributes:
        id: Plugin identifier.
        name: Human-readable name.
        version: Plugin version.
        config: Plugin configuration.
    """

    id: str = "dynamic_prompt_injection"
    name: str = "Dynamic Prompt Injection"
    version: str = "1.0.0"

    def __init__(
        self,
        config: Optional[DynamicPromptConfig] = None,
        embedding_client: Optional[CloudflareEmbeddingClient] = None,
        agentfs_client: Optional[Any] = None,
    ):
        """Initialize the dynamic prompt injection plugin.

        Args:
            config: Plugin configuration.
            embedding_client: Cloudflare embedding client.
            agentfs_client: AgentFS memory client (optional).
        """
        self.config = config or DynamicPromptConfig()

        # Initialize clients
        self.embedding_client = embedding_client or CloudflareEmbeddingClient(self.config)
        self.agentfs = agentfs_client

        # Initialize components
        self.store = RedisFragmentStore(self.config)
        self.intent_analyzer = IntentAnalyzer(
            config=self.config,
            embedding_client=self.embedding_client,
            agentfs_client=self.agentfs,
        )
        self.retrieval_engine = FragmentRetrievalEngine(
            config=self.config,
            store=self.store,
            agentfs_client=self.agentfs,
        )
        self.prompt_builder = DynamicPromptBuilder(
            config=self.config,
            redis_client=self.store.redis,
        )

        # Store original instructions as fallback
        self._original_instructions: Optional[str] = None

        # Telemetry stream
        self._telemetry_stream = "agent:prompt_injection:events"

        logger.info(
            f"DynamicPromptInjectionPlugin initialized "
            f"(agent_type={self.config.agent_type}, token_budget={self.config.token_budget})"
        )

    def dependencies(self) -> List[str]:
        """Return plugin dependencies.

        Returns:
            List of plugin IDs this plugin depends on.
        """
        # Optional dependency on AgentFS memory plugin
        return []

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Configure agent with dynamic prompt injection.

        Stores original instructions and injects management tools.

        Args:
            agent: Agent to configure.

        Returns:
            Configured agent.
        """
        # Store reference to original instructions as fallback
        self._original_instructions = agent.instructions

        # Add management tools
        new_tools = list(agent.tools)
        new_tools.extend(self._create_management_tools())

        return agent.clone(tools=new_tools)

    async def on_before_run_async(
        self,
        context: AgentContext,
        input: str,
    ) -> None:
        """Before LLM execution: dynamically assemble system instructions.

        Flow:
        1. Get conversation history from AgentFS (if available)
        2. Analyze user intent
        3. Retrieve relevant fragments
        4. Build dynamic prompt
        5. Inject into context metadata
        6. Log telemetry

        Args:
            context: Agent context.
            input: User input message.
        """
        await self._before_run_async(context, input)

    def on_before_run(
        self,
        context: AgentContext,
        input: str,
    ) -> None:
        """Sync fallback - sets fallback instructions.

        Note: This plugin requires async execution. When called synchronously,
        it falls back to original instructions.

        Args:
            context: Agent context.
            input: User input message.
        """
        # Sync context: use original instructions as fallback
        context.metadata["dynamic_instructions"] = self._original_instructions
        logger.warning(
            "DynamicPromptInjectionPlugin called synchronously - "
            "use async context for full functionality"
        )

    async def _before_run_async(
        self,
        context: AgentContext,
        input: str,
    ) -> None:
        """Async implementation of before_run hook."""
        try:
            # 1. Get conversation history
            conversation_history = await self._get_conversation_history(context)

            # 2. Analyze intent
            intent = await self.intent_analyzer.analyze(
                message=input,
                context=context,
                conversation_history=conversation_history,
            )

            # 3. Retrieve fragments
            fragments = await self.retrieval_engine.retrieve_fragments(
                intent=intent,
                context=context,
                agent_type=self.config.agent_type,
                token_budget=self.config.token_budget,
            )

            # 4. Build session variables
            session_variables = await self._build_session_variables(context)

            # 5. Build dynamic prompt
            dynamic_prompt, checksum, metrics = await self.prompt_builder.build_prompt(
                fragments=fragments,
                context=context,
                session_variables=session_variables,
            )

            # 6. Inject into context metadata
            context.metadata["dynamic_instructions"] = dynamic_prompt
            context.metadata["fragment_ids"] = [f.fragment_id for f in fragments]
            context.metadata["prompt_checksum"] = checksum
            context.metadata["assembly_metrics"] = metrics.to_dict()
            context.metadata["intent"] = {
                "task_type": intent.task_type,
                "domains": intent.domain_signals,
                "complexity": intent.complexity,
                "requires_tools": intent.requires_tools,
            }

            # 7. Update fragment usage statistics
            await self._update_fragment_usage(fragments)

            # 8. Log telemetry
            await self._log_telemetry(
                event_type="prompt_assembled",
                context=context,
                payload={
                    "fragment_count": len(fragments),
                    "checksum": checksum,
                    "intent": intent.task_type,
                    "token_estimate": metrics.total_tokens,
                    "cache_hit": metrics.cache_hit,
                    "assembly_time_ms": metrics.assembly_time_ms,
                },
            )

            logger.debug(
                f"Assembled prompt: {len(fragments)} fragments, "
                f"~{metrics.total_tokens} tokens, "
                f"cache_hit={metrics.cache_hit}"
            )

        except Exception as e:
            # Fallback to original instructions on error
            context.metadata["dynamic_instructions"] = self._original_instructions
            context.metadata["dynamic_prompt_error"] = str(e)

            await self._log_telemetry(
                event_type="prompt_assembly_failed",
                context=context,
                payload={"error": str(e)},
            )

            logger.error(f"Prompt assembly failed: {e}", exc_info=True)

    async def on_after_run_async(
        self,
        context: AgentContext,
        result: RunResult,
    ) -> None:
        """After LLM execution: collect feedback signals.

        Args:
            context: Agent context.
            result: Run result.
        """
        await self._after_run_async(context, result)

    def on_after_run(
        self,
        context: AgentContext,
        result: RunResult,
    ) -> None:
        """Sync fallback for after run - no-op in sync context.

        Args:
            context: Agent context.
            result: Run result.
        """
        # Feedback collection requires async - skip in sync context
        if self.config.enable_feedback_loop:
            logger.debug("Skipping feedback collection in sync context")

    async def _after_run_async(
        self,
        context: AgentContext,
        result: RunResult,
    ) -> None:
        """Async implementation of after_run hook."""
        # Check feedback loop config
        if not self.config.enable_feedback_loop:
            return

        try:
            fragment_ids = context.metadata.get("fragment_ids", [])
            if not fragment_ids:
                return

            # Extract quality signals
            success = self._is_success(result)
            retry_count = context.metadata.get("retry_count", 0)
            token_usage = self._extract_token_usage(result)

            # Update fragment performance metrics
            await self._update_fragment_performance(
                fragment_ids=fragment_ids,
                success=success,
                retry_count=retry_count,
            )

            # Log telemetry
            await self._log_telemetry(
                event_type="prompt_execution_completed",
                context=context,
                payload={
                    "success": success,
                    "retry_count": retry_count,
                    "token_usage": token_usage,
                    "fragment_count": len(fragment_ids),
                },
            )

        except Exception as e:
            await self._log_telemetry(
                event_type="feedback_collection_failed",
                context=context,
                payload={"error": str(e)},
            )
            logger.error(f"Feedback collection failed: {e}", exc_info=True)

    def _create_management_tools(self) -> List:
        """Create fragment management tools."""
        plugin = self

        @function_tool
        async def list_fragments(
            context: RunContextWrapper[AgentContext],
            fragment_type: str = "",
            limit: int = 20,
        ) -> str:
            """List available instruction fragments.

            Args:
                fragment_type: Filter by type (core, domain, capability, scenario, correction).
                limit: Maximum results (default 20).

            Returns:
                List of fragments.
            """
            try:
                from .models import FragmentType

                frag_type = None
                if fragment_type:
                    frag_type = FragmentType(fragment_type)

                fragments = await plugin.store.list_fragments(
                    agent_type=plugin.config.agent_type,
                    fragment_type=frag_type,
                    limit=limit,
                )

                if not fragments:
                    return "No fragments found."

                lines = [f"Found {len(fragments)} fragments:\n"]
                for f in fragments:
                    lines.append(
                        f"- [{f.fragment_type.value}] {f.fragment_id[:8]}... "
                        f"(priority={f.priority.value}, usage={f.usage_count})"
                    )

                return "\n".join(lines)

            except Exception as e:
                return f"Error listing fragments: {str(e)}"

        @function_tool
        async def get_prompt_stats(
            context: RunContextWrapper[AgentContext],
        ) -> str:
            """Get dynamic prompt injection statistics.

            Returns:
                Statistics about prompt assembly and caching.
            """
            try:
                cache_stats = await plugin.prompt_builder.get_cache_stats()
                metrics = context.context.metadata.get("assembly_metrics", {})

                return (
                    f"Dynamic Prompt Statistics:\n"
                    f"- Cache entries: {cache_stats.get('entries', 0)}\n"
                    f"- Cache TTL: {cache_stats.get('ttl_seconds', 0)}s\n"
                    f"- Last assembly fragments: {metrics.get('fragment_count', 0)}\n"
                    f"- Last assembly tokens: {metrics.get('total_tokens', 0)}\n"
                    f"- Last assembly time: {metrics.get('total_time_ms', 0):.2f}ms\n"
                    f"- Last cache hit: {metrics.get('cache_hit', False)}"
                )

            except Exception as e:
                return f"Error getting stats: {str(e)}"

        @function_tool
        async def clear_prompt_cache(
            context: RunContextWrapper[AgentContext],
        ) -> str:
            """Clear the prompt cache.

            Returns:
                Confirmation message.
            """
            try:
                count = await plugin.prompt_builder.clear_cache()
                return f"Cleared {count} cached prompts."
            except Exception as e:
                return f"Error clearing cache: {str(e)}"

        return [list_fragments, get_prompt_stats, clear_prompt_cache]

    async def _get_conversation_history(
        self,
        context: AgentContext,
    ) -> List[Dict[str, str]]:
        """Retrieve conversation history from AgentFS."""
        if not self.agentfs:
            return []

        try:
            history = await self.agentfs.get_conversation_history(
                user_id=context.user_id,
                session_id=context.session_id,
                limit=10,
            )
            return history or []
        except Exception as e:
            logger.warning(f"Failed to get conversation history: {e}")
            return []

    async def _build_session_variables(
        self,
        context: AgentContext,
    ) -> Dict[str, str]:
        """Build session-specific variables for template injection."""
        variables: Dict[str, str] = {}

        # Add date/time
        variables["date_today"] = datetime.utcnow().strftime("%Y-%m-%d")
        variables["time_now"] = datetime.utcnow().strftime("%H:%M:%S UTC")

        # Add context info
        variables["user_id"] = context.user_id or "unknown"
        variables["session_id"] = context.session_id or "default"
        variables["channel"] = context.channel or "api"
        variables["modality"] = context.modality or "text"

        # Extract from AgentFS user profile if available
        if self.agentfs:
            try:
                profile = await self.agentfs.get_user_profile(context.user_id)
                if profile:
                    variables["user_name"] = profile.get("name", "User")
                    variables["timezone"] = profile.get("timezone", "UTC")
                    variables["company_name"] = profile.get("company", "")
            except Exception as e:
                logger.debug(f"Failed to get user profile: {e}")

        # Add any metadata variables (non-dict, non-list values)
        for key, value in context.metadata.items():
            if isinstance(value, (str, int, float, bool)):
                variables[key] = str(value)

        return variables

    async def _update_fragment_usage(
        self,
        fragments: List[InstructionFragment],
    ) -> None:
        """Increment usage count for selected fragments."""
        for fragment in fragments:
            await self.store.increment_usage(
                fragment_id=fragment.fragment_id,
                agent_type=fragment.agent_type,
            )

    async def _update_fragment_performance(
        self,
        fragment_ids: List[str],
        success: bool,
        retry_count: int,
    ) -> None:
        """Update fragment performance metrics."""
        for fragment_id in fragment_ids:
            await self.store.update_performance(
                fragment_id=fragment_id,
                agent_type=self.config.agent_type,
                success=success,
                retry_count=retry_count,
            )

    def _is_success(self, result: RunResult) -> bool:
        """Determine if execution was successful."""
        return hasattr(result, "final_output") and result.final_output is not None

    def _extract_token_usage(self, result: RunResult) -> Dict[str, int]:
        """Extract token usage from result."""
        usage = {}
        if hasattr(result, "raw_responses"):
            for response in result.raw_responses:
                if hasattr(response, "usage"):
                    usage["prompt_tokens"] = getattr(response.usage, "prompt_tokens", 0)
                    usage["completion_tokens"] = getattr(response.usage, "completion_tokens", 0)
                    usage["total_tokens"] = getattr(response.usage, "total_tokens", 0)
                    break
        return usage

    async def _log_telemetry(
        self,
        event_type: str,
        context: AgentContext,
        payload: Dict[str, Any],
    ) -> None:
        """Log telemetry event to Redis Stream."""
        try:
            event = {
                "event_type": event_type,
                "timestamp": datetime.utcnow().isoformat(),
                "user_id": context.user_id,
                "session_id": context.session_id or "default",
                "agent_type": self.config.agent_type,
                **payload,
            }

            # Convert non-string values to strings for Redis Stream
            stream_data = {k: str(v) for k, v in event.items()}

            self.store.redis.xadd(
                self._telemetry_stream,
                stream_data,
                maxlen=10000,  # Keep last 10k events
            )

        except Exception as e:
            logger.debug(f"Failed to log telemetry: {e}")

    async def store_fragment(
        self,
        fragment: InstructionFragment,
        dedupe_by_tags: bool = True,
    ) -> str:
        """Store a new fragment with auto-generated embedding and deduplication.

        If dedupe_by_tags is True and a fragment with the same agent_type and tags
        already exists, the existing fragment will be updated instead of creating
        a new one. This prevents duplicate fragments from accumulating on each run.

        Args:
            fragment: Fragment to store.
            dedupe_by_tags: If True, check for existing fragment by tags and update
                           instead of creating duplicate. Default is True.

        Returns:
            Fragment ID (either new or existing if deduplicated).
        """
        # Generate embedding if not already set
        if not fragment.embedding:
            try:
                embeddings = await self.embedding_client.embed_texts([fragment.content])
                if embeddings and len(embeddings) > 0:
                    fragment.embedding = embeddings[0]
                    logger.debug(f"Generated embedding for fragment {fragment.fragment_id}")
            except Exception as e:
                logger.warning(f"Failed to generate embedding for fragment {fragment.fragment_id}: {e}")
        
        # Use store_or_update_fragment for deduplication
        fragment_id, was_updated = await self.store.store_or_update_fragment(
            fragment, dedupe_by_tags=dedupe_by_tags
        )
        
        if was_updated:
            logger.info(f"Updated existing fragment {fragment_id} (deduplicated by tags)")
        
        return fragment_id

    async def get_fragment(
        self,
        fragment_id: str,
    ) -> InstructionFragment:
        """Get a fragment by ID.

        Args:
            fragment_id: Fragment ID.

        Returns:
            InstructionFragment.
        """
        return await self.store.get_fragment(
            fragment_id=fragment_id,
            agent_type=self.config.agent_type,
        )

    async def delete_fragment(
        self,
        fragment_id: str,
    ) -> bool:
        """Delete a fragment.

        Args:
            fragment_id: Fragment ID.

        Returns:
            True if deleted.
        """
        return await self.store.delete_fragment(
            fragment_id=fragment_id,
            agent_type=self.config.agent_type,
        )

    def close(self) -> None:
        """Close connections and cleanup resources."""
        self.store.close()
        
        # Try to close embedding client safely
        try:
            # Try to get the current running loop
            try:
                loop = asyncio.get_running_loop()
                # If we're in an async context, create a task to close
                if not loop.is_closed():
                    loop.create_task(self.embedding_client.close())
            except RuntimeError:
                # No running loop, try to get event loop (might be closed)
                try:
                    loop = asyncio.get_event_loop()
                    if not loop.is_closed():
                        loop.run_until_complete(self.embedding_client.close())
                except RuntimeError:
                    # Event loop is closed or unavailable, try sync close
                    try:
                        # Check if embedding client has a sync close method
                        if hasattr(self.embedding_client, '_sync_client') and self.embedding_client._sync_client:
                            self.embedding_client._sync_client.close()
                        if hasattr(self.embedding_client, '_client') and self.embedding_client._client:
                            if not self.embedding_client._client.is_closed:
                                # Use asyncio.run to create a new loop for closing
                                asyncio.run(self.embedding_client.close())
                    except Exception:
                        # Last resort - ignore errors during cleanup
                        pass
        except Exception:
            # Catch any other exceptions during cleanup
            pass

        logger.info("DynamicPromptInjectionPlugin closed")
