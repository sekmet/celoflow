"""Analytics and monitoring for Dynamic Prompt Injection Plugin."""

import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .config import DynamicPromptConfig

logger = logging.getLogger(__name__)


class PromptAnalytics:
    """Analytics and metrics tracking for prompt injection.

    Tracks fragment usage, cache performance, and assembly metrics.
    Uses Redis Streams for real-time event logging.
    """

    TELEMETRY_STREAM = "agent:prompt_injection:events"
    METRICS_PREFIX = "prompt_metrics:"

    def __init__(
        self,
        config: DynamicPromptConfig,
        redis_client: Any = None,
    ):
        """Initialize analytics.

        Args:
            config: Plugin configuration.
            redis_client: Redis client.
        """
        self.config = config
        self._redis = redis_client

    @property
    def redis(self) -> Any:
        """Get Redis client."""
        if self._redis is None:
            import redis
            self._redis = redis.Redis.from_url(
                self.config.redis_url,
                decode_responses=True,
            )
        return self._redis

    async def log_event(
        self,
        event_type: str,
        payload: Dict[str, Any],
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> str:
        """Log an analytics event.

        Args:
            event_type: Type of event.
            payload: Event data.
            user_id: User identifier.
            session_id: Session identifier.

        Returns:
            Event ID.
        """
        event = {
            "event_type": event_type,
            "timestamp": datetime.utcnow().isoformat(),
            "agent_type": self.config.agent_type,
            "user_id": user_id or "unknown",
            "session_id": session_id or "default",
            **{k: str(v) for k, v in payload.items()},
        }

        try:
            event_id = self.redis.xadd(
                self.TELEMETRY_STREAM,
                event,
                maxlen=100000,
            )
            return event_id
        except Exception as e:
            logger.warning(f"Failed to log event: {e}")
            return ""

    async def get_events(
        self,
        event_type: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get analytics events.

        Args:
            event_type: Filter by event type.
            start_time: Start time filter.
            end_time: End time filter.
            limit: Maximum events to return.

        Returns:
            List of events.
        """
        try:
            # Use time-based range
            start_id = "-"
            end_id = "+"

            if start_time:
                start_id = f"{int(start_time.timestamp() * 1000)}-0"
            if end_time:
                end_id = f"{int(end_time.timestamp() * 1000)}-0"

            results = self.redis.xrange(
                self.TELEMETRY_STREAM,
                min=start_id,
                max=end_id,
                count=limit,
            )

            events = []
            for event_id, data in results:
                if event_type and data.get("event_type") != event_type:
                    continue
                events.append({"id": event_id, **data})

            return events

        except Exception as e:
            logger.warning(f"Failed to get events: {e}")
            return []

    async def get_fragment_usage_stats(
        self,
        fragment_id: Optional[str] = None,
        time_window_hours: int = 24,
    ) -> Dict[str, Any]:
        """Get fragment usage statistics.

        Args:
            fragment_id: Specific fragment ID (or None for all).
            time_window_hours: Time window in hours.

        Returns:
            Usage statistics.
        """
        start_time = datetime.utcnow() - timedelta(hours=time_window_hours)

        events = await self.get_events(
            event_type="prompt_assembled",
            start_time=start_time,
            limit=10000,
        )

        stats = {
            "total_assemblies": 0,
            "cache_hits": 0,
            "cache_hit_rate": 0.0,
            "avg_fragment_count": 0.0,
            "avg_token_count": 0.0,
            "avg_assembly_time_ms": 0.0,
            "fragment_usage": {},
        }

        if not events:
            return stats

        total_fragments = 0
        total_tokens = 0
        total_time = 0.0

        for event in events:
            stats["total_assemblies"] += 1

            if event.get("cache_hit") == "True":
                stats["cache_hits"] += 1

            total_fragments += int(event.get("fragment_count", 0))
            total_tokens += int(event.get("token_estimate", 0))
            total_time += float(event.get("assembly_time_ms", 0))

        if stats["total_assemblies"] > 0:
            stats["cache_hit_rate"] = stats["cache_hits"] / stats["total_assemblies"]
            stats["avg_fragment_count"] = total_fragments / stats["total_assemblies"]
            stats["avg_token_count"] = total_tokens / stats["total_assemblies"]
            stats["avg_assembly_time_ms"] = total_time / stats["total_assemblies"]

        return stats

    async def get_intent_distribution(
        self,
        time_window_hours: int = 24,
    ) -> Dict[str, int]:
        """Get distribution of detected intents.

        Args:
            time_window_hours: Time window in hours.

        Returns:
            Intent type counts.
        """
        start_time = datetime.utcnow() - timedelta(hours=time_window_hours)

        events = await self.get_events(
            event_type="prompt_assembled",
            start_time=start_time,
            limit=10000,
        )

        distribution: Dict[str, int] = {}
        for event in events:
            intent = event.get("intent", "unknown")
            distribution[intent] = distribution.get(intent, 0) + 1

        return distribution

    async def get_error_rate(
        self,
        time_window_hours: int = 24,
    ) -> Dict[str, Any]:
        """Get error rate statistics.

        Args:
            time_window_hours: Time window in hours.

        Returns:
            Error statistics.
        """
        start_time = datetime.utcnow() - timedelta(hours=time_window_hours)

        # Get assembly events
        assembly_events = await self.get_events(
            event_type="prompt_assembled",
            start_time=start_time,
            limit=10000,
        )

        # Get failure events
        failure_events = await self.get_events(
            event_type="prompt_assembly_failed",
            start_time=start_time,
            limit=10000,
        )

        total = len(assembly_events) + len(failure_events)
        error_rate = len(failure_events) / total if total > 0 else 0.0

        return {
            "total_attempts": total,
            "successes": len(assembly_events),
            "failures": len(failure_events),
            "error_rate": error_rate,
        }

    async def increment_counter(
        self,
        metric_name: str,
        value: int = 1,
    ) -> int:
        """Increment a metric counter.

        Args:
            metric_name: Name of the metric.
            value: Value to increment by.

        Returns:
            New counter value.
        """
        key = f"{self.METRICS_PREFIX}{metric_name}"
        return self.redis.incrby(key, value)

    async def get_counter(
        self,
        metric_name: str,
    ) -> int:
        """Get a metric counter value.

        Args:
            metric_name: Name of the metric.

        Returns:
            Counter value.
        """
        key = f"{self.METRICS_PREFIX}{metric_name}"
        value = self.redis.get(key)
        return int(value) if value else 0

    async def record_latency(
        self,
        metric_name: str,
        latency_ms: float,
    ) -> None:
        """Record a latency measurement.

        Args:
            metric_name: Name of the metric.
            latency_ms: Latency in milliseconds.
        """
        key = f"{self.METRICS_PREFIX}latency:{metric_name}"

        # Use a sorted set with timestamp as score for time-series data
        timestamp = datetime.utcnow().timestamp()
        self.redis.zadd(key, {f"{timestamp}:{latency_ms}": timestamp})

        # Keep only last hour of data
        cutoff = timestamp - 3600
        self.redis.zremrangebyscore(key, "-inf", cutoff)

    async def get_latency_stats(
        self,
        metric_name: str,
    ) -> Dict[str, float]:
        """Get latency statistics.

        Args:
            metric_name: Name of the metric.

        Returns:
            Latency statistics (avg, p50, p95, p99).
        """
        key = f"{self.METRICS_PREFIX}latency:{metric_name}"

        try:
            members = self.redis.zrange(key, 0, -1)
            if not members:
                return {"avg": 0, "p50": 0, "p95": 0, "p99": 0, "count": 0}

            latencies = []
            for member in members:
                parts = member.split(":")
                if len(parts) >= 2:
                    latencies.append(float(parts[1]))

            if not latencies:
                return {"avg": 0, "p50": 0, "p95": 0, "p99": 0, "count": 0}

            latencies.sort()
            count = len(latencies)

            return {
                "avg": sum(latencies) / count,
                "p50": latencies[int(count * 0.5)],
                "p95": latencies[int(count * 0.95)] if count > 20 else latencies[-1],
                "p99": latencies[int(count * 0.99)] if count > 100 else latencies[-1],
                "count": count,
            }

        except Exception as e:
            logger.warning(f"Failed to get latency stats: {e}")
            return {"avg": 0, "p50": 0, "p95": 0, "p99": 0, "count": 0}


class PrometheusMetrics:
    """Prometheus metrics exporter for monitoring.

    Exposes metrics in Prometheus format for monitoring dashboards.
    """

    def __init__(self, config: DynamicPromptConfig):
        """Initialize Prometheus metrics.

        Args:
            config: Plugin configuration.
        """
        self.config = config
        self._counters: Dict[str, int] = {}
        self._gauges: Dict[str, float] = {}
        self._histograms: Dict[str, List[float]] = {}

    def increment(self, name: str, labels: Dict[str, str] = None, value: int = 1):
        """Increment a counter."""
        key = self._make_key(name, labels)
        self._counters[key] = self._counters.get(key, 0) + value

    def set_gauge(self, name: str, value: float, labels: Dict[str, str] = None):
        """Set a gauge value."""
        key = self._make_key(name, labels)
        self._gauges[key] = value

    def observe(self, name: str, value: float, labels: Dict[str, str] = None):
        """Record a histogram observation."""
        key = self._make_key(name, labels)
        if key not in self._histograms:
            self._histograms[key] = []
        self._histograms[key].append(value)
        # Keep only last 1000 observations
        if len(self._histograms[key]) > 1000:
            self._histograms[key] = self._histograms[key][-1000:]

    def _make_key(self, name: str, labels: Dict[str, str] = None) -> str:
        """Create metric key with labels."""
        if not labels:
            return name
        label_str = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
        return f"{name}{{{label_str}}}"

    def export(self) -> str:
        """Export metrics in Prometheus format.

        Returns:
            Prometheus-formatted metrics string.
        """
        lines = []

        # Export counters
        for key, value in self._counters.items():
            lines.append(f"# TYPE {key.split('{')[0]} counter")
            lines.append(f"{key} {value}")

        # Export gauges
        for key, value in self._gauges.items():
            lines.append(f"# TYPE {key.split('{')[0]} gauge")
            lines.append(f"{key} {value}")

        # Export histogram summaries
        for key, values in self._histograms.items():
            if values:
                base_name = key.split("{")[0]
                labels = key[len(base_name):] if "{" in key else ""

                lines.append(f"# TYPE {base_name} histogram")
                lines.append(f"{base_name}_count{labels} {len(values)}")
                lines.append(f"{base_name}_sum{labels} {sum(values)}")

                sorted_vals = sorted(values)
                count = len(sorted_vals)
                for quantile in [0.5, 0.9, 0.95, 0.99]:
                    idx = int(count * quantile)
                    lines.append(
                        f'{base_name}{{quantile="{quantile}"{labels[1:] if labels else "}"}}} '
                        f"{sorted_vals[idx] if idx < count else sorted_vals[-1]}"
                    )


        return "\n".join(lines)
