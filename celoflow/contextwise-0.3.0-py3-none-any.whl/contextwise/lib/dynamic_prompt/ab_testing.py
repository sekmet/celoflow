"""A/B Testing Framework for Dynamic Prompt Injection Plugin."""

import hashlib
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from .config import DynamicPromptConfig
from .models import ABTestExperiment, ABTestVariant

logger = logging.getLogger(__name__)


class FragmentABTester:
    """A/B testing framework for fragment effectiveness.

    Supports:
    - Experiment creation and management
    - Consistent user assignment using hashing
    - Metrics collection and statistical analysis
    - Variant-based fragment selection
    """

    EXPERIMENTS_KEY = "ab_experiments"
    ASSIGNMENTS_KEY = "ab_assignments"
    METRICS_KEY = "ab_metrics"

    def __init__(
        self,
        config: DynamicPromptConfig,
        redis_client: Any = None,
    ):
        """Initialize A/B tester.

        Args:
            config: Plugin configuration.
            redis_client: Redis client.
        """
        self.config = config
        self._redis = redis_client

    @property
    def redis(self) -> Any:
        """Get Redis client."""
        if self._redis is None:
            import redis
            self._redis = redis.Redis.from_url(
                self.config.redis_url,
                decode_responses=True,
            )
        return self._redis

    async def create_experiment(
        self,
        experiment: ABTestExperiment,
    ) -> str:
        """Create a new A/B test experiment.

        Args:
            experiment: Experiment configuration.

        Returns:
            Experiment ID.
        """
        import json

        data = {
            "experiment_id": experiment.experiment_id,
            "name": experiment.name,
            "description": experiment.description,
            "variants": [
                {
                    "variant_id": v.variant_id,
                    "name": v.name,
                    "fragment_ids": v.fragment_ids,
                    "weight": v.weight,
                    "is_control": v.is_control,
                }
                for v in experiment.variants
            ],
            "start_date": experiment.start_date or datetime.utcnow().isoformat(),
            "end_date": experiment.end_date,
            "is_active": experiment.is_active,
            "created_at": datetime.utcnow().isoformat(),
        }

        self.redis.hset(
            self.EXPERIMENTS_KEY,
            experiment.experiment_id,
            json.dumps(data),
        )

        logger.info(f"Created experiment {experiment.experiment_id}: {experiment.name}")
        return experiment.experiment_id

    async def get_experiment(
        self,
        experiment_id: str,
    ) -> Optional[ABTestExperiment]:
        """Get an experiment by ID.

        Args:
            experiment_id: Experiment ID.

        Returns:
            Experiment or None.
        """
        import json

        data = self.redis.hget(self.EXPERIMENTS_KEY, experiment_id)
        if not data:
            return None

        exp_data = json.loads(data)
        variants = [
            ABTestVariant(
                variant_id=v["variant_id"],
                name=v["name"],
                fragment_ids=v["fragment_ids"],
                weight=v["weight"],
                is_control=v["is_control"],
            )
            for v in exp_data.get("variants", [])
        ]

        return ABTestExperiment(
            experiment_id=exp_data["experiment_id"],
            name=exp_data["name"],
            description=exp_data.get("description", ""),
            variants=variants,
            start_date=exp_data.get("start_date"),
            end_date=exp_data.get("end_date"),
            is_active=exp_data.get("is_active", True),
        )

    async def list_experiments(
        self,
        active_only: bool = True,
    ) -> List[ABTestExperiment]:
        """List all experiments.

        Args:
            active_only: Only return active experiments.

        Returns:
            List of experiments.
        """
        import json

        experiments = []
        all_data = self.redis.hgetall(self.EXPERIMENTS_KEY)

        for exp_id, data in all_data.items():
            exp_data = json.loads(data)
            if active_only and not exp_data.get("is_active", True):
                continue

            experiment = await self.get_experiment(exp_id)
            if experiment:
                experiments.append(experiment)

        return experiments

    async def assign_variant(
        self,
        experiment_id: str,
        user_id: str,
    ) -> Optional[ABTestVariant]:
        """Assign a user to an experiment variant.

        Uses consistent hashing for deterministic assignment.

        Args:
            experiment_id: Experiment ID.
            user_id: User identifier.

        Returns:
            Assigned variant or None.
        """
        experiment = await self.get_experiment(experiment_id)
        if not experiment or not experiment.is_active:
            return None

        # Check for existing assignment
        assignment_key = f"{self.ASSIGNMENTS_KEY}:{experiment_id}"
        existing = self.redis.hget(assignment_key, user_id)
        if existing:
            variant = next(
                (v for v in experiment.variants if v.variant_id == existing),
                None,
            )
            if variant:
                return variant

        # Compute consistent hash for assignment
        hash_input = f"{experiment_id}:{user_id}"
        hash_value = int(hashlib.md5(hash_input.encode()).hexdigest(), 16)
        hash_percent = (hash_value % 10000) / 100.0  # 0-100

        # Assign based on weights
        cumulative_weight = 0.0
        assigned_variant = None

        for variant in experiment.variants:
            cumulative_weight += variant.weight
            if hash_percent < cumulative_weight:
                assigned_variant = variant
                break

        if not assigned_variant and experiment.variants:
            assigned_variant = experiment.variants[-1]

        # Store assignment
        if assigned_variant:
            self.redis.hset(assignment_key, user_id, assigned_variant.variant_id)
            logger.debug(
                f"Assigned user {user_id} to variant {assigned_variant.variant_id} "
                f"in experiment {experiment_id}"
            )

        return assigned_variant

    async def get_variant_fragments(
        self,
        experiment_id: str,
        user_id: str,
    ) -> List[str]:
        """Get fragment IDs for a user's assigned variant.

        Args:
            experiment_id: Experiment ID.
            user_id: User identifier.

        Returns:
            List of fragment IDs.
        """
        variant = await self.assign_variant(experiment_id, user_id)
        if variant:
            return variant.fragment_ids
        return []

    async def record_metric(
        self,
        experiment_id: str,
        variant_id: str,
        metric_name: str,
        value: float,
    ) -> None:
        """Record a metric observation for a variant.

        Args:
            experiment_id: Experiment ID.
            variant_id: Variant ID.
            metric_name: Metric name.
            value: Metric value.
        """
        import json

        key = f"{self.METRICS_KEY}:{experiment_id}:{variant_id}:{metric_name}"
        timestamp = datetime.utcnow().timestamp()

        self.redis.zadd(key, {json.dumps({"value": value, "ts": timestamp}): timestamp})

        # Keep only last 24 hours of data
        cutoff = timestamp - 86400
        self.redis.zremrangebyscore(key, "-inf", cutoff)

    async def get_experiment_results(
        self,
        experiment_id: str,
    ) -> Dict[str, Any]:
        """Get experiment results and statistics.

        Args:
            experiment_id: Experiment ID.

        Returns:
            Results dictionary.
        """
        import json

        experiment = await self.get_experiment(experiment_id)
        if not experiment:
            return {"error": "Experiment not found"}

        results = {
            "experiment_id": experiment_id,
            "name": experiment.name,
            "is_active": experiment.is_active,
            "variants": {},
        }

        for variant in experiment.variants:
            variant_results = {
                "name": variant.name,
                "is_control": variant.is_control,
                "metrics": {},
            }

            # Get assignment count
            assignment_key = f"{self.ASSIGNMENTS_KEY}:{experiment_id}"
            all_assignments = self.redis.hgetall(assignment_key)
            variant_results["assignments"] = sum(
                1 for v in all_assignments.values() if v == variant.variant_id
            )

            # Get metrics
            for metric_name in ["success_rate", "retry_count", "latency_ms"]:
                key = f"{self.METRICS_KEY}:{experiment_id}:{variant.variant_id}:{metric_name}"
                observations = self.redis.zrange(key, 0, -1)

                if observations:
                    values = [json.loads(o)["value"] for o in observations]
                    variant_results["metrics"][metric_name] = {
                        "count": len(values),
                        "mean": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                    }

            results["variants"][variant.variant_id] = variant_results

        return results

    async def end_experiment(
        self,
        experiment_id: str,
    ) -> bool:
        """End an active experiment.

        Args:
            experiment_id: Experiment ID.

        Returns:
            True if ended.
        """
        import json

        data = self.redis.hget(self.EXPERIMENTS_KEY, experiment_id)
        if not data:
            return False

        exp_data = json.loads(data)
        exp_data["is_active"] = False
        exp_data["end_date"] = datetime.utcnow().isoformat()

        self.redis.hset(self.EXPERIMENTS_KEY, experiment_id, json.dumps(exp_data))
        logger.info(f"Ended experiment {experiment_id}")
        return True

    async def delete_experiment(
        self,
        experiment_id: str,
    ) -> bool:
        """Delete an experiment and its data.

        Args:
            experiment_id: Experiment ID.

        Returns:
            True if deleted.
        """
        # Delete experiment
        self.redis.hdel(self.EXPERIMENTS_KEY, experiment_id)

        # Delete assignments
        self.redis.delete(f"{self.ASSIGNMENTS_KEY}:{experiment_id}")

        # Delete metrics (pattern match)
        pattern = f"{self.METRICS_KEY}:{experiment_id}:*"
        cursor = 0
        while True:
            cursor, keys = self.redis.scan(cursor, match=pattern)
            if keys:
                self.redis.delete(*keys)
            if cursor == 0:
                break

        logger.info(f"Deleted experiment {experiment_id}")
        return True
