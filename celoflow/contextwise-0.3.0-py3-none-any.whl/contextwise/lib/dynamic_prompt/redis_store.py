"""Redis store for fragment storage and vector search."""

import json
import logging
from typing import Any, Dict, List, Optional

from .config import DynamicPromptConfig
from .exceptions import RedisConnectionError, FragmentNotFoundError
from .models import InstructionFragment, FragmentType, FragmentPriority

logger = logging.getLogger(__name__)


class RedisFragmentStore:
    """Redis-based fragment store with vector search support.

    Uses RedisJSON for fragment storage and RediSearch for vector similarity.

    Attributes:
        config: Plugin configuration.
        redis: Redis client.
    """

    # RediSearch index schema
    INDEX_SCHEMA = {
        "name": "fragment_idx",
        "prefix": "fragment:",
        "storage": "redis",
        "schema": {
            "content": {"type": "TEXT", "weight": 2.0},
            "tags": {"type": "TAG", "separator": ","},
            "keywords": {"type": "TAG", "separator": ","},
            "agent_type": {"type": "TAG"},
            "fragment_type": {"type": "TAG"},
            "priority": {"type": "NUMERIC", "sortable": True},
            "is_active": {"type": "TAG"},
            "embedding": {
                "type": "VECTOR",
                "dims": 1024,
                "distance_metric": "COSINE",
                "algorithm": "HNSW",
                "m": 16,
                "ef_construction": 200,
            },
            "usage_count": {"type": "NUMERIC", "sortable": True},
            "acceptance_rate": {"type": "NUMERIC", "sortable": True},
            "avg_retry_count": {"type": "NUMERIC", "sortable": True},
        },
    }

    def __init__(self, config: DynamicPromptConfig, redis_client: Any = None):
        """Initialize the Redis fragment store.

        Args:
            config: Plugin configuration.
            redis_client: Optional Redis client (will create if not provided).
        """
        self.config = config
        self._redis = redis_client
        self._index_created = False

    @property
    def redis(self) -> Any:
        """Get or create Redis client."""
        if self._redis is None:
            self._redis = self._create_client()
        return self._redis

    def _create_client(self) -> Any:
        """Create Redis client from configuration."""
        try:
            import redis
            from urllib.parse import urlparse

            # Parse URL to extract components
            parsed = urlparse(self.config.redis_url)
            
            # Build connection kwargs
            client_kwargs = {
                "host": parsed.hostname or "localhost",
                "port": parsed.port or 6379,
                "db": self.config.redis_db,
                "decode_responses": True,
            }
            
            # Handle password from URL or explicit config
            url_password = parsed.password
            config_password = self.config.redis_password
            
            # Use password from config if explicitly set, otherwise use URL password
            if config_password:
                client_kwargs["password"] = config_password
                logger.debug("Using password from configuration")
            elif url_password:
                client_kwargs["password"] = url_password
                logger.debug("Using password from URL")
            else:
                logger.warning("No password configured - Redis may require authentication")

            client = redis.Redis(**client_kwargs)
            
            # Test connection
            client.ping()
            logger.info(f"Connected to Redis at {self.config.redis_url}")
            return client
            
        except Exception as e:
            raise RedisConnectionError(
                f"Failed to connect to Redis: {e}",
                original_error=e,
            )

    def _get_key(self, agent_type: str, fragment_id: str) -> str:
        """Get Redis key for a fragment."""
        return f"{self.config.fragment_prefix}{agent_type}:{fragment_id}"

    async def ensure_index(self) -> None:
        """Ensure the RediSearch index exists."""
        if self._index_created:
            return

        try:
            # Check if index exists
            try:
                self.redis.ft(self.config.fragment_index_name).info()
                self._index_created = True
                logger.debug(f"Index {self.config.fragment_index_name} already exists")
                return
            except Exception:
                pass

            # Create index
            self._create_index()
            self._index_created = True
            logger.info(f"Created index {self.config.fragment_index_name}")

        except Exception as e:
            logger.warning(f"Failed to create index: {e}")

    def _create_index(self) -> None:
        """Create the RediSearch index."""
        from redis.commands.search.field import (
            NumericField,
            TagField,
            TextField,
            VectorField,
        )
        from redis.commands.search.index_definition import IndexDefinition, IndexType

        schema = (
            TextField("$.content", as_name="content", weight=2.0),
            TagField("$.tags[*]", as_name="tags"),
            TagField("$.keywords[*]", as_name="keywords"),
            TagField("$.agent_type", as_name="agent_type"),
            TagField("$.fragment_type", as_name="fragment_type"),
            NumericField("$.priority", as_name="priority", sortable=True),
            TagField("$.is_active", as_name="is_active"),
            NumericField("$.usage_count", as_name="usage_count", sortable=True),
            NumericField("$.acceptance_rate", as_name="acceptance_rate", sortable=True),
            NumericField("$.avg_retry_count", as_name="avg_retry_count", sortable=True),
            VectorField(
                "$.embedding",
                "HNSW",
                {
                    "TYPE": "FLOAT32",
                    "DIM": self.config.embedding_dimensions,
                    "DISTANCE_METRIC": "COSINE",
                    "M": 16,
                    "EF_CONSTRUCTION": 200,
                },
                as_name="embedding",
            ),
        )

        definition = IndexDefinition(
            prefix=[self.config.fragment_prefix],
            index_type=IndexType.JSON,
        )

        self.redis.ft(self.config.fragment_index_name).create_index(
            schema,
            definition=definition,
        )

    async def store_fragment(self, fragment: InstructionFragment) -> str:
        """Store a fragment in Redis.

        Args:
            fragment: Fragment to store.

        Returns:
            Fragment ID.
        """
        await self.ensure_index()

        key = self._get_key(fragment.agent_type, fragment.fragment_id)
        data = fragment.to_dict()

        # Store as JSON
        self.redis.json().set(key, "$", data)

        # Set TTL if specified
        if fragment.ttl_seconds:
            self.redis.expire(key, fragment.ttl_seconds)

        logger.debug(f"Stored fragment {fragment.fragment_id}")
        return fragment.fragment_id
    
    async def find_fragment_by_tags(
        self,
        agent_type: str,
        tags: List[str],
        fragment_type: Optional[str] = None,
    ) -> Optional[InstructionFragment]:
        """Find an existing fragment by agent_type and tags.
        
        This is useful for deduplication - checking if a similar fragment
        already exists before creating a new one.

        Args:
            agent_type: Agent type to filter by.
            tags: Tags to match (all tags must be present).
            fragment_type: Optional fragment type filter.

        Returns:
            InstructionFragment if found, None otherwise.
        """
        await self.ensure_index()
        
        from redis.commands.search.query import Query
        
        # Build filter query
        filter_parts = ["@is_active:{true}"]
        
        # Agent type filter
        if agent_type and agent_type != "*":
            escaped_agent = self._escape_tag_value(agent_type)
            filter_parts.append(f"@agent_type:{{{escaped_agent}}}")
        
        # Fragment type filter
        if fragment_type:
            escaped_type = self._escape_tag_value(fragment_type)
            filter_parts.append(f"@fragment_type:{{{escaped_type}}}")
        
        # Tags filter - require all tags to match
        if tags:
            tag_conditions = []
            for tag in tags:
                escaped_tag = self._escape_tag_value(tag)
                tag_conditions.append(f"@tags:{{{escaped_tag}}}")
            filter_parts.extend(tag_conditions)
        
        query_str = " ".join(filter_parts) if filter_parts else "*"
        
        try:
            query = Query(query_str).return_fields("$").dialect(2)
            results = self.redis.ft(self.config.fragment_index_name).search(query)
            
            if results.docs:
                # Return the first matching fragment
                doc = results.docs[0]
                # Use getattr for Redis Document objects (consistent with other methods)
                json_data = getattr(doc, "$", None) or getattr(doc, "json", None)
                if json_data:
                    data = json.loads(json_data) if isinstance(json_data, str) else json_data
                    return InstructionFragment.from_dict(data)
                
        except Exception as e:
            logger.warning(f"Error finding fragment by tags: {e}")
        
        return None
    
    async def store_or_update_fragment(
        self,
        fragment: InstructionFragment,
        dedupe_by_tags: bool = True,
    ) -> tuple[str, bool]:
        """Store a fragment, updating if a similar one already exists.
        
        This method provides deduplication by checking if a fragment with
        the same agent_type and tags already exists. If so, it updates the
        existing fragment instead of creating a new one.

        Args:
            fragment: Fragment to store or update.
            dedupe_by_tags: If True, check for existing fragment by tags.

        Returns:
            Tuple of (fragment_id, was_updated) where was_updated is True
            if an existing fragment was updated, False if new was created.
        """
        if dedupe_by_tags and fragment.tags:
            existing = await self.find_fragment_by_tags(
                agent_type=fragment.agent_type,
                tags=fragment.tags,
                fragment_type=fragment.fragment_type.value if fragment.fragment_type else None,
            )
            
            if existing:
                # Update existing fragment with new content
                from datetime import datetime
                existing.content = fragment.content
                existing.variables = fragment.variables
                existing.keywords = fragment.keywords
                existing.embedding = fragment.embedding
                existing.updated_at = datetime.utcnow().isoformat()
                
                await self.store_fragment(existing)
                logger.debug(f"Updated existing fragment {existing.fragment_id} (matched by tags)")
                return existing.fragment_id, True
        
        # Store as new fragment
        fragment_id = await self.store_fragment(fragment)
        return fragment_id, False

    async def get_fragment(
        self,
        fragment_id: str,
        agent_type: str = "generic",
    ) -> InstructionFragment:
        """Get a fragment by ID.

        Args:
            fragment_id: Fragment ID.
            agent_type: Agent type.

        Returns:
            InstructionFragment.

        Raises:
            FragmentNotFoundError: If fragment not found.
        """
        key = self._get_key(agent_type, fragment_id)
        data = self.redis.json().get(key)

        if not data:
            # Try with wildcard agent type
            key = self._get_key("*", fragment_id)
            data = self.redis.json().get(key)

        if not data:
            raise FragmentNotFoundError(fragment_id)

        return InstructionFragment.from_dict(data)

    async def delete_fragment(
        self,
        fragment_id: str,
        agent_type: str = "generic",
    ) -> bool:
        """Delete a fragment.

        Args:
            fragment_id: Fragment ID.
            agent_type: Agent type.

        Returns:
            True if deleted, False if not found.
        """
        key = self._get_key(agent_type, fragment_id)
        result = self.redis.delete(key)
        return result > 0

    async def update_fragment(
        self,
        fragment: InstructionFragment,
    ) -> None:
        """Update an existing fragment.

        Args:
            fragment: Fragment with updated values.
        """
        from datetime import datetime

        fragment.updated_at = datetime.utcnow().isoformat()
        await self.store_fragment(fragment)

    def _escape_tag_value(self, value: str) -> str:
        """Escape special characters in RediSearch TAG values.
        
        Args:
            value: The tag value to escape.
            
        Returns:
            Escaped tag value safe for RediSearch queries.
        """
        # Escape special RediSearch characters: , . < > { } [ ] " ' : ; ! @ # $ % ^ & * ( ) - + = ~
        special_chars = r',.<>{}[]"\':;!@#$%^&*()-+=~| '
        escaped = value
        for char in special_chars:
            escaped = escaped.replace(char, f'\\{char}')
        return escaped

    async def search_fragments(
        self,
        query_embedding: List[float],
        agent_type: str = "generic",
        fragment_type: Optional[str] = None,
        tags: Optional[List[str]] = None,
        limit: int = 10,
        min_score: float = 0.0,
    ) -> List[tuple[InstructionFragment, float]]:
        """Search fragments by vector similarity.

        Args:
            query_embedding: Query embedding vector.
            agent_type: Agent type filter.
            fragment_type: Fragment type filter.
            tags: Tag filters.
            limit: Maximum results.
            min_score: Minimum similarity score.

        Returns:
            List of (fragment, score) tuples.
        """
        await self.ensure_index()

        from redis.commands.search.query import Query
        import numpy as np

        # Build filter using proper RediSearch syntax with escaped values
        filter_parts = ["@is_active:{true}"]

        # Handle agent_type filter - escape special characters
        if agent_type and agent_type != "*":
            escaped_agent = self._escape_tag_value(agent_type)
            filter_parts.append(f"@agent_type:{{{escaped_agent}}}")

        # Handle fragment_type filter - escape special characters
        if fragment_type:
            escaped_type = self._escape_tag_value(fragment_type)
            filter_parts.append(f"@fragment_type:{{{escaped_type}}}")

        # Handle tags filter - use proper TAG syntax with escaping
        if tags:
            tag_conditions = []
            for tag in tags:
                escaped_tag = self._escape_tag_value(tag)
                tag_conditions.append(f"@tags:{{{escaped_tag}}}")
            filter_parts.append(f"({' | '.join(tag_conditions)})")

        # Create filter string - wrap in parentheses for complex filters
        if len(filter_parts) > 1:
            filter_str = f"({' '.join(filter_parts)})"
        else:
            filter_str = filter_parts[0] if filter_parts else "*"

        # Convert embedding to bytes
        query_vector = np.array(query_embedding, dtype=np.float32).tobytes()

        # Build vector query with proper syntax - ensure no whitespace issues
        query_str = f"{filter_str}=>[KNN {limit} @embedding $vec AS score]"
        logger.debug(f"Redis search query: {query_str}")
        
        query = (
            Query(query_str)
            .sort_by("score")
            .return_fields("score", "$")
            .dialect(2)
        )

        try:
            results = self.redis.ft(self.config.fragment_index_name).search(
                query,
                query_params={"vec": query_vector},
            )

            fragments = []
            for doc in results.docs:
                try:
                    # Parse JSON data - use getattr for Redis Document objects
                    json_data = getattr(doc, "$", None) or getattr(doc, "json", None)
                    if json_data:
                        data = json.loads(json_data) if isinstance(json_data, str) else json_data
                        if data:
                            fragment = InstructionFragment.from_dict(data)
                            score_val = getattr(doc, "score", 1)
                            score = 1 - float(score_val)  # Convert distance to similarity
                            if score >= min_score:
                                fragments.append((fragment, score))
                except Exception as e:
                    logger.warning(f"Failed to parse fragment: {e}")

            return fragments

        except Exception as e:
            logger.error(f"Search failed: {e} (query: {query_str})")
            return []

    async def get_fragments_by_type(
        self,
        fragment_type: FragmentType,
        agent_type: str = "generic",
        limit: int = 50,
    ) -> List[InstructionFragment]:
        """Get fragments by type.

        Args:
            fragment_type: Fragment type.
            agent_type: Agent type filter.
            limit: Maximum results.

        Returns:
            List of fragments.
        """
        await self.ensure_index()

        from redis.commands.search.query import Query

        # Build query using proper RediSearch syntax with escaping
        escaped_type = self._escape_tag_value(fragment_type.value)
        filter_parts = [
            "@is_active:{true}",
            f"@fragment_type:{{{escaped_type}}}",
        ]

        # Handle agent_type filter - escape special characters
        if agent_type and agent_type != "*":
            escaped_agent = self._escape_tag_value(agent_type)
            filter_parts.append(f"@agent_type:{{{escaped_agent}}}")

        query_str = " ".join(filter_parts)
        logger.debug(f"Redis type query: {query_str}")
        
        query = (
            Query(query_str)
            .sort_by("priority", asc=False)
            .return_fields("$")
            .paging(0, limit)
        )

        try:
            results = self.redis.ft(self.config.fragment_index_name).search(query)

            fragments = []
            for doc in results.docs:
                try:
                    # Use getattr for Redis Document objects
                    json_data = getattr(doc, "$", None) or getattr(doc, "json", None)
                    if json_data:
                        data = json.loads(json_data) if isinstance(json_data, str) else json_data
                        if data:
                            fragments.append(InstructionFragment.from_dict(data))
                except Exception as e:
                    logger.warning(f"Failed to parse fragment: {e}")

            return fragments

        except Exception as e:
            logger.error(f"Query failed: {e} (query: {query_str})")
            return []

    async def increment_usage(
        self,
        fragment_id: str,
        agent_type: str = "generic",
    ) -> None:
        """Increment usage count for a fragment.

        Args:
            fragment_id: Fragment ID.
            agent_type: Agent type.
        """
        from datetime import datetime

        key = self._get_key(agent_type, fragment_id)

        try:
            self.redis.json().numincrby(key, "$.usage_count", 1)
            self.redis.json().set(key, "$.last_used", datetime.utcnow().isoformat())
        except Exception as e:
            logger.warning(f"Failed to increment usage: {e}")

    async def update_performance(
        self,
        fragment_id: str,
        agent_type: str,
        success: bool,
        retry_count: int,
        alpha: float = 0.1,
    ) -> None:
        """Update fragment performance metrics using EMA.

        Args:
            fragment_id: Fragment ID.
            agent_type: Agent type.
            success: Whether the execution was successful.
            retry_count: Number of retries.
            alpha: EMA smoothing factor.
        """
        key = self._get_key(agent_type, fragment_id)

        try:
            data = self.redis.json().get(key)
            if not data:
                return

            current_acceptance = data.get("acceptance_rate", 0.5)
            current_retry = data.get("avg_retry_count", 1.0)

            # Update with EMA
            new_acceptance = alpha * (1.0 if success else 0.0) + (1 - alpha) * current_acceptance
            new_retry = alpha * retry_count + (1 - alpha) * current_retry

            self.redis.json().set(key, "$.acceptance_rate", new_acceptance)
            self.redis.json().set(key, "$.avg_retry_count", new_retry)

        except Exception as e:
            logger.warning(f"Failed to update performance: {e}")

    async def list_fragments(
        self,
        agent_type: Optional[str] = None,
        fragment_type: Optional[FragmentType] = None,
        is_active: bool = True,
        limit: int = 100,
        offset: int = 0,
    ) -> List[InstructionFragment]:
        """List fragments with filtering.

        Args:
            agent_type: Filter by agent type.
            fragment_type: Filter by fragment type.
            is_active: Filter by active status.
            limit: Maximum results.
            offset: Pagination offset.

        Returns:
            List of fragments.
        """
        await self.ensure_index()

        from redis.commands.search.query import Query

        filters = []
        if is_active is not None:
            filters.append(f"@is_active:{{{str(is_active).lower()}}}")
        if agent_type:
            filters.append(f"@agent_type:{{{agent_type}}}")
        if fragment_type:
            filters.append(f"@fragment_type:{{{fragment_type.value}}}")

        query_str = " ".join(filters) if filters else "*"
        query = Query(query_str).return_fields("$").paging(offset, limit)

        try:
            results = self.redis.ft(self.config.fragment_index_name).search(query)

            fragments = []
            for doc in results.docs:
                try:
                    # Use getattr for Redis Document objects
                    json_data = getattr(doc, "$", None) or getattr(doc, "json", None)
                    if json_data:
                        data = json.loads(json_data) if isinstance(json_data, str) else json_data
                        if data:
                            fragments.append(InstructionFragment.from_dict(data))
                except Exception as e:
                    logger.warning(f"Failed to parse fragment: {e}")

            return fragments

        except Exception as e:
            logger.error(f"List failed: {e}")
            return []

    def close(self) -> None:
        """Close the Redis connection."""
        if self._redis:
            self._redis.close()
