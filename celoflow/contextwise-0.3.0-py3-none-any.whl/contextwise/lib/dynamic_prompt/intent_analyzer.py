"""Intent Analyzer for Dynamic Prompt Injection Plugin.

Analyzes user messages to extract semantic intent for fragment retrieval.
"""

import logging
from typing import Any, Dict, List, Literal, Optional

from .cloudflare_client import CloudflareEmbeddingClient
from .config import DynamicPromptConfig
from .exceptions import IntentAnalysisError
from .models import UserIntent

logger = logging.getLogger(__name__)


class IntentAnalyzer:
    """Analyzes user message + conversation history to extract semantic intent.

    Multi-signal intent extraction:
    1. Embed current message using Cloudflare Workers AI
    2. Extract task type from message patterns
    3. Detect domain from keyword overlap + semantic similarity
    4. Infer modality from channel + message structure
    5. Estimate complexity from message length + history
    """

    # Domain keyword mappings
    DOMAIN_KEYWORDS: Dict[str, List[str]] = {
        "finance": [
            "stock",
            "portfolio",
            "investment",
            "trading",
            "financial",
            "bank",
            "money",
            "budget",
            "expense",
            "revenue",
            "profit",
            "loss",
            "tax",
            "accounting",
        ],
        "healthcare": [
            "medical",
            "diagnosis",
            "treatment",
            "patient",
            "clinical",
            "doctor",
            "hospital",
            "symptom",
            "medicine",
            "health",
            "disease",
        ],
        "legal": [
            "law",
            "contract",
            "compliance",
            "regulatory",
            "legal",
            "court",
            "lawsuit",
            "attorney",
            "rights",
            "agreement",
        ],
        "technology": [
            "software",
            "hardware",
            "algorithm",
            "system",
            "network",
            "computer",
            "programming",
            "code",
            "api",
            "database",
        ],
        "data_science": [
            "analysis",
            "dataset",
            "model",
            "prediction",
            "statistics",
            "machine learning",
            "ai",
            "analytics",
            "visualization",
        ],
        "ecommerce": [
            "product",
            "order",
            "cart",
            "checkout",
            "shipping",
            "inventory",
            "customer",
            "sale",
            "discount",
            "price",
        ],
        "beauty": [
            "salon",
            "salão",
            "beauty",
            "beleza",
            "hair",
            "cabelo",
            "corte",
            "barber",
            "barbearia",
            "estética",
            "spa",
            "agendamento",
            "horário",
            "portfolio",
            "fotos",
            "transformação",
            "instagram",
            "google my business",
        ],
    }

    # Task type patterns
    TASK_PATTERNS: Dict[str, List[str]] = {
        "coding": [
            "write code",
            "implement",
            "function",
            "class",
            "```",
            "debug",
            "fix bug",
            "refactor",
            "programming",
        ],
        "creative": [
            "story",
            "poem",
            "creative",
            "imagine",
            "draft",
            "write a",
            "compose",
            "create a",
        ],
        "analysis": [
            "analyze",
            "compare",
            "summarize",
            "trends",
            "insights",
            "evaluate",
            "assess",
            "review",
        ],
    }

    # Urgency indicators
    HIGH_URGENCY_WORDS = ["urgent", "asap", "immediately", "critical", "emergency"]
    MEDIUM_URGENCY_WORDS = ["soon", "today", "quickly", "fast"]

    def __init__(
        self,
        config: DynamicPromptConfig,
        embedding_client: Optional[CloudflareEmbeddingClient] = None,
        agentfs_client: Optional[Any] = None,
    ):
        """Initialize the intent analyzer.

        Args:
            config: Plugin configuration.
            embedding_client: Cloudflare embedding client.
            agentfs_client: AgentFS memory client (optional).
        """
        self.config = config
        self.embedding_client = embedding_client or CloudflareEmbeddingClient(config)
        self.agentfs = agentfs_client
        self._domain_embeddings: Dict[str, List[float]] = {}

    async def analyze(
        self,
        message: str,
        context: Any,
        conversation_history: List[Dict[str, str]] = None,
    ) -> UserIntent:
        """Analyze user message to extract semantic intent.

        Args:
            message: The user's message.
            context: Agent context with session info.
            conversation_history: Previous conversation turns.

        Returns:
            UserIntent with extracted signals.
        """
        conversation_history = conversation_history or []

        try:
            # 1. Embed user message
            embedding = await self._embed_text(message)

            # 2. Extract task type
            task_type = self._classify_task_type(
                message=message,
                history=conversation_history,
            )

            # 3. Detect domain signals
            domain_signals = await self._detect_domains(
                message=message,
                embedding=embedding,
                history=conversation_history,
            )

            # 4. Infer modality
            modality = self._infer_modality(context)

            # 5. Estimate complexity
            complexity = self._estimate_complexity(
                message=message,
                history=conversation_history,
                task_type=task_type,
            )

            # 6. Predict required tools
            requires_tools = self._predict_required_tools(
                message=message,
                task_type=task_type,
                domain_signals=domain_signals,
            )

            # 7. Assess urgency
            urgency = self._assess_urgency(message)

            return UserIntent(
                embedding=embedding,
                task_type=task_type,
                domain_signals=domain_signals,
                modality=modality,
                complexity=complexity,
                requires_tools=requires_tools,
                urgency=urgency,
                confidence=0.8 if embedding else 0.5,
                raw_message=message,
            )

        except Exception as e:
            logger.error(f"Intent analysis failed: {e}", exc_info=True)
            # Return default intent on error
            return UserIntent(
                task_type="question_answering",
                modality=self._infer_modality(context),
                complexity="simple",
                raw_message=message,
            )

    def _classify_task_type(
        self,
        message: str,
        history: List[Dict[str, str]],
    ) -> str:
        """Classify task type using pattern matching + context.

        Args:
            message: User message.
            history: Conversation history.

        Returns:
            Task type string.
        """
        message_lower = message.lower()

        # Check each task type's patterns
        for task_type, patterns in self.TASK_PATTERNS.items():
            if any(pattern in message_lower for pattern in patterns):
                return task_type

        # Question indicators (default)
        question_starters = ["what", "how", "why", "when", "who", "where", "can you"]
        if any(message_lower.startswith(q) for q in question_starters):
            return "question_answering"

        # Fallback to context from history
        if history:
            # Check recent messages for task context
            for turn in reversed(history[-3:]):
                content = turn.get("content", "").lower()
                for task_type, patterns in self.TASK_PATTERNS.items():
                    if any(pattern in content for pattern in patterns):
                        return task_type

        return "question_answering"

    async def _detect_domains(
        self,
        message: str,
        embedding: List[float],
        history: List[Dict[str, str]],
    ) -> List[str]:
        """Detect domain signals using keyword and semantic matching.

        Args:
            message: User message.
            embedding: Message embedding.
            history: Conversation history.

        Returns:
            List of detected domains.
        """
        domains = []
        message_lower = message.lower()

        # Rule-based keyword detection
        for domain, keywords in self.DOMAIN_KEYWORDS.items():
            if any(kw in message_lower for kw in keywords):
                domains.append(domain)

        # Semantic similarity to domain embeddings (if no keyword hits)
        if not domains and embedding:
            domains = await self._semantic_domain_detection(embedding)

        # Check history for domain context
        if not domains and history:
            for turn in reversed(history[-5:]):
                content = turn.get("content", "").lower()
                for domain, keywords in self.DOMAIN_KEYWORDS.items():
                    if any(kw in content for kw in keywords):
                        domains.append(domain)
                        break

        # Deduplicate and limit to top 3
        return list(dict.fromkeys(domains))[:3]

    async def _semantic_domain_detection(
        self,
        embedding: List[float],
    ) -> List[str]:
        """Detect domains using semantic similarity.

        Args:
            embedding: Message embedding.

        Returns:
            List of detected domains.
        """
        if not self._domain_embeddings:
            # Load or compute domain embeddings
            await self._load_domain_embeddings()

        detected = []
        for domain, domain_emb in self._domain_embeddings.items():
            similarity = self._cosine_similarity(embedding, domain_emb)
            if similarity > 0.70:
                detected.append((domain, similarity))

        # Sort by similarity and return domain names
        detected.sort(key=lambda x: x[1], reverse=True)
        return [d[0] for d in detected[:3]]

    async def _load_domain_embeddings(self) -> None:
        """Load or compute domain keyword embeddings."""
        for domain, keywords in self.DOMAIN_KEYWORDS.items():
            # Embed a representative phrase for each domain
            domain_text = f"{domain}: {', '.join(keywords[:5])}"
            try:
                emb = await self.embedding_client.embed_texts([domain_text])
                if emb:
                    self._domain_embeddings[domain] = emb[0]
            except Exception as e:
                logger.warning(f"Failed to embed domain {domain}: {e}")

    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """Compute cosine similarity between two vectors."""
        if not a or not b or len(a) != len(b):
            return 0.0

        dot_product = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return dot_product / (norm_a * norm_b)

    def _infer_modality(self, context: Any) -> str:
        """Infer output modality from channel and context.

        Args:
            context: Agent context.

        Returns:
            Modality string (text, voice, code).
        """
        if context is None:
            return "text"

        # Check explicit modality
        if hasattr(context, "modality") and context.modality:
            return context.modality

        # Channel-based inference
        channel = getattr(context, "channel", "api")
        if channel in ["voice", "phone", "livekit"]:
            return "voice"
        elif channel in ["api", "whatsapp", "discord", "slack", "cli"]:
            return "text"

        return "text"

    def _estimate_complexity(
        self,
        message: str,
        history: List[Dict[str, str]],
        task_type: str,
    ) -> Literal["simple", "medium", "complex"]:
        """Estimate task complexity.

        Args:
            message: User message.
            history: Conversation history.
            task_type: Detected task type.

        Returns:
            Complexity level.
        """
        word_count = len(message.split())

        # Multi-step indicator
        step_indicators = ["first", "then", "next", "finally", "step 1", "step 2"]
        has_steps = any(indicator in message.lower() for indicator in step_indicators)

        # Complex coding tasks
        if task_type == "coding" and word_count > 50:
            return "complex"

        # Multi-step or long messages
        if has_steps or word_count > 100:
            return "complex"

        # Medium complexity
        if word_count > 30 or len(history) > 5:
            return "medium"

        return "simple"

    def _predict_required_tools(
        self,
        message: str,
        task_type: str,
        domain_signals: List[str],
    ) -> List[str]:
        """Predict which tools will be needed.

        Args:
            message: User message.
            task_type: Detected task type.
            domain_signals: Detected domains.

        Returns:
            List of predicted tool names.
        """
        tools = []
        message_lower = message.lower()

        # Code execution indicators
        code_indicators = ["run", "execute", "compile", "test", "debug"]
        if task_type == "coding" or any(kw in message_lower for kw in code_indicators):
            tools.append("code_interpreter")

        # Web search indicators
        search_indicators = ["search", "latest", "recent", "current", "news", "find"]
        if any(kw in message_lower for kw in search_indicators):
            tools.append("web_search")

        # Domain-specific tools
        if "finance" in domain_signals:
            tools.append("financial_data_api")
        if "ecommerce" in domain_signals:
            tools.append("ecommerce_api")

        # File operations
        file_indicators = ["file", "read", "write", "save", "upload", "download"]
        if any(kw in message_lower for kw in file_indicators):
            tools.append("filesystem")

        return tools

    def _assess_urgency(self, message: str) -> Literal["low", "medium", "high"]:
        """Assess urgency from message markers.

        Args:
            message: User message.

        Returns:
            Urgency level.
        """
        message_lower = message.lower()

        if any(kw in message_lower for kw in self.HIGH_URGENCY_WORDS):
            return "high"
        elif any(kw in message_lower for kw in self.MEDIUM_URGENCY_WORDS):
            return "medium"

        return "low"

    async def _embed_text(self, text: str) -> List[float]:
        """Generate embedding for text.

        Args:
            text: Text to embed.

        Returns:
            Embedding vector.
        """
        try:
            embeddings = await self.embedding_client.embed_texts([text])
            return embeddings[0] if embeddings else []
        except RuntimeError as e:
            # Handle event loop closed errors gracefully
            if "Event loop is closed" in str(e):
                logger.debug(f"Event loop closed, skipping embedding: {e}")
            else:
                logger.warning(f"Runtime error in embedding: {e}")
            return []
        except Exception as e:
            logger.warning(f"Failed to embed text: {e}")
            return []
