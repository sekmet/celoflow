"""Cloudflare Workers AI client for embedding generation."""

import asyncio
import logging
import time
from typing import List, Optional, Dict, Any

import httpx

from .config import DynamicPromptConfig
from .exceptions import EmbeddingError

logger = logging.getLogger(__name__)


class CloudflareEmbeddingClient:
    """Client for Cloudflare Workers AI embedding generation.

    Uses the @cf/qwen/qwen3-embedding-0.6b model by default (1024 dimensions).

    Attributes:
        config: Plugin configuration.
        _client: HTTP client for API requests.
    """

    def __init__(self, config: DynamicPromptConfig):
        """Initialize the Cloudflare embedding client.

        Args:
            config: Plugin configuration with Cloudflare credentials.
        """
        self.config = config
        self._client: Optional[httpx.AsyncClient] = None
        self._sync_client: Optional[httpx.Client] = None

    @property
    def api_url(self) -> str:
        """Get the API URL for the embedding model."""
        return self.config.get_cloudflare_api_url(self.config.embedding_model)

    @property
    def headers(self) -> Dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.config.cloudflare_api_token}",
            "Content-Type": "application/json",
        }

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=self.config.timeout,
                headers=self.headers,
            )
        return self._client

    def _get_sync_client(self) -> httpx.Client:
        """Get or create sync HTTP client."""
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(
                timeout=self.config.timeout,
                headers=self.headers,
            )
        return self._sync_client

    def _get_retry_delay(self, response: Optional[httpx.Response] = None, attempt: int = 0) -> float:
        """Calculate retry delay with rate limit handling.
        
        Args:
            response: HTTP response (if available).
            attempt: Current retry attempt number.
            
        Returns:
            Delay in seconds before next retry.
        """
        # Check for Retry-After header for rate limits
        if response and response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                try:
                    # Retry-After can be seconds or HTTP date
                    if retry_after.isdigit():
                        return float(retry_after) + 0.1  # Add small buffer
                    else:
                        # Parse HTTP date format
                        from datetime import datetime, timezone
                        # Handle different HTTP date formats
                        for fmt in ("%a, %d %b %Y %H:%M:%S GMT", "%a, %d %b %Y %H:%M:%S %Z"):
                            try:
                                retry_time = datetime.strptime(retry_after, fmt)
                                if retry_time.tzinfo is None:
                                    retry_time = retry_time.replace(tzinfo=timezone.utc)
                                delay = (retry_time.timestamp() - time.time()) + 0.1
                                return max(delay, 1.0)  # Minimum 1 second
                            except ValueError:
                                continue
                        logger.warning(f"Unable to parse Retry-After header: {retry_after}")
                except (ValueError, TypeError):
                    logger.warning(f"Invalid Retry-After header: {retry_after}")
        
        # For rate limits (429), use longer exponential backoff
        if response and response.status_code == 429:
            # Start with 2 seconds, then exponential: 2, 4, 8, 16...
            base_delay = 2.0
            return base_delay * (2 ** attempt)
        
        # For other errors, use standard exponential backoff
        return self.config.retry_delay * (2 ** attempt)

    async def embed_text(self, text: str) -> List[float]:
        """Generate embedding for a single text.

        Args:
            text: Text to embed.

        Returns:
            Embedding vector (1024 dimensions by default).

        Raises:
            EmbeddingError: If embedding generation fails.
        """
        return await self.embed_texts([text])[0] if text else []

    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts.

        Args:
            texts: List of texts to embed.

        Returns:
            List of embedding vectors.

        Raises:
            EmbeddingError: If embedding generation fails.
        """
        if not texts:
            return []

        if not self.config.has_cloudflare_credentials:
            raise EmbeddingError(
                "Cloudflare credentials not configured. "
                "Set CLOUDFLARE_API_KEY and CLOUDFLARE_ACCOUNT_ID."
            )

        client = await self._get_client()
        last_response = None

        for attempt in range(self.config.max_retries):
            try:
                response = await client.post(
                    self.api_url,
                    json={"text": texts},
                )
                last_response = response
                response.raise_for_status()

                result = response.json()
                if not result.get("success", False):
                    errors = result.get("errors", [])
                    raise EmbeddingError(f"API returned errors: {errors}")

                data = result.get("result", {}).get("data", [])
                if not data:
                    raise EmbeddingError("No embedding data in response")

                return data

            except httpx.HTTPStatusError as e:
                response = getattr(e, 'response', None)
                is_rate_limit = response and response.status_code == 429
                
                if is_rate_limit:
                    logger.warning(
                        f"Cloudflare API rate limit exceeded (attempt {attempt + 1}/{self.config.max_retries}). "
                        f"Retrying after delay..."
                    )
                else:
                    logger.warning(
                        f"Cloudflare API error (attempt {attempt + 1}/{self.config.max_retries}): {e}"
                    )
                
                if attempt == self.config.max_retries - 1:
                    error_msg = (
                        f"Rate limit exceeded after {self.config.max_retries} attempts"
                        if is_rate_limit
                        else f"Cloudflare API error after {self.config.max_retries} attempts"
                    )
                    raise EmbeddingError(error_msg, original_error=e)
                
                delay = self._get_retry_delay(response, attempt)
                logger.info(f"Waiting {delay:.1f}s before retry...")
                await asyncio.sleep(delay)

            except httpx.RequestError as e:
                logger.warning(
                    f"Request error (attempt {attempt + 1}/{self.config.max_retries}): {e}"
                )
                if attempt == self.config.max_retries - 1:
                    raise EmbeddingError(
                        f"Request failed after {self.config.max_retries} attempts",
                        original_error=e,
                    )
                delay = self._get_retry_delay(None, attempt)
                await asyncio.sleep(delay)

        return []

    def embed_text_sync(self, text: str) -> List[float]:
        """Generate embedding synchronously (for setup/initialization).

        Args:
            text: Text to embed.

        Returns:
            Embedding vector.

        Raises:
            EmbeddingError: If embedding generation fails.
        """
        if not text:
            return []

        if not self.config.has_cloudflare_credentials:
            raise EmbeddingError(
                "Cloudflare credentials not configured. "
                "Set CLOUDFLARE_API_KEY and CLOUDFLARE_ACCOUNT_ID."
            )

        client = self._get_sync_client()

        for attempt in range(self.config.max_retries):
            try:
                response = client.post(
                    self.api_url,
                    json={"text": [text]},
                )
                response.raise_for_status()

                result = response.json()
                if not result.get("success", False):
                    errors = result.get("errors", [])
                    raise EmbeddingError(f"API returned errors: {errors}")

                data = result.get("result", {}).get("data", [])
                if not data:
                    raise EmbeddingError("No embedding data in response")

                return data[0]

            except httpx.HTTPStatusError as e:
                response = getattr(e, 'response', None)
                is_rate_limit = response and response.status_code == 429
                
                if is_rate_limit:
                    logger.warning(
                        f"Cloudflare API rate limit exceeded (attempt {attempt + 1}/{self.config.max_retries}). "
                        f"Retrying after delay..."
                    )
                else:
                    logger.warning(
                        f"Cloudflare API error (attempt {attempt + 1}/{self.config.max_retries}): {e}"
                    )
                
                if attempt == self.config.max_retries - 1:
                    error_msg = (
                        f"Rate limit exceeded after {self.config.max_retries} attempts"
                        if is_rate_limit
                        else f"Cloudflare API error after {self.config.max_retries} attempts"
                    )
                    raise EmbeddingError(error_msg, original_error=e)
                
                delay = self._get_retry_delay(response, attempt)
                logger.info(f"Waiting {delay:.1f}s before retry...")
                time.sleep(delay)

            except httpx.RequestError as e:
                logger.warning(
                    f"Request error (attempt {attempt + 1}/{self.config.max_retries}): {e}"
                )
                if attempt == self.config.max_retries - 1:
                    raise EmbeddingError(
                        f"Request failed after {self.config.max_retries} attempts",
                        original_error=e,
                    )
                delay = self._get_retry_delay(None, attempt)
                time.sleep(delay)

        return []

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()

    async def __aenter__(self) -> "CloudflareEmbeddingClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()
