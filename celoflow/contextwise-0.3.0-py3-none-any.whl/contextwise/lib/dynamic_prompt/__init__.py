"""Dynamic Prompt Injection Plugin.

This plugin dynamically assembles system instructions from semantic fragments
stored in Redis. It integrates with Cloudflare Workers AI for embeddings and
AgentFS memory for session context.

Main components:
- DynamicPromptInjectionPlugin: Main plugin class
- IntentAnalyzer: Multi-signal intent extraction
- FragmentRetrievalEngine: Multi-stage fragment retrieval
- DynamicPromptBuilder: Prompt assembly with caching
- CloudflareEmbeddingClient: Embedding generation

Usage:
    from contextwise.lib.dynamic_prompt import (
        DynamicPromptInjectionPlugin,
        DynamicPromptConfig,
    )

    config = DynamicPromptConfig(
        redis_url="redis://localhost:6389",
        cloudflare_api_token="your-api-token",
        cloudflare_account_id="your-account-id",
    )

    plugin = DynamicPromptInjectionPlugin(config=config)
"""

from .config import DynamicPromptConfig
from .models import (
    InstructionFragment,
    UserIntent,
    FragmentType,
    FragmentPriority,
    AssemblyMetrics,
)
from .exceptions import (
    DynamicPromptError,
    FragmentNotFoundError,
    EmbeddingError,
    RedisConnectionError,
    CacheError,
)
from .plugin import DynamicPromptInjectionPlugin

__all__ = [
    # Plugin
    "DynamicPromptInjectionPlugin",
    # Config
    "DynamicPromptConfig",
    # Models
    "InstructionFragment",
    "UserIntent",
    "FragmentType",
    "FragmentPriority",
    "AssemblyMetrics",
    # Exceptions
    "DynamicPromptError",
    "FragmentNotFoundError",
    "EmbeddingError",
    "RedisConnectionError",
    "CacheError",
]
