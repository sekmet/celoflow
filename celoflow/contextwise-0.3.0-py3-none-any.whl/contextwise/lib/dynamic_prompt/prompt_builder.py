"""Dynamic Prompt Builder for Dynamic Prompt Injection Plugin.

Assembles dynamic system instructions from fragments with caching.
"""

import hashlib
import logging
from typing import Any, Dict, List, Optional, Tuple

from .config import DynamicPromptConfig
from .exceptions import CacheError, PromptAssemblyError
from .models import AssemblyMetrics, FragmentType, InstructionFragment

logger = logging.getLogger(__name__)


class DynamicPromptBuilder:
    """Assembles dynamic system instructions from fragments.

    Handles template variable injection, section organization, and caching.

    Attributes:
        config: Plugin configuration.
        redis: Redis client for caching.
    """

    CACHE_PREFIX = "prompt_cache"

    # Section order for prompt assembly
    SECTION_ORDER = ["role", "capabilities", "domain", "constraints", "guidance", "examples"]

    def __init__(
        self,
        config: DynamicPromptConfig,
        redis_client: Any = None,
    ):
        """Initialize the prompt builder.

        Args:
            config: Plugin configuration.
            redis_client: Redis client for caching (optional).
        """
        self.config = config
        self._redis = redis_client

    @property
    def redis(self) -> Any:
        """Get Redis client."""
        if self._redis is None:
            import redis
            self._redis = redis.Redis.from_url(
                self.config.redis_url,
                decode_responses=True,
            )
        return self._redis

    async def build_prompt(
        self,
        fragments: List[InstructionFragment],
        context: Any,
        session_variables: Dict[str, str] = None,
    ) -> Tuple[str, str, AssemblyMetrics]:
        """Build dynamic system prompt from fragments.

        Args:
            fragments: Selected fragments to assemble.
            context: Agent context.
            session_variables: Variables for template injection.

        Returns:
            Tuple of (assembled_prompt, checksum, metrics).
        """
        import time

        start_time = time.time()
        session_variables = session_variables or {}
        metrics = AssemblyMetrics()

        try:
            # Generate checksum from fragment IDs + version
            checksum = self._compute_checksum(fragments, session_variables)
            metrics.checksum = checksum
            metrics.fragment_ids = [f.fragment_id for f in fragments]

            # Check cache
            if self.config.enable_prompt_cache:
                cached_prompt = await self._get_cached_prompt(checksum)
                if cached_prompt:
                    # Inject fresh session variables into cached template
                    final_prompt = self._inject_variables(cached_prompt, session_variables)
                    metrics.cache_hit = True
                    metrics.total_time_ms = (time.time() - start_time) * 1000
                    logger.debug(f"Cache hit for checksum {checksum[:16]}...")
                    return final_prompt, checksum, metrics

            # Assemble prompt from fragments
            assembly_start = time.time()
            assembled_prompt = self._assemble_fragments(fragments)
            metrics.assembly_time_ms = (time.time() - assembly_start) * 1000

            # Cache the template (before variable injection)
            if self.config.enable_prompt_cache:
                await self._cache_prompt(checksum, assembled_prompt)

            # Inject session variables
            final_prompt = self._inject_variables(assembled_prompt, session_variables)

            # Update metrics
            metrics.fragment_count = len(fragments)
            metrics.total_tokens = sum(f.avg_token_contribution for f in fragments)
            metrics.total_time_ms = (time.time() - start_time) * 1000

            logger.debug(
                f"Assembled prompt with {len(fragments)} fragments, "
                f"~{metrics.total_tokens} tokens, "
                f"in {metrics.total_time_ms:.2f}ms"
            )

            return final_prompt, checksum, metrics

        except Exception as e:
            logger.error(f"Prompt assembly failed: {e}", exc_info=True)
            raise PromptAssemblyError(str(e), original_error=e)

    def _compute_checksum(
        self,
        fragments: List[InstructionFragment],
        session_variables: Dict[str, str],
    ) -> str:
        """Compute checksum from fragment IDs and versions.

        Args:
            fragments: Fragments to include.
            session_variables: Variable keys (not values).

        Returns:
            SHA256 checksum string.
        """
        # Sort fragments by ID for consistent hashing
        fragment_signature = "|".join(
            f"{f.fragment_id}:{f.version}"
            for f in sorted(fragments, key=lambda x: x.fragment_id)
        )

        # Include variable keys (not values, since they change)
        variable_keys = "|".join(sorted(session_variables.keys()))

        signature = f"{fragment_signature}::{variable_keys}"
        return hashlib.sha256(signature.encode()).hexdigest()

    def _assemble_fragments(
        self,
        fragments: List[InstructionFragment],
    ) -> str:
        """Assemble fragments into structured prompt.

        Structure:
        # ROLE
        <core role fragments>

        # CAPABILITIES
        <capability fragments>

        # DOMAIN KNOWLEDGE
        <domain fragments>

        # CONSTRAINTS & GUIDELINES
        <constraint fragments>

        # CONTEXTUAL GUIDANCE
        <scenario/correction fragments>

        Args:
            fragments: Fragments to assemble.

        Returns:
            Assembled prompt string.
        """
        # Group fragments by section
        sections: Dict[str, List[InstructionFragment]] = {
            "role": [],
            "capabilities": [],
            "domain": [],
            "constraints": [],
            "guidance": [],
            "examples": [],
        }

        for fragment in fragments:
            section = fragment.section or self._infer_section(fragment)
            if section in sections:
                sections[section].append(fragment)

        # Build prompt sections
        prompt_parts: List[str] = []

        section_headers = {
            "role": "# ROLE",
            "capabilities": "# CAPABILITIES",
            "domain": "# DOMAIN KNOWLEDGE",
            "constraints": "# CONSTRAINTS & GUIDELINES",
            "guidance": "# CONTEXTUAL GUIDANCE",
            "examples": "# EXAMPLES",
        }

        for section_name in self.SECTION_ORDER:
            section_fragments = sections.get(section_name, [])
            if section_fragments:
                header = section_headers.get(section_name, f"# {section_name.upper()}")
                prompt_parts.append(header)
                prompt_parts.extend(self._merge_fragments(section_fragments))
                prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _infer_section(self, fragment: InstructionFragment) -> str:
        """Infer section from fragment type if not explicitly set.

        Args:
            fragment: Fragment to infer section for.

        Returns:
            Section name.
        """
        type_to_section = {
            FragmentType.CORE: "role",
            FragmentType.DOMAIN: "domain",
            FragmentType.CAPABILITY: "capabilities",
            FragmentType.SCENARIO: "guidance",
            FragmentType.CORRECTION: "constraints",
        }
        return type_to_section.get(fragment.fragment_type, "guidance")

    def _merge_fragments(
        self,
        fragments: List[InstructionFragment],
    ) -> List[str]:
        """Merge fragments according to their merge_strategy.

        Strategies:
        - append: Add to section in order
        - prepend: Add to beginning of section
        - replace: Replace entire section
        - merge: Intelligent merge (remove duplicates, consolidate)

        Args:
            fragments: Fragments to merge.

        Returns:
            List of merged content strings.
        """
        merged: List[str] = []

        # Group by merge strategy
        replace_fragments = [f for f in fragments if f.merge_strategy == "replace"]
        prepend_fragments = [f for f in fragments if f.merge_strategy == "prepend"]
        append_fragments = [f for f in fragments if f.merge_strategy == "append"]
        merge_fragments = [f for f in fragments if f.merge_strategy == "merge"]

        # Process replace (takes precedence)
        if replace_fragments:
            # Use the highest priority replace fragment
            replace_fragments.sort(key=lambda f: f.priority.value, reverse=True)
            merged.append(replace_fragments[0].content)
            return merged

        # Process prepend
        for fragment in prepend_fragments:
            merged.insert(0, fragment.content)

        # Process append
        for fragment in append_fragments:
            merged.append(fragment.content)

        # Process merge (smart consolidation)
        if merge_fragments:
            consolidated = self._smart_merge(merge_fragments)
            merged.append(consolidated)

        return merged

    def _smart_merge(
        self,
        fragments: List[InstructionFragment],
    ) -> str:
        """Intelligently merge fragments.

        Removes duplicate sentences and maintains logical flow.

        Args:
            fragments: Fragments to merge.

        Returns:
            Merged content string.
        """
        sentences: List[str] = []
        seen: set = set()

        for fragment in fragments:
            for sentence in fragment.content.split(". "):
                sentence = sentence.strip()
                if sentence and sentence not in seen:
                    sentences.append(sentence)
                    seen.add(sentence)

        result = ". ".join(sentences)
        if result and not result.endswith("."):
            result += "."

        return result

    def _inject_variables(
        self,
        template: str,
        variables: Dict[str, str],
    ) -> str:
        """Inject session-specific variables into template.

        Variables format: {variable_name}
        Example: "You are an assistant for {company_name}"

        Args:
            template: Template string with placeholders.
            variables: Variable values.

        Returns:
            Template with variables injected.
        """
        result = template
        for key, value in variables.items():
            placeholder = f"{{{key}}}"
            result = result.replace(placeholder, str(value))
        return result

    async def _get_cached_prompt(self, checksum: str) -> Optional[str]:
        """Get cached prompt by checksum.

        Args:
            checksum: Prompt checksum.

        Returns:
            Cached prompt or None.
        """
        try:
            return self.redis.hget(self.CACHE_PREFIX, checksum)
        except Exception as e:
            logger.warning(f"Cache read failed: {e}")
            return None

    async def _cache_prompt(self, checksum: str, prompt: str) -> None:
        """Cache assembled prompt.

        Args:
            checksum: Prompt checksum.
            prompt: Assembled prompt.
        """
        try:
            self.redis.hset(self.CACHE_PREFIX, checksum, prompt)
            # Set TTL on the hash if not already set
            ttl = self.redis.ttl(self.CACHE_PREFIX)
            if ttl == -1:  # No TTL set
                self.redis.expire(self.CACHE_PREFIX, self.config.cache_ttl)
        except Exception as e:
            logger.warning(f"Cache write failed: {e}")

    async def clear_cache(self) -> int:
        """Clear the prompt cache.

        Returns:
            Number of entries cleared.
        """
        try:
            count = self.redis.hlen(self.CACHE_PREFIX)
            self.redis.delete(self.CACHE_PREFIX)
            logger.info(f"Cleared {count} cached prompts")
            return count
        except Exception as e:
            logger.warning(f"Cache clear failed: {e}")
            return 0

    async def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics.

        Returns:
            Cache statistics dict.
        """
        try:
            count = self.redis.hlen(self.CACHE_PREFIX)
            ttl = self.redis.ttl(self.CACHE_PREFIX)
            return {
                "entries": count,
                "ttl_seconds": ttl,
                "prefix": self.CACHE_PREFIX,
            }
        except Exception as e:
            logger.warning(f"Failed to get cache stats: {e}")
            return {"error": str(e)}
