"""Core orchestrator that ensures ALL retry and fallback options are exhausted
before showing honest error message to user.

Design Decision: Clear execution flow:
1. Check circuit breaker (fail fast if open)
2. Execute with retry strategy (multiple attempts)
3. If retry fails, try fallback providers (one by one)
4. ONLY if everything fails, create user-facing error message

This ensures users NEVER see technical errors when there are still options to try.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Callable, Dict, List, Optional, Type

from .interfaces import (
    ErrorClassifierInterface,
    RetryStrategyInterface,
    CircuitBreakerInterface,
    FallbackStrategyInterface,
    MetricsCollectorInterface,
    LocalizationInterface,
)
from .types import ErrorCategory, ErrorContext, ErrorHandlingResult, CircuitBreakerState
from ..registry.plugin_registry import PluginRegistry
from ..exceptions import CircuitBreakerOpenError, AllProvidersFailedError

logger = logging.getLogger(__name__)


class ErrorHandlingOrchestrator:
    """Core orchestrator with CRITICAL execution guarantee:
    User error messages are ONLY shown after ALL retry and fallback attempts.

    Execution Flow:
    1. Primary provider with full retry logic
    2. Fallback provider(s) with full retry logic
    3. Emergency fallback if configured
    4. ONLY THEN: Honest user message in their locale
    """

    def __init__(
        self,
        config: Any,
        plugin_registry: Optional[PluginRegistry] = None,
    ):
        self.config = config
        self.registry = plugin_registry or PluginRegistry()

        # Import plugins to trigger registration
        self._ensure_plugins_registered()

        # Load plugins via dependency injection
        self.classifier = self._load_plugin(
            ErrorClassifierInterface,
            config.plugins.classifier
        )
        self.retry_strategy = self._load_plugin(
            RetryStrategyInterface,
            config.plugins.retry_strategy,
            max_attempts=config.max_retries,
            base_delay=config.retry_base_delay,
            max_delay=config.retry_max_delay,
            exponential_base=config.retry_exponential_base,
            jitter_factor=config.retry_jitter_factor,
        )
        self.circuit_breaker = self._load_plugin(
            CircuitBreakerInterface,
            config.plugins.circuit_breaker,
            failure_threshold=config.circuit_breaker_failure_threshold,
            recovery_timeout=config.circuit_breaker_recovery_timeout,
            half_open_max_calls=config.circuit_breaker_half_open_calls,
        )
        self.fallback_strategy = self._load_plugin(
            FallbackStrategyInterface,
            config.plugins.fallback_strategy
        )
        self.metrics = self._load_plugin(
            MetricsCollectorInterface,
            config.plugins.metrics_collector
        )
        self.localizer = self._load_plugin(
            LocalizationInterface,
            config.plugins.localizer
        )

        # Cost tracking per conversation
        self._conversation_costs: Dict[str, float] = {}
        self._cost_lock = asyncio.Lock()

        logger.info(
            f"ErrorHandlingOrchestrator initialized with plugins: "
            f"classifier={config.plugins.classifier}, "
            f"retry={config.plugins.retry_strategy}, "
            f"fallback={config.plugins.fallback_strategy}"
        )

    @staticmethod
    def _ensure_plugins_registered():
        """Import all plugin modules to trigger @register_plugin decorators."""
        # These imports trigger the decorator registration
        from ..plugins import classifiers  # noqa: F401
        from ..plugins import retry_strategies  # noqa: F401
        from ..plugins import fallback_strategies  # noqa: F401
        from ..plugins import circuit_breakers  # noqa: F401
        from ..plugins import metrics  # noqa: F401
        from ..plugins import localization  # noqa: F401

    def _load_plugin(self, interface: Type, plugin_name: str, **kwargs):
        """Load plugin via dependency injection."""
        plugin = self.registry.get_plugin(interface, plugin_name, **kwargs)
        if not plugin:
            raise ValueError(
                f"Plugin not found: {plugin_name} for interface {interface.__name__}. "
                f"Available: {self.registry.list_plugins(interface)}"
            )
        return plugin

    async def execute_with_resilience(
        self,
        operation: Callable,
        context: ErrorContext,
        fallback_operations: Optional[List[Callable]] = None,
        **kwargs,
    ) -> ErrorHandlingResult:
        """Execute operation with EXHAUSTIVE retry and fallback before user error.

        CRITICAL GUARANTEE: User error message is ONLY shown after:
        1. Primary operation tried with full retry logic
        2. ALL fallback operations tried with full retry logic
        3. No other options remain

        Args:
            operation: Primary operation to execute
            context: Error context with user locale, conversation ID, etc.
            fallback_operations: Optional list of fallback operations to try
            **kwargs: Arguments for operations

        Returns:
            ErrorHandlingResult with success status and user message ONLY if all failed
        """
        start_time = time.time()
        all_providers_tried = [context.provider_id]
        total_attempts = 0

        # Step 1: Check circuit breaker BEFORE any attempts
        if not await self.circuit_breaker.can_execute(context.provider_id):
            logger.warning(
                f"Circuit breaker OPEN for {context.provider_id}, "
                f"skipping primary and trying fallbacks immediately"
            )
            self.metrics.record_circuit_breaker_trip(context.provider_id)

            # Circuit breaker open - skip primary and go straight to fallbacks
            if fallback_operations and self.config.fallback_enabled:
                return await self._try_all_fallbacks(
                    fallback_operations=fallback_operations,
                    context=context,
                    all_providers_tried=all_providers_tried,
                    total_attempts=total_attempts,
                    start_time=start_time,
                    **kwargs,
                )
            else:
                # No fallbacks available - create user message
                return self._create_final_user_message(
                    error=CircuitBreakerOpenError(f"Circuit breaker open for {context.provider_id}"),
                    context=context,
                    all_providers_tried=all_providers_tried,
                    total_attempts=0,
                    start_time=start_time,
                )

        # Step 2: Try primary provider with FULL retry logic
        logger.info(
            f"Attempting primary provider {context.provider_id} with retry logic"
        )

        primary_result = await self.retry_strategy.execute_with_retry(
            operation=operation,
            context=context,
            classifier=self.classifier,
            circuit_breaker=self.circuit_breaker,
            **kwargs,
        )

        total_attempts += primary_result.attempts

        # Primary succeeded - return immediately
        if primary_result.success:
            logger.info(
                f"Primary provider {context.provider_id} succeeded "
                f"after {primary_result.attempts} attempts"
            )
            primary_result.total_duration = time.time() - start_time
            primary_result.providers_tried = all_providers_tried
            self.metrics.record_success(context, primary_result)
            return primary_result

        # Step 3: Primary failed - log and try ALL fallbacks
        logger.warning(
            f"Primary provider {context.provider_id} failed after "
            f"{primary_result.attempts} attempts: {primary_result.error}"
        )

        # Step 4: Try ALL fallback operations
        if fallback_operations and self.config.fallback_enabled:
            return await self._try_all_fallbacks(
                fallback_operations=fallback_operations,
                context=context,
                all_providers_tried=all_providers_tried,
                total_attempts=total_attempts,
                start_time=start_time,
                **kwargs,
            )

        # Step 5: NO fallbacks available - create honest user message
        logger.error(
            f"All retry attempts exhausted for {context.provider_id}, "
            f"no fallbacks configured. Showing user error message."
        )

        return self._create_final_user_message(
            error=primary_result.error,
            context=context,
            all_providers_tried=all_providers_tried,
            total_attempts=total_attempts,
            start_time=start_time,
        )

    async def _try_all_fallbacks(
        self,
        fallback_operations: List[Callable],
        context: ErrorContext,
        all_providers_tried: List[str],
        total_attempts: int,
        start_time: float,
        **kwargs,
    ) -> ErrorHandlingResult:
        """Try ALL fallback operations with full retry logic.

        CRITICAL: This method tries EVERY fallback operation before giving up.
        User message is ONLY shown if ALL fallbacks fail.
        """
        logger.info(
            f"Primary provider failed. Trying {len(fallback_operations)} fallback(s)"
        )

        fallback_providers = kwargs.get('fallback_providers', [])

        for idx, fallback_op in enumerate(fallback_operations):
            fallback_provider = (
                fallback_providers[idx]
                if idx < len(fallback_providers)
                else f"fallback_{idx}"
            )

            logger.info(
                f"Attempting fallback provider {fallback_provider} "
                f"({idx + 1}/{len(fallback_operations)})"
            )

            all_providers_tried.append(fallback_provider)

            # Check circuit breaker for fallback provider
            if not await self.circuit_breaker.can_execute(fallback_provider):
                logger.warning(
                    f"Circuit breaker OPEN for fallback provider {fallback_provider}, "
                    f"skipping to next fallback"
                )
                self.metrics.record_circuit_breaker_trip(fallback_provider)
                continue

            # Create new context for fallback
            fallback_context = ErrorContext(
                provider_id=fallback_provider,
                operation=context.operation,
                attempt=1,
                total_cost=context.total_cost,
                user_locale=context.user_locale,
                conversation_id=context.conversation_id,
                metadata=context.metadata,
            )

            # Try fallback with FULL retry logic
            fallback_result = await self.retry_strategy.execute_with_retry(
                operation=fallback_op,
                context=fallback_context,
                classifier=self.classifier,
                circuit_breaker=self.circuit_breaker,
                **kwargs,
            )

            total_attempts += fallback_result.attempts

            # Fallback succeeded - return with metadata
            if fallback_result.success:
                logger.info(
                    f"Fallback provider {fallback_provider} succeeded "
                    f"after {fallback_result.attempts} attempts"
                )
                fallback_result.fallback_used = True
                fallback_result.provider_used = fallback_provider
                fallback_result.providers_tried = all_providers_tried
                fallback_result.retry_count = total_attempts
                fallback_result.total_duration = time.time() - start_time
                self.metrics.record_fallback_success(context, fallback_result)
                return fallback_result

            # Fallback failed - log and try next one
            logger.warning(
                f"Fallback provider {fallback_provider} failed after "
                f"{fallback_result.attempts} attempts: {fallback_result.error}"
            )

        # ALL fallbacks exhausted - create honest user message
        logger.error(
            f"ALL providers failed ({', '.join(all_providers_tried)}). "
            f"Total attempts: {total_attempts}. Showing user error message."
        )

        return self._create_final_user_message(
            error=AllProvidersFailedError(
                f"All providers failed after {total_attempts} attempts"
            ),
            context=context,
            all_providers_tried=all_providers_tried,
            total_attempts=total_attempts,
            start_time=start_time,
        )

    def _create_final_user_message(
        self,
        error: Exception,
        context: ErrorContext,
        all_providers_tried: List[str],
        total_attempts: int,
        start_time: float,
    ) -> ErrorHandlingResult:
        """Create final user-facing error message ONLY after all options exhausted.

        Design Decision: Use localization to provide honest, actionable message
        in user's language. Message should be empathetic and helpful.
        """
        # Classify error to determine appropriate message
        error_category = self.classifier.classify(error, context.provider_id)

        # Map error category to message key
        message_key_map = {
            ErrorCategory.RATE_LIMIT: "rate_limit_exhausted",
            ErrorCategory.AUTHENTICATION: "authentication_failed",
            ErrorCategory.RESOURCE_EXHAUSTED: "resource_exhausted",
            ErrorCategory.CIRCUIT_BREAKER_OPEN: "service_temporarily_unavailable",
            ErrorCategory.COST_LIMIT_EXCEEDED: "cost_limit_exceeded",
            ErrorCategory.TRANSIENT: "temporary_service_issue",
            ErrorCategory.PERMANENT: "request_cannot_be_processed",
            ErrorCategory.UNKNOWN: "unexpected_error",
        }

        message_key = message_key_map.get(error_category, "unexpected_error")

        # Get localized message with context
        user_message = self.localizer.get_message(
            message_key=message_key,
            locale=context.user_locale,
            providers_tried=len(all_providers_tried),
            total_attempts=total_attempts,
        )

        # Create result with comprehensive metadata
        result = ErrorHandlingResult(
            success=False,
            error=error,
            provider_used=None,
            attempts=total_attempts,
            user_message=user_message,
            providers_tried=all_providers_tried,
            retry_count=total_attempts,
            total_duration=time.time() - start_time,
        )

        # Record failure metrics
        self.metrics.record_failure(context, result)

        # Log comprehensive failure details for debugging
        logger.error(
            f"FINAL FAILURE - User message shown. "
            f"Details: providers_tried={all_providers_tried}, "
            f"total_attempts={total_attempts}, "
            f"duration={result.total_duration:.2f}s, "
            f"error_category={error_category.value}, "
            f"locale={context.user_locale}, "
            f"conversation_id={context.conversation_id}"
        )

        return result
