"""Abstract interfaces for error handling plugins.

Design Decision: Depend on abstractions, not implementations (Dependency Inversion Principle).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

from .types import ErrorCategory, ErrorContext, ErrorHandlingResult, CircuitBreakerState

if TYPE_CHECKING:
    from .orchestrator import ErrorHandlingOrchestrator


class ErrorClassifierInterface(ABC):
    """Interface for error classification plugins."""

    @abstractmethod
    def classify(self, error: Exception, provider_id: str) -> ErrorCategory:
        """Classify error into category.

        Args:
            error: Exception to classify
            provider_id: Provider that raised the error

        Returns:
            ErrorCategory for this error
        """
        pass

    @abstractmethod
    def is_retryable(self, category: ErrorCategory) -> bool:
        """Check if error category is retryable."""
        pass


class RetryStrategyInterface(ABC):
    """Interface for retry strategy plugins."""

    @abstractmethod
    async def execute_with_retry(
        self,
        operation: Callable,
        context: ErrorContext,
        classifier: ErrorClassifierInterface,
        circuit_breaker: CircuitBreakerInterface,
        **kwargs,
    ) -> ErrorHandlingResult:
        """Execute operation with retry logic.

        Design Decision: Returns result even on failure (no exceptions thrown).
        This allows fallback strategies to handle gracefully.
        """
        pass


class CircuitBreakerInterface(ABC):
    """Interface for circuit breaker plugins."""

    @abstractmethod
    async def can_execute(self, provider_id: str) -> bool:
        """Check if provider can execute requests."""
        pass

    @abstractmethod
    async def record_success(self, provider_id: str) -> None:
        """Record successful execution."""
        pass

    @abstractmethod
    async def record_failure(self, provider_id: str, error: Exception) -> None:
        """Record failed execution."""
        pass

    @abstractmethod
    def get_state(self, provider_id: str) -> CircuitBreakerState:
        """Get current circuit breaker state."""
        pass


class FallbackStrategyInterface(ABC):
    """Interface for fallback strategy plugins."""

    @abstractmethod
    async def handle_failure(
        self,
        primary_result: ErrorHandlingResult,
        context: ErrorContext,
        orchestrator: ErrorHandlingOrchestrator,
        available_providers: List[str],
        **kwargs,
    ) -> ErrorHandlingResult:
        """Handle failure by trying fallback providers.

        Design Decision: Receives list of available providers and tries them
        until one succeeds or all fail. Returns result with metadata about
        which providers were tried.

        CRITICAL: This should try ALL available fallback providers before
        giving up. User message only shown after all options exhausted.
        """
        pass


class MetricsCollectorInterface(ABC):
    """Interface for metrics collection plugins."""

    @abstractmethod
    def record_success(self, context: ErrorContext, result: ErrorHandlingResult) -> None:
        """Record successful operation."""
        pass

    @abstractmethod
    def record_failure(self, context: ErrorContext, result: ErrorHandlingResult) -> None:
        """Record failed operation."""
        pass

    @abstractmethod
    def record_fallback_success(self, context: ErrorContext, result: ErrorHandlingResult) -> None:
        """Record successful fallback."""
        pass

    @abstractmethod
    def record_circuit_breaker_trip(self, provider_id: str) -> None:
        """Record circuit breaker trip."""
        pass


class LocalizationInterface(ABC):
    """Interface for message localization plugins."""

    @abstractmethod
    def get_message(self, message_key: str, locale: str, **kwargs) -> str:
        """Get localized message.

        Args:
            message_key: Key for message template
            locale: User's locale (e.g., "en", "pt-BR", "es")
            **kwargs: Template variables

        Returns:
            Localized message string
        """
        pass
