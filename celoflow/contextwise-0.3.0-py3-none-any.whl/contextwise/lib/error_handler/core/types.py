"""Shared types for error handling system."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum
import time


class ErrorCategory(Enum):
    """Error classification categories."""
    TRANSIENT = "transient"
    RATE_LIMIT = "rate_limit"
    AUTHENTICATION = "authentication"
    INVALID_REQUEST = "invalid_request"
    CONTENT_POLICY = "content_policy"
    RESOURCE_EXHAUSTED = "resource_exhausted"
    CIRCUIT_BREAKER_OPEN = "circuit_breaker_open"
    COST_LIMIT_EXCEEDED = "cost_limit_exceeded"
    PERMANENT = "permanent"
    UNKNOWN = "unknown"


class CircuitBreakerState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class ErrorContext:
    """Context for error handling decisions."""
    provider_id: str
    operation: str
    attempt: int
    total_cost: float
    user_locale: str
    conversation_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    start_time: float = field(default_factory=time.time)


@dataclass
class ErrorHandlingResult:
    """Result of error handling operation."""
    success: bool
    response: Optional[Any] = None
    error: Optional[Exception] = None
    provider_used: Optional[str] = None
    attempts: int = 0
    total_cost: float = 0.0
    fallback_used: bool = False
    circuit_breaker_tripped: bool = False
    user_message: Optional[str] = None
    providers_tried: List[str] = field(default_factory=list)
    retry_count: int = 0
    total_duration: float = 0.0


@dataclass
class ProviderConfig:
    """Configuration for a specific provider."""
    provider_id: str
    api_base: str
    cost_per_request: float
    retry_categories: set = field(default_factory=set)
    max_retries: int = 3
    timeout: float = 30.0
    models: List[str] = field(default_factory=list)
