"""Core error handling types, interfaces, and orchestrator."""

from .types import (
    ErrorCategory,
    CircuitBreakerState,
    ErrorContext,
    ErrorHandlingResult,
    ProviderConfig,
)
from .interfaces import (
    ErrorClassifierInterface,
    RetryStrategyInterface,
    CircuitBreakerInterface,
    FallbackStrategyInterface,
    MetricsCollectorInterface,
    LocalizationInterface,
)

__all__ = [
    "ErrorCategory",
    "CircuitBreakerState",
    "ErrorContext",
    "ErrorHandlingResult",
    "ProviderConfig",
    "ErrorClassifierInterface",
    "RetryStrategyInterface",
    "CircuitBreakerInterface",
    "FallbackStrategyInterface",
    "MetricsCollectorInterface",
    "LocalizationInterface",
]
