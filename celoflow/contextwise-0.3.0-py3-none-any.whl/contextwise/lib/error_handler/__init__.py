"""Universal Provider Error Handling: Production-grade modular error handling system.

Provides comprehensive resilience across all LLM providers (OpenAI, Anthropic,
Gemini, Groq, and OpenAI-compatible APIs) with the critical guarantee that
honest error messages are ONLY shown to users after exhausting all retry logic
and fallback mechanisms.

Execution Flow:
    Primary Provider (with full retry)
        -> Fallback Provider 1 (with full retry)
        -> Fallback Provider 2 (with full retry)
        -> Emergency Fallback (if configured)
        -> ONLY if ALL fail: Honest User Message (in their language)

Usage:
    from contextwise.lib.error_handler import (
        ErrorHandlingOrchestrator,
        ErrorHandlerConfig,
        ErrorContext,
    )

    config = ErrorHandlerConfig.from_env()
    orchestrator = ErrorHandlingOrchestrator(config=config)

    result = await orchestrator.execute_with_resilience(
        operation=my_llm_call,
        context=ErrorContext(
            provider_id="gemini",
            operation="chat",
            attempt=1,
            total_cost=0.0,
            user_locale="pt-BR",
        ),
        fallback_operations=[groq_fallback, openai_fallback],
    )
"""

from .core.types import (
    ErrorCategory,
    CircuitBreakerState,
    ErrorContext,
    ErrorHandlingResult,
    ProviderConfig,
)
from .core.interfaces import (
    ErrorClassifierInterface,
    RetryStrategyInterface,
    CircuitBreakerInterface,
    FallbackStrategyInterface,
    MetricsCollectorInterface,
    LocalizationInterface,
)
from .core.orchestrator import ErrorHandlingOrchestrator
from .config.error_handler_config import (
    ErrorHandlerConfig,
    PluginSelection,
    ProviderConfigEntry,
)
from .exceptions import (
    ErrorHandlerException,
    CircuitBreakerOpenError,
    AllProvidersFailedError,
    CostLimitExceededError,
    PluginNotFoundError,
    PluginRegistrationError,
)
from .registry.plugin_registry import PluginRegistry, register_plugin

__all__ = [
    # Core orchestrator
    "ErrorHandlingOrchestrator",
    # Types
    "ErrorCategory",
    "CircuitBreakerState",
    "ErrorContext",
    "ErrorHandlingResult",
    "ProviderConfig",
    # Interfaces
    "ErrorClassifierInterface",
    "RetryStrategyInterface",
    "CircuitBreakerInterface",
    "FallbackStrategyInterface",
    "MetricsCollectorInterface",
    "LocalizationInterface",
    # Configuration
    "ErrorHandlerConfig",
    "PluginSelection",
    "ProviderConfigEntry",
    # Exceptions
    "ErrorHandlerException",
    "CircuitBreakerOpenError",
    "AllProvidersFailedError",
    "CostLimitExceededError",
    "PluginNotFoundError",
    "PluginRegistrationError",
    # Registry
    "PluginRegistry",
    "register_plugin",
]
