"""Custom exceptions for the error handling system."""


class ErrorHandlerException(Exception):
    """Base exception for error handler."""
    pass


class CircuitBreakerOpenError(ErrorHandlerException):
    """Raised when circuit breaker is open for a provider."""
    pass


class AllProvidersFailedError(ErrorHandlerException):
    """Raised when all providers (primary + fallbacks) have failed."""
    pass


class CostLimitExceededError(ErrorHandlerException):
    """Raised when conversation cost limit is exceeded."""
    pass


class PluginNotFoundError(ErrorHandlerException):
    """Raised when a required plugin is not registered."""
    pass


class PluginRegistrationError(ErrorHandlerException):
    """Raised when plugin registration fails."""
    pass
