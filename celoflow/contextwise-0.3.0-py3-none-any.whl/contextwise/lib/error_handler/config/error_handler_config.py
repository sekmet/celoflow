"""Configuration for universal error handler.

Design Decision: Configuration-driven behavior enables runtime changes
without code deployments.
"""

import json
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class PluginSelection:
    """Plugin selection configuration."""
    classifier: str = "generic_classifier"
    retry_strategy: str = "exponential_backoff"
    circuit_breaker: str = "threshold_breaker"
    fallback_strategy: str = "provider_chain"
    metrics_collector: str = "prometheus_metrics"
    localizer: str = "message_localizer"


@dataclass
class ProviderConfigEntry:
    """Configuration for a specific provider."""
    provider_id: str
    enabled: bool = True
    api_base: Optional[str] = None
    cost_per_request: float = 0.001
    max_retries: int = 3
    timeout: float = 30.0
    fallback_providers: List[str] = field(default_factory=list)


@dataclass
class ErrorHandlerConfig:
    """Main error handler configuration."""

    # Plugin selection
    plugins: PluginSelection = field(default_factory=PluginSelection)

    # Global settings
    enabled: bool = True
    fallback_enabled: bool = True
    cost_limit_per_conversation: Optional[float] = 1.0
    default_locale: str = "en"

    # Retry settings
    max_retries: int = 3
    retry_base_delay: float = 1.0
    retry_max_delay: float = 30.0
    retry_exponential_base: float = 2.0
    retry_jitter_factor: float = 0.1

    # Circuit breaker settings
    circuit_breaker_failure_threshold: int = 5
    circuit_breaker_recovery_timeout: float = 60.0
    circuit_breaker_half_open_calls: int = 1

    # Provider configurations
    providers: Dict[str, ProviderConfigEntry] = field(default_factory=dict)

    def __post_init__(self):
        """Initialize default provider configurations."""
        if not self.providers:
            self.providers = self._get_default_providers()

    def _get_default_providers(self) -> Dict[str, ProviderConfigEntry]:
        """Get default provider configurations."""
        return {
            "openai": ProviderConfigEntry(
                provider_id="openai",
                api_base="https://api.openai.com/v1",
                cost_per_request=0.002,
                fallback_providers=["groq", "gemini"],
            ),
            "groq": ProviderConfigEntry(
                provider_id="groq",
                api_base="https://api.groq.com/openai/v1",
                cost_per_request=0.0001,
                fallback_providers=["gemini", "openai"],
            ),
            "anthropic": ProviderConfigEntry(
                provider_id="anthropic",
                api_base="https://api.anthropic.com",
                cost_per_request=0.003,
                fallback_providers=["openai", "gemini"],
            ),
            "gemini": ProviderConfigEntry(
                provider_id="gemini",
                api_base="https://generativelanguage.googleapis.com/v1beta/openai/",
                cost_per_request=0.001,
                fallback_providers=["groq", "openai"],
            ),
        }

    @classmethod
    def from_env(cls) -> "ErrorHandlerConfig":
        """Load configuration from environment variables."""
        plugins = PluginSelection(
            classifier=os.getenv("ERROR_HANDLER_CLASSIFIER", "generic_classifier"),
            retry_strategy=os.getenv("ERROR_HANDLER_RETRY_STRATEGY", "exponential_backoff"),
            circuit_breaker=os.getenv("ERROR_HANDLER_CIRCUIT_BREAKER", "threshold_breaker"),
            fallback_strategy=os.getenv("ERROR_HANDLER_FALLBACK_STRATEGY", "provider_chain"),
            metrics_collector=os.getenv("ERROR_HANDLER_METRICS", "prometheus_metrics"),
            localizer=os.getenv("ERROR_HANDLER_LOCALIZER", "message_localizer"),
        )

        config = cls(
            enabled=os.getenv("ERROR_HANDLER_ENABLED", "true").lower() == "true",
            fallback_enabled=os.getenv("ERROR_HANDLER_FALLBACK_ENABLED", "true").lower() == "true",
            cost_limit_per_conversation=float(os.getenv("ERROR_HANDLER_COST_LIMIT", "1.0")),
            default_locale=os.getenv("ERROR_HANDLER_DEFAULT_LOCALE", "en"),
            max_retries=int(os.getenv("ERROR_HANDLER_MAX_RETRIES", "3")),
            retry_base_delay=float(os.getenv("ERROR_HANDLER_RETRY_BASE_DELAY", "1.0")),
            retry_max_delay=float(os.getenv("ERROR_HANDLER_RETRY_MAX_DELAY", "30.0")),
            retry_exponential_base=float(os.getenv("ERROR_HANDLER_RETRY_EXP_BASE", "2.0")),
            retry_jitter_factor=float(os.getenv("ERROR_HANDLER_RETRY_JITTER", "0.1")),
            circuit_breaker_failure_threshold=int(os.getenv("ERROR_HANDLER_CB_THRESHOLD", "5")),
            circuit_breaker_recovery_timeout=float(os.getenv("ERROR_HANDLER_CB_RECOVERY", "60.0")),
            circuit_breaker_half_open_calls=int(os.getenv("ERROR_HANDLER_CB_HALF_OPEN", "1")),
            plugins=plugins,
        )

        return config

    @classmethod
    def from_file(cls, config_file: str) -> "ErrorHandlerConfig":
        """Load configuration from JSON file."""
        with open(config_file, 'r') as f:
            config_data = json.load(f)

        # Extract nested configs
        plugins_data = config_data.pop("plugins", {})
        providers_data = config_data.pop("providers", {})

        plugins = PluginSelection(**plugins_data) if plugins_data else PluginSelection()
        providers = {
            k: ProviderConfigEntry(**v) for k, v in providers_data.items()
        } if providers_data else {}

        return cls(plugins=plugins, providers=providers, **config_data)
