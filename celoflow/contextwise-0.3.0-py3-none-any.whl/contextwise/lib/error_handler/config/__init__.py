"""Configuration management for error handler."""

from .error_handler_config import ErrorHandlerConfig, PluginSelection, ProviderConfigEntry

__all__ = [
    "ErrorHandlerConfig",
    "PluginSelection",
    "ProviderConfigEntry",
]
