"""Plugin registration system for error handling components.

Design Decision: Use a decorator-based registration pattern that allows
plugins to self-register when their modules are imported. The registry
is a singleton that maps (interface_type, plugin_name) to plugin classes.
"""

import logging
from typing import Any, Dict, Optional, Tuple, Type

logger = logging.getLogger(__name__)

# Global registry: maps (interface_type, plugin_name) -> plugin_class
_PLUGIN_REGISTRY: Dict[Tuple[Type, str], Type] = {}


def register_plugin(name: str, interface: Type):
    """Decorator to register a plugin class.

    Args:
        name: Unique name for this plugin
        interface: The interface this plugin implements

    Returns:
        Decorator function

    Example:
        @register_plugin("gemini_classifier", ErrorClassifierInterface)
        class GeminiErrorClassifier(ErrorClassifierInterface):
            ...
    """
    def decorator(cls):
        key = (interface, name)
        if key in _PLUGIN_REGISTRY:
            logger.warning(
                f"Plugin '{name}' for interface '{interface.__name__}' "
                f"is being re-registered (was: {_PLUGIN_REGISTRY[key].__name__}, "
                f"now: {cls.__name__})"
            )
        _PLUGIN_REGISTRY[key] = cls
        logger.debug(
            f"Registered plugin '{name}' for interface '{interface.__name__}' "
            f"-> {cls.__name__}"
        )
        return cls
    return decorator


class PluginRegistry:
    """Plugin registry for error handling components.

    Provides lookup and instantiation of registered plugins by
    interface type and plugin name.
    """

    def __init__(self):
        self._instance_cache: Dict[Tuple[Type, str], Any] = {}

    def get_plugin(
        self,
        interface: Type,
        name: str,
        *args,
        **kwargs,
    ) -> Optional[Any]:
        """Get a plugin instance by interface and name.

        Args:
            interface: The interface type to look up
            name: The registered plugin name
            *args: Positional arguments for plugin constructor
            **kwargs: Keyword arguments for plugin constructor

        Returns:
            Plugin instance, or None if not found
        """
        key = (interface, name)

        # Return cached instance if no constructor args provided
        if key in self._instance_cache and not args and not kwargs:
            return self._instance_cache[key]

        # Look up in global registry
        plugin_cls = _PLUGIN_REGISTRY.get(key)
        if plugin_cls is None:
            logger.warning(
                f"Plugin not found: name='{name}', "
                f"interface='{interface.__name__}'. "
                f"Available: {self.list_plugins(interface)}"
            )
            return None

        # Instantiate and cache
        try:
            instance = plugin_cls(*args, **kwargs)
            if not args and not kwargs:
                self._instance_cache[key] = instance
            logger.debug(
                f"Instantiated plugin '{name}' -> {plugin_cls.__name__}"
            )
            return instance
        except Exception as e:
            logger.error(
                f"Failed to instantiate plugin '{name}' "
                f"({plugin_cls.__name__}): {e}"
            )
            return None

    def list_plugins(self, interface: Optional[Type] = None) -> list:
        """List registered plugin names, optionally filtered by interface.

        Args:
            interface: Optional interface type to filter by

        Returns:
            List of plugin names
        """
        if interface is None:
            return [
                (iface.__name__, name)
                for (iface, name) in _PLUGIN_REGISTRY
            ]
        return [
            name
            for (iface, name) in _PLUGIN_REGISTRY
            if iface == interface
        ]

    def is_registered(self, interface: Type, name: str) -> bool:
        """Check if a plugin is registered."""
        return (interface, name) in _PLUGIN_REGISTRY

    def clear_cache(self) -> None:
        """Clear the instance cache (useful for testing)."""
        self._instance_cache.clear()
