"""Plugin and provider registry system."""

from .plugin_registry import PluginRegistry, register_plugin

__all__ = [
    "PluginRegistry",
    "register_plugin",
]
