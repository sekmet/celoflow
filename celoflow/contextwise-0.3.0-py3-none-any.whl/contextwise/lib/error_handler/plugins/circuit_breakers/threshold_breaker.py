"""Threshold-based circuit breaker.

Design Decision: Classic circuit breaker pattern with three states:
- CLOSED: Normal operation, requests pass through
- OPEN: Failing, reject requests immediately
- HALF_OPEN: Testing recovery, allow limited requests

Transitions:
- CLOSED -> OPEN: When failure count exceeds threshold
- OPEN -> HALF_OPEN: After recovery timeout expires
- HALF_OPEN -> CLOSED: On successful test request
- HALF_OPEN -> OPEN: On failed test request
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Dict

from ...core.interfaces import CircuitBreakerInterface
from ...core.types import CircuitBreakerState
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@dataclass
class _ProviderState:
    """Internal state tracking for a single provider."""
    state: CircuitBreakerState = CircuitBreakerState.CLOSED
    failure_count: int = 0
    success_count: int = 0
    last_failure_time: float = 0.0
    last_state_change: float = field(default_factory=time.time)
    half_open_calls: int = 0


@register_plugin("threshold_breaker", CircuitBreakerInterface)
class ThresholdCircuitBreaker(CircuitBreakerInterface):
    """Threshold-based circuit breaker.

    Features:
    - Configurable failure threshold before opening
    - Configurable recovery timeout before half-open
    - Configurable number of test calls in half-open state
    - Per-provider state tracking
    - Thread-safe via asyncio.Lock
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_max_calls: int = 1,
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        self._states: Dict[str, _ProviderState] = {}
        self._lock = asyncio.Lock()

        logger.info(
            f"ThresholdCircuitBreaker initialized: "
            f"failure_threshold={failure_threshold}, "
            f"recovery_timeout={recovery_timeout}s, "
            f"half_open_max_calls={half_open_max_calls}"
        )

    def _get_state(self, provider_id: str) -> _ProviderState:
        """Get or create provider state."""
        if provider_id not in self._states:
            self._states[provider_id] = _ProviderState()
        return self._states[provider_id]

    async def can_execute(self, provider_id: str) -> bool:
        """Check if provider can execute requests."""
        async with self._lock:
            state = self._get_state(provider_id)

            if state.state == CircuitBreakerState.CLOSED:
                return True

            if state.state == CircuitBreakerState.OPEN:
                # Check if recovery timeout has elapsed
                elapsed = time.time() - state.last_failure_time
                if elapsed >= self.recovery_timeout:
                    # Transition to HALF_OPEN
                    state.state = CircuitBreakerState.HALF_OPEN
                    state.half_open_calls = 0
                    state.last_state_change = time.time()
                    logger.info(
                        f"Circuit breaker for {provider_id}: "
                        f"OPEN -> HALF_OPEN (recovery timeout elapsed: {elapsed:.1f}s)"
                    )
                    return True
                else:
                    remaining = self.recovery_timeout - elapsed
                    logger.debug(
                        f"Circuit breaker OPEN for {provider_id}, "
                        f"{remaining:.1f}s until recovery attempt"
                    )
                    return False

            if state.state == CircuitBreakerState.HALF_OPEN:
                # Allow limited test calls
                if state.half_open_calls < self.half_open_max_calls:
                    state.half_open_calls += 1
                    return True
                return False

            return False

    async def record_success(self, provider_id: str) -> None:
        """Record successful execution."""
        async with self._lock:
            state = self._get_state(provider_id)

            if state.state == CircuitBreakerState.HALF_OPEN:
                # Recovery confirmed - close circuit
                state.state = CircuitBreakerState.CLOSED
                state.failure_count = 0
                state.success_count = 0
                state.half_open_calls = 0
                state.last_state_change = time.time()
                logger.info(
                    f"Circuit breaker for {provider_id}: "
                    f"HALF_OPEN -> CLOSED (recovery confirmed)"
                )
            elif state.state == CircuitBreakerState.CLOSED:
                # Reset failure count on success
                state.failure_count = 0
                state.success_count += 1

    async def record_failure(self, provider_id: str, error: Exception) -> None:
        """Record failed execution."""
        async with self._lock:
            state = self._get_state(provider_id)
            state.last_failure_time = time.time()

            if state.state == CircuitBreakerState.HALF_OPEN:
                # Recovery failed - reopen circuit
                state.state = CircuitBreakerState.OPEN
                state.last_state_change = time.time()
                logger.warning(
                    f"Circuit breaker for {provider_id}: "
                    f"HALF_OPEN -> OPEN (recovery failed: {error})"
                )
            elif state.state == CircuitBreakerState.CLOSED:
                state.failure_count += 1
                if state.failure_count >= self.failure_threshold:
                    state.state = CircuitBreakerState.OPEN
                    state.last_state_change = time.time()
                    logger.warning(
                        f"Circuit breaker for {provider_id}: "
                        f"CLOSED -> OPEN (failures={state.failure_count}, "
                        f"threshold={self.failure_threshold})"
                    )
                else:
                    logger.debug(
                        f"Circuit breaker for {provider_id}: "
                        f"failure {state.failure_count}/{self.failure_threshold}"
                    )

    def get_state(self, provider_id: str) -> CircuitBreakerState:
        """Get current circuit breaker state."""
        state = self._get_state(provider_id)
        return state.state

    def reset(self, provider_id: str) -> None:
        """Reset circuit breaker for a provider (useful for testing)."""
        if provider_id in self._states:
            del self._states[provider_id]
            logger.info(f"Circuit breaker reset for {provider_id}")

    def reset_all(self) -> None:
        """Reset all circuit breakers (useful for testing)."""
        self._states.clear()
        logger.info("All circuit breakers reset")
