"""Circuit breaker plugins.

Importing this module registers all circuit breaker plugins with the global registry.
"""

from .threshold_breaker import ThresholdCircuitBreaker

__all__ = [
    "ThresholdCircuitBreaker",
]
