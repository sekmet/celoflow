"""Exponential backoff retry strategy with jitter.

Design Decision: Use exponential backoff with jitter to avoid thundering herd.
Category-aware delays (longer for rate limits, shorter for transient errors).
"""

import asyncio
import logging
import random
import time
from typing import Callable

from ...core.interfaces import (
    RetryStrategyInterface,
    ErrorClassifierInterface,
    CircuitBreakerInterface,
)
from ...core.types import ErrorCategory, ErrorContext, ErrorHandlingResult
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@register_plugin("exponential_backoff", RetryStrategyInterface)
class ExponentialBackoffRetry(RetryStrategyInterface):
    """Exponential backoff with jitter and category-aware delays.

    Features:
    - Base delay increases exponentially: delay = base * (2 ^ attempt)
    - Jitter prevents thundering herd
    - Category-specific multipliers (rate limits get longer delays)
    - Max delay cap prevents excessive waiting
    """

    # Category-specific delay multipliers
    CATEGORY_MULTIPLIERS = {
        ErrorCategory.TRANSIENT: 1.0,
        ErrorCategory.RATE_LIMIT: 2.5,
        ErrorCategory.RESOURCE_EXHAUSTED: 3.0,
    }

    def __init__(
        self,
        max_attempts: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 30.0,
        exponential_base: float = 2.0,
        jitter_factor: float = 0.1,
    ):
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter_factor = jitter_factor

        logger.info(
            f"ExponentialBackoffRetry initialized: "
            f"max_attempts={max_attempts}, base_delay={base_delay}, "
            f"max_delay={max_delay}"
        )

    async def execute_with_retry(
        self,
        operation: Callable,
        context: ErrorContext,
        classifier: ErrorClassifierInterface,
        circuit_breaker: CircuitBreakerInterface,
        **kwargs,
    ) -> ErrorHandlingResult:
        """Execute operation with exponential backoff retry.

        CRITICAL: This method tries up to max_attempts times before giving up.
        Returns result even on failure (doesn't throw exception).
        """
        last_error = None
        attempts = 0

        while attempts < self.max_attempts:
            attempts += 1

            try:
                logger.debug(
                    f"Attempt {attempts}/{self.max_attempts} for "
                    f"provider {context.provider_id}"
                )

                # Execute operation
                response = await operation(**kwargs)

                # Success - record and return
                await circuit_breaker.record_success(context.provider_id)

                logger.info(
                    f"Operation succeeded on attempt {attempts} "
                    f"for provider {context.provider_id}"
                )

                return ErrorHandlingResult(
                    success=True,
                    response=response,
                    provider_used=context.provider_id,
                    attempts=attempts,
                )

            except Exception as e:
                last_error = e

                # Classify error
                error_category = classifier.classify(e, context.provider_id)

                logger.warning(
                    f"Attempt {attempts}/{self.max_attempts} failed for "
                    f"provider {context.provider_id}: {e} "
                    f"(category: {error_category.value})"
                )

                # Record failure in circuit breaker
                await circuit_breaker.record_failure(context.provider_id, e)

                # Check if retryable
                if not classifier.is_retryable(error_category):
                    logger.error(
                        f"Error category {error_category.value} is not retryable. "
                        f"Stopping retry attempts."
                    )
                    break

                # If not last attempt, wait with exponential backoff
                if attempts < self.max_attempts:
                    delay = self._calculate_delay(attempts, error_category)

                    logger.debug(
                        f"Waiting {delay:.2f}s before retry "
                        f"(category: {error_category.value})"
                    )

                    await asyncio.sleep(delay)
                else:
                    logger.error(
                        f"Max attempts ({self.max_attempts}) reached for "
                        f"provider {context.provider_id}"
                    )

        # All retries exhausted - return failure result
        return ErrorHandlingResult(
            success=False,
            error=last_error,
            provider_used=context.provider_id,
            attempts=attempts,
        )

    def _calculate_delay(
        self,
        attempt: int,
        category: ErrorCategory,
    ) -> float:
        """Calculate delay with exponential backoff and jitter.

        Formula: delay = base * (exponential_base ^ (attempt - 1)) * category_multiplier + jitter
        """
        # Base exponential backoff
        delay = self.base_delay * (self.exponential_base ** (attempt - 1))

        # Category-specific multiplier
        multiplier = self.CATEGORY_MULTIPLIERS.get(category, 1.0)
        delay *= multiplier

        # Cap at max delay
        delay = min(delay, self.max_delay)

        # Add jitter (±jitter_factor of delay)
        jitter_range = delay * self.jitter_factor
        jitter = random.uniform(-jitter_range, jitter_range)
        delay += jitter

        return max(0, delay)
