"""Error handling plugins: classifiers, retry strategies, fallbacks, circuit breakers, metrics, localization."""
