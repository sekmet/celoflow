"""Metrics collection plugins.

Importing this module registers all metrics plugins with the global registry.
"""

from .log_metrics import LogMetricsCollector

__all__ = [
    "LogMetricsCollector",
]
