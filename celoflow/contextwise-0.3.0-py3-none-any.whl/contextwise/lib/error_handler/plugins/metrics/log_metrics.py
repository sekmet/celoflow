"""Log-based metrics collector.

Design Decision: Provide a lightweight, zero-dependency metrics collector
that logs structured metrics data. This serves as both the default metrics
implementation and a base for more advanced collectors (Prometheus, CloudWatch).

Production systems can replace this with prometheus_metrics or cloudwatch_metrics
via plugin configuration.
"""

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List

from ...core.interfaces import MetricsCollectorInterface
from ...core.types import ErrorContext, ErrorHandlingResult
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@dataclass
class _MetricsSummary:
    """Accumulated metrics for a provider."""
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    fallback_successes: int = 0
    circuit_breaker_trips: int = 0
    total_retry_attempts: int = 0
    total_duration: float = 0.0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0


@register_plugin("log_metrics", MetricsCollectorInterface)
class LogMetricsCollector(MetricsCollectorInterface):
    """Log-based metrics collector.

    Logs structured metrics data and maintains in-memory counters.
    Suitable for development and as a fallback when no external
    metrics system is configured.
    """

    def __init__(self):
        self._provider_metrics: Dict[str, _MetricsSummary] = defaultdict(_MetricsSummary)
        self._events: List[Dict] = []
        self._max_events = 1000

    def record_success(self, context: ErrorContext, result: ErrorHandlingResult) -> None:
        """Record successful operation."""
        metrics = self._provider_metrics[context.provider_id]
        metrics.total_requests += 1
        metrics.successful_requests += 1
        metrics.total_retry_attempts += result.attempts
        metrics.total_duration += result.total_duration
        metrics.last_success_time = time.time()

        self._add_event({
            "type": "success",
            "provider": context.provider_id,
            "operation": context.operation,
            "attempts": result.attempts,
            "duration": result.total_duration,
            "conversation_id": context.conversation_id,
        })

        logger.info(
            f"METRICS [SUCCESS] provider={context.provider_id} "
            f"operation={context.operation} attempts={result.attempts} "
            f"duration={result.total_duration:.3f}s"
        )

    def record_failure(self, context: ErrorContext, result: ErrorHandlingResult) -> None:
        """Record failed operation."""
        metrics = self._provider_metrics[context.provider_id]
        metrics.total_requests += 1
        metrics.failed_requests += 1
        metrics.total_retry_attempts += result.attempts
        metrics.total_duration += result.total_duration
        metrics.last_failure_time = time.time()

        self._add_event({
            "type": "failure",
            "provider": context.provider_id,
            "operation": context.operation,
            "attempts": result.attempts,
            "duration": result.total_duration,
            "providers_tried": result.providers_tried,
            "error": str(result.error) if result.error else None,
            "user_message_shown": result.user_message is not None,
            "conversation_id": context.conversation_id,
        })

        logger.error(
            f"METRICS [FAILURE] provider={context.provider_id} "
            f"operation={context.operation} attempts={result.attempts} "
            f"duration={result.total_duration:.3f}s "
            f"providers_tried={result.providers_tried} "
            f"error={result.error}"
        )

    def record_fallback_success(self, context: ErrorContext, result: ErrorHandlingResult) -> None:
        """Record successful fallback."""
        metrics = self._provider_metrics[result.provider_used or context.provider_id]
        metrics.fallback_successes += 1

        self._add_event({
            "type": "fallback_success",
            "primary_provider": context.provider_id,
            "fallback_provider": result.provider_used,
            "operation": context.operation,
            "attempts": result.attempts,
            "duration": result.total_duration,
            "providers_tried": result.providers_tried,
            "conversation_id": context.conversation_id,
        })

        logger.info(
            f"METRICS [FALLBACK_SUCCESS] "
            f"primary={context.provider_id} "
            f"fallback={result.provider_used} "
            f"attempts={result.attempts} "
            f"duration={result.total_duration:.3f}s "
            f"providers_tried={result.providers_tried}"
        )

    def record_circuit_breaker_trip(self, provider_id: str) -> None:
        """Record circuit breaker trip."""
        metrics = self._provider_metrics[provider_id]
        metrics.circuit_breaker_trips += 1

        self._add_event({
            "type": "circuit_breaker_trip",
            "provider": provider_id,
        })

        logger.warning(
            f"METRICS [CIRCUIT_BREAKER_TRIP] provider={provider_id} "
            f"total_trips={metrics.circuit_breaker_trips}"
        )

    def get_summary(self, provider_id: str = None) -> Dict:
        """Get metrics summary.

        Args:
            provider_id: Optional provider to get summary for.
                If None, returns summary for all providers.

        Returns:
            Dict with metrics summary
        """
        if provider_id:
            m = self._provider_metrics[provider_id]
            success_rate = (
                m.successful_requests / m.total_requests * 100
                if m.total_requests > 0 else 0
            )
            avg_duration = (
                m.total_duration / m.total_requests
                if m.total_requests > 0 else 0
            )
            return {
                "provider": provider_id,
                "total_requests": m.total_requests,
                "successful": m.successful_requests,
                "failed": m.failed_requests,
                "fallback_successes": m.fallback_successes,
                "circuit_breaker_trips": m.circuit_breaker_trips,
                "success_rate": f"{success_rate:.1f}%",
                "avg_duration": f"{avg_duration:.3f}s",
            }

        return {
            provider: self.get_summary(provider)
            for provider in self._provider_metrics
        }

    def _add_event(self, event: Dict) -> None:
        """Add event to event log with bounded size."""
        event["timestamp"] = time.time()
        self._events.append(event)
        if len(self._events) > self._max_events:
            self._events = self._events[-self._max_events:]


# Also register as "prometheus_metrics" for config compatibility
# (acts as a drop-in replacement until a real Prometheus integration is needed)
@register_plugin("prometheus_metrics", MetricsCollectorInterface)
class PrometheusCompatMetrics(LogMetricsCollector):
    """Prometheus-compatible metrics collector.

    Currently delegates to LogMetricsCollector. When Prometheus client
    library is available, this can be extended to export real Prometheus
    metrics via the standard client.
    """
    pass
