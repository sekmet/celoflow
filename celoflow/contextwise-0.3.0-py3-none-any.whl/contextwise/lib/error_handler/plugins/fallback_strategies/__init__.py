"""Fallback strategy plugins.

Importing this module registers all fallback strategy plugins with the global registry.
"""

from .provider_chain import ProviderChainFallback

__all__ = [
    "ProviderChainFallback",
]
