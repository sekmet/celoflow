"""Multi-provider chain fallback strategy.

Design Decision: Try providers in priority order (cost, quality, availability).
Each fallback provider gets FULL retry logic before moving to next.
"""

from __future__ import annotations

import logging
from typing import List, TYPE_CHECKING

from ...core.interfaces import FallbackStrategyInterface
from ...core.types import ErrorContext, ErrorHandlingResult
from ...registry.plugin_registry import register_plugin

if TYPE_CHECKING:
    from ...core.orchestrator import ErrorHandlingOrchestrator

logger = logging.getLogger(__name__)


@register_plugin("provider_chain", FallbackStrategyInterface)
class ProviderChainFallback(FallbackStrategyInterface):
    """Multi-provider chain fallback.

    Features:
    - Tries providers in configured priority order
    - Each provider gets full retry logic
    - Tracks which providers were tried
    - Returns immediately on first success
    - ONLY returns failure after ALL providers exhausted
    """

    def __init__(
        self,
        provider_priority: List[str] = None,
        cost_aware: bool = True,
    ):
        """Initialize provider chain.

        Args:
            provider_priority: Ordered list of providers to try.
                Default: ["groq", "gemini", "openai", "anthropic"]
            cost_aware: If True, prioritize cheaper providers first
        """
        self.provider_priority = provider_priority or [
            "groq",
            "gemini",
            "openai",
            "anthropic",
        ]
        self.cost_aware = cost_aware

        logger.info(
            f"ProviderChainFallback initialized with priority: "
            f"{self.provider_priority}"
        )

    async def handle_failure(
        self,
        primary_result: ErrorHandlingResult,
        context: ErrorContext,
        orchestrator: ErrorHandlingOrchestrator,
        available_providers: List[str],
        **kwargs,
    ) -> ErrorHandlingResult:
        """Try each fallback provider with full retry logic.

        CRITICAL: This method tries EVERY available fallback provider
        before giving up. User message only shown after exhausting all.
        """
        logger.info(
            f"Primary provider {context.provider_id} failed. "
            f"Available fallbacks: {available_providers}"
        )

        # Determine fallback order
        fallback_order = self._determine_fallback_order(
            primary_provider=context.provider_id,
            available_providers=available_providers,
        )

        logger.info(f"Fallback attempt order: {fallback_order}")

        providers_tried = [context.provider_id]
        total_attempts = primary_result.attempts

        # Try each fallback provider
        for fallback_provider in fallback_order:
            logger.info(
                f"Attempting fallback provider: {fallback_provider} "
                f"({fallback_order.index(fallback_provider) + 1}/"
                f"{len(fallback_order)})"
            )

            providers_tried.append(fallback_provider)

            # Get fallback operation
            fallback_operation = kwargs.get('fallback_operations', {}).get(
                fallback_provider
            )

            if not fallback_operation:
                logger.warning(
                    f"No operation configured for fallback provider "
                    f"{fallback_provider}, skipping"
                )
                continue

            # Create context for fallback
            fallback_context = ErrorContext(
                provider_id=fallback_provider,
                operation=context.operation,
                attempt=1,
                total_cost=context.total_cost,
                user_locale=context.user_locale,
                conversation_id=context.conversation_id,
                metadata=context.metadata,
            )

            # Try fallback with FULL retry logic (via orchestrator)
            try:
                fallback_result = await orchestrator.retry_strategy.execute_with_retry(
                    operation=fallback_operation,
                    context=fallback_context,
                    classifier=orchestrator.classifier,
                    circuit_breaker=orchestrator.circuit_breaker,
                    **kwargs,
                )

                total_attempts += fallback_result.attempts

                # Fallback succeeded!
                if fallback_result.success:
                    logger.info(
                        f"Fallback provider {fallback_provider} succeeded "
                        f"after {fallback_result.attempts} attempts"
                    )

                    fallback_result.fallback_used = True
                    fallback_result.provider_used = fallback_provider
                    fallback_result.providers_tried = providers_tried
                    fallback_result.retry_count = total_attempts

                    return fallback_result

                # Fallback failed - continue to next provider
                logger.warning(
                    f"Fallback provider {fallback_provider} failed after "
                    f"{fallback_result.attempts} attempts: {fallback_result.error}"
                )

            except Exception as e:
                logger.error(
                    f"Unexpected error with fallback provider "
                    f"{fallback_provider}: {e}"
                )
                continue

        # ALL fallbacks exhausted - return failure
        logger.error(
            f"ALL fallback providers exhausted. "
            f"Providers tried: {providers_tried}, "
            f"Total attempts: {total_attempts}"
        )

        return ErrorHandlingResult(
            success=False,
            error=primary_result.error,
            provider_used=None,
            attempts=total_attempts,
            providers_tried=providers_tried,
            retry_count=total_attempts,
        )

    def _determine_fallback_order(
        self,
        primary_provider: str,
        available_providers: List[str],
    ) -> List[str]:
        """Determine order of fallback providers.

        Design Decision: Use configured priority, filtering out:
        - Primary provider (already failed)
        - Unavailable providers
        """
        # Filter out primary provider and unavailable providers
        fallback_candidates = [
            p for p in self.provider_priority
            if p != primary_provider and p in available_providers
        ]

        # Add any available providers not in priority list
        for provider in available_providers:
            if provider not in fallback_candidates and provider != primary_provider:
                fallback_candidates.append(provider)

        return fallback_candidates
