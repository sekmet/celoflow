"""OpenAI-specific error classifier."""

import logging

from ...core.interfaces import ErrorClassifierInterface
from ...core.types import ErrorCategory
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@register_plugin("openai_classifier", ErrorClassifierInterface)
class OpenAIErrorClassifier(ErrorClassifierInterface):
    """OpenAI-specific error classification."""

    def classify(self, error: Exception, provider_id: str) -> ErrorCategory:
        """Classify OpenAI errors."""
        error_str = str(error).lower()
        error_type = type(error).__name__.lower()

        # OpenAI SDK specific error types
        if "ratelimiterror" in error_type:
            return ErrorCategory.RATE_LIMIT
        elif "authenticationerror" in error_type:
            return ErrorCategory.AUTHENTICATION
        elif "badrequest" in error_type or "invalidrequesterror" in error_type:
            return ErrorCategory.INVALID_REQUEST
        elif "permissiondenied" in error_type:
            return ErrorCategory.AUTHENTICATION
        elif "notfounderror" in error_type:
            return ErrorCategory.INVALID_REQUEST

        # HTTP status codes
        if "429" in error_str:
            return ErrorCategory.RATE_LIMIT
        elif any(code in error_str for code in ["500", "502", "503"]):
            return ErrorCategory.TRANSIENT
        elif "401" in error_str:
            return ErrorCategory.AUTHENTICATION
        elif "400" in error_str:
            return ErrorCategory.INVALID_REQUEST
        elif "403" in error_str:
            return ErrorCategory.AUTHENTICATION

        # Content policy
        if any(keyword in error_str for keyword in [
            "content_policy", "content policy", "safety", "moderation"
        ]):
            return ErrorCategory.CONTENT_POLICY

        # Network errors
        if any(keyword in error_str for keyword in [
            "timeout", "connection", "network", "dns"
        ]):
            return ErrorCategory.TRANSIENT

        # Quota / billing
        if any(keyword in error_str for keyword in [
            "quota", "billing", "insufficient_quota"
        ]):
            return ErrorCategory.RESOURCE_EXHAUSTED

        logger.warning(f"Unknown OpenAI error pattern: {error}")
        return ErrorCategory.UNKNOWN

    def is_retryable(self, category: ErrorCategory) -> bool:
        """Check if error category should be retried."""
        return category in {
            ErrorCategory.TRANSIENT,
            ErrorCategory.RATE_LIMIT,
        }
