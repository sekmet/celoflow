"""Groq-specific error classifier.

Note: Groq uses OpenAI-compatible API, so error patterns are similar.
"""

import logging

from ...core.interfaces import ErrorClassifierInterface
from ...core.types import ErrorCategory
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@register_plugin("groq_classifier", ErrorClassifierInterface)
class GroqErrorClassifier(ErrorClassifierInterface):
    """Groq-specific error classification (OpenAI-compatible)."""

    def classify(self, error: Exception, provider_id: str) -> ErrorCategory:
        """Classify Groq errors (OpenAI-compatible)."""
        error_str = str(error).lower()

        # HTTP status codes (same as OpenAI since Groq is OpenAI-compatible)
        if "429" in error_str or "rate limit" in error_str:
            return ErrorCategory.RATE_LIMIT
        elif any(code in error_str for code in ["500", "503"]):
            return ErrorCategory.TRANSIENT
        elif "401" in error_str:
            return ErrorCategory.AUTHENTICATION
        elif "400" in error_str:
            return ErrorCategory.INVALID_REQUEST

        # Network errors
        if any(keyword in error_str for keyword in [
            "timeout", "connection", "network"
        ]):
            return ErrorCategory.TRANSIENT

        # Groq-specific: model not available
        if "model" in error_str and "not available" in error_str:
            return ErrorCategory.RESOURCE_EXHAUSTED

        logger.warning(f"Unknown Groq error pattern: {error}")
        return ErrorCategory.UNKNOWN

    def is_retryable(self, category: ErrorCategory) -> bool:
        """Check if error category should be retried."""
        return category in {
            ErrorCategory.TRANSIENT,
            ErrorCategory.RATE_LIMIT,
        }
