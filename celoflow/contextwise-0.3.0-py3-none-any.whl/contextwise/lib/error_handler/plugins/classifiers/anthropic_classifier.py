"""Anthropic-specific error classifier."""

import logging

from ...core.interfaces import ErrorClassifierInterface
from ...core.types import ErrorCategory
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@register_plugin("anthropic_classifier", ErrorClassifierInterface)
class AnthropicErrorClassifier(ErrorClassifierInterface):
    """Anthropic-specific error classification."""

    def classify(self, error: Exception, provider_id: str) -> ErrorCategory:
        """Classify Anthropic errors."""
        error_str = str(error).lower()
        error_type = type(error).__name__.lower()

        # Anthropic SDK specific error types
        if "ratelimiterror" in error_type:
            return ErrorCategory.RATE_LIMIT
        elif "authenticationerror" in error_type:
            return ErrorCategory.AUTHENTICATION
        elif "badrequest" in error_type:
            return ErrorCategory.INVALID_REQUEST
        elif "permissionerror" in error_type:
            return ErrorCategory.AUTHENTICATION

        # Anthropic-specific patterns
        if "overloaded" in error_str:
            return ErrorCategory.TRANSIENT

        # Rate limit keyword patterns
        if "rate limit" in error_str or "rate_limit" in error_str:
            return ErrorCategory.RATE_LIMIT

        # HTTP status codes
        if "429" in error_str:
            return ErrorCategory.RATE_LIMIT
        elif "500" in error_str or "529" in error_str:
            return ErrorCategory.TRANSIENT
        elif "401" in error_str:
            return ErrorCategory.AUTHENTICATION
        elif "400" in error_str:
            return ErrorCategory.INVALID_REQUEST
        elif "403" in error_str:
            return ErrorCategory.AUTHENTICATION

        # Content policy
        if any(keyword in error_str for keyword in [
            "content policy", "safety", "blocked"
        ]):
            return ErrorCategory.CONTENT_POLICY

        # Network errors
        if any(keyword in error_str for keyword in [
            "timeout", "connection", "network"
        ]):
            return ErrorCategory.TRANSIENT

        logger.warning(f"Unknown Anthropic error pattern: {error}")
        return ErrorCategory.UNKNOWN

    def is_retryable(self, category: ErrorCategory) -> bool:
        """Check if error category should be retried."""
        return category in {
            ErrorCategory.TRANSIENT,
            ErrorCategory.RATE_LIMIT,
        }
