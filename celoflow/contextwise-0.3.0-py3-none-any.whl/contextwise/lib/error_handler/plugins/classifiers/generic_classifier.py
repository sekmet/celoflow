"""Generic fallback error classifier.

Used when no provider-specific classifier is configured.
Classifies errors based on common HTTP status codes and error patterns.
"""

import logging

from ...core.interfaces import ErrorClassifierInterface
from ...core.types import ErrorCategory
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@register_plugin("generic_classifier", ErrorClassifierInterface)
class GenericErrorClassifier(ErrorClassifierInterface):
    """Generic error classifier that works across all providers.

    Uses common HTTP status code patterns and error message keywords
    to classify errors when no provider-specific classifier is available.
    """

    def classify(self, error: Exception, provider_id: str) -> ErrorCategory:
        """Classify error using generic patterns."""
        error_str = str(error).lower()
        error_type = type(error).__name__.lower()

        # Check for common SDK error type names
        if "ratelimit" in error_type:
            return ErrorCategory.RATE_LIMIT
        elif "auth" in error_type and "error" in error_type:
            return ErrorCategory.AUTHENTICATION
        elif "timeout" in error_type:
            return ErrorCategory.TRANSIENT

        # HTTP status codes
        if "429" in error_str:
            return ErrorCategory.RATE_LIMIT
        elif any(code in error_str for code in ["500", "502", "503", "504"]):
            return ErrorCategory.TRANSIENT
        elif "401" in error_str or "403" in error_str:
            return ErrorCategory.AUTHENTICATION
        elif "400" in error_str or "422" in error_str:
            return ErrorCategory.INVALID_REQUEST
        elif "404" in error_str:
            return ErrorCategory.INVALID_REQUEST

        # Keyword-based classification
        # Resource exhaustion checked BEFORE rate limit to avoid
        # "quota" matching rate_limit when it's actually a billing issue
        if any(keyword in error_str for keyword in [
            "resource exhausted", "out of quota", "billing",
            "insufficient", "capacity",
        ]):
            return ErrorCategory.RESOURCE_EXHAUSTED

        if any(keyword in error_str for keyword in [
            "rate limit", "rate_limit", "too many requests",
        ]):
            return ErrorCategory.RATE_LIMIT

        if any(keyword in error_str for keyword in [
            "timeout", "timed out", "connection refused",
            "connection reset", "network", "dns", "unreachable",
            "temporary failure", "service unavailable",
        ]):
            return ErrorCategory.TRANSIENT

        if any(keyword in error_str for keyword in [
            "unauthorized", "invalid api key", "api key",
            "authentication", "forbidden", "permission denied",
        ]):
            return ErrorCategory.AUTHENTICATION

        if any(keyword in error_str for keyword in [
            "content policy", "safety", "blocked", "filtered",
            "moderation", "harmful",
        ]):
            return ErrorCategory.CONTENT_POLICY

        if any(keyword in error_str for keyword in [
            "invalid", "malformed", "bad request", "missing required",
        ]):
            return ErrorCategory.INVALID_REQUEST

        logger.warning(
            f"Unclassified error for provider '{provider_id}': "
            f"type={type(error).__name__}, message={error}"
        )
        return ErrorCategory.UNKNOWN

    def is_retryable(self, category: ErrorCategory) -> bool:
        """Check if error category should be retried."""
        return category in {
            ErrorCategory.TRANSIENT,
            ErrorCategory.RATE_LIMIT,
            ErrorCategory.RESOURCE_EXHAUSTED,
        }
