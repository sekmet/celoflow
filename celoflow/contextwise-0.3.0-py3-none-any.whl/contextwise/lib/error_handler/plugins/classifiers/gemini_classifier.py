"""Gemini-specific error classifier.

Based on the investigation report (ERR-2026-02-09-001), this classifier
handles both native SDK and OpenAI-compatible mode errors.
"""

import logging

from ...core.interfaces import ErrorClassifierInterface
from ...core.types import ErrorCategory
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@register_plugin("gemini_classifier", ErrorClassifierInterface)
class GeminiErrorClassifier(ErrorClassifierInterface):
    """Gemini-specific error classification with patterns from production logs.

    Handles:
    - Native SDK errors (google.genai.errors.ServerError)
    - OpenAI-compatible mode errors (HTTP status codes)
    - Network timeouts and connection issues
    """

    def classify(self, error: Exception, provider_id: str) -> ErrorCategory:
        """Classify Gemini error based on production patterns.

        Based on ERR-2026-02-09-001 investigation:
        - 500 INTERNAL errors are TRANSIENT (should retry)
        - 429 errors are RATE_LIMIT
        - Network errors are TRANSIENT
        """
        error_str = str(error).lower()
        error_type = type(error).__name__

        # Native SDK: google.genai.errors.ServerError
        if "servererror" in error_type.lower():
            if "500" in error_str or "internal" in error_str:
                logger.debug(f"Gemini ServerError classified as TRANSIENT: {error}")
                return ErrorCategory.TRANSIENT
            elif "503" in error_str:
                return ErrorCategory.TRANSIENT

        # HTTP status codes (both native and OpenAI-compatible mode)
        if "500" in error_str and "internal" in error_str:
            return ErrorCategory.TRANSIENT
        elif "503" in error_str:
            return ErrorCategory.TRANSIENT
        elif "429" in error_str or "quota" in error_str or "rate limit" in error_str:
            return ErrorCategory.RATE_LIMIT
        elif "401" in error_str or "unauthorized" in error_str or "api key" in error_str:
            return ErrorCategory.AUTHENTICATION
        elif "400" in error_str or "bad request" in error_str:
            return ErrorCategory.INVALID_REQUEST

        # Network errors
        if any(keyword in error_str for keyword in [
            "timeout", "connection", "network", "dns", "unreachable"
        ]):
            return ErrorCategory.TRANSIENT

        # Resource exhaustion
        if "resource" in error_str and "exhausted" in error_str:
            return ErrorCategory.RESOURCE_EXHAUSTED

        # Content policy violations
        if any(keyword in error_str for keyword in [
            "content policy", "safety", "blocked", "filtered"
        ]):
            return ErrorCategory.CONTENT_POLICY

        # Unknown error
        logger.warning(f"Unknown Gemini error pattern: {error}")
        return ErrorCategory.UNKNOWN

    def is_retryable(self, category: ErrorCategory) -> bool:
        """Check if error category should be retried."""
        retryable_categories = {
            ErrorCategory.TRANSIENT,
            ErrorCategory.RATE_LIMIT,
            ErrorCategory.RESOURCE_EXHAUSTED,
        }
        return category in retryable_categories
