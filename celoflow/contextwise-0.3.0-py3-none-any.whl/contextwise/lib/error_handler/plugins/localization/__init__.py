"""Localization plugins.

Importing this module registers all localization plugins with the global registry.
"""

from .message_localizer import MessageLocalizer

__all__ = [
    "MessageLocalizer",
]
