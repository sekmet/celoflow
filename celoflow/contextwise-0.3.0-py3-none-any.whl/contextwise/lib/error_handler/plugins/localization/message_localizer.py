"""Multi-language message localization.

Design Decision: Provide honest, empathetic messages in user's language.
Messages should be actionable and avoid technical jargon.
"""

import logging
from typing import Dict

from ...core.interfaces import LocalizationInterface
from ...registry.plugin_registry import register_plugin

logger = logging.getLogger(__name__)


@register_plugin("message_localizer", LocalizationInterface)
class MessageLocalizer(LocalizationInterface):
    """Multi-language message localization.

    Supported languages:
    - English (en)
    - Portuguese Brazil (pt-BR)
    - Spanish (es)
    - French (fr)
    - German (de)
    - Italian (it)
    - Japanese (ja)
    - Chinese Simplified (zh-CN)
    """

    MESSAGES: Dict[str, Dict[str, str]] = {
        "en": {
            "rate_limit_exhausted": (
                "I'm currently experiencing high demand. "
                "Please try again in a few moments. "
                "Thank you for your patience!"
            ),
            "temporary_service_issue": (
                "I'm having a brief technical hiccup. "
                "Please try again in a moment. "
                "I apologize for the inconvenience!"
            ),
            "service_temporarily_unavailable": (
                "I'm temporarily unavailable due to maintenance. "
                "Please try again shortly. "
                "Thank you for your understanding!"
            ),
            "all_providers_failed": (
                "I'm experiencing technical difficulties at the moment. "
                "I've tried multiple systems but none are responding. "
                "Please try again in a few minutes. "
                "I sincerely apologize for the inconvenience!"
            ),
            "authentication_failed": (
                "There's an authentication issue preventing me from responding. "
                "Please contact support if this persists."
            ),
            "resource_exhausted": (
                "System resources are temporarily exhausted. "
                "Please try again in a few moments."
            ),
            "cost_limit_exceeded": (
                "The cost limit for this conversation has been reached. "
                "Please start a new conversation to continue."
            ),
            "request_cannot_be_processed": (
                "I'm unable to process this request. "
                "Please try rephrasing or contact support."
            ),
            "unexpected_error": (
                "An unexpected error occurred. "
                "Please try again or contact support if this persists."
            ),
        },
        "pt-BR": {
            "rate_limit_exhausted": (
                "Estou enfrentando alta demanda no momento. "
                "Por favor, tente novamente em alguns instantes. "
                "Obrigado pela paciencia!"
            ),
            "temporary_service_issue": (
                "Estou com um pequeno problema tecnico. "
                "Por favor, tente novamente em um momento. "
                "Peco desculpas pelo inconveniente!"
            ),
            "service_temporarily_unavailable": (
                "Estou temporariamente indisponivel devido a manutencao. "
                "Por favor, tente novamente em breve. "
                "Obrigado pela compreensao!"
            ),
            "all_providers_failed": (
                "Estou enfrentando dificuldades tecnicas no momento. "
                "Tentei multiplos sistemas mas nenhum esta respondendo. "
                "Por favor, tente novamente em alguns minutos. "
                "Peco sinceras desculpas pelo inconveniente!"
            ),
            "authentication_failed": (
                "Ha um problema de autenticacao impedindo minha resposta. "
                "Por favor, contate o suporte se isso persistir."
            ),
            "resource_exhausted": (
                "Os recursos do sistema estao temporariamente esgotados. "
                "Por favor, tente novamente em alguns instantes."
            ),
            "cost_limit_exceeded": (
                "O limite de custo para esta conversa foi atingido. "
                "Por favor, inicie uma nova conversa para continuar."
            ),
            "request_cannot_be_processed": (
                "Nao consigo processar esta solicitacao. "
                "Por favor, tente reformular ou contate o suporte."
            ),
            "unexpected_error": (
                "Ocorreu um erro inesperado. "
                "Por favor, tente novamente ou contate o suporte se persistir."
            ),
        },
        "es": {
            "rate_limit_exhausted": (
                "Estoy experimentando alta demanda en este momento. "
                "Por favor, intente de nuevo en unos momentos. "
                "Gracias por su paciencia!"
            ),
            "temporary_service_issue": (
                "Estoy teniendo un pequeno problema tecnico. "
                "Por favor, intente de nuevo en un momento. "
                "Disculpe las molestias!"
            ),
            "service_temporarily_unavailable": (
                "Estoy temporalmente no disponible debido al mantenimiento. "
                "Por favor, intente de nuevo pronto. "
                "Gracias por su comprension!"
            ),
            "all_providers_failed": (
                "Estoy experimentando dificultades tecnicas en este momento. "
                "He intentado multiples sistemas pero ninguno responde. "
                "Por favor, intente de nuevo en unos minutos. "
                "Sinceras disculpas por las molestias!"
            ),
            "authentication_failed": (
                "Hay un problema de autenticacion que impide mi respuesta. "
                "Por favor, contacte soporte si esto persiste."
            ),
            "resource_exhausted": (
                "Los recursos del sistema estan temporalmente agotados. "
                "Por favor, intente de nuevo en unos momentos."
            ),
            "cost_limit_exceeded": (
                "Se ha alcanzado el limite de costo para esta conversacion. "
                "Por favor, inicie una nueva conversacion para continuar."
            ),
            "request_cannot_be_processed": (
                "No puedo procesar esta solicitud. "
                "Por favor, intente reformularla o contacte soporte."
            ),
            "unexpected_error": (
                "Ocurrio un error inesperado. "
                "Por favor, intente de nuevo o contacte soporte si persiste."
            ),
        },
        "fr": {
            "rate_limit_exhausted": (
                "Je fais face a une forte demande en ce moment. "
                "Veuillez reessayer dans quelques instants. "
                "Merci de votre patience !"
            ),
            "temporary_service_issue": (
                "J'ai un petit probleme technique. "
                "Veuillez reessayer dans un moment. "
                "Je m'excuse pour le desagrement !"
            ),
            "service_temporarily_unavailable": (
                "Je suis temporairement indisponible en raison de la maintenance. "
                "Veuillez reessayer sous peu. "
                "Merci de votre comprehension !"
            ),
            "all_providers_failed": (
                "Je rencontre des difficultes techniques en ce moment. "
                "J'ai essaye plusieurs systemes mais aucun ne repond. "
                "Veuillez reessayer dans quelques minutes. "
                "Je m'excuse sincerement pour le desagrement !"
            ),
            "authentication_failed": (
                "Il y a un probleme d'authentification empechant ma reponse. "
                "Veuillez contacter le support si cela persiste."
            ),
            "resource_exhausted": (
                "Les ressources du systeme sont temporairement epuisees. "
                "Veuillez reessayer dans quelques instants."
            ),
            "cost_limit_exceeded": (
                "La limite de cout pour cette conversation a ete atteinte. "
                "Veuillez demarrer une nouvelle conversation pour continuer."
            ),
            "request_cannot_be_processed": (
                "Je ne peux pas traiter cette demande. "
                "Veuillez reformuler ou contacter le support."
            ),
            "unexpected_error": (
                "Une erreur inattendue s'est produite. "
                "Veuillez reessayer ou contacter le support si cela persiste."
            ),
        },
        "de": {
            "rate_limit_exhausted": (
                "Ich habe gerade eine hohe Nachfrage. "
                "Bitte versuchen Sie es in ein paar Momenten erneut. "
                "Danke fuer Ihre Geduld!"
            ),
            "temporary_service_issue": (
                "Ich habe ein kleines technisches Problem. "
                "Bitte versuchen Sie es in einem Moment erneut. "
                "Entschuldigung fuer die Unannehmlichkeiten!"
            ),
            "service_temporarily_unavailable": (
                "Ich bin aufgrund von Wartungsarbeiten voruebergehend nicht verfuegbar. "
                "Bitte versuchen Sie es in Kuerze erneut. "
                "Danke fuer Ihr Verstaendnis!"
            ),
            "all_providers_failed": (
                "Ich habe derzeit technische Schwierigkeiten. "
                "Ich habe mehrere Systeme versucht, aber keines antwortet. "
                "Bitte versuchen Sie es in ein paar Minuten erneut. "
                "Ich entschuldige mich aufrichtig fuer die Unannehmlichkeiten!"
            ),
            "authentication_failed": (
                "Es gibt ein Authentifizierungsproblem, das meine Antwort verhindert. "
                "Bitte kontaktieren Sie den Support, wenn dies anhaelt."
            ),
            "resource_exhausted": (
                "Systemressourcen sind voruebergehend erschoepft. "
                "Bitte versuchen Sie es in ein paar Momenten erneut."
            ),
            "cost_limit_exceeded": (
                "Das Kostenlimit fuer diese Konversation wurde erreicht. "
                "Bitte starten Sie eine neue Konversation, um fortzufahren."
            ),
            "request_cannot_be_processed": (
                "Ich kann diese Anfrage nicht verarbeiten. "
                "Bitte formulieren Sie sie neu oder kontaktieren Sie den Support."
            ),
            "unexpected_error": (
                "Ein unerwarteter Fehler ist aufgetreten. "
                "Bitte versuchen Sie es erneut oder kontaktieren Sie den Support."
            ),
        },
        "it": {
            "rate_limit_exhausted": (
                "Sto riscontrando un'alta domanda in questo momento. "
                "Per favore, riprova tra qualche istante. "
                "Grazie per la pazienza!"
            ),
            "temporary_service_issue": (
                "Sto avendo un piccolo problema tecnico. "
                "Per favore, riprova tra un momento. "
                "Mi scuso per l'inconveniente!"
            ),
            "service_temporarily_unavailable": (
                "Sono temporaneamente non disponibile per manutenzione. "
                "Per favore, riprova a breve. "
                "Grazie per la comprensione!"
            ),
            "all_providers_failed": (
                "Sto riscontrando difficolta tecniche in questo momento. "
                "Ho provato piu sistemi ma nessuno risponde. "
                "Per favore, riprova tra qualche minuto. "
                "Mi scuso sinceramente per l'inconveniente!"
            ),
            "authentication_failed": (
                "C'e un problema di autenticazione che impedisce la mia risposta. "
                "Per favore, contatta il supporto se il problema persiste."
            ),
            "resource_exhausted": (
                "Le risorse del sistema sono temporaneamente esaurite. "
                "Per favore, riprova tra qualche istante."
            ),
            "cost_limit_exceeded": (
                "Il limite di costo per questa conversazione e stato raggiunto. "
                "Per favore, inizia una nuova conversazione per continuare."
            ),
            "request_cannot_be_processed": (
                "Non riesco a elaborare questa richiesta. "
                "Per favore, prova a riformularla o contatta il supporto."
            ),
            "unexpected_error": (
                "Si e verificato un errore imprevisto. "
                "Per favore, riprova o contatta il supporto se il problema persiste."
            ),
        },
        "ja": {
            "rate_limit_exhausted": (
                "現在、高い需要が発生しています。"
                "しばらくしてからもう一度お試しください。"
                "お待ちいただきありがとうございます！"
            ),
            "temporary_service_issue": (
                "一時的な技術的問題が発生しています。"
                "しばらくしてからもう一度お試しください。"
                "ご不便をおかけして申し訳ございません！"
            ),
            "service_temporarily_unavailable": (
                "メンテナンスのため一時的にご利用いただけません。"
                "まもなくもう一度お試しください。"
                "ご理解いただきありがとうございます！"
            ),
            "all_providers_failed": (
                "現在、技術的な問題が発生しています。"
                "複数のシステムを試しましたが、応答がありません。"
                "数分後にもう一度お試しください。"
                "ご不便をおかけして誠に申し訳ございません！"
            ),
            "authentication_failed": (
                "認証の問題により応答できません。"
                "問題が続く場合はサポートにお問い合わせください。"
            ),
            "resource_exhausted": (
                "システムリソースが一時的に枯渇しています。"
                "しばらくしてからもう一度お試しください。"
            ),
            "cost_limit_exceeded": (
                "この会話のコスト制限に達しました。"
                "続行するには新しい会話を開始してください。"
            ),
            "request_cannot_be_processed": (
                "このリクエストを処理できません。"
                "言い換えるか、サポートにお問い合わせください。"
            ),
            "unexpected_error": (
                "予期しないエラーが発生しました。"
                "もう一度お試しいただくか、問題が続く場合はサポートにお問い合わせください。"
            ),
        },
        "zh-CN": {
            "rate_limit_exhausted": (
                "目前需求量较大。"
                "请稍后再试。"
                "感谢您的耐心等待！"
            ),
            "temporary_service_issue": (
                "遇到了一个小技术问题。"
                "请稍后再试。"
                "对给您带来的不便深表歉意！"
            ),
            "service_temporarily_unavailable": (
                "由于维护，暂时无法使用。"
                "请稍后再试。"
                "感谢您的理解！"
            ),
            "all_providers_failed": (
                "目前遇到了技术困难。"
                "已尝试多个系统但均无响应。"
                "请几分钟后再试。"
                "对给您带来的不便深表歉意！"
            ),
            "authentication_failed": (
                "存在认证问题，无法响应。"
                "如果问题持续，请联系支持。"
            ),
            "resource_exhausted": (
                "系统资源暂时耗尽。"
                "请稍后再试。"
            ),
            "cost_limit_exceeded": (
                "此对话的费用限制已达到。"
                "请开始新的对话以继续。"
            ),
            "request_cannot_be_processed": (
                "无法处理此请求。"
                "请尝试重新表述或联系支持。"
            ),
            "unexpected_error": (
                "发生了意外错误。"
                "请重试或在问题持续时联系支持。"
            ),
        },
    }

    def __init__(self, default_locale: str = "en"):
        self.default_locale = default_locale
        logger.info(
            f"MessageLocalizer initialized with default locale: {default_locale}"
        )

    def get_message(
        self,
        message_key: str,
        locale: str,
        **kwargs,
    ) -> str:
        """Get localized message with template variables.

        Args:
            message_key: Key for message template
            locale: User's locale (e.g., "en", "pt-BR")
            **kwargs: Template variables (e.g., providers_tried, total_attempts)

        Returns:
            Localized message string
        """
        # Normalize locale
        normalized_locale = self._normalize_locale(locale)

        # Get messages for locale (fallback to default if not found)
        locale_messages = self.MESSAGES.get(
            normalized_locale,
            self.MESSAGES.get(self.default_locale, self.MESSAGES["en"])
        )

        # Get message template
        message_template = locale_messages.get(
            message_key,
            locale_messages.get("unexpected_error", "An error occurred.")
        )

        # Format with template variables if any
        try:
            message = message_template.format(**kwargs)
        except KeyError:
            # Template variables don't match - return template as-is
            message = message_template

        logger.debug(
            f"Localized message for key='{message_key}', locale='{locale}': {message}"
        )

        return message

    def _normalize_locale(self, locale: str) -> str:
        """Normalize locale to supported format.

        Examples:
        - "pt" -> "pt-BR"
        - "pt_BR" -> "pt-BR"
        - "en-US" -> "en"
        """
        if not locale:
            return self.default_locale

        # Convert underscore to hyphen
        locale = locale.replace("_", "-")

        # Map common variations
        locale_map = {
            "pt": "pt-BR",
            "zh": "zh-CN",
            "en-US": "en",
            "en-GB": "en",
        }

        return locale_map.get(locale, locale)
