"""Acontext plugin bundle for easy integration.

This module provides a convenience class for creating all Acontext
plugins at once with a single configuration.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List, Optional

from ..base import AgentPlugin
from .config import AcontextConfig
from .client_plugin import AcontextClientPlugin
from .session_plugin import AcontextSessionPlugin
from .space_plugin import AcontextSpacePlugin
from .disk_plugin import AcontextDiskPlugin
from .observe_plugin import AcontextObservePlugin


@dataclass
class AcontextPluginBundle:
    """Bundle of all Acontext plugins for easy integration.
    
    This class provides a convenient way to create and configure
    all Acontext plugins with a single configuration.
    
    Attributes:
        api_key: Acontext API key.
        base_url: Acontext API base URL.
        enable_sessions: Enable session persistence.
        enable_spaces: Enable skill learning.
        enable_disks: Enable artifact storage.
        enable_observation: Enable task observation.
        default_space_id: Default space UUID.
        default_disk_id: Default disk UUID.
        timeout: Request timeout.
    
    Example:
        ```python
        from contextwise.lib.acontext import AcontextPluginBundle
        
        # Create all plugins
        bundle = AcontextPluginBundle(api_key="sk-ac-...")
        plugins = bundle.create_plugins()
        
        # Add to plugin manager
        plugin_manager = PluginManager(
            base_agent=base_agent,
            plugins=plugins,
        )
        ```
    """
    
    api_key: str = ""
    base_url: str = "http://localhost:8029/api/v1"
    timeout: float = 32.0
    enable_sessions: bool = True
    enable_spaces: bool = True
    enable_disks: bool = True
    enable_observation: bool = True
    default_space_id: Optional[str] = None
    default_disk_id: Optional[str] = None
    
    @classmethod
    def from_config(cls, config: AcontextConfig) -> "AcontextPluginBundle":
        """Create bundle from configuration.
        
        Args:
            config: Acontext configuration.
            
        Returns:
            Configured bundle instance.
        """
        return cls(
            api_key=config.api_key,
            base_url=config.base_url,
            timeout=config.timeout,
            enable_sessions=config.enable_sessions,
            enable_spaces=config.enable_spaces,
            enable_disks=config.enable_disks,
            enable_observation=config.enable_observation,
        )
    
    @classmethod
    def from_env(cls) -> "AcontextPluginBundle":
        """Create bundle from environment variables.
        
        Environment variables:
            - ACONTEXT_API_KEY: API key
            - ACONTEXT_BASE_URL: Base URL
            - ACONTEXT_TIMEOUT: Request timeout
            - ACONTEXT_ENABLE_SESSIONS: Enable sessions
            - ACONTEXT_ENABLE_SPACES: Enable spaces
            - ACONTEXT_ENABLE_DISKS: Enable disks
            - ACONTEXT_ENABLE_OBSERVATION: Enable observation
            - ACONTEXT_DEFAULT_SPACE_ID: Default space ID
            - ACONTEXT_DEFAULT_DISK_ID: Default disk ID
        
        Returns:
            Configured bundle instance.
        """
        return cls(
            api_key=os.getenv("ACONTEXT_API_KEY", ""),
            base_url=os.getenv("ACONTEXT_BASE_URL", "http://localhost:8029/api/v1"),
            timeout=float(os.getenv("ACONTEXT_TIMEOUT", "32")),
            enable_sessions=os.getenv("ACONTEXT_ENABLE_SESSIONS", "true").lower() == "true",
            enable_spaces=os.getenv("ACONTEXT_ENABLE_SPACES", "true").lower() == "true",
            enable_disks=os.getenv("ACONTEXT_ENABLE_DISKS", "true").lower() == "true",
            enable_observation=os.getenv("ACONTEXT_ENABLE_OBSERVATION", "true").lower() == "true",
            default_space_id=os.getenv("ACONTEXT_DEFAULT_SPACE_ID"),
            default_disk_id=os.getenv("ACONTEXT_DEFAULT_DISK_ID"),
        )
    
    @property
    def is_configured(self) -> bool:
        """Check if the bundle is properly configured.
        
        Returns:
            True if API key is set.
        """
        return bool(self.api_key)
    
    def create_plugins(self) -> List[AgentPlugin]:
        """Create all enabled Acontext plugins.
        
        Returns:
            List of configured plugin instances.
        """
        plugins: List[AgentPlugin] = []
        
        # Client plugin is always needed
        client_plugin = AcontextClientPlugin(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout,
        )
        plugins.append(client_plugin)
        
        # Session plugin
        session_plugin: Optional[AcontextSessionPlugin] = None
        if self.enable_sessions:
            session_plugin = AcontextSessionPlugin(
                client_plugin=client_plugin,
                default_space_id=self.default_space_id,
            )
            plugins.append(session_plugin)
        
        # Space plugin
        if self.enable_spaces:
            space_plugin = AcontextSpacePlugin(
                client_plugin=client_plugin,
                default_space_id=self.default_space_id,
            )
            plugins.append(space_plugin)
        
        # Disk plugin
        if self.enable_disks:
            disk_plugin = AcontextDiskPlugin(
                client_plugin=client_plugin,
                default_disk_id=self.default_disk_id,
            )
            plugins.append(disk_plugin)
        
        # Observe plugin
        if self.enable_observation and session_plugin:
            observe_plugin = AcontextObservePlugin(
                client_plugin=client_plugin,
                session_plugin=session_plugin,
            )
            plugins.append(observe_plugin)
        
        return plugins
    
    def create_client_plugin(self) -> AcontextClientPlugin:
        """Create just the client plugin.
        
        Returns:
            Configured client plugin.
        """
        return AcontextClientPlugin(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout,
        )
