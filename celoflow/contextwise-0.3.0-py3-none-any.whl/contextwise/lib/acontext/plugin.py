"""Acontext Plugin - Unified plugin for simple integration.

This module provides a single plugin class that combines all Acontext
functionality into one easy-to-use plugin compatible with AgentBuilder.

Example:
    from contextwise import AgentBuilder, AcontextPlugin
    
    # Simple usage - reads from environment
    acontext = AcontextPlugin()
    
    builder = AgentBuilder(
        name="My Assistant",
        model="gpt-4o-mini",
    )
    builder.add_plugin(acontext)
    agent = builder.build()
"""

from __future__ import annotations

import os
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from agents import Agent, RunResult, RunConfig, function_tool, RunContextWrapper

from ..base import AgentPlugin
from ..context import AgentContext
from .config import AcontextConfig
from .context import AcontextAgentContext
from .bundle import AcontextPluginBundle

logger = logging.getLogger(__name__)


@dataclass
class AcontextPluginConfig:
    """Configuration for the unified Acontext plugin.
    
    Attributes:
        api_key: Acontext API key. If None, reads from ACONTEXT_API_KEY env var.
        base_url: Acontext API base URL. If None, reads from ACONTEXT_BASE_URL env var.
        timeout: Request timeout in seconds.
        enable_sessions: Enable session persistence (stores conversation history).
        enable_spaces: Enable skill learning and search.
        enable_disks: Enable artifact storage (files).
        enable_observation: Enable task observation.
        enable_tools: Add Acontext tools (search_skills, save_file, etc.) to agent.
        auto_create_space: Automatically create a skill space if none exists.
        auto_create_disk: Automatically create an artifact disk if none exists.
        default_space_id: Default space UUID for skills.
        default_disk_id: Default disk UUID for files.
    """
    
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    timeout: float = 32.0
    enable_sessions: bool = True
    enable_spaces: bool = True
    enable_disks: bool = True
    enable_observation: bool = True
    enable_tools: bool = True
    auto_create_space: bool = True
    auto_create_disk: bool = True
    default_space_id: Optional[str] = None
    default_disk_id: Optional[str] = None
    
    def __post_init__(self):
        """Load from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv("ACONTEXT_API_KEY", "")
        if self.base_url is None:
            self.base_url = os.getenv("ACONTEXT_BASE_URL", "http://localhost:8029/api/v1")
        if self.default_space_id is None:
            self.default_space_id = os.getenv("ACONTEXT_DEFAULT_SPACE_ID")
        if self.default_disk_id is None:
            self.default_disk_id = os.getenv("ACONTEXT_DEFAULT_DISK_ID")
    
    @property
    def is_configured(self) -> bool:
        """Check if API key is set."""
        return bool(self.api_key)


class AcontextPlugin(AgentPlugin[AgentContext]):
    """Unified Acontext plugin for simple integration.
    
    This plugin provides a single-class interface for all Acontext features:
    - Session persistence
    - Skill learning and search
    - Artifact storage
    - Task observation
    
    It's designed to work with AgentBuilder.add_plugin() just like
    other contextwise plugins (HMLRMemoryPlugin, etc.).
    
    Example:
        from contextwise import AgentBuilder, AcontextPlugin
        
        # Simple usage - reads from environment
        acontext = AcontextPlugin()
        
        # Or with custom config
        acontext = AcontextPlugin(
            config=AcontextPluginConfig(
                api_key="sk-ac-...",
                enable_spaces=True,
                enable_disks=False,
            )
        )
        
        builder = AgentBuilder(
            name="My Assistant",
            model="gpt-4o-mini",
        )
        builder.add_plugin(acontext)
        agent = builder.build()
    """
    
    id: str = "acontext"
    name: str = "Acontext Plugin"
    version: str = "1.0.0"
    
    def __init__(
        self,
        config: Optional[AcontextPluginConfig] = None,
    ):
        """Initialize the Acontext plugin.
        
        Args:
            config: Plugin configuration. If None, defaults are loaded from environment.
        """
        self.config = config or AcontextPluginConfig()
        
        # Create internal plugin bundle
        self._bundle = AcontextPluginBundle(
            api_key=self.config.api_key or "",
            base_url=self.config.base_url or "http://localhost:8029/api/v1",
            timeout=self.config.timeout,
            enable_sessions=self.config.enable_sessions,
            enable_spaces=self.config.enable_spaces,
            enable_disks=self.config.enable_disks,
            enable_observation=self.config.enable_observation,
            default_space_id=self.config.default_space_id,
            default_disk_id=self.config.default_disk_id,
        )
        
        # Create child plugins
        self._plugins = self._bundle.create_plugins()
        
        # Track state
        self._client = None
        self._session_plugin = None
        self._space_plugin = None
        self._disk_plugin = None
        self._observe_plugin = None
        
        # Map plugins by type
        for plugin in self._plugins:
            if plugin.id == "acontext-client":
                self._client = plugin
            elif plugin.id == "acontext-session":
                self._session_plugin = plugin
            elif plugin.id == "acontext-space":
                self._space_plugin = plugin
            elif plugin.id == "acontext-disk":
                self._disk_plugin = plugin
            elif plugin.id == "acontext-observe":
                self._observe_plugin = plugin
        
        if self.config.is_configured:
            logger.info(f"Acontext Plugin initialized: {self.config.base_url}")
        else:
            logger.warning("Acontext API key not configured - set ACONTEXT_API_KEY")
    
    @classmethod
    def from_env(cls) -> "AcontextPlugin":
        """Create plugin from environment variables.
        
        Environment variables:
            - ACONTEXT_API_KEY: API key
            - ACONTEXT_BASE_URL: Base URL
            - ACONTEXT_DEFAULT_SPACE_ID: Default space ID
            - ACONTEXT_DEFAULT_DISK_ID: Default disk ID
        
        Returns:
            Configured plugin instance.
        """
        return cls(config=AcontextPluginConfig())
    
    def dependencies(self) -> List[str]:
        """Return plugin dependencies."""
        return []
    
    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Configure agent with Acontext tools.
        
        Adds function tools for skill search, learning, and artifact management
        when enable_tools is True.
        """
        if not self.config.enable_tools:
            return agent
        
        # Add Acontext function tools
        from .tools import create_acontext_tools
        acontext_tools = create_acontext_tools(self)
        
        # Clone agent with extended tools
        existing_tools = list(agent.tools) if agent.tools else []
        existing_tools.extend(acontext_tools)
        
        configured_agent = agent.clone(tools=existing_tools)
        
        # Let each child plugin configure the agent
        for plugin in self._plugins:
            if hasattr(plugin, 'configure_agent'):
                configured_agent = plugin.configure_agent(configured_agent)
        
        return configured_agent
    
    def get_tools(self) -> list:
        """Get function tools for manual registration.
        
        Use this if you want to add Acontext tools to an agent manually
        without using configure_agent.
        
        Returns:
            List of function_tool decorated functions
        """
        from .tools import create_acontext_tools
        return create_acontext_tools(self)
    
    def extend_run_config(self, config: RunConfig) -> RunConfig:
        """Extend run configuration with Acontext settings."""
        for plugin in self._plugins:
            if hasattr(plugin, 'extend_run_config'):
                config = plugin.extend_run_config(config)
        return config
    
    def on_before_run(self, context: AgentContext, input_text: str) -> None:
        """Called before agent run - delegates to child plugins."""
        # Convert AgentContext to AcontextAgentContext if needed
        acontext_context = self._ensure_acontext_context(context)
        
        for plugin in self._plugins:
            if hasattr(plugin, 'on_before_run'):
                try:
                    plugin.on_before_run(acontext_context, input_text)
                except Exception as e:
                    logger.error(f"Acontext on_before_run error ({plugin.id}): {e}")
    
    def on_after_run(self, context: AgentContext, result: RunResult) -> None:
        """Called after agent run - delegates to child plugins."""
        # Convert AgentContext to AcontextAgentContext if needed
        acontext_context = self._ensure_acontext_context(context)
        
        for plugin in self._plugins:
            if hasattr(plugin, 'on_after_run'):
                try:
                    plugin.on_after_run(acontext_context, result)
                except Exception as e:
                    logger.error(f"Acontext on_after_run error ({plugin.id}): {e}")
    
    def _ensure_acontext_context(self, context: AgentContext) -> AcontextAgentContext:
        """Ensure we have an AcontextAgentContext.
        
        If a base AgentContext is provided, wrap it in AcontextAgentContext.
        """
        if isinstance(context, AcontextAgentContext):
            return context
        
        # Create AcontextAgentContext from base context
        return AcontextAgentContext(
            user_id=context.user_id,
            channel=context.channel,
            locale=context.locale,
            session_id=context.session_id,
            metadata=context.metadata.copy() if context.metadata else {},
            enable_learning=True,
            enable_observation=True,
        )
    
    # =========================================================================
    # Convenience Methods
    # =========================================================================
    
    def get_client(self):
        """Get the Acontext client from the client plugin."""
        if not self._client:
            return None

        client = self._client.client

        if self.config.default_space_id is None:
            file_space_id: Optional[str] = None
            try:
                space_file = Path(".acontext_space_id")
                if space_file.exists():
                    file_space_id = space_file.read_text().strip() or None
            except Exception:
                file_space_id = None

            self.config.default_space_id = os.getenv("ACONTEXT_DEFAULT_SPACE_ID") or file_space_id

        if self.config.default_space_id is None:
            try:
                space = client.spaces.create()
                self.config.default_space_id = space.id
                try:
                    Path(".acontext_space_id").write_text(space.id)
                except Exception:
                    pass
            except Exception:
                pass

        if self._session_plugin and hasattr(self._session_plugin, "default_space_id"):
            self._session_plugin.default_space_id = self.config.default_space_id
        if self._space_plugin and hasattr(self._space_plugin, "default_space_id"):
            self._space_plugin.default_space_id = self.config.default_space_id

        return client
    
    def search_skills(self, query: str, limit: int = 10, mode: str = "fast") -> Dict[str, Any]:
        """Search for learned skills.
        
        Args:
            query: Search query
            limit: Maximum results
            mode: "fast" or "agentic"
            
        Returns:
            Search results with cited_blocks
        """
        if not self._space_plugin:
            return {"skills": [], "error": "Space plugin not enabled"}
        
        try:
            client = self.get_client()
            if not client:
                return {"skills": [], "error": "Client not available"}
            
            space_id = self.config.default_space_id
            if not space_id and self.config.auto_create_space:
                # Try to get or create a space
                space_id = self._space_plugin.get_or_create_default_space()
            
            if not space_id:
                return {"skills": [], "error": "No space configured"}
            
            result = client.spaces.experience_search(
                space_id=space_id,
                query=query,
                limit=limit,
                mode=mode,
            )
            
            skills = []
            if hasattr(result, 'cited_blocks'):
                for block in result.cited_blocks:
                    skills.append({
                        "title": getattr(block, 'title', 'Unknown'),
                        "distance": getattr(block, 'distance', 0),
                        "type": getattr(block, 'type', 'unknown'),
                        "props": getattr(block, 'props', {}),
                    })
            
            return {"skills": skills, "query": query}
        except Exception as e:
            logger.error(f"Skill search error: {e}")
            return {"skills": [], "error": str(e)}
    
    def flush_session(self, session_id: str) -> Dict[str, Any]:
        """Flush session buffer to trigger learning.
        
        Args:
            session_id: Session UUID
            
        Returns:
            Flush result
        """
        try:
            client = self.get_client()
            if not client:
                return {"success": False, "error": "Client not available"}
            
            client.sessions.flush(session_id)
            return {"success": True, "session_id": session_id}
        except Exception as e:
            logger.error(f"Flush error: {e}")
            return {"success": False, "error": str(e)}
    
    def get_learned_tools(self) -> List[Dict[str, Any]]:
        """Get all learned tools.
        
        Returns:
            List of tools with SOP counts
        """
        try:
            client = self.get_client()
            if not client:
                return []
            
            tools = client.tools.get_tool_name()
            return [
                {"name": getattr(t, 'name', 'Unknown'), "sop_count": getattr(t, 'sop_count', 0)}
                for t in tools
            ]
        except Exception as e:
            logger.error(f"Get tools error: {e}")
            return []
    
    def rename_tools(self, renames: List[Dict[str, str]]) -> Dict[str, Any]:
        """Batch rename tools for consistency.
        
        Based on: edit-agent-tools.md
        
        Args:
            renames: List of {"old_name": "...", "new_name": "..."} dicts
            
        Returns:
            Result with status and any errors
        """
        result = {"success": False, "error": ""}
        
        try:
            client = self.get_client()
            if client is None:
                result["error"] = "Acontext client not available"
                return result
            
            response = client.tools.rename_tool_name(rename=renames)
            if hasattr(response, 'status') and response.status == 0:
                result["success"] = True
                logger.info(f"Renamed {len(renames)} tools successfully")
            else:
                result["error"] = getattr(response, 'errmsg', 'Unknown error')
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Tool rename failed: {e}")
        
        return result
    
    # =========================================================================
    # Skill Learning Methods (based on self-learn-skills.md)
    # =========================================================================
    
    def get_or_create_skill_space(self, space_file: Optional[str] = None) -> Optional[str]:
        """Get or create the skill learning space.
        
        Stores space_id in a local file for persistence across restarts.
        
        Args:
            space_file: Optional path to store space ID (defaults to .acontext_space_id)
            
        Returns:
            Space ID or None if Acontext is not available.
        """
        # Return cached/configured space ID first
        if self.config.default_space_id:
            return self.config.default_space_id
        
        client = self.get_client()
        if client is None:
            return None
        
        # Check for stored space ID
        from pathlib import Path
        if space_file is None:
            space_file = ".acontext_space_id"
        space_path = Path(space_file)
        
        if space_path.exists():
            space_id = space_path.read_text().strip()
            logger.info(f"Using existing skill space: {space_id}")
            return space_id
        
        # Create new space
        try:
            space = client.spaces.create()
            space_id = space.id
            space_path.write_text(space_id)
            logger.info(f"Created skill learning space: {space_id}")
            return space_id
        except Exception as e:
            logger.error(f"Failed to create skill space: {e}")
            return None
    
    def parse_skill_file(self, file_path: str) -> Dict[str, Any]:
        """Parse a skill definition file.
        
        Skill file format:
            ---
            name: Skill Name
            description: What this skill does
            use_when: When to apply this skill
            preferences: User preferences for this skill
            ---
            
            ## Steps
            1. First step
            2. Second step
            ...
        
        Args:
            file_path: Path to the skill .txt file
            
        Returns:
            Parsed skill dictionary with metadata and steps
        """
        from pathlib import Path
        path = Path(file_path)
        content = path.read_text(encoding="utf-8")
        
        skill = {
            "name": path.stem,
            "description": "",
            "use_when": "",
            "preferences": "",
            "steps": [],
            "raw_content": content,
        }
        
        lines = content.strip().split("\n")
        in_header = False
        header_lines = []
        body_lines = []
        
        for i, line in enumerate(lines):
            if line.strip() == "---":
                if not in_header:
                    in_header = True
                else:
                    in_header = False
                    body_lines = lines[i+1:]
                    break
            elif in_header:
                header_lines.append(line)
            else:
                body_lines.append(line)
        
        # Parse header
        for line in header_lines:
            if ":" in line:
                key, value = line.split(":", 1)
                key = key.strip().lower().replace(" ", "_")
                value = value.strip()
                if key in skill:
                    skill[key] = value
        
        # Parse steps from body
        steps = []
        for line in body_lines:
            line = line.strip()
            if line.startswith(("1.", "2.", "3.", "4.", "5.", "6.", "7.", "8.", "9.", "-")):
                step = line.lstrip("0123456789.-) ").strip()
                if step:
                    steps.append(step)
        
        skill["steps"] = steps
        skill["body"] = "\n".join(body_lines).strip()
        
        return skill
    
    def _infer_tool_name(self, step: str) -> str:
        """Infer a tool name from a step description."""
        step_lower = step.lower()
        
        tool_keywords = {
            "search": "search_web", "find": "search_web", "look up": "search_web",
            "read": "read_file", "open": "read_file", "load": "read_file",
            "write": "write_file", "save": "save_file", "create": "create_file",
            "edit": "edit_file", "modify": "edit_file", "update": "edit_file",
            "delete": "delete_file", "remove": "delete_file", "list": "list_files",
            "review": "code_review", "analyze": "analyze_code", "test": "run_tests",
            "run": "execute_command", "execute": "execute_command",
            "deploy": "deploy_app", "build": "build_project",
            "install": "install_package", "check": "verify_status",
            "validate": "validate_data", "format": "format_code", "lint": "lint_code",
            "document": "generate_docs", "commit": "git_commit", "push": "git_push",
        }
        
        for keyword, tool in tool_keywords.items():
            if keyword in step_lower:
                return tool
        
        return "execute_step"
    
    def _create_skill_messages(self, skill: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Convert a skill definition into Acontext messages for learning."""
        messages = []
        
        # User request
        messages.append({
            "role": "user",
            "parts": [{"type": "text", "text": f"I need help with: {skill['name']}\n\n{skill['description']}"}]
        })
        
        # Assistant plan
        plan_text = f"I'll help you with {skill['name']}.\n\n"
        if skill["use_when"]:
            plan_text += f"**When to use:** {skill['use_when']}\n\n"
        if skill["preferences"]:
            plan_text += f"**Preferences:** {skill['preferences']}\n\n"
        plan_text += "Here's my plan:\n"
        for i, step in enumerate(skill["steps"], 1):
            plan_text += f"{i}. {step}\n"
        
        messages.append({
            "role": "assistant",
            "parts": [{"type": "text", "text": plan_text}]
        })
        
        # User confirms
        messages.append({
            "role": "user",
            "parts": [{"type": "text", "text": "Yes, please proceed with this approach."}]
        })
        
        # Execute steps with tool calls
        for i, step in enumerate(skill["steps"], 1):
            tool_name = self._infer_tool_name(step)
            messages.append({
                "role": "assistant",
                "parts": [{
                    "type": "tool-call",
                    "text": tool_name,
                    "meta": {"name": tool_name, "arguments": {"action": step, "step_number": i}}
                }]
            })
            messages.append({
                "role": "assistant",
                "parts": [{"type": "text", "text": f"Step {i} completed: {step}"}]
            })
        
        # Success confirmation
        messages.append({
            "role": "assistant",
            "parts": [{"type": "text", "text": f"✅ Successfully completed: {skill['name']}\n\nAll steps executed according to plan."}]
        })
        messages.append({
            "role": "user",
            "parts": [{"type": "text", "text": "Great work! Task completed successfully."}]
        })
        
        return messages
    
    def learn_skill_from_file(self, file_path: str) -> Dict[str, Any]:
        """Learn a skill from a .txt file.
        
        This function reads a skill definition file, creates a session connected
        to a Space, sends the skill as messages, and triggers learning via flush.
        
        Based on: self-learn-skills.md
        
        Args:
            file_path: Path to the skill .txt file
            
        Returns:
            Dict with learning results including:
            - success: bool
            - skill_name: str
            - session_id: str
            - space_id: str
            - tasks_extracted: int
            - error: str (if failed)
        """
        import time
        result = {"success": False, "skill_name": "", "error": ""}
        
        client = self.get_client()
        if client is None:
            result["error"] = "Acontext client not available"
            return result
        
        space_id = self.get_or_create_skill_space()
        if space_id is None:
            result["error"] = "Could not get or create skill space"
            return result
        
        try:
            # Parse skill file
            skill = self.parse_skill_file(file_path)
            result["skill_name"] = skill["name"]
            logger.info(f"Learning skill: {skill['name']} ({len(skill['steps'])} steps)")
            
            # Create session connected to space
            session = client.sessions.create(space_id=space_id)
            result["session_id"] = session.id
            result["space_id"] = space_id
            
            # Create and send messages
            messages = self._create_skill_messages(skill)
            for msg in messages:
                client.sessions.send_message(session_id=session.id, blob=msg, format="acontext")
            
            # Flush to trigger learning (session-buffer-mechanism.md)
            logger.info("Flushing session buffer to trigger learning...")
            client.sessions.flush(session.id)
            
            # Wait for processing
            time.sleep(2)
            
            # Check tasks
            tasks_response = client.sessions.get_tasks(session.id)
            task_count = len(tasks_response.items) if hasattr(tasks_response, 'items') else 0
            result["tasks_extracted"] = task_count
            result["success"] = True
            
            logger.info(f"✅ Skill '{skill['name']}' learned! Tasks: {task_count}")
            
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Failed to learn skill: {e}")
        
        return result
    
    def learn_all_skills_from_directory(self, directory: str = "skills") -> List[Dict[str, Any]]:
        """Learn all skills from .txt files in a directory.
        
        Args:
            directory: Path to directory containing skill files
            
        Returns:
            List of learning results for each skill file
        """
        from pathlib import Path
        dir_path = Path(directory)
        if not dir_path.exists():
            dir_path = Path(__file__).parent / directory
        
        if not dir_path.exists():
            logger.error(f"Directory not found: {directory}")
            return []
        
        results = []
        skill_files = sorted(dir_path.glob("*.txt"))
        logger.info(f"Found {len(skill_files)} skill files in {dir_path}")
        
        for file_path in skill_files:
            result = self.learn_skill_from_file(str(file_path))
            results.append(result)
        
        successful = sum(1 for r in results if r["success"])
        logger.info(f"Learned {successful}/{len(results)} skills successfully")
        
        return results
    
    # =========================================================================
    # Advanced Skill Search (based on search-skills.md)
    # =========================================================================
    
    def search_skills_with_context(
        self,
        query: str,
        mode: str = "fast",
        limit: int = 10,
        build_prompt: bool = True,
        semantic_threshold: Optional[float] = None,
        max_iterations: Optional[int] = None,
        space_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Search for learned skills and optionally build a prompt with context.
        
        Based on: search-skills.md
        
        Args:
            query: Natural language search query
            mode: Search mode - "fast" (embeddings) or "agentic" (iterative)
            limit: Maximum results to return (1-50)
            build_prompt: Whether to build a prompt with skill context
            semantic_threshold: Distance threshold for agentic mode (0=identical, 2=opposite)
            max_iterations: Maximum iterations for agentic mode (1-100, default 16)
            space_id: Optional space ID to search in (uses default if not provided)
            
        Returns:
            Dict with:
            - skills: List of matched skill blocks with use_when, preferences, tool_sops
            - prompt: Built prompt with context (if build_prompt=True)
            - query: Original query
            - space_id: Space that was searched
        """
        result = {"skills": [], "prompt": "", "query": query, "space_id": None, "error": None}
        
        client = self.get_client()
        if client is None:
            result["error"] = "Acontext client not available"
            return result
        
        if space_id is None:
            space_id = self.get_or_create_skill_space()
        if space_id is None:
            result["error"] = "Could not get or create skill space"
            return result
        
        result["space_id"] = space_id
        
        try:
            # Build search parameters
            search_params = {
                "space_id": space_id,
                "query": query,
                "mode": mode,
                "limit": limit,
            }
            
            # Add agentic mode parameters if specified
            if mode == "agentic":
                if semantic_threshold is not None:
                    search_params["semantic_threshold"] = semantic_threshold
                if max_iterations is not None:
                    search_params["max_iterations"] = max_iterations
            
            # Search for skills
            search_result = client.spaces.experience_search(**search_params)
            
            skills = []
            if hasattr(search_result, 'cited_blocks'):
                for block in search_result.cited_blocks:
                    skill_info = {
                        "title": getattr(block, 'title', 'Unknown'),
                        "distance": getattr(block, 'distance', 0),
                        "type": getattr(block, 'type', 'unknown'),
                        "props": getattr(block, 'props', {}),
                    }
                    skills.append(skill_info)
            
            result["skills"] = skills
            
            # Build prompt with context if requested
            if build_prompt and skills:
                context_parts = []
                for skill in skills:
                    props = skill.get("props", {})
                    use_when = props.get("use_when", skill["title"])
                    preferences = props.get("preferences", "")
                    tool_sops = props.get("tool_sops", [])
                    
                    context_parts.append(f"""
Use when: {use_when}
Preferences: {preferences}
Tool SOPs: {tool_sops}
""")
                
                context = "\n---\n".join(context_parts)
                result["prompt"] = f"""SKILLS REFERENCES:
{context}

USER REQUEST: {query}

Please act to complete the request using the skills above when relevant."""
            
            logger.info(f"Found {len(skills)} skills for query: '{query}'")
            
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Skill search failed: {e}")
        
        return result
    
    def verify_skill_learned(self, skill_name: str) -> bool:
        """Verify that a skill was learned by searching for it.
        
        Args:
            skill_name: Name of the skill to verify
            
        Returns:
            True if skill is found in the space
        """
        result = self.search_skills_with_context(skill_name, limit=5, build_prompt=False)
        
        for skill in result["skills"]:
            if skill_name.lower() in skill["title"].lower():
                logger.info(f"✅ Skill verified: {skill['title']} (distance: {skill['distance']:.2f})")
                return True
        
        logger.warning(f"⚠️ Skill not found: {skill_name}")
        return False
    
    # =========================================================================
    # Session Management (based on session-buffer-mechanism.md)
    # =========================================================================
    
    def flush_session_buffer(self, context: AcontextAgentContext) -> Dict[str, Any]:
        """Force processing of the session buffer from context.
        
        Acontext batches messages for cost optimization. Use this to force
        immediate processing when needed.
        
        Based on: session-buffer-mechanism.md
        
        Args:
            context: Agent context with acontext_session_id
            
        Returns:
            Flush result or error info
        """
        session_id = context.acontext_session_id
        if not session_id:
            return {"success": False, "error": "No acontext_session_id in context"}
        
        return self.flush_session(session_id)
    
    def get_tasks(self, session_id: str, limit: Optional[int] = None) -> Dict[str, Any]:
        """Get observed tasks from a session.
        
        Args:
            session_id: The Acontext session ID
            limit: Maximum tasks to return
            
        Returns:
            Dict with tasks list
        """
        try:
            client = self.get_client()
            if client is None:
                return {"tasks": [], "error": "Client not available"}
            
            result = client.sessions.get_tasks(session_id, limit=limit)
            tasks = []
            if hasattr(result, 'items'):
                for task in result.items:
                    tasks.append({
                        "id": getattr(task, 'id', ''),
                        "status": getattr(task, 'status', 'unknown'),
                        "data": getattr(task, 'data', {}),
                    })
            return {"tasks": tasks, "session_id": session_id}
        except Exception as e:
            logger.error(f"Get tasks error: {e}")
            return {"tasks": [], "error": str(e)}
    
    def get_learning_status(self, context: AcontextAgentContext) -> Dict[str, Any]:
        """Get learning status for a session.
        
        Args:
            context: Agent context with acontext_session_id
            
        Returns:
            Learning status with digested/pending counts
        """
        if not context.acontext_session_id:
            return {"space_digested_count": 0, "not_space_digested_count": 0}
        
        try:
            client = self.get_client()
            if client is None:
                return {"error": "Client not available"}
            
            status = client.sessions.get_learning_status(context.acontext_session_id)
            return status.model_dump() if hasattr(status, 'model_dump') else {}
        except Exception as e:
            logger.error(f"Get learning status error: {e}")
            return {"error": str(e)}
    
    def get_token_counts(self, session_id: str) -> Dict[str, int]:
        """Get token counts for a session.
        
        Args:
            session_id: The Acontext session ID
            
        Returns:
            Token counts dict
        """
        try:
            client = self.get_client()
            if client is None:
                return {"total_tokens": 0}
            
            result = client.sessions.get_token_counts(session_id)
            return result.model_dump() if hasattr(result, 'model_dump') else {}
        except Exception as e:
            logger.error(f"Get token counts error: {e}")
            return {"total_tokens": 0}
    
    # =========================================================================
    # File/Artifact Management (based on disk plugin)
    # =========================================================================
    
    def save_file(
        self,
        filename: str,
        content: str,
        path: str = "/",
        context: Optional[AcontextAgentContext] = None,
    ) -> Dict[str, Any]:
        """Save a file to artifact storage.
        
        Args:
            filename: Name of the file
            content: Text content of the file
            path: Directory path to save the file
            context: Optional agent context
            
        Returns:
            Result with file info
        """
        if not self._disk_plugin:
            return {"success": False, "error": "Disk plugin not enabled"}
        
        try:
            ctx = context or AcontextAgentContext(user_id="system")
            result = self._disk_plugin.upload_artifact(
                ctx,
                filename=filename,
                content=content.encode(),
                file_path=path,
            )
            return {"success": True, "file": f"{path}{filename}", "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def read_file(
        self,
        filename: str,
        path: str = "/",
        context: Optional[AcontextAgentContext] = None,
    ) -> Dict[str, Any]:
        """Read a file from artifact storage.
        
        Args:
            filename: Name of the file
            path: Directory path of the file
            context: Optional agent context
            
        Returns:
            Result with file content
        """
        if not self._disk_plugin:
            return {"success": False, "error": "Disk plugin not enabled"}
        
        try:
            ctx = context or AcontextAgentContext(user_id="system")
            result = self._disk_plugin.get_artifact(
                ctx,
                filename=filename,
                file_path=path,
            )
            if result and result.get("content"):
                return {
                    "success": True,
                    "file": f"{path}{filename}",
                    "content": result["content"].get("raw", ""),
                }
            return {"success": False, "error": f"File not found: {path}{filename}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_files(
        self,
        path: str = "/",
        context: Optional[AcontextAgentContext] = None,
    ) -> Dict[str, Any]:
        """List files in artifact storage.
        
        Args:
            path: Directory path to list
            context: Optional agent context
            
        Returns:
            Result with files list
        """
        if not self._disk_plugin:
            return {"success": False, "files": [], "error": "Disk plugin not enabled"}
        
        try:
            ctx = context or AcontextAgentContext(user_id="system")
            files = self._disk_plugin.list_artifacts(ctx, path=path)
            return {"success": True, "path": path, "files": files}
        except Exception as e:
            return {"success": False, "files": [], "error": str(e)}
    
    # =========================================================================
    # Space/Session/Disk Management (for direct API access)
    # =========================================================================
    
    def create_space(self) -> Dict[str, Any]:
        """Create a new skill learning space.
        
        Returns:
            Dict with space_id or error
        """
        try:
            client = self.get_client()
            if client is None:
                return {"success": False, "error": "Client not available"}
            
            space = client.spaces.create()
            return {"success": True, "space_id": space.id}
        except Exception as e:
            logger.error(f"Create space error: {e}")
            return {"success": False, "error": str(e)}
    
    def create_session(self, space_id: Optional[str] = None) -> Dict[str, Any]:
        """Create a new session, optionally attached to a space.
        
        Args:
            space_id: Optional space ID to attach the session to
            
        Returns:
            Dict with session_id or error
        """
        try:
            client = self.get_client()
            if client is None:
                return {"success": False, "error": "Client not available"}

            resolved_space_id = (
                space_id
                or self.config.default_space_id
                or os.getenv("ACONTEXT_DEFAULT_SPACE_ID")
                or (Path(".acontext_space_id").read_text().strip() if Path(".acontext_space_id").exists() else None)
            )

            if resolved_space_id is None:
                space = client.spaces.create()
                resolved_space_id = space.id
                self.config.default_space_id = resolved_space_id
                try:
                    Path(".acontext_space_id").write_text(resolved_space_id)
                except Exception:
                    pass

            session = client.sessions.create(space_id=resolved_space_id)
            return {"success": True, "session_id": session.id, "space_id": getattr(session, 'space_id', None)}
        except Exception as e:
            logger.error(f"Create session error: {e}")
            return {"success": False, "error": str(e)}
    
    def create_disk(self) -> Dict[str, Any]:
        """Create a new artifact storage disk.
        
        Returns:
            Dict with disk_id or error
        """
        try:
            client = self.get_client()
            if client is None:
                return {"success": False, "error": "Client not available"}
            
            disk = client.disks.create()
            return {"success": True, "disk_id": disk.id}
        except Exception as e:
            logger.error(f"Create disk error: {e}")
            return {"success": False, "error": str(e)}
    
    def send_message(
        self,
        session_id: str,
        message: Dict[str, Any],
        format: str = "openai",
    ) -> Dict[str, Any]:
        """Send a message to a session.
        
        Args:
            session_id: Session ID
            message: Message dict with role and content
            format: Message format ("openai" or "acontext")
            
        Returns:
            Result dict
        """
        try:
            client = self.get_client()
            if client is None:
                return {"success": False, "error": "Client not available"}
            
            client.sessions.send_message(session_id=session_id, blob=message, format=format)
            return {"success": True, "session_id": session_id}
        except Exception as e:
            logger.error(f"Send message error: {e}")
            return {"success": False, "error": str(e)}
    
    def get_session_learning_status(self, session_id: str) -> Dict[str, Any]:
        """Get learning status for a session by ID.
        
        Args:
            session_id: Session ID
            
        Returns:
            Learning status with digested/pending counts
        """
        try:
            client = self.get_client()
            if client is None:
                return {"error": "Client not available"}
            
            status = client.sessions.get_learning_status(session_id)
            return {
                "space_digested_count": getattr(status, 'space_digested_count', 0),
                "not_space_digested_count": getattr(status, 'not_space_digested_count', 0),
            }
        except Exception as e:
            logger.error(f"Get learning status error: {e}")
            return {"error": str(e)}
    
    def get_unconfirmed_experiences(self, space_id: str) -> Dict[str, Any]:
        """Get unconfirmed experiences from a space.
        
        Args:
            space_id: Space ID
            
        Returns:
            Dict with experiences list
        """
        try:
            client = self.get_client()
            if client is None:
                return {"success": False, "experiences": [], "error": "Client not available"}
            
            result = client.spaces.get_unconfirmed_experiences(space_id=space_id)
            experiences = []
            if hasattr(result, 'items'):
                for exp in result.items:
                    experiences.append({
                        "id": getattr(exp, 'id', ''),
                        "experience_data": getattr(exp, 'experience_data', {}),
                    })
            return {"success": True, "experiences": experiences}
        except Exception as e:
            logger.error(f"Get unconfirmed experiences error: {e}")
            return {"success": False, "experiences": [], "error": str(e)}
    
    def confirm_experience(
        self,
        space_id: str,
        experience_id: str,
        save: bool = True,
    ) -> Dict[str, Any]:
        """Confirm or reject an experience.
        
        Args:
            space_id: Space ID
            experience_id: Experience ID
            save: True to approve, False to reject
            
        Returns:
            Result dict
        """
        try:
            client = self.get_client()
            if client is None:
                return {"success": False, "error": "Client not available"}
            
            result = client.spaces.confirm_experience(
                space_id=space_id,
                experience_id=experience_id,
                save=save,
            )
            if result is None:
                return {"success": True, "approved": False, "message": "Experience rejected"}
            
            use_when = ""
            if hasattr(result, 'experience_data'):
                data = result.experience_data
                if isinstance(data, dict):
                    use_when = data.get("data", {}).get("use_when", "")
            
            return {"success": True, "approved": True, "use_when": use_when}
        except Exception as e:
            logger.error(f"Confirm experience error: {e}")
            return {"success": False, "error": str(e)}
    
    # =========================================================================
    # Disk Artifact Operations (direct client access)
    # =========================================================================
    
    def disk_write_file(
        self,
        disk_id: str,
        filename: str,
        content: str,
        file_path: str = "/",
    ) -> Dict[str, Any]:
        """Write a file to a specific disk.
        
        Args:
            disk_id: Disk ID
            filename: File name
            content: File content
            file_path: Directory path
            
        Returns:
            Result dict with artifact info
        """
        try:
            from acontext import FileUpload
            client = self.get_client()
            if client is None:
                return {"success": False, "error": "Client not available"}
            
            # Normalize path
            if not file_path.startswith("/"):
                file_path = f"/{file_path}"
            if not file_path.endswith("/"):
                file_path = f"{file_path}/"
            
            payload = FileUpload(filename=filename, content=content.encode("utf-8"))
            artifact = client.disks.artifacts.upsert(disk_id, file=payload, file_path=file_path)
            return {
                "success": True,
                "disk_id": disk_id,
                "path": artifact.path,
                "filename": artifact.filename,
            }
        except Exception as e:
            logger.error(f"Disk write file error: {e}")
            return {"success": False, "error": str(e)}
    
    def disk_read_file(
        self,
        disk_id: str,
        filename: str,
        file_path: str = "/",
        max_chars: int = 1200,
    ) -> Dict[str, Any]:
        """Read a file from a specific disk.
        
        Args:
            disk_id: Disk ID
            filename: File name
            file_path: Directory path
            max_chars: Maximum characters to return
            
        Returns:
            Result dict with file content
        """
        try:
            client = self.get_client()
            if client is None:
                return {"success": False, "error": "Client not available"}
            
            # Normalize path
            if not file_path.startswith("/"):
                file_path = f"/{file_path}"
            if not file_path.endswith("/"):
                file_path = f"{file_path}/"
            
            result = client.disks.artifacts.get(
                disk_id,
                file_path=file_path,
                filename=filename,
                with_public_url=True,
                with_content=True,
            )
            if not result.content:
                return {"success": False, "error": "File not found or empty"}
            
            raw = result.content.raw
            content_str = raw if isinstance(raw, str) else raw.decode("utf-8", errors="replace")
            preview = content_str[:max_chars]
            
            return {
                "success": True,
                "disk_id": disk_id,
                "path": file_path,
                "filename": filename,
                "content": preview,
                "truncated": len(content_str) > len(preview),
            }
        except Exception as e:
            logger.error(f"Disk read file error: {e}")
            return {"success": False, "error": str(e)}
    
    def disk_list_artifacts(
        self,
        disk_id: str,
        file_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List artifacts in a disk directory.
        
        Args:
            disk_id: Disk ID
            file_path: Directory path (optional)
            
        Returns:
            Result dict with artifacts list
        """
        try:
            client = self.get_client()
            if client is None:
                return {"success": False, "error": "Client not available"}
            
            # Normalize path if provided
            normalized_path = None
            if file_path:
                if not file_path.startswith("/"):
                    file_path = f"/{file_path}"
                if not file_path.endswith("/"):
                    file_path = f"{file_path}/"
                normalized_path = file_path
            
            result = client.disks.artifacts.list(disk_id, path=normalized_path)
            artifacts = [
                {
                    "filename": artifact.filename,
                    "path": artifact.path,
                    "meta": artifact.meta,
                }
                for artifact in result.artifacts
            ]
            return {
                "success": True,
                "disk_id": disk_id,
                "path": normalized_path or "/",
                "artifacts": artifacts,
                "directories": result.directories,
            }
        except Exception as e:
            logger.error(f"Disk list artifacts error: {e}")
            return {"success": False, "error": str(e)}
