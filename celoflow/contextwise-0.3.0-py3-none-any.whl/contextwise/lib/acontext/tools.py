"""Acontext Function Tools - LLM-callable tools for Acontext operations.

This module provides @function_tool decorated helpers that delegate to
AcontextPlugin methods, enabling LLMs to trigger learning flows, search
skills, and manage artifacts directly within conversations.

These tools are automatically registered with the agent when
AcontextPluginConfig.enable_tools is True.

Example usage in agent configuration:
    from contextwise import Agent
    from contextwise.lib.acontext import AcontextPlugin

    agent = Agent(
        model="gpt-4o-mini",
        instructions="You can search and learn skills",
        plugins=[AcontextPlugin(config=AcontextPluginConfig(enable_tools=True))]
    )

Tools available:
    - search_learned_skills: Search for learned skills/experiences
    - get_learning_status: Get current learning status for a session
    - trigger_learning: Trigger immediate learning from session buffer
    - write_artifact: Write a file to artifact storage
    - read_artifact: Read a file from artifact storage
    - list_artifacts: List files in artifact storage
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from agents import function_tool, RunContextWrapper

if TYPE_CHECKING:
    from .plugin import AcontextPlugin

logger = logging.getLogger(__name__)


def create_acontext_tools(plugin: "AcontextPlugin") -> List[Any]:
    """Create function tools for Acontext operations.

    These tools are registered with the agent when enable_tools is True
    in AcontextPluginConfig.

    Args:
        plugin: AcontextPlugin instance to delegate operations to

    Returns:
        List of function_tool decorated functions
    """

    @function_tool
    def search_learned_skills(
        ctx: RunContextWrapper[Any],
        query: str,
        limit: int = 5,
        mode: str = "fast",
    ) -> str:
        """Search for learned skills and experiences relevant to the query.

        Use this tool to find previously learned skills, procedures, and
        best practices that may help with the current task.

        Args:
            query: Natural language search query describing what you're looking for
            limit: Maximum number of results to return (1-50)
            mode: Search mode - "fast" for quick results or "agentic" for deeper search

        Returns:
            JSON string with matching skills including title, relevance score,
            and usage guidance. Returns a prompt with skill context if matches found.
        """
        try:
            result = plugin.search_skills_with_context(
                query=query,
                mode=mode,
                limit=limit,
                build_prompt=True,
            )
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            logger.error(f"search_learned_skills error: {e}")
            return json.dumps({"error": str(e), "skills": []})

    @function_tool
    def get_learning_status(
        ctx: RunContextWrapper[Any],
        session_id: Optional[str] = None,
    ) -> str:
        """Get the current learning status for a session.

        Use this to check how many messages have been processed and
        learned from in the current or specified session.

        Args:
            session_id: Optional session ID. If not provided, uses current context.

        Returns:
            JSON string with digested/pending message counts and learning state.
        """
        try:
            if session_id:
                result = plugin.get_session_learning_status(session_id)
            else:
                # Try to get from current context
                from .context import AcontextAgentContext
                context = AcontextAgentContext(user_id="current")
                result = plugin.get_learning_status(context)
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            logger.error(f"get_learning_status error: {e}")
            return json.dumps({"error": str(e)})

    @function_tool
    def trigger_learning(
        ctx: RunContextWrapper[Any],
        session_id: str,
    ) -> str:
        """Trigger immediate learning from the session buffer.

        Use this when you want to ensure recent interactions are
        immediately processed for learning instead of waiting for
        automatic batch processing.

        Args:
            session_id: The Acontext session ID to flush and learn from

        Returns:
            JSON string with flush result and any errors.
        """
        try:
            result = plugin.flush_session(session_id)
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            logger.error(f"trigger_learning error: {e}")
            return json.dumps({"success": False, "error": str(e)})

    @function_tool
    def write_artifact(
        ctx: RunContextWrapper[Any],
        filename: str,
        content: str,
        file_path: str = "/",
    ) -> str:
        """Write a file to Acontext artifact storage.

        Use this to save files, documents, or data that should persist
        across sessions and be accessible later.

        Args:
            filename: Name of the file to create/update
            content: Text content to write to the file
            file_path: Directory path where the file should be saved (default: root)

        Returns:
            JSON string with success status and file path.
        """
        try:
            result = plugin.save_file(
                filename=filename,
                content=content,
                path=file_path,
            )
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            logger.error(f"write_artifact error: {e}")
            return json.dumps({"success": False, "error": str(e)})

    @function_tool
    def read_artifact(
        ctx: RunContextWrapper[Any],
        filename: str,
        file_path: str = "/",
    ) -> str:
        """Read a file from Acontext artifact storage.

        Use this to retrieve previously saved files and documents.

        Args:
            filename: Name of the file to read
            file_path: Directory path where the file is located (default: root)

        Returns:
            JSON string with file content or error message.
        """
        try:
            result = plugin.read_file(
                filename=filename,
                path=file_path,
            )
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            logger.error(f"read_artifact error: {e}")
            return json.dumps({"success": False, "error": str(e)})

    @function_tool
    def list_artifacts(
        ctx: RunContextWrapper[Any],
        file_path: str = "/",
    ) -> str:
        """List files in Acontext artifact storage.

        Use this to see what files are available in a directory.

        Args:
            file_path: Directory path to list (default: root)

        Returns:
            JSON string with list of files and subdirectories.
        """
        try:
            result = plugin.list_files(path=file_path)
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            logger.error(f"list_artifacts error: {e}")
            return json.dumps({"success": False, "files": [], "error": str(e)})

    @function_tool
    def get_unconfirmed_experiences(
        ctx: RunContextWrapper[Any],
        space_id: Optional[str] = None,
    ) -> str:
        """Get unconfirmed experiences pending review.

        Use this to see what experiences are waiting for confirmation
        before being added to the knowledge base.

        Args:
            space_id: Optional space ID. Uses default space if not provided.

        Returns:
            JSON string with list of pending experiences.
        """
        try:
            if not space_id:
                space_id = plugin.get_or_create_skill_space()
            if not space_id:
                return json.dumps({"success": False, "error": "No space available"})
            result = plugin.get_unconfirmed_experiences(space_id)
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            logger.error(f"get_unconfirmed_experiences error: {e}")
            return json.dumps({"success": False, "experiences": [], "error": str(e)})

    @function_tool
    def confirm_experience(
        ctx: RunContextWrapper[Any],
        experience_id: str,
        save: bool = True,
        space_id: Optional[str] = None,
    ) -> str:
        """Confirm or reject a pending experience.

        Use this to approve (save=True) or reject (save=False) an
        experience that is pending review.

        Args:
            experience_id: The experience ID to confirm
            save: True to approve and save, False to reject
            space_id: Optional space ID. Uses default space if not provided.

        Returns:
            JSON string with confirmation result.
        """
        try:
            if not space_id:
                space_id = plugin.get_or_create_skill_space()
            if not space_id:
                return json.dumps({"success": False, "error": "No space available"})
            result = plugin.confirm_experience(
                space_id=space_id,
                experience_id=experience_id,
                save=save,
            )
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            logger.error(f"confirm_experience error: {e}")
            return json.dumps({"success": False, "error": str(e)})

    return [
        search_learned_skills,
        get_learning_status,
        trigger_learning,
        write_artifact,
        read_artifact,
        list_artifacts,
        get_unconfirmed_experiences,
        confirm_experience,
    ]
