"""Acontext disk plugin for artifact storage.

This module provides a plugin for storing and retrieving files
via Acontext Disks API, enabling persistent artifact storage.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from agents import Agent, function_tool

from ..base import AgentPlugin
from .context import AcontextAgentContext
from .client_plugin import AcontextClientPlugin

logger = logging.getLogger(__name__)


@dataclass
class AcontextDiskPlugin(AgentPlugin[AcontextAgentContext]):
    """Plugin for artifact storage via Acontext Disks.
    
    This plugin provides file storage capabilities, allowing agents
    to save and retrieve artifacts like documents and images.
    
    Attributes:
        id: Plugin identifier.
        name: Human-readable plugin name.
        version: Plugin version.
        client_plugin: Reference to the client plugin.
        default_disk_id: Default disk UUID for file storage.
    
    Example:
        >>> disk_plugin = AcontextDiskPlugin(
        ...     client_plugin=client_plugin,
        ...     default_disk_id="disk-uuid",
        ... )
    """
    
    # Plugin metadata
    id: str = "acontext-disk"
    name: str = "Acontext Disk Plugin"
    version: str = "1.0.0"
    
    # Dependencies
    client_plugin: Optional[AcontextClientPlugin] = None
    
    # Configuration
    default_disk_id: Optional[str] = None
    
    def dependencies(self) -> list[str]:
        """Return plugin IDs that must be loaded before this plugin.
        
        Returns:
            List containing client plugin ID.
        """
        return ["acontext-client"]
    
    def get_or_create_disk(
        self, 
        context: AcontextAgentContext,
    ) -> str:
        """Get or create a disk for artifact storage.
        
        Args:
            context: Agent context (can be AgentContext or AcontextAgentContext).
            
        Returns:
            Acontext disk UUID.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        # Get acontext_disk_id safely (may not exist on base AgentContext)
        context_disk_id = getattr(context, 'acontext_disk_id', None)
        disk_id = context_disk_id or self.default_disk_id
        
        if disk_id is None:
            try:
                disk = self.client_plugin.client.disks.create()
                disk_id = disk.id
                # Set acontext_disk_id if context supports it
                if hasattr(context, 'acontext_disk_id'):
                    context.acontext_disk_id = disk_id
                logger.info(f"Created Acontext disk: {disk_id}")
            except Exception as e:
                logger.error(f"Failed to create disk: {e}")
                raise
        
        return disk_id
    
    def upload_artifact(
        self,
        context: AcontextAgentContext,
        filename: str,
        content: bytes,
        file_path: str = "/",
    ) -> Dict[str, Any]:
        """Upload an artifact to disk.
        
        Args:
            context: Agent context.
            filename: Name of the file.
            content: File content as bytes.
            file_path: Directory path (default: root).
            
        Returns:
            Artifact metadata dict.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        disk_id = self.get_or_create_disk(context)
        
        try:
            # Import FileUpload from acontext
            from acontext import FileUpload
            
            file = FileUpload(filename=filename, content=content)
            artifact = self.client_plugin.client.disks.artifacts.upsert(
                disk_id,
                file=file,
                file_path=file_path,
            )
            logger.info(f"Uploaded artifact: {file_path}{filename}")
            return artifact.model_dump()
        except ImportError:
            raise ImportError("acontext package not installed")
        except Exception as e:
            logger.error(f"Failed to upload artifact: {e}")
            raise
    
    def get_artifact(
        self,
        context: AcontextAgentContext,
        filename: str,
        file_path: str = "/",
        with_content: bool = True,
    ) -> Optional[Dict[str, Any]]:
        """Get an artifact from disk.
        
        Args:
            context: Agent context.
            filename: Name of the file.
            file_path: Directory path (default: root).
            with_content: Include file content.
            
        Returns:
            Artifact metadata dict or None if not found.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        disk_id = self.get_or_create_disk(context)
        
        try:
            artifact = self.client_plugin.client.disks.artifacts.get(
                disk_id,
                file_path=file_path,
                filename=filename,
                with_content=with_content,
                with_public_url=True,
            )
            return artifact.model_dump()
        except Exception as e:
            logger.debug(f"Artifact not found: {file_path}{filename}")
            return None
    
    def list_artifacts(
        self,
        context: AcontextAgentContext,
        path: str = "/",
    ) -> List[Dict[str, Any]]:
        """List artifacts in a path.
        
        Args:
            context: Agent context.
            path: Directory path to list.
            
        Returns:
            List of artifact metadata dicts.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        disk_id = self.get_or_create_disk(context)
        
        try:
            result = self.client_plugin.client.disks.artifacts.list(
                disk_id,
                path=path,
            )
            # Handle different return types from the API
            if hasattr(result, 'artifacts'):
                artifacts = result.artifacts
            elif isinstance(result, (list, tuple)):
                artifacts = result
            else:
                artifacts = []
            
            # Convert to dicts safely
            artifact_dicts = []
            for a in artifacts:
                if hasattr(a, 'model_dump'):
                    artifact_dicts.append(a.model_dump())
                elif isinstance(a, dict):
                    artifact_dicts.append(a)
                else:
                    artifact_dicts.append({'filename': str(a)})
            return artifact_dicts
        except Exception as e:
            logger.error(f"Failed to list artifacts: {e}")
            return []
    
    def configure_agent(
        self, 
        agent: Agent[AcontextAgentContext],
    ) -> Agent[AcontextAgentContext]:
        """Add file management tools to agent.
        
        Args:
            agent: The agent to configure.
            
        Returns:
            Agent with file tools added.
        """
        plugin = self
        
        @function_tool
        def save_file(filename: str, content: str, path: str = "/") -> str:
            """Save a file to the artifact storage.
            
            Use this tool to persist files like documents, code,
            or other text content.
            
            Args:
                filename: Name of the file to save.
                content: Text content of the file.
                path: Directory path to save to (default: root).
                
            Returns:
                Confirmation message with file details.
            """
            try:
                plugin.upload_artifact(
                    AcontextAgentContext(user_id="system"),
                    filename=filename,
                    content=content.encode("utf-8"),
                    file_path=path,
                )
                return f"File saved: {path}{filename}"
            except Exception as e:
                return f"Error saving file: {e}"
        
        @function_tool
        def read_file(filename: str, path: str = "/") -> str:
            """Read a file from artifact storage.
            
            Use this tool to retrieve previously saved files.
            
            Args:
                filename: Name of the file to read.
                path: Directory path of the file (default: root).
                
            Returns:
                The file content or error message.
            """
            result = plugin.get_artifact(
                AcontextAgentContext(user_id="system"),
                filename=filename,
                file_path=path,
            )
            
            if result and result.get("content"):
                return result["content"].get("raw", "")
            return f"File not found: {path}{filename}"
        
        @function_tool
        def list_files(path: str = "/") -> str:
            """List files in a directory.
            
            Use this tool to see what files are available.
            
            Args:
                path: Directory path to list (default: root).
                
            Returns:
                List of filenames in the directory.
            """
            artifacts = plugin.list_artifacts(
                AcontextAgentContext(user_id="system"),
                path=path,
            )
            
            if not artifacts:
                return f"No files found in {path}"
            
            filenames = [a.get("filename", "unknown") for a in artifacts]
            return f"Files in {path}:\n" + "\n".join(f"- {f}" for f in filenames)
        
        # Add tools to agent
        existing_tools = list(agent.tools) if agent.tools else []
        existing_tools.extend([save_file, read_file, list_files])
        
        return agent.clone(tools=existing_tools)
