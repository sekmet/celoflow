"""Extended context with Acontext integration.

This module provides an extended agent context that includes
Acontext-specific fields for session, space, and disk management.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from ..context import AgentContext


@dataclass
class AcontextAgentContext(AgentContext):
    """Extended context with Acontext integration.
    
    This context extends the base AgentContext with fields for
    tracking Acontext resources like sessions, spaces, and disks.
    
    Attributes:
        user_id: Unique identifier for the user.
        channel: Communication channel (api, whatsapp, etc.).
        session_id: Local session identifier.
        locale: User's locale.
        metadata: Additional metadata.
        acontext_session_id: Acontext session UUID.
        acontext_space_id: Acontext space UUID for skill learning.
        acontext_disk_id: Acontext disk UUID for artifact storage.
        enable_learning: Whether to enable skill learning.
        enable_observation: Whether to enable task observation.
    
    Example:
        >>> context = AcontextAgentContext(
        ...     user_id="user123",
        ...     channel="whatsapp",
        ...     enable_learning=True,
        ... )
    """
    
    # Acontext-specific fields
    acontext_session_id: Optional[str] = None
    acontext_space_id: Optional[str] = None
    acontext_disk_id: Optional[str] = None
    enable_learning: bool = True
    enable_observation: bool = True
    
    def with_acontext_session(self, session_id: str) -> "AcontextAgentContext":
        """Create a new context with Acontext session ID.
        
        Args:
            session_id: Acontext session UUID.
            
        Returns:
            New context with session ID set.
        """
        return AcontextAgentContext(
            user_id=self.user_id,
            channel=self.channel,
            session_id=self.session_id,
            locale=self.locale,
            metadata=self.metadata,
            acontext_session_id=session_id,
            acontext_space_id=self.acontext_space_id,
            acontext_disk_id=self.acontext_disk_id,
            enable_learning=self.enable_learning,
            enable_observation=self.enable_observation,
        )
    
    def with_acontext_space(self, space_id: str) -> "AcontextAgentContext":
        """Create a new context with Acontext space ID.
        
        Args:
            space_id: Acontext space UUID.
            
        Returns:
            New context with space ID set.
        """
        return AcontextAgentContext(
            user_id=self.user_id,
            channel=self.channel,
            session_id=self.session_id,
            locale=self.locale,
            metadata=self.metadata,
            acontext_session_id=self.acontext_session_id,
            acontext_space_id=space_id,
            acontext_disk_id=self.acontext_disk_id,
            enable_learning=self.enable_learning,
            enable_observation=self.enable_observation,
        )
