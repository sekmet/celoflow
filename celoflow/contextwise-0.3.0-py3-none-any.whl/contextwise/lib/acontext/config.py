"""Configuration for Acontext integration.

This module provides configuration dataclasses for connecting to
the Acontext platform.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class AcontextConfig:
    """Configuration for Acontext integration.
    
    Attributes:
        api_key: Acontext API key (sk-ac-...).
        base_url: Acontext API base URL.
        timeout: Request timeout in seconds.
        enable_sessions: Enable session persistence.
        enable_spaces: Enable skill learning.
        enable_disks: Enable artifact storage.
        enable_observation: Enable task observation.
    
    Example:
        >>> config = AcontextConfig.from_env()
        >>> print(config.base_url)
        'http://localhost:8029/api/v1'
    """
    
    api_key: str = ""
    base_url: str = "http://localhost:8029/api/v1"
    timeout: float = 32.0
    enable_sessions: bool = True
    enable_spaces: bool = True
    enable_disks: bool = True
    enable_observation: bool = True
    
    @classmethod
    def from_env(cls) -> "AcontextConfig":
        """Load configuration from environment variables.
        
        Environment variables:
            - ACONTEXT_API_KEY: API key
            - ACONTEXT_BASE_URL: Base URL (default: http://localhost:8029/api/v1)
            - ACONTEXT_TIMEOUT: Request timeout (default: 32)
            - ACONTEXT_ENABLE_SESSIONS: Enable sessions (default: true)
            - ACONTEXT_ENABLE_SPACES: Enable spaces (default: true)
            - ACONTEXT_ENABLE_DISKS: Enable disks (default: true)
            - ACONTEXT_ENABLE_OBSERVATION: Enable observation (default: true)
        
        Returns:
            Configured AcontextConfig instance.
        """
        return cls(
            api_key=os.getenv("ACONTEXT_API_KEY", ""),
            base_url=os.getenv("ACONTEXT_BASE_URL", "http://localhost:8029/api/v1"),
            timeout=float(os.getenv("ACONTEXT_TIMEOUT", "32")),
            enable_sessions=os.getenv("ACONTEXT_ENABLE_SESSIONS", "true").lower() == "true",
            enable_spaces=os.getenv("ACONTEXT_ENABLE_SPACES", "true").lower() == "true",
            enable_disks=os.getenv("ACONTEXT_ENABLE_DISKS", "true").lower() == "true",
            enable_observation=os.getenv("ACONTEXT_ENABLE_OBSERVATION", "true").lower() == "true",
        )
    
    @property
    def is_configured(self) -> bool:
        """Check if Acontext is properly configured.
        
        Returns:
            True if API key is set.
        """
        return bool(self.api_key)
