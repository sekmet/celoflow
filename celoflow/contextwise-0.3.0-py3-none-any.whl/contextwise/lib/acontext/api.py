"""Acontext API Router - FastAPI endpoints for Acontext integration.

This module provides a reusable FastAPI router with all Acontext endpoints.
Use it with any FastAPI app to add Acontext-powered agent capabilities.

Example:
    from fastapi import FastAPI
    from contextwise.lib.acontext import create_acontext_router, AcontextPlugin
    
    app = FastAPI()
    plugin = AcontextPlugin()
    
    # Add all Acontext endpoints
    app.include_router(create_acontext_router(plugin), prefix="/api")
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

logger = logging.getLogger(__name__)


# =============================================================================
# Pydantic Models for API
# =============================================================================

class ChatRequest(BaseModel):
    """Request model for chat endpoint."""
    message: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    channel: str = "api"


class ChatResponse(BaseModel):
    """Response model for chat endpoint."""
    response: str
    session_id: str
    acontext_session_id: Optional[str] = None
    events: List[Dict[str, Any]] = []


class StatusResponse(BaseModel):
    """Response model for status endpoint."""
    status: str
    acontext_configured: bool
    acontext_base_url: str
    plugins_loaded: List[str]


class SkillSearchRequest(BaseModel):
    """Request model for skill search."""
    query: str
    mode: str = "fast"
    limit: int = 10
    build_prompt: bool = True
    semantic_threshold: Optional[float] = None
    max_iterations: Optional[int] = None
    space_id: Optional[str] = None


class SkillSearchResponse(BaseModel):
    """Response model for skill search."""
    skills: List[Dict[str, Any]]
    prompt: str = ""
    query: str
    space_id: Optional[str] = None
    error: Optional[str] = None


class LearnSkillRequest(BaseModel):
    """Request to learn a skill from a file."""
    file_path: str


class LearnAllSkillsRequest(BaseModel):
    """Request to learn all skills from a directory."""
    directory: str = "skills"


class RenameToolRequest(BaseModel):
    """Request to rename tools."""
    renames: List[Dict[str, str]]  # [{"old_name": "...", "new_name": "..."}]


class SaveFileRequest(BaseModel):
    """Request to save a file."""
    filename: str
    content: str
    path: str = "/"


class ReadFileRequest(BaseModel):
    """Request to read a file."""
    filename: str
    path: str = "/"


class ExperienceConfirmRequest(BaseModel):
    """Request to confirm or reject an experience."""
    space_id: Optional[str] = None
    save: bool = True


class LearningStatusResponse(BaseModel):
    """Response model for learning status."""
    session_id: Optional[str] = None
    space_id: Optional[str] = None
    space_digested_count: int = 0
    not_space_digested_count: int = 0
    error: Optional[str] = None


class ExperiencesResponse(BaseModel):
    """Response model for experiences list."""
    experiences: List[Dict[str, Any]] = []
    success: bool = True
    error: Optional[str] = None


class ExperienceConfirmResponse(BaseModel):
    """Response model for experience confirmation."""
    success: bool
    approved: Optional[bool] = None
    use_when: Optional[str] = None
    error: Optional[str] = None


# =============================================================================
# Router Factory
# =============================================================================

def create_acontext_router(plugin) -> APIRouter:
    """Create a FastAPI router with all Acontext endpoints.
    
    Args:
        plugin: AcontextPlugin instance
        
    Returns:
        Configured APIRouter with all endpoints
    """
    router = APIRouter(tags=["Acontext"])
    
    # =========================================================================
    # Status Endpoints
    # =========================================================================
    
    @router.get("/status", response_model=StatusResponse)
    async def get_status():
        """Get Acontext plugin status."""
        return StatusResponse(
            status="running",
            acontext_configured=plugin.config.is_configured,
            acontext_base_url=plugin.config.base_url or "",
            plugins_loaded=[p.id for p in plugin._plugins],
        )
    
    # =========================================================================
    # Skill Search Endpoints
    # =========================================================================
    
    @router.post("/skills/search", response_model=SkillSearchResponse)
    async def search_skills(request: SkillSearchRequest):
        """Search for learned skills.
        
        Supports both "fast" (embedding) and "agentic" (iterative) modes.
        """
        try:
            result = plugin.search_skills_with_context(
                query=request.query,
                mode=request.mode,
                limit=request.limit,
                build_prompt=request.build_prompt,
                semantic_threshold=request.semantic_threshold,
                max_iterations=request.max_iterations,
                space_id=request.space_id,
            )
            return SkillSearchResponse(**result)
        except Exception as e:
            logger.exception("Skill search error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.get("/skills/verify/{skill_name}")
    async def verify_skill(skill_name: str):
        """Verify a skill was learned by searching for it."""
        try:
            found = plugin.verify_skill_learned(skill_name)
            return {
                "skill_name": skill_name,
                "found": found,
                "status": "verified" if found else "not_found",
            }
        except Exception as e:
            logger.exception("Skill verification error")
            raise HTTPException(status_code=500, detail=str(e))
    
    # =========================================================================
    # Skill Learning Endpoints
    # =========================================================================
    
    @router.post("/skills/learn")
    async def learn_skill(request: LearnSkillRequest):
        """Learn a skill from a .txt file."""
        try:
            result = plugin.learn_skill_from_file(request.file_path)
            if result["success"]:
                return result
            raise HTTPException(status_code=400, detail=result["error"])
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Skill learning error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.post("/skills/learn-all")
    async def learn_all_skills(request: LearnAllSkillsRequest):
        """Learn all skills from a directory."""
        try:
            results = plugin.learn_all_skills_from_directory(request.directory)
            successful = sum(1 for r in results if r["success"])
            return {
                "total": len(results),
                "successful": successful,
                "failed": len(results) - successful,
                "results": results,
            }
        except Exception as e:
            logger.exception("Bulk skill learning error")
            raise HTTPException(status_code=500, detail=str(e))
    
    # =========================================================================
    # Tool Management Endpoints
    # =========================================================================
    
    @router.get("/tools")
    async def list_tools():
        """List all learned tools with SOP counts."""
        try:
            tools = plugin.get_learned_tools()
            return {"tools": tools, "count": len(tools)}
        except Exception as e:
            logger.exception("List tools error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.post("/tools/rename")
    async def rename_tools(request: RenameToolRequest):
        """Batch rename tools."""
        try:
            result = plugin.rename_tools(request.renames)
            if result["success"]:
                return {"status": "success", "renamed_count": len(request.renames)}
            raise HTTPException(status_code=400, detail=result["error"])
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Rename tools error")
            raise HTTPException(status_code=500, detail=str(e))
    
    # =========================================================================
    # Session Management Endpoints
    # =========================================================================
    
    @router.post("/sessions/{session_id}/flush")
    async def flush_session(session_id: str):
        """Force processing of session buffer."""
        try:
            result = plugin.flush_session(session_id)
            if result["success"]:
                return result
            raise HTTPException(status_code=400, detail=result["error"])
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Session flush error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.get("/sessions/{session_id}/tasks")
    async def get_tasks(session_id: str, limit: Optional[int] = None):
        """Get observed tasks from a session."""
        try:
            result = plugin.get_tasks(session_id, limit=limit)
            return result
        except Exception as e:
            logger.exception("Get tasks error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.get("/sessions/{session_id}/tokens")
    async def get_token_counts(session_id: str):
        """Get token counts for a session."""
        try:
            result = plugin.get_token_counts(session_id)
            return {"session_id": session_id, "tokens": result}
        except Exception as e:
            logger.exception("Get token counts error")
            raise HTTPException(status_code=500, detail=str(e))
    
    # =========================================================================
    # File Management Endpoints
    # =========================================================================
    
    @router.post("/files/save")
    async def save_file(request: SaveFileRequest):
        """Save a file to artifact storage."""
        try:
            result = plugin.save_file(
                filename=request.filename,
                content=request.content,
                path=request.path,
            )
            if result["success"]:
                return result
            raise HTTPException(status_code=400, detail=result["error"])
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Save file error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.post("/files/read")
    async def read_file(request: ReadFileRequest):
        """Read a file from artifact storage."""
        try:
            result = plugin.read_file(
                filename=request.filename,
                path=request.path,
            )
            if result["success"]:
                return result
            raise HTTPException(status_code=404, detail=result["error"])
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Read file error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.get("/files/list")
    async def list_files(path: str = "/"):
        """List files in artifact storage."""
        try:
            result = plugin.list_files(path=path)
            return result
        except Exception as e:
            logger.exception("List files error")
            raise HTTPException(status_code=500, detail=str(e))
    
    # =========================================================================
    # Experience Management Endpoints (LEVEL 3)
    # =========================================================================
    
    @router.get("/experiences", response_model=ExperiencesResponse)
    async def get_experiences(space_id: Optional[str] = None):
        """Get unconfirmed experiences from a space.
        
        If space_id is not provided, uses the default/auto-created space.
        """
        try:
            if not space_id:
                space_id = plugin.get_or_create_skill_space()
            if not space_id:
                return ExperiencesResponse(
                    success=False,
                    error="No space available"
                )
            result = plugin.get_unconfirmed_experiences(space_id)
            return ExperiencesResponse(**result)
        except Exception as e:
            logger.exception("Get experiences error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.post("/experiences/{experience_id}/confirm", response_model=ExperienceConfirmResponse)
    async def confirm_experience_endpoint(
        experience_id: str,
        request: Optional[ExperienceConfirmRequest] = None,
    ):
        """Confirm (approve) an experience.
        
        Approves the experience and adds it to the knowledge base.
        """
        try:
            req = request or ExperienceConfirmRequest()
            space_id = req.space_id or plugin.get_or_create_skill_space()
            if not space_id:
                return ExperienceConfirmResponse(
                    success=False,
                    error="No space available"
                )
            result = plugin.confirm_experience(
                space_id=space_id,
                experience_id=experience_id,
                save=True,
            )
            return ExperienceConfirmResponse(**result)
        except Exception as e:
            logger.exception("Confirm experience error")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.post("/experiences/{experience_id}/reject", response_model=ExperienceConfirmResponse)
    async def reject_experience_endpoint(
        experience_id: str,
        request: Optional[ExperienceConfirmRequest] = None,
    ):
        """Reject an experience.
        
        Rejects the experience and removes it from the pending queue.
        """
        try:
            req = request or ExperienceConfirmRequest()
            space_id = req.space_id or plugin.get_or_create_skill_space()
            if not space_id:
                return ExperienceConfirmResponse(
                    success=False,
                    error="No space available"
                )
            result = plugin.confirm_experience(
                space_id=space_id,
                experience_id=experience_id,
                save=False,
            )
            return ExperienceConfirmResponse(**result)
        except Exception as e:
            logger.exception("Reject experience error")
            raise HTTPException(status_code=500, detail=str(e))
    
    # =========================================================================
    # Learning Status Endpoints (LEVEL 3)
    # =========================================================================
    
    @router.get("/learning-status", response_model=LearningStatusResponse)
    async def get_learning_status(
        session_id: Optional[str] = None,
        space_id: Optional[str] = None,
    ):
        """Get learning status for a session.
        
        Returns counts of digested and pending messages in the session.
        """
        try:
            if session_id:
                result = plugin.get_session_learning_status(session_id)
                return LearningStatusResponse(
                    session_id=session_id,
                    space_id=space_id,
                    **result,
                )
            else:
                # Use default context
                from .context import AcontextAgentContext
                context = AcontextAgentContext(user_id="api")
                result = plugin.get_learning_status(context)
                return LearningStatusResponse(
                    space_id=space_id,
                    **result,
                )
        except Exception as e:
            logger.exception("Get learning status error")
            raise HTTPException(status_code=500, detail=str(e))
    
    return router
