"""Acontext space plugin for skill learning.

This module provides a plugin for searching and learning skills
via Acontext Spaces API, enabling self-learning agents.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from agents import Agent, function_tool

from ..base import AgentPlugin
from .context import AcontextAgentContext
from .client_plugin import AcontextClientPlugin

logger = logging.getLogger(__name__)


@dataclass
class AcontextSpacePlugin(AgentPlugin[AcontextAgentContext]):
    """Plugin for skill learning and experience search via Acontext Spaces.
    
    This plugin provides access to learned skills and experiences,
    enabling agents to retrieve relevant SOPs and preferences.
    
    Attributes:
        id: Plugin identifier.
        name: Human-readable plugin name.
        version: Plugin version.
        client_plugin: Reference to the client plugin.
        default_space_id: Default space UUID for skill storage.
        search_mode: Search mode (fast or agentic).
        enable_auto_learning: Enable automatic skill learning.
    
    Example:
        >>> space_plugin = AcontextSpacePlugin(
        ...     client_plugin=client_plugin,
        ...     default_space_id="space-uuid",
        ... )
    """
    
    # Plugin metadata
    id: str = "acontext-space"
    name: str = "Acontext Space Plugin"
    version: str = "1.0.0"
    
    # Dependencies
    client_plugin: Optional[AcontextClientPlugin] = None
    
    # Configuration
    default_space_id: Optional[str] = None
    search_mode: str = "fast"  # "fast" or "agentic"
    enable_auto_learning: bool = True
    
    def dependencies(self) -> list[str]:
        """Return plugin IDs that must be loaded before this plugin.
        
        Returns:
            List containing client plugin ID.
        """
        return ["acontext-client"]
    
    def get_or_create_space(
        self, 
        context: AcontextAgentContext,
    ) -> str:
        """Get or create a space for skill learning.
        
        Args:
            context: Agent context (can be AgentContext or AcontextAgentContext).
            
        Returns:
            Acontext space UUID.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        # Get acontext_space_id safely (may not exist on base AgentContext)
        context_space_id = getattr(context, 'acontext_space_id', None)
        space_id = context_space_id or self.default_space_id

        if space_id is None:
            env_space_id = os.getenv("ACONTEXT_DEFAULT_SPACE_ID")
            if env_space_id:
                space_id = env_space_id

        if space_id is None:
            try:
                space_file = Path(".acontext_space_id")
                if space_file.exists():
                    file_space_id = space_file.read_text().strip()
                    if file_space_id:
                        space_id = file_space_id
            except Exception:
                pass
        
        if space_id is None:
            try:
                space = self.client_plugin.client.spaces.create()
                space_id = space.id
                try:
                    Path(".acontext_space_id").write_text(space_id)
                except Exception:
                    pass
                # Set acontext_space_id if context supports it
                if hasattr(context, 'acontext_space_id'):
                    context.acontext_space_id = space_id
                logger.info(f"Created Acontext space: {space_id}")
            except Exception as e:
                logger.error(f"Failed to create space: {e}")
                raise
        
        return space_id
    
    def search_skills(
        self,
        context: AcontextAgentContext,
        query: str,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Search for relevant skills based on query.
        
        Args:
            context: Agent context.
            query: Search query describing the task.
            limit: Maximum number of results.
            
        Returns:
            List of skill dictionaries.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        space_id = self.get_or_create_space(context)
        
        try:
            result = self.client_plugin.client.spaces.experience_search(
                space_id=space_id,
                query=query,
                limit=limit,
                mode=self.search_mode,
            )
            return [block.model_dump() for block in result.cited_blocks]
        except Exception as e:
            logger.error(f"Failed to search skills: {e}")
            return []
    
    def get_learning_status(
        self,
        context: AcontextAgentContext,
    ) -> Dict[str, int]:
        """Get learning status for the session.
        
        Args:
            context: Agent context.
            
        Returns:
            Dict with digested/not digested counts.
        """
        if not self.client_plugin or not context.acontext_session_id:
            return {"space_digested_count": 0, "not_space_digested_count": 0}
        
        try:
            status = self.client_plugin.client.sessions.get_learning_status(
                context.acontext_session_id
            )
            return status.model_dump()
        except Exception as e:
            logger.error(f"Failed to get learning status: {e}")
            return {"space_digested_count": 0, "not_space_digested_count": 0}
    
    def configure_agent(
        self, 
        agent: Agent[AcontextAgentContext],
    ) -> Agent[AcontextAgentContext]:
        """Add skill search tool to agent.
        
        Args:
            agent: The agent to configure.
            
        Returns:
            Agent with skill search tool added.
        """
        plugin = self
        
        @function_tool
        def search_skills(query: str) -> str:
            """Search for relevant skills and SOPs based on the query.
            
            Use this tool to find learned procedures and preferences
            for completing tasks.
            
            Args:
                query: The task or action to search skills for.
                
            Returns:
                A formatted list of relevant skills and SOPs.
            """
            skills = plugin.search_skills(
                AcontextAgentContext(user_id="system"),
                query,
            )
            
            if not skills:
                return "No relevant skills found."
            
            result_parts = []
            for skill in skills:
                part = f"**Skill**: {skill.get('use_when', 'N/A')}\n"
                part += f"**Preferences**: {skill.get('preferences', 'N/A')}\n"
                sops = skill.get('tool_sops', [])
                if sops:
                    part += f"**Steps**: {', '.join(sops)}"
                result_parts.append(part)
            
            return "\n\n---\n\n".join(result_parts)
        
        # Add tool to agent
        existing_tools = list(agent.tools) if agent.tools else []
        existing_tools.append(search_skills)
        
        return agent.clone(tools=existing_tools)
