"""Acontext observe plugin for task tracking.

This module provides a plugin for observing and tracking agent
tasks via Acontext, enabling performance analytics.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from agents import Agent

from ..base import AgentPlugin
from .context import AcontextAgentContext
from .client_plugin import AcontextClientPlugin
from .session_plugin import AcontextSessionPlugin

logger = logging.getLogger(__name__)


@dataclass
class AcontextObservePlugin(AgentPlugin[AcontextAgentContext]):
    """Plugin for task observation and tracking.
    
    This plugin tracks agent tasks and provides analytics on
    agent performance and task completion.
    
    Attributes:
        id: Plugin identifier.
        name: Human-readable plugin name.
        version: Plugin version.
        client_plugin: Reference to the client plugin.
        session_plugin: Reference to the session plugin.
        auto_flush: Automatically flush after each run.
    
    Example:
        >>> observe_plugin = AcontextObservePlugin(
        ...     client_plugin=client_plugin,
        ...     session_plugin=session_plugin,
        ...     auto_flush=True,
        ... )
    """
    
    # Plugin metadata
    id: str = "acontext-observe"
    name: str = "Acontext Observe Plugin"
    version: str = "1.0.0"
    
    # Dependencies
    client_plugin: Optional[AcontextClientPlugin] = None
    session_plugin: Optional[AcontextSessionPlugin] = None
    
    # Configuration
    auto_flush: bool = False
    
    def dependencies(self) -> list[str]:
        """Return plugin IDs that must be loaded before this plugin.
        
        Returns:
            List containing client and session plugin IDs.
        """
        return ["acontext-client", "acontext-session"]
    
    def get_tasks(
        self,
        context: AcontextAgentContext,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Get observed tasks from session.
        
        Args:
            context: Agent context.
            limit: Maximum number of tasks to retrieve.
            
        Returns:
            List of task dictionaries.
        """
        if not self.client_plugin or not context.acontext_session_id:
            return []
        
        try:
            result = self.client_plugin.client.sessions.get_tasks(
                context.acontext_session_id,
                limit=limit,
            )
            return [task.model_dump() for task in result.items]
        except Exception as e:
            logger.error(f"Failed to get tasks: {e}")
            return []
    
    def flush_session(
        self,
        context: AcontextAgentContext,
    ) -> Dict[str, str]:
        """Flush session to trigger task extraction.
        
        Args:
            context: Agent context.
            
        Returns:
            Status dict.
        """
        if not self.client_plugin or not context.acontext_session_id:
            return {"status": "no_session"}
        
        try:
            return self.client_plugin.client.sessions.flush(
                context.acontext_session_id
            )
        except Exception as e:
            logger.error(f"Failed to flush session: {e}")
            return {"status": "error", "error": str(e)}
    
    def get_token_counts(
        self,
        context: AcontextAgentContext,
    ) -> Dict[str, int]:
        """Get token counts for session.
        
        Args:
            context: Agent context.
            
        Returns:
            Dict with token counts.
        """
        if not self.client_plugin or not context.acontext_session_id:
            return {"total_tokens": 0}
        
        try:
            result = self.client_plugin.client.sessions.get_token_counts(
                context.acontext_session_id
            )
            return result.model_dump()
        except Exception as e:
            logger.error(f"Failed to get token counts: {e}")
            return {"total_tokens": 0}
    
    def on_after_run(
        self, 
        context: AcontextAgentContext, 
        result: Any,
    ) -> None:
        """Optionally flush after each run.
        
        Args:
            context: Agent context.
            result: Run result.
        """
        if self.auto_flush and context.acontext_session_id:
            try:
                self.flush_session(context)
                logger.debug("Session flushed after run")
            except Exception as e:
                logger.warning(f"Failed to flush session: {e}")
    
    def configure_agent(
        self, 
        agent: Agent[AcontextAgentContext],
    ) -> Agent[AcontextAgentContext]:
        """Configure agent (no-op for observe plugin).
        
        Args:
            agent: The agent to configure.
            
        Returns:
            Unchanged agent.
        """
        return agent
