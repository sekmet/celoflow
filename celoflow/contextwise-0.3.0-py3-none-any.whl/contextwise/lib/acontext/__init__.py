"""Acontext integration for contextwise.

This module provides plugins for integrating the Acontext context
management platform with the contextwise agent framework.

Features:
    - Persistent session storage via Acontext Sessions API
    - Skill learning and experience search via Spaces API
    - Artifact storage via Disks API
    - Task observation and tracking
    - Function tools for LLM-driven learning and artifact management (LEVEL 3)
    - Experience confirmation and learning status endpoints

Simple Usage (recommended - unified Agent pattern):
    ```python
    from contextwise import Agent
    from contextwise.lib.acontext import AcontextPlugin
    
    # Create agent with Acontext integration
    agent = Agent(
        model="gpt-4o-mini",
        instructions="You can search and learn skills",
        plugins=[AcontextPlugin.from_env()],
    )
    ```

Advanced Usage:
    ```python
    from contextwise.lib.acontext import AcontextPluginBundle, AcontextPluginConfig
    
    # Create with custom config
    plugin = AcontextPlugin(
        config=AcontextPluginConfig(
            enable_tools=True,
            enable_spaces=True,
        )
    )
    
    # Or create all Acontext plugins manually
    bundle = AcontextPluginBundle(api_key="sk-ac-...")
    plugins = bundle.create_plugins()
    ```

Legacy Usage (AgentBuilder - still supported):
    ```python
    from contextwise import AgentBuilder
    from contextwise.lib.acontext import AcontextPlugin
    
    builder = AgentBuilder(name="My Assistant", model="gpt-4o-mini")
    builder.add_plugin(AcontextPlugin())
    agent = builder.build()
    ```
"""

from .config import AcontextConfig
from .context import AcontextAgentContext
from .plugin import AcontextPlugin, AcontextPluginConfig
from .api import create_acontext_router
from .client_plugin import AcontextClientPlugin
from .session_plugin import AcontextSessionPlugin
from .space_plugin import AcontextSpacePlugin
from .disk_plugin import AcontextDiskPlugin
from .observe_plugin import AcontextObservePlugin
from .bundle import AcontextPluginBundle
from .tools import create_acontext_tools

__all__ = [
    # Unified Plugin (recommended)
    "AcontextPlugin",
    "AcontextPluginConfig",
    # API Router
    "create_acontext_router",
    # Function Tools (LEVEL 3)
    "create_acontext_tools",
    # Configuration
    "AcontextConfig",
    "AcontextAgentContext",
    # Individual Plugins (advanced)
    "AcontextClientPlugin",
    "AcontextSessionPlugin",
    "AcontextSpacePlugin",
    "AcontextDiskPlugin",
    "AcontextObservePlugin",
    # Bundle (advanced)
    "AcontextPluginBundle",
]
