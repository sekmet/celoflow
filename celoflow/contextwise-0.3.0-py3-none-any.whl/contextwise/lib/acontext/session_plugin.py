"""Acontext session plugin for persistent context storage.

This module provides a plugin for storing conversation context
in Acontext sessions, enabling persistent memory across restarts.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from agents import Agent

from ..base import AgentPlugin
from .context import AcontextAgentContext
from .client_plugin import AcontextClientPlugin

logger = logging.getLogger(__name__)


@dataclass
class AcontextSessionPlugin(AgentPlugin[AcontextAgentContext]):
    """Plugin for persistent session storage via Acontext.
    
    This plugin stores conversation messages in Acontext sessions,
    providing persistent memory that survives application restarts.
    
    Attributes:
        id: Plugin identifier.
        name: Human-readable plugin name.
        version: Plugin version.
        client_plugin: Reference to the client plugin.
        message_format: Message format (openai, anthropic, acontext).
    
    Example:
        >>> client_plugin = AcontextClientPlugin(api_key="sk-ac-...")
        >>> session_plugin = AcontextSessionPlugin(
        ...     client_plugin=client_plugin,
        ... )
    """
    
    # Plugin metadata
    id: str = "acontext-session"
    name: str = "Acontext Session Plugin"
    version: str = "1.0.0"
    
    # Dependencies
    client_plugin: Optional[AcontextClientPlugin] = None
    
    # Configuration
    message_format: str = "openai"  # "openai", "anthropic", "acontext"
    default_space_id: Optional[str] = None
    
    # Internal cache
    _session_cache: Dict[str, str] = field(default_factory=dict, repr=False)
    
    def dependencies(self) -> list[str]:
        """Return plugin IDs that must be loaded before this plugin.
        
        Returns:
            List containing client plugin ID.
        """
        return ["acontext-client"]
    
    def get_or_create_session(
        self, 
        context: AcontextAgentContext,
        space_id: Optional[str] = None,
    ) -> str:
        """Get existing or create new Acontext session.
        
        Args:
            context: Agent context (can be AgentContext or AcontextAgentContext).
            space_id: Optional space ID to associate with session.
            
        Returns:
            Acontext session UUID.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        cache_key = context.session_id or context.user_id
        
        # Return cached session if available
        if cache_key in self._session_cache:
            return self._session_cache[cache_key]
        
        # Get acontext_space_id safely (may not exist on base AgentContext)
        context_space_id = getattr(context, 'acontext_space_id', None)
        resolved_space_id = space_id or context_space_id or self.default_space_id
        if resolved_space_id is None:
            env_space_id = os.getenv("ACONTEXT_DEFAULT_SPACE_ID")
            if env_space_id:
                resolved_space_id = env_space_id

        if resolved_space_id is None:
            space_file = Path(".acontext_space_id")
            if space_file.exists():
                file_space_id = space_file.read_text().strip()
                if file_space_id:
                    resolved_space_id = file_space_id

        if resolved_space_id is None:
            space = self.client_plugin.client.spaces.create()
            resolved_space_id = space.id
            try:
                Path(".acontext_space_id").write_text(resolved_space_id)
            except Exception:
                pass

        if resolved_space_id is None:
            raise ValueError("No default_space_id available for Acontext session")

        if hasattr(context, 'acontext_space_id'):
            context.acontext_space_id = resolved_space_id
        
        # Create new session
        try:
            session = self.client_plugin.client.sessions.create(
                space_id=resolved_space_id,
                configs={
                    "user_id": context.user_id,
                    "channel": context.channel,
                    "locale": getattr(context, 'locale', None),
                },
            )
            
            self._session_cache[cache_key] = session.id
            # Set acontext_session_id if context supports it
            if hasattr(context, 'acontext_session_id'):
                context.acontext_session_id = session.id
            logger.info(f"Created Acontext session: {session.id}")
            return session.id
            
        except Exception as e:
            logger.error(f"Failed to create Acontext session: {e}")
            raise
    
    def send_message(
        self,
        context: AcontextAgentContext,
        message: Dict[str, Any],
    ) -> None:
        """Send a message to Acontext session.
        
        Args:
            context: Agent context.
            message: Message dict with role and content.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        session_id = self.get_or_create_session(context)
        
        try:
            self.client_plugin.client.sessions.send_message(
                session_id=session_id,
                blob=message,
                format=self.message_format,
            )
            logger.debug(f"Sent message to session {session_id}")
        except Exception as e:
            logger.error(f"Failed to send message: {e}")
            raise
    
    def get_messages(
        self,
        context: AcontextAgentContext,
        limit: Optional[int] = None,
    ) -> List[Any]:
        """Get messages from Acontext session.
        
        Args:
            context: Agent context.
            limit: Maximum number of messages to retrieve.
            
        Returns:
            List of message objects.
        """
        if not self.client_plugin:
            raise ValueError("Client plugin not configured")
        
        session_id = self.get_or_create_session(context)
        
        try:
            result = self.client_plugin.client.sessions.get_messages(
                session_id=session_id,
                limit=limit,
                format=self.message_format,
            )
            return result.items
        except Exception as e:
            logger.error(f"Failed to get messages: {e}")
            return []
    
    def on_before_run(
        self, 
        context: AcontextAgentContext, 
        input_text: str,
    ) -> None:
        """Store user message before agent run.
        
        Args:
            context: Agent context.
            input_text: User's input message.
        """
        try:
            self.send_message(context, {
                "role": "user",
                "content": input_text,
            })
        except Exception as e:
            logger.warning(f"Failed to store user message: {e}")
    
    def on_after_run(
        self, 
        context: AcontextAgentContext, 
        result: Any,
    ) -> None:
        """Store assistant response after agent run.
        
        Args:
            context: Agent context.
            result: Run result with final_output.
        """
        if hasattr(result, "final_output") and result.final_output:
            try:
                self.send_message(context, {
                    "role": "assistant",
                    "content": result.final_output,
                })
            except Exception as e:
                logger.warning(f"Failed to store assistant message: {e}")
    
    def configure_agent(
        self, 
        agent: Agent[AcontextAgentContext],
    ) -> Agent[AcontextAgentContext]:
        """Configure agent (no-op for session plugin).
        
        Args:
            agent: The agent to configure.
            
        Returns:
            Unchanged agent.
        """
        return agent
    
    def clear_cache(self) -> None:
        """Clear the session cache."""
        self._session_cache.clear()
        logger.info("Session cache cleared")
