"""Acontext client plugin for contextwise.

This module provides the core plugin that manages the Acontext
client connection. Other Acontext plugins depend on this plugin.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Optional, TYPE_CHECKING

from agents import Agent

from ..base import AgentPlugin
from .context import AcontextAgentContext
from .config import AcontextConfig

if TYPE_CHECKING:
    # Import only for type checking to avoid circular imports
    # The actual import happens at runtime when needed
    pass

logger = logging.getLogger(__name__)


@dataclass
class AcontextClientPlugin(AgentPlugin[AcontextAgentContext]):
    """Plugin that manages Acontext client connection.
    
    This plugin provides the core Acontext client that other
    plugins use to communicate with the Acontext platform.
    
    Attributes:
        id: Plugin identifier.
        name: Human-readable plugin name.
        version: Plugin version.
        api_key: Acontext API key.
        base_url: Acontext API base URL.
        timeout: Request timeout in seconds.
    
    Example:
        >>> plugin = AcontextClientPlugin(
        ...     api_key="sk-ac-...",
        ...     base_url="http://localhost:8029/api/v1",
        ... )
        >>> client = plugin.client
    """
    
    # Plugin metadata
    id: str = "acontext-client"
    name: str = "Acontext Client Plugin"
    version: str = "1.0.0"
    
    # Configuration
    api_key: str = ""
    base_url: str = "http://localhost:8029/api/v1"
    timeout: float = 32.0
    
    # Internal client (lazy initialized)
    _client: Optional[Any] = field(default=None, repr=False)
    
    @classmethod
    def from_config(cls, config: AcontextConfig) -> "AcontextClientPlugin":
        """Create plugin from configuration.
        
        Args:
            config: Acontext configuration.
            
        Returns:
            Configured plugin instance.
        """
        return cls(
            api_key=config.api_key,
            base_url=config.base_url,
            timeout=config.timeout,
        )
    
    @classmethod
    def from_env(cls) -> "AcontextClientPlugin":
        """Create plugin from environment variables.
        
        Returns:
            Configured plugin instance.
        """
        return cls.from_config(AcontextConfig.from_env())
    
    @property
    def client(self) -> Any:
        """Get the Acontext client (lazy initialization).
        
        Returns:
            AcontextClient instance.
            
        Raises:
            ImportError: If acontext package is not installed.
            ValueError: If API key is not configured.
        """
        if self._client is None:
            if not self.api_key:
                raise ValueError(
                    "Acontext API key not configured. "
                    "Set ACONTEXT_API_KEY environment variable or pass api_key parameter."
                )
            
            try:
                from acontext import AcontextClient
                
                self._client = AcontextClient(
                    api_key=self.api_key,
                    base_url=self.base_url,
                    timeout=self.timeout,
                )
                logger.info(f"Acontext client initialized: {self.base_url}")
            except ImportError:
                raise ImportError(
                    "acontext package not installed. "
                    "Install with: uv add acontext"
                )
        
        return self._client
    
    @property
    def is_configured(self) -> bool:
        """Check if the plugin is properly configured.
        
        Returns:
            True if API key is set.
        """
        return bool(self.api_key)
    
    def dependencies(self) -> list[str]:
        """Return plugin IDs that must be loaded before this plugin.
        
        Returns:
            Empty list (no dependencies).
        """
        return []
    
    def configure_agent(
        self, 
        agent: Agent[AcontextAgentContext],
    ) -> Agent[AcontextAgentContext]:
        """Configure agent (no-op for client plugin).
        
        Args:
            agent: The agent to configure.
            
        Returns:
            Unchanged agent.
        """
        return agent
    
    def close(self) -> None:
        """Close the Acontext client connection.
        
        Releases resources held by the client.
        """
        if self._client is not None:
            try:
                self._client.close()
            except Exception as e:
                logger.warning(f"Error closing Acontext client: {e}")
            finally:
                self._client = None
                logger.info("Acontext client closed")
    
    def __del__(self) -> None:
        """Cleanup on garbage collection."""
        self.close()
