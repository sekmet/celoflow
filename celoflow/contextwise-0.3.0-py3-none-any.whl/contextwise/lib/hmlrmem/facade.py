"""HMLR Memory Facade.

This module acts as the bridge between ContextWise and the HMLR system.
It encapsulates the complexity of the HMLR component graph and exposes
simple, task-oriented methods for the plugin to use.

Phase 4 Enhancement: Proper keyword extraction, embedding-based retrieval,
and semantic search integration.
"""

import logging
import asyncio
import os
import re
from typing import Optional, Dict, Any, List, Set, Tuple
from functools import lru_cache

# Core HMLR imports
from .core.component_factory import ComponentBundle, ComponentFactory
from .memory.models import ConversationTurn, Intent, QueryType, RetrievedContext

from .models import HMLRMemoryConfig

logger = logging.getLogger(__name__)


# =============================================================================
# Keyword Extraction Utilities
# =============================================================================
_SPANISH_STOPWORDS: Set[str] = frozenset([
    "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "al",
    "a", "en", "con", "por", "para", "y", "o", "que", "es", "son", "se",
    "su", "sus", "mi", "mis", "tu", "tus", "me", "te", "le", "lo", "nos",
    "les", "esto", "esta", "estos", "estas", "ese", "esa", "esos", "esas",
    "como", "pero", "si", "no", "muy", "ya", "solo", "hay", "ser", "estar",
    "haber", "tener", "hacer", "poder", "querer", "deber", "saber", "ir",
    "ver", "dar", "decir", "venir", "pasar", "poner", "llegar", "creer",
])

_ENGLISH_STOPWORDS: Set[str] = frozenset([
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "must", "shall", "can", "need", "dare",
    "to", "of", "in", "for", "on", "with", "at", "by", "from", "as",
    "into", "through", "during", "before", "after", "above", "below",
    "between", "under", "again", "further", "then", "once", "here",
    "there", "when", "where", "why", "how", "all", "each", "few", "more",
    "most", "other", "some", "such", "no", "nor", "not", "only", "own",
    "same", "so", "than", "too", "very", "just", "and", "but", "if", "or",
    "because", "until", "while", "about", "against", "both", "over",
    "this", "that", "these", "those", "i", "me", "my", "we", "our", "you",
    "your", "he", "him", "his", "she", "her", "it", "its", "they", "them",
])

_ALL_STOPWORDS: Set[str] = _SPANISH_STOPWORDS | _ENGLISH_STOPWORDS

# Pre-compiled regex for word extraction
_WORD_PATTERN = re.compile(r'\b[a-záéíóúüñ]+\b', re.IGNORECASE)


def extract_keywords(text: str, min_length: int = 3, max_keywords: int = 10) -> List[str]:
    """Extract meaningful keywords from text.
    
    Removes stopwords and short words, returns unique keywords.
    
    Args:
        text: Input text to extract keywords from.
        min_length: Minimum word length to consider.
        max_keywords: Maximum number of keywords to return.
    
    Returns:
        List of extracted keywords.
    """
    if not text:
        return []
    
    # Extract words using regex
    words = _WORD_PATTERN.findall(text.lower())
    
    # Filter stopwords and short words
    keywords = [
        word for word in words 
        if word not in _ALL_STOPWORDS and len(word) >= min_length
    ]
    
    # Remove duplicates while preserving order
    seen = set()
    unique_keywords = []
    for kw in keywords:
        if kw not in seen:
            seen.add(kw)
            unique_keywords.append(kw)
            if len(unique_keywords) >= max_keywords:
                break
    
    return unique_keywords


@lru_cache(maxsize=100)
def extract_keywords_cached(text: str) -> Tuple[str, ...]:
    """Cached keyword extraction (returns tuple for hashability)."""
    return tuple(extract_keywords(text))


def classify_query_type(message: str) -> QueryType:
    """Classify the query type based on message content.
    
    Args:
        message: User message to classify.
    
    Returns:
        QueryType enum value.
    """
    message_lower = message.lower()
    
    # Task creation queries
    task_request_keywords = ["crear", "nueva tarea", "agregar", "añadir", "create task", "add task", "new task"]
    if any(kw in message_lower for kw in task_request_keywords):
        return QueryType.TASK_REQUEST
    
    # Task update/check queries
    task_update_keywords = ["actualizar", "completar", "marcar", "update task", "complete task", "check task", "tarea", "pendiente"]
    if any(kw in message_lower for kw in task_update_keywords):
        return QueryType.TASK_UPDATE
    
    # Memory recall queries
    memory_keywords = ["última vez", "ultima vez", "antes", "anterior", "recordás", "acordas", 
                       "buscar", "encontrar", "dónde", "donde", "cuándo", "cuando", "search", "find",
                       "remember", "recall", "what did", "when did"]
    if any(kw in message_lower for kw in memory_keywords):
        return QueryType.MEMORY_QUERY
    
    # Default to chat
    return QueryType.CHAT


class HMLRMemoryFacade:
    """Facade for interacting with HMLR memory system.
    
    This class owns the HMLR component bundle and coordinates
    retrieval, storage, and debugging operations for the plugin.
    """

    def __init__(self, config: HMLRMemoryConfig, bundle: Optional[ComponentBundle] = None):
        """Initialize the facade.
        
        Args:
            config: Configuration for the HMLR system.
            bundle: Optional pre-existing component bundle (for testing).
                    If None, a new bundle is created using the factory.
        """
        self.config = config
        
        if bundle:
            self.components = bundle
        else:
            logger.info("Initializing HMLR components via factory...")
            
            # Set COGNITIVE_LATTICE_DB env var from config.db_path
            # This is required by ComponentFactory to create the database at the correct path
            if config.db_path:
                os.environ["COGNITIVE_LATTICE_DB"] = config.db_path
                logger.info(f"HMLR: Set COGNITIVE_LATTICE_DB env var to: {config.db_path}")
                
                # Ensure the directory exists for the database file
                db_dir = os.path.dirname(config.db_path)
                if db_dir and not os.path.exists(db_dir):
                    os.makedirs(db_dir, exist_ok=True)
                    logger.info(f"HMLR: Created directory for database: {db_dir}")
            
            self.components = ComponentFactory.create_all_components(
                use_llm_intent_mode=config.use_llm_intent_mode,
                context_budget_tokens=config.max_context_tokens,
                crawler_recency_weight=config.recency_weight,
                device=config.device,
                sliding_window_path=config.get_sliding_window_path(),
                max_sliding_window_turns=config.max_sliding_window_turns
            )
            # Note: db_path should be set via COGNITIVE_LATTICE_DB env var
            # sliding_window_path is auto-derived from db_path in config.__post_init__
            if config.db_path:
                logger.info(f"HMLR configured with db_path: {config.db_path}")
            if config.sliding_window_path:
                logger.info(f"HMLR configured with sliding_window_path: {config.sliding_window_path}")

    def log_turn(
        self,
        conversation_id: str,
        user_message: str,
        assistant_message: Optional[str]
    ) -> Optional[ConversationTurn]:
        """Log a completed conversation turn to HMLR.
        
        Args:
            conversation_id: Unique identifier for the conversation (session ID).
            user_message: The user's input.
            assistant_message: The assistant's response.
            
        Returns:
            The logged ConversationTurn object, or None if logging failed.
        """
        if not assistant_message:
            logger.warning("Skipping HMLR logging: No assistant message provided.")
            return None
            
        try:
            # Delegate to ConversationManager
            turn = self.components.conversation_mgr.log_turn(
                session_id=conversation_id,
                user_message=user_message,
                assistant_response=assistant_message,
                # Optional metadata could be passed here if we extracted it from Result
                keywords=[], 
                summary=None
            )
            logger.debug(f"Logged HMLR turn: {turn.turn_id} for session {conversation_id}")
            return turn
            
        except Exception as e:
            logger.error(f"Failed to log turn to HMLR: {e}", exc_info=True)
            return None

    async def build_context_for_query(
        self, 
        conversation_id: str, 
        user_message: str
    ) -> str:
        """Retrieve and hydrate context for a user query.
        
        Uses the full HMLR retrieval pipeline with enhanced keyword extraction
        and embedding-based semantic search:
        
        1. Extract keywords from user message (not just split).
        2. Classify query type for better intent understanding.
        3. Generate embeddings for semantic similarity (if available).
        4. Retrieve candidates via LatticeCrawler with semantic scoring.
        5. Filter and route via TheGovernor.
        6. Hydrate final context via ContextHydrator (Bridge Block aware).
        
        Args:
            conversation_id: Session identifier.
            user_message: The user's query.
            
        Returns:
            A formatted context string ready for LLM injection.
        """
        try:
            # 1. Get current day ID
            day_id = self.components.conversation_mgr.current_day
            
            # 2. Extract keywords using proper NLP (if enabled)
            if self.config.use_keywords:
                keywords = list(extract_keywords_cached(user_message))
                if not keywords:
                    # Fallback to basic split if no keywords extracted
                    keywords = [w for w in user_message.lower().split() if len(w) > 2]
                logger.debug(f"HMLR: Extracted keywords: {keywords}")
            else:
                keywords = []
                logger.debug("HMLR: Keyword extraction disabled")
            
            # 3. Classify query type for better intent
            query_type = classify_query_type(user_message)
            logger.debug(f"HMLR: Query type classified as: {query_type}")
            
            # 4. Create enhanced intent with proper keywords
            intent = Intent(
                keywords=keywords,
                query_type=query_type,
                raw_query=user_message
            )
            
            # 5. Generate embedding for semantic search (if enabled and embedding_storage available)
            query_embedding = None
            if self.config.use_embeddings and hasattr(self.components, 'embedding_storage') and self.components.embedding_storage:
                try:
                    query_embedding = self.components.embedding_storage.embedding_manager.encode(user_message)
                    logger.debug("HMLR: Generated query embedding for semantic search")
                except Exception as e:
                    logger.warning(f"HMLR: Could not generate embedding: {e}")
            elif not self.config.use_embeddings:
                logger.debug("HMLR: Embedding generation disabled")
            
            # 6. Retrieve candidates with semantic scoring
            candidates = self.components.lattice_retrieval.retrieve_candidates(
                query=user_message,
                intent=intent,
                top_k=20
            )
            
            # 7. Apply semantic re-ranking if we have embeddings (using config alpha)
            if query_embedding is not None and candidates and self.config.enable_semantic_search:
                candidates = self._rerank_with_embeddings(
                    candidates, 
                    query_embedding,
                    alpha=self.config.semantic_rerank_alpha
                )
                logger.debug(f"HMLR: Re-ranked {len(candidates)} candidates with semantic similarity (alpha={self.config.semantic_rerank_alpha})")
            
            # 8. Govern (TheGovernor) - filter and route
            if self.components.governor:
                decision, filtered_memories, facts = await self.components.governor.govern(
                    query=user_message,
                    day_id=day_id,
                    candidates=candidates
                )
                
                matched_block_id = decision.get("matched_block_id")
                is_new_topic = decision.get("is_new_topic", False)
            else:
                # Fallback without Governor
                logger.warning("HMLR: Governor not available, using direct retrieval")
                filtered_memories = candidates[:10]  # Take top 10
                facts = []
                matched_block_id = None
                is_new_topic = True
            
            # 9. Hydrate context based on decision
            context_str = await self._hydrate_context(
                matched_block_id=matched_block_id,
                is_new_topic=is_new_topic,
                filtered_memories=filtered_memories,
                facts=facts,
                user_message=user_message
            )
            
            # 10. Log retrieval metrics
            self._log_retrieval_metrics(
                conversation_id=conversation_id,
                num_keywords=len(keywords),
                query_type=query_type,
                num_candidates=len(candidates),
                num_filtered=len(filtered_memories) if filtered_memories else 0,
                has_embedding=query_embedding is not None
            )

            return context_str
            
        except Exception as e:
            logger.error(f"Failed to build HMLR context: {e}", exc_info=True)
            return f"[HMLR Retrieval Error: {str(e)}]"
    
    def _rerank_with_embeddings(
        self,
        candidates: List[Any],
        query_embedding: Any,
        alpha: float = 0.5
    ) -> List[Any]:
        """Re-rank candidates using embedding similarity.
        
        Combines existing score with semantic similarity using weighted average.
        
        Args:
            candidates: List of memory candidates.
            query_embedding: Query embedding vector.
            alpha: Weight for semantic similarity (0-1).
        
        Returns:
            Re-ranked candidates.
        """
        try:
            import numpy as np
            
            for candidate in candidates:
                # Get candidate embedding if available
                candidate_embedding = getattr(candidate, 'embedding', None)
                if candidate_embedding is not None:
                    # Compute cosine similarity
                    similarity = np.dot(query_embedding, candidate_embedding) / (
                        np.linalg.norm(query_embedding) * np.linalg.norm(candidate_embedding) + 1e-8
                    )
                    
                    # Combine with existing score
                    original_score = getattr(candidate, 'score', 0.0)
                    candidate.score = alpha * similarity + (1 - alpha) * original_score
            
            # Sort by combined score
            candidates.sort(key=lambda x: getattr(x, 'score', 0.0), reverse=True)
            
        except ImportError:
            logger.warning("HMLR: numpy not available for semantic re-ranking")
        except Exception as e:
            logger.warning(f"HMLR: Re-ranking failed: {e}")
        
        return candidates
    
    async def _hydrate_context(
        self,
        matched_block_id: Optional[str],
        is_new_topic: bool,
        filtered_memories: List[Any],
        facts: List[Any],
        user_message: str
    ) -> str:
        """Hydrate context based on retrieval decision.
        
        Args:
            matched_block_id: ID of matched bridge block (if any).
            is_new_topic: Whether this is a new topic.
            filtered_memories: Filtered memory candidates.
            facts: Extracted facts.
            user_message: Original user message.
        
        Returns:
            Hydrated context string.
        """
        if matched_block_id:
            # Use Bridge Block hydration
            logger.info(f"HMLR: Using Bridge Block {matched_block_id}")
            return self.components.context_hydrator.hydrate_bridge_block(
                block_id=matched_block_id,
                memories=filtered_memories,
                facts=facts,
                user_message=user_message,
                is_new_topic=is_new_topic
            )
        elif is_new_topic:
            # New Topic: hydrate with fresh context
            logger.info("HMLR: New topic detected, hydrating fresh context.")
            return self.components.context_hydrator.hydrate_bridge_block(
                block_id="new_topic_placeholder",
                memories=filtered_memories,
                facts=facts,
                user_message=user_message,
                is_new_topic=True
            )
        else:
            # Fallback to standard hydration
            logger.warning("HMLR: No matching block - falling back to legacy prompt")
            return self.components.context_hydrator.build_prompt(
                system_prompt="",
                sliding_window=self.components.sliding_window,
                retrieved_context=self._wrap_as_retrieved_context(filtered_memories, facts),
                user_message=user_message
            )
    
    def _log_retrieval_metrics(
        self,
        conversation_id: str,
        num_keywords: int,
        query_type: QueryType,
        num_candidates: int,
        num_filtered: int,
        has_embedding: bool
    ) -> None:
        """Log retrieval metrics for monitoring."""
        logger.info(
            f"HMLR Retrieval: session={conversation_id}, "
            f"keywords={num_keywords}, query_type={query_type.value}, "
            f"candidates={num_candidates}, filtered={num_filtered}, "
            f"semantic_search={has_embedding}"
        )

    def get_debug_state(self, conversation_id: str) -> Dict[str, Any]:
        """Get debug information about HMLR state.
        
        Args:
            conversation_id: Session identifier.
            
        Returns:
            Dictionary containing debug stats.
        """
        try:
            mgr = self.components.conversation_mgr
            summary = mgr.get_window_summary()
            
            # Get embedding stats if available
            embedding_stats = {}
            if hasattr(self.components, 'embedding_storage') and self.components.embedding_storage:
                try:
                    embedding_stats = {
                        "embeddings_enabled": True,
                        "device": getattr(self.components.embedding_storage, 'device', 'unknown'),
                    }
                except Exception:
                    embedding_stats = {"embeddings_enabled": False}
            
            return {
                "session_id": conversation_id,
                "current_day": mgr.current_day,
                "window_stats": summary,
                "active_blocks_count": len(self.components.storage.get_active_bridge_blocks()),
                "total_days_stored": self.components.storage.count_days() if hasattr(self.components.storage, 'count_days') else -1,
                "governor_available": self.components.governor is not None,
                "embedding_stats": embedding_stats,
                "keyword_cache_info": extract_keywords_cached.cache_info()._asdict(),
            }
        except Exception as e:
            logger.error(f"Failed to get debug state: {e}")
            return {"error": str(e)}

    def _wrap_as_retrieved_context(self, memories: List[Any], facts: List[Any]):
        """Helper to wrap MemoryCandidates into RetrievedContext object for legacy hydrator."""
        # Imported at top level

        
        # Convert MemoryCandidates to dicts expected by RetrievedContext
        contexts = []
        for mem in memories:
            if hasattr(mem, 'full_object') and mem.full_object:
                contexts.append(mem.full_object)
            else:
                contexts.append({
                    "context": getattr(mem, 'content_preview', str(mem)),
                    "relevance_score": getattr(mem, 'score', 0.0),
                    "day_id": "unknown"
                })
        
        # For this simplified wrap, we don't fully populate active_tasks or sources
        return RetrievedContext(
            contexts=contexts,
            active_tasks=[],
            sources=[],
            total_tokens=0 # recalculated by hydrator
        )
