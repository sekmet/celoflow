"""
Sliding Window Persistence

Saves and loads the sliding window state to/from a JSON file.
This ensures compression and window state persists across sessions.

File: memory/sliding_window_state.json
- Contains all turns currently in the sliding window
- Includes compression state (detail_level, compressed_content)
- Overwritten after each turn
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
from dataclasses import asdict

from contextwise.lib.hmlrmem.memory.models import ConversationTurn


class SlidingWindowPersistence:
    """Handles saving/loading sliding window state to persistent storage"""
    
    def __init__(self, state_file: str = "memory/sliding_window_state.json"):
        self.state_file = Path(state_file)
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
    
    def save_window(self, turns: List[ConversationTurn], active_topics: Dict[str, datetime] = None, 
                   in_window_ids: Dict[str, set] = None) -> None:
        """
        Save the current sliding window state to file.
        
        Args:
            turns: List of ConversationTurn objects
            active_topics: Dict of active topics {topic: last_used}
            in_window_ids: Dict of ID sets {type: set(ids)}
        """
        state = {
            "last_updated": datetime.now().isoformat(),
            "turn_count": len(turns),
            "active_topics": {},
            "in_window_ids": {},
            "turns": []
        }
        
        # Serialize active topics
        if active_topics:
            state["active_topics"] = {
                topic: dt.isoformat() if isinstance(dt, datetime) else str(dt)
                for topic, dt in active_topics.items()
            }
            
        # Serialize in-window IDs (convert sets to lists)
        if in_window_ids:
            state["in_window_ids"] = {
                k: list(v) for k, v in in_window_ids.items()
            }
        
        for turn in turns:
            # Handle timestamp - could be string or datetime
            if isinstance(turn.timestamp, datetime):
                timestamp_str = turn.timestamp.isoformat()
            elif isinstance(turn.timestamp, str):
                timestamp_str = turn.timestamp
            else:
                timestamp_str = str(turn.timestamp)
            
            turn_data = {
                "turn_id": turn.turn_id,
                "session_id": turn.session_id,
                "day_id": turn.day_id,
                "turn_sequence": turn.turn_sequence,
                "timestamp": timestamp_str,
                "detail_level": turn.detail_level,
                "user_message": turn.user_message,
                "assistant_response": turn.assistant_response,
                "compressed_content": turn.compressed_content,
                "compression_timestamp": turn.compression_timestamp.isoformat() if turn.compression_timestamp else None,
                "keywords": turn.keywords if hasattr(turn, 'keywords') else [],
                "assistant_summary": turn.assistant_summary if hasattr(turn, 'assistant_summary') else None
            }
            state["turns"].append(turn_data)
        
        # Write atomically (write to temp file, then rename)
        temp_file = self.state_file.with_suffix('.tmp')
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2)
        
        temp_file.replace(self.state_file)
        print(f"   💾 Saved sliding window state: {len(turns)} turns, {len(state['active_topics'])} topics")
    
    def load_window(self) -> Dict[str, Any]:
        """
        Load the sliding window state from file.
        
        Returns:
            Dict containing 'turns', 'active_topics', 'in_window_ids'
        """
        if not self.state_file.exists():
            print(f"   ℹ️  No saved window state found - starting fresh")
            return {"turns": [], "active_topics": {}, "in_window_ids": {}}
        
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            turns = []
            for turn_data in state.get("turns", []):
                # Reconstruct ConversationTurn from saved data
                turn = ConversationTurn(
                    turn_id=turn_data["turn_id"],
                    session_id=turn_data["session_id"],
                    day_id=turn_data["day_id"],
                    timestamp=turn_data["timestamp"],
                    turn_sequence=turn_data["turn_sequence"],
                    user_message=turn_data["user_message"],
                    assistant_response=turn_data["assistant_response"],
                    detail_level=turn_data.get("detail_level", "VERBATIM"),
                    compressed_content=turn_data.get("compressed_content"),
                    compression_timestamp=datetime.fromisoformat(turn_data["compression_timestamp"]) 
                        if turn_data.get("compression_timestamp") else None,
                    keywords=turn_data.get("keywords", []),
                    assistant_summary=turn_data.get("assistant_summary")
                )
                turns.append(turn)
            
            # Reconstruct active topics
            active_topics = {}
            for topic, dt_str in state.get("active_topics", {}).items():
                active_topics[topic] = datetime.fromisoformat(dt_str)
            
            # Reconstruct in-window IDs
            in_window_ids = {}
            for k, v in state.get("in_window_ids", {}).items():
                in_window_ids[k] = set(v)
            
            print(f"   📂 Loaded sliding window state: {len(turns)} turns, {len(active_topics)} topics")
            
            return {
                "turns": turns,
                "active_topics": active_topics,
                "in_window_ids": in_window_ids
            }
            
        except Exception as e:
            print(f"   ⚠️  Error loading window state: {e}")
            return {"turns": [], "active_topics": {}, "in_window_ids": {}}
    
    def clear_window(self) -> None:
        """Clear the saved window state (useful for testing)"""
        if self.state_file.exists():
            self.state_file.unlink()
            print(f"   🗑️  Cleared sliding window state")
