"""HMLR Memory Plugin.

This plugin integrates the HMLR system with ContextWise agents.
It handles:
1. Lifecycle hooks: Buffering input and logging completed turns.
2. Tool injection: Exposing context retrieval tools to the agent.
3. Configuration: Managing HMLR settings.

It serves as the glue between the agent framework and the HMLR facade.
"""

import logging
from typing import Optional, List, Dict, Any, Callable

from agents import Agent, RunResult, RunConfig, function_tool, RunContextWrapper

from ..base import AgentPlugin
from ..context import AgentContext
from .models import HMLRMemoryConfig
from .facade import HMLRMemoryFacade

logger = logging.getLogger(__name__)


class HMLRMemoryPlugin(AgentPlugin[AgentContext]):
    """Plugin for HMLR Long-Term Memory integration.
    
    This plugin provides robust integration between ContextWise agents
    and the HMLR long-term memory system, featuring:
    - Consistent session ID handling across lifecycle hooks
    - Input buffering for turn logging
    - On-demand context retrieval tools
    
    Attributes:
        config: Configuration for the HMLR system.
        facade: The facade instance managing HMLR components.
    """
    
    id: str = "hmlr_memory"
    name: str = "HMLR Memory Plugin"
    version: str = "0.2.0"

    def __init__(
        self, 
        config: Optional[HMLRMemoryConfig] = None,
        facade: Optional[HMLRMemoryFacade] = None
    ):
        """Initialize the HMLR plugin.
        
        Args:
            config: Configuration object. If None, defaults are used.
            facade: Optional facade instance. If None, one is created from config.
        """
        self.config = config or HMLRMemoryConfig()
        self.facade = facade or HMLRMemoryFacade(self.config)
        # Initialize input buffer with thread-safe dict
        self._input_buffers: Dict[str, str] = {}
        # Track active session IDs for debugging
        self._active_sessions: Dict[str, str] = {}  # {resolved_id: original_context_info}
        logger.info(f"HMLR Plugin initialized with DB: {self.config.db_path or 'default'}")

    def dependencies(self) -> List[str]:
        """Return plugin dependencies."""
        # We don't strictly *require* storage plugin to load, 
        # but we expect a valid session_id in the context.
        return []

    def _resolve_session_id(self, context: AgentContext) -> str:
        """Resolve a consistent session ID from context.
        
        This method ensures the same session ID is used across all lifecycle
        hooks (on_before_run, on_after_run) and tools, preventing input
        buffering mismatches.
        
        Resolution order:
        1. context.session_id (preferred, set by API/builder)
        2. context.user_id (fallback for single-user sessions)
        3. context.metadata["_hmlr_session_id"] (stored from first call)
        4. "default" (last resort)
        
        Args:
            context: The agent context (may be None if called outside plugin hooks).
            
        Returns:
            A consistent session ID string.
        """
        # Handle None context (when tool is called directly without context)
        if context is None:
            # Use the last known session or default
            if self._active_sessions:
                return next(iter(self._active_sessions.keys()))
            return "default"
        
        # Ensure metadata dict exists
        if not hasattr(context, 'metadata') or context.metadata is None:
            context.metadata = {}
        
        # Check if we already resolved and stored a session ID for this context
        if context.metadata.get("_hmlr_session_id"):
            return context.metadata["_hmlr_session_id"]
        
        # Resolve from available sources
        session_id = getattr(context, 'session_id', None) or getattr(context, 'user_id', None) or "default"
        
        # Store in metadata for consistent access across hooks
        context.metadata["_hmlr_session_id"] = session_id
        
        # Track for debugging
        context_info = f"session_id={getattr(context, 'session_id', None)}, user_id={getattr(context, 'user_id', None)}"
        self._active_sessions[session_id] = context_info
        
        return session_id

    async def get_hmlr_context(self, context: AgentContext, query: str) -> str:
        """
        Retrieve relevant context from long-term memory (HMLR) based on the user's query.
        Use this tool when the user refers to past conversations, tasks, or facts
        that are not in the current short-term history.
        
        Args:
            query: The user's query or a specific search term to look up.
        """
        try:
            # Use consistent session ID resolution
            session_id = self._resolve_session_id(context)
            
            # Retrieve context
            result = await self.facade.build_context_for_query(session_id, query)
            logger.debug(f"HMLR context retrieved for session {session_id}: {len(result)} chars")
            return result
        except Exception as e:
            logger.error(f"Error in get_hmlr_context tool: {e}", exc_info=True)
            return f"Error retrieving context: {str(e)}"

    async def get_hmlr_memory_debug(self, context: AgentContext) -> str:
        """
        Retrieve debug state from HMLR memory.
        Use this tool for debugging purposes to inspect the current state of HMLR.
        """
        try:
            session_id = self._resolve_session_id(context)
            state = self.facade.get_debug_state(session_id)
            # Add active sessions info
            state["active_sessions"] = list(self._active_sessions.keys())
            state["buffered_inputs"] = list(self._input_buffers.keys())
            return f"HMLR Debug State: {state}"
        except Exception as e:
            logger.error(f"Error in get_hmlr_memory_debug tool: {e}", exc_info=True)
            return f"Error retrieving debug state: {str(e)}"

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """
        Injects HMLR tools into the agent.
        """
        if not self.config.enable_tools:
            return agent

        # Wrapper for retrieve tool (to allow setting .name)
        @function_tool
        async def get_hmlr_context(context: RunContextWrapper[AgentContext], query: str) -> str:
            """
            Retrieve relevant context from long-term memory (HMLR) based on the user's query.
            Use this tool when the user refers to past conversations, tasks, or facts
            that are not in the current short-term history.
            
            Args:
                query: The user's query or a specific search term to look up.
            """
            # Unwrap context if needed, or use directly if it proxies attributes
            # usually RunContextWrapper proxies, but let's check
            # For now assume we access attributes directly or unwrap
            # Checking attribute access directly:
            # session_id = context.session_id
            # But context is RunContextWrapper.
            # Let's try direct access assuming proxy/getattr magic, or .data / .context
            real_context = context.context
            return await self.get_hmlr_context(real_context, query)
        
        new_tools = list(agent.tools) + [get_hmlr_context]
        
        if self.config.enable_tools:
            # Debug tool
            @function_tool
            async def get_hmlr_memory_debug(context: RunContextWrapper[AgentContext]) -> str:
                """
                Retrieve debug state from HMLR memory.
                Use this tool for debugging purposes to inspect the current state of HMLR.
                """
                real_context = context.context
                return await self.get_hmlr_memory_debug(real_context)
            new_tools.append(get_hmlr_memory_debug)

        return agent.clone(
            tools=new_tools,
            instructions=agent.instructions
        )

    def configure_run_config(
        self,
        context: AgentContext,
        base_config: Optional[RunConfig],
    ) -> Optional[RunConfig]:
        """Optionally extend the run configuration for this request.

        If None is returned, the existing config is left unchanged.
        """
        if self.config.auto_inject_context:
            memory_guidance = "\n\nMEMORY: When users reference past conversations, appointments, preferences, or any historical information, use the get_hmlr_context tool to retrieve relevant context from long-term memory before responding."
            if base_config:
                new_instructions = (base_config.instructions or "") + memory_guidance
                return RunConfig(
                    instructions=new_instructions,
                    **{k: v for k, v in base_config.__dict__.items() if k != 'instructions'}
                )
            else:
                return RunConfig(instructions=memory_guidance)
        return base_config

    def on_before_run(self, context: AgentContext, input_text: str) -> None:
        """Buffer user input for later logging.
        
        This method is called by the PluginManager before the agent runs.
        It stores the user input in both the context metadata and an instance
        buffer for robust retrieval in on_after_run.
        
        Args:
            context: Agent context.
            input_text: User's input message.
        """
        # Resolve session ID consistently
        session_id = self._resolve_session_id(context)
        
        # Store input in both locations for robustness
        context.metadata["_hmlr_buffered_input"] = input_text
        self._input_buffers[session_id] = input_text
        
        input_preview = input_text[:50] + "..." if len(input_text) > 50 else input_text
        logger.info(f"HMLR: on_before_run buffering input for session {session_id}: '{input_preview}'")

    def on_after_run(self, context: AgentContext, result: RunResult) -> None:
        """Log the completed conversation turn to HMLR.
        
        This method is called by the PluginManager after the agent runs.
        It retrieves the buffered input and logs the complete turn to the
        HMLR memory system.
        
        Args:
            context: Agent context.
            result: The result of the run.
        """
        try:
            # Use consistent session ID resolution
            session_id = self._resolve_session_id(context)
            logger.info(f"HMLR: on_after_run triggered for session {session_id}")
            
            # Try multiple sources for buffered input (most reliable first)
            user_input = (
                self._input_buffers.get(session_id) or
                context.metadata.get("_hmlr_buffered_input")
            )
                
            if not user_input:
                buffer_keys = list(self._input_buffers.keys())
                logger.warning(
                    f"HMLR: No buffered input found for logging "
                    f"(session={session_id}, buffer_keys={buffer_keys})"
                )
                return

            assistant_response = result.final_output
            if not assistant_response:
                # Might be a tool usage run or empty response
                logger.debug("HMLR: No final output (tool use?), skipping log.")
                return
            
            logger.info(f"HMLR: Logging turn to database for session {session_id}")
            # Log to HMLR
            self.facade.log_turn(
                conversation_id=session_id,
                user_message=user_input,
                assistant_message=assistant_response
            )
            
            # Clean up buffers
            context.metadata.pop("_hmlr_buffered_input", None)
            self._input_buffers.pop(session_id, None)
            
            logger.debug(f"HMLR: Turn logged successfully for session {session_id}")
                
        except Exception as e:
            logger.error(f"HMLR: Failed to log turn in on_after_run: {e}", exc_info=True)
