"""Configuration models for HMLR Memory Plugin.

This module defines the configuration dataclass for the HMLR plugin.
"""

from dataclasses import dataclass, field
from typing import Optional
import os


@dataclass
class HMLRMemoryConfig:
    """Configuration for HMLR Memory Plugin.
    
    Attributes:
        db_path: Path to the HMLR SQLite database file. 
                 Defaults to standard 'cognitive_lattice_memory.db' if None.
        sliding_window_path: Path to the sliding window state JSON file.
                            Used for persisting short-term context across server restarts.
                            Defaults to 'sliding_window_state.json' in the same directory as db_path.
        max_context_tokens: Budget for hydrated context injection.
        recency_weight: Tuning parameter for recency bias in retrieval (0.0 to 1.0).
        use_llm_intent_mode: Whether to rely on LLM-based IntentAnalyzer. 
                             False uses heuristic/regex mode.
        enable_tools: Whether to expose HMLR tools (get_hmlr_context, get_hmlr_memory_debug) to the agent.
        auto_inject_context: Whether to automatically append usage guidelines to agent instructions.
        device: Device for embedding model ('cpu' or 'cuda').
        max_sliding_window_turns: Maximum number of turns to keep in the sliding window.
        use_embeddings: Whether to enable embedding-based retrieval and semantic search.
        use_keywords: Whether to enable keyword extraction for memory retrieval.
        enable_semantic_search: Whether to enable semantic tool discovery via embeddings.
        semantic_rerank_alpha: Weight for semantic similarity in re-ranking (0.0 to 1.0).
    """
    db_path: Optional[str] = None
    sliding_window_path: Optional[str] = None
    max_context_tokens: int = 6000
    recency_weight: float = 0.5
    use_llm_intent_mode: bool = False
    enable_tools: bool = True
    auto_inject_context: bool = False
    device: str = "cpu"
    max_sliding_window_turns: int = 20
    use_embeddings: bool = True
    use_keywords: bool = True
    enable_semantic_search: bool = True
    semantic_rerank_alpha: float = 0.5
    
    def __post_init__(self):
        """Derive sliding_window_path from db_path if not explicitly set."""
        if self.sliding_window_path is None and self.db_path:
            # Place sliding window state file next to the database
            db_dir = os.path.dirname(self.db_path) or "."
            self.sliding_window_path = os.path.join(db_dir, "sliding_window_state.json")
    
    def get_sliding_window_path(self) -> str:
        """Get the resolved sliding window persistence path.
        
        Returns:
            Path to the sliding window state file.
        """
        if self.sliding_window_path:
            return self.sliding_window_path
        # Default fallback
        return "memory/sliding_window_state.json"
