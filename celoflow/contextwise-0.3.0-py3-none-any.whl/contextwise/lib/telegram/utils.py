"""Telegram utility functions for Contextwise v0.3.0.

This module provides utility functions for Telegram Bot API interactions,
including message sending, bot profile lookup, and update parsing.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

import httpx

logger = logging.getLogger(__name__)

TELEGRAM_MAX_MESSAGE_LENGTH = 4096


def get_telegram_bot_token(bot_token: Optional[str] = None) -> str:
    """Resolve Telegram bot token from parameter or environment.

    Args:
        bot_token: Explicit bot token.

    Returns:
        Telegram bot token.

    Raises:
        ValueError: If token is not configured.
    """
    resolved = bot_token or os.getenv("TELEGRAM_BOT_TOKEN", "")
    if not resolved:
        raise ValueError("Telegram bot token not configured")
    return resolved


def _telegram_url(bot_token: str, method: str) -> str:
    """Build Telegram Bot API URL for a method."""
    return f"https://api.telegram.org/bot{bot_token}/{method}"


def _extract_api_error(payload: Dict[str, Any]) -> str:
    """Extract a readable error from Telegram API payload."""
    description = payload.get("description")
    error_code = payload.get("error_code")

    if error_code and description:
        return f"{error_code}: {description}"
    if description:
        return str(description)
    return "Unknown Telegram API error"


def send_telegram_message(
    chat_id: str,
    text: str,
    bot_token: Optional[str] = None,
    reply_to_message_id: Optional[int] = None,
    message_thread_id: Optional[int] = None,
    parse_mode: Optional[str] = None,
) -> Dict[str, Any]:
    """Send a Telegram message synchronously.

    Args:
        chat_id: Target Telegram chat ID.
        text: Message text.
        bot_token: Bot token (falls back to TELEGRAM_BOT_TOKEN).
        reply_to_message_id: Optional message ID to reply to.
        message_thread_id: Optional forum topic/thread ID.
        parse_mode: Optional parse mode (MarkdownV2/HTML).

    Returns:
        Telegram API message result payload.

    Raises:
        ValueError: If token is missing or API returns an error.
        httpx.HTTPError: If the HTTP request fails.
    """
    token = get_telegram_bot_token(bot_token)
    url = _telegram_url(token, "sendMessage")

    payload: Dict[str, Any] = {
        "chat_id": chat_id,
        "text": text,
    }
    if reply_to_message_id is not None:
        payload["reply_to_message_id"] = reply_to_message_id
    if message_thread_id is not None:
        payload["message_thread_id"] = message_thread_id
    if parse_mode:
        payload["parse_mode"] = parse_mode

    with httpx.Client(timeout=30.0) as client:
        response = client.post(url, json=payload)
        response.raise_for_status()
        data = response.json()

    if not data.get("ok", False):
        raise ValueError(_extract_api_error(data))

    return data.get("result", data)


async def send_telegram_message_async(
    chat_id: str,
    text: str,
    bot_token: Optional[str] = None,
    reply_to_message_id: Optional[int] = None,
    message_thread_id: Optional[int] = None,
    parse_mode: Optional[str] = None,
) -> Dict[str, Any]:
    """Send a Telegram message asynchronously.

    Args:
        chat_id: Target Telegram chat ID.
        text: Message text.
        bot_token: Bot token (falls back to TELEGRAM_BOT_TOKEN).
        reply_to_message_id: Optional message ID to reply to.
        message_thread_id: Optional forum topic/thread ID.
        parse_mode: Optional parse mode (MarkdownV2/HTML).

    Returns:
        Telegram API message result payload.

    Raises:
        ValueError: If token is missing or API returns an error.
        httpx.HTTPError: If the HTTP request fails.
    """
    token = get_telegram_bot_token(bot_token)
    url = _telegram_url(token, "sendMessage")

    payload: Dict[str, Any] = {
        "chat_id": chat_id,
        "text": text,
    }
    if reply_to_message_id is not None:
        payload["reply_to_message_id"] = reply_to_message_id
    if message_thread_id is not None:
        payload["message_thread_id"] = message_thread_id
    if parse_mode:
        payload["parse_mode"] = parse_mode

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(url, json=payload)
        response.raise_for_status()
        data = response.json()

    if not data.get("ok", False):
        raise ValueError(_extract_api_error(data))

    return data.get("result", data)


def get_telegram_me(bot_token: Optional[str] = None) -> Dict[str, Any]:
    """Fetch Telegram bot profile synchronously.

    Args:
        bot_token: Bot token (falls back to TELEGRAM_BOT_TOKEN).

    Returns:
        Telegram bot profile payload.

    Raises:
        ValueError: If token is missing or API returns an error.
        httpx.HTTPError: If the HTTP request fails.
    """
    token = get_telegram_bot_token(bot_token)
    url = _telegram_url(token, "getMe")

    with httpx.Client(timeout=30.0) as client:
        response = client.get(url)
        response.raise_for_status()
        data = response.json()

    if not data.get("ok", False):
        raise ValueError(_extract_api_error(data))

    return data.get("result", data)


async def get_telegram_me_async(bot_token: Optional[str] = None) -> Dict[str, Any]:
    """Fetch Telegram bot profile asynchronously.

    Args:
        bot_token: Bot token (falls back to TELEGRAM_BOT_TOKEN).

    Returns:
        Telegram bot profile payload.

    Raises:
        ValueError: If token is missing or API returns an error.
        httpx.HTTPError: If the HTTP request fails.
    """
    token = get_telegram_bot_token(bot_token)
    url = _telegram_url(token, "getMe")

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.get(url)
        response.raise_for_status()
        data = response.json()

    if not data.get("ok", False):
        raise ValueError(_extract_api_error(data))

    return data.get("result", data)


def send_telegram_chat_action(
    chat_id: str,
    action: str = "typing",
    bot_token: Optional[str] = None,
) -> Dict[str, Any]:
    """Send a Telegram chat action (typing indicator) synchronously.

    Args:
        chat_id: Target Telegram chat ID.
        action: Chat action to send (typing, upload_photo, record_video, etc.).
        bot_token: Bot token (falls back to TELEGRAM_BOT_TOKEN).

    Returns:
        Telegram API result payload.

    Raises:
        ValueError: If token is missing or API returns an error.
        httpx.HTTPError: If the HTTP request fails.
    """
    token = get_telegram_bot_token(bot_token)
    url = _telegram_url(token, "sendChatAction")

    payload: Dict[str, Any] = {
        "chat_id": chat_id,
        "action": action,
    }

    with httpx.Client(timeout=30.0) as client:
        response = client.post(url, json=payload)
        response.raise_for_status()
        data = response.json()

    if not data.get("ok", False):
        raise ValueError(_extract_api_error(data))

    return data.get("result", data)


async def send_telegram_chat_action_async(
    chat_id: str,
    action: str = "typing",
    bot_token: Optional[str] = None,
) -> Dict[str, Any]:
    """Send a Telegram chat action (typing indicator) asynchronously.

    Args:
        chat_id: Target Telegram chat ID.
        action: Chat action to send (typing, upload_photo, record_video, etc.).
        bot_token: Bot token (falls back to TELEGRAM_BOT_TOKEN).

    Returns:
        Telegram API result payload.

    Raises:
        ValueError: If token is missing or API returns an error.
        httpx.HTTPError: If the HTTP request fails.
    """
    token = get_telegram_bot_token(bot_token)
    url = _telegram_url(token, "sendChatAction")

    payload: Dict[str, Any] = {
        "chat_id": chat_id,
        "action": action,
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(url, json=payload)
        response.raise_for_status()
        data = response.json()

    if not data.get("ok", False):
        raise ValueError(_extract_api_error(data))

    return data.get("result", data)


def parse_telegram_update(body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Parse Telegram update payload to normalized message data.

    Supported update objects: message, edited_message, channel_post,
    edited_channel_post. Only text-based updates are normalized.

    Args:
        body: Telegram update payload.

    Returns:
        Normalized message dict, or None when update is not processable.
    """
    message = (
        body.get("message")
        or body.get("edited_message")
        or body.get("channel_post")
        or body.get("edited_channel_post")
    )

    if not isinstance(message, dict):
        return None

    text = message.get("text")
    if not text:
        return None

    chat = message.get("chat", {}) or {}
    from_user = message.get("from", {}) or {}
    sender_chat = message.get("sender_chat", {}) or {}

    chat_id = chat.get("id")
    if chat_id is None:
        return None

    sender_id = from_user.get("id", sender_chat.get("id"))
    sender_username = from_user.get("username") or sender_chat.get("username")

    return {
        "type": "text",
        "content": text,
        "from": "" if sender_id is None else str(sender_id),
        "id": "" if message.get("message_id") is None else str(message.get("message_id")),
        "chat_id": str(chat_id),
        "chat_type": chat.get("type", "private"),
        "message_thread_id": message.get("message_thread_id"),
        "username": sender_username,
        "language_code": from_user.get("language_code"),
        "is_bot": from_user.get("is_bot", False),
        "entities": message.get("entities", []) or [],
        "update_id": body.get("update_id"),
        "raw": message,
    }
