"""Telegram webhook router for Contextwise v0.3.0.

This module provides FastAPI router creation for Telegram webhook endpoints,
including secret verification and async message dispatch.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Awaitable, Callable, Optional

from fastapi import APIRouter, Header, Request, Response

from .utils import get_telegram_me_async, parse_telegram_update

if TYPE_CHECKING:
    from contextwise.channels import TelegramChannel

logger = logging.getLogger(__name__)


def create_telegram_router(
    api_plugin: "TelegramChannel",
    async_message_handler: Optional[Callable[[dict], Awaitable[None]]] = None,
) -> APIRouter:
    """Create FastAPI router for Telegram webhook endpoints.

    Args:
        api_plugin: TelegramChannel instance with configuration.
        async_message_handler: Optional async handler for inbound messages.

    Returns:
        FastAPI APIRouter with /webhook and /status endpoints.
    """
    router = APIRouter(tags=["telegram"])

    @router.post("/webhook")
    async def telegram_webhook(
        request: Request,
        x_telegram_bot_api_secret_token: Optional[str] = Header(default=None),
    ):
        """Handle Telegram webhook updates."""
        # Verify webhook secret (if configured)
        if api_plugin.webhook_secret:
            if x_telegram_bot_api_secret_token != api_plugin.webhook_secret:
                logger.warning("Invalid Telegram webhook secret token")
                return Response(status_code=403)

        # Parse JSON payload
        try:
            body = await request.json()
        except Exception as exc:
            logger.error(f"Failed to parse Telegram webhook JSON: {exc}")
            return Response(status_code=400)

        # Parse normalized message
        parsed = None
        if hasattr(api_plugin, "parse_webhook_message"):
            parsed = api_plugin.parse_webhook_message(body)
        if parsed is None:
            parsed = parse_telegram_update(body)

        if parsed is None:
            return {"status": "ignored"}

        # Dispatch async message processing
        if async_message_handler:
            asyncio.create_task(_process_message_safe(parsed, async_message_handler))

        return {"status": "accepted"}

    @router.get("/status")
    async def telegram_status():
        """Get Telegram channel status and bot metadata."""
        if not api_plugin.bot_token:
            return {
                "channel": "telegram",
                "status": "unconfigured",
                "error": "Telegram bot token not configured",
            }

        try:
            me = await get_telegram_me_async(api_plugin.bot_token)
            return {
                "channel": "telegram",
                "status": "healthy",
                "bot": {
                    "id": me.get("id"),
                    "username": me.get("username"),
                    "name": me.get("first_name"),
                    "can_join_groups": me.get("can_join_groups"),
                    "supports_inline_queries": me.get("supports_inline_queries"),
                },
                "config": {
                    "dm_policy": api_plugin.dm_policy,
                    "group_policy": api_plugin.group_policy,
                    "groups_configured": len(api_plugin.groups),
                },
            }
        except Exception as exc:
            logger.error(f"Telegram status probe failed: {exc}")
            return {
                "channel": "telegram",
                "status": "unhealthy",
                "error": str(exc),
            }

    return router


async def _process_message_safe(
    message: dict,
    handler: Callable[[dict], Awaitable[None]],
) -> None:
    """Process a Telegram message with guarded error handling."""
    try:
        await handler(message)
    except Exception as exc:
        logger.exception(f"Error processing Telegram message: {exc}")
