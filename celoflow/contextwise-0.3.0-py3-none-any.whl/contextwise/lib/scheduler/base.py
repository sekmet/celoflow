"""Base scheduler plugin interface and data models.

This module defines the abstract interface for scheduler backends following
the Contextwise plugin pattern.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from agents import Agent, RunContextWrapper, Tool, ToolOutputText, function_tool

from ..context import AgentContext
from ..base import AgentPlugin


# ============================================================================
# Enums and Data Models
# ============================================================================


class JobStatus(str, Enum):
    """Status of a job execution."""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    RETRYING = "retrying"


class RetryStrategy(str, Enum):
    """Strategy for retrying failed jobs."""
    NONE = "none"
    LINEAR = "linear"
    EXPONENTIAL = "exponential"


@dataclass
class JobConfig:
    """Configuration for a scheduled job.

    Attributes:
        job_id: Unique identifier for the job
        name: Human-readable job name
        schedule: Cron expression for recurring jobs (e.g., "0 9 * * *")
        run_at: ISO8601 datetime string for one-time jobs
        target: Callable to execute with context dict
        priority: Priority level (0-10, higher = more important)
        max_retries: Maximum retry attempts on failure
        retry_strategy: Strategy for retry delays
        timezone: Timezone string (e.g., "America/New_York")
        metadata: Additional metadata dict
        enabled: Whether job is active
    """
    job_id: str
    name: str
    target: Callable[[Dict[str, Any]], Any]
    schedule: Optional[str] = None
    run_at: Optional[str] = None
    priority: int = 5
    max_retries: int = 0
    retry_strategy: RetryStrategy = RetryStrategy.NONE
    timezone: str = "UTC"
    metadata: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True


@dataclass
class JobExecution:
    """Record of a job execution.

    Attributes:
        execution_id: Unique execution identifier
        job_id: Job identifier
        status: Current execution status
        start_time: When execution started
        end_time: When execution completed
        output: Execution output or result
        error: Error message if failed
        retry_count: Number of retry attempts
    """
    execution_id: str
    job_id: str
    status: JobStatus
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    output: Optional[str] = None
    error: Optional[str] = None
    retry_count: int = 0


@dataclass
class JobInfo:
    """Information about a scheduled job."""
    job_id: str
    name: str
    schedule: Optional[str]
    run_at: Optional[str]
    priority: int
    enabled: bool
    next_run_time: Optional[str] = None


# ============================================================================
# Abstract Scheduler Plugin
# ============================================================================


class SchedulerBackendPlugin(AgentPlugin, ABC):
    """Base plugin for scheduler backends.

    Concrete implementations provide specific scheduling engines
    (e.g., APScheduler, Celery, custom implementations).
    """

    @abstractmethod
    def create_job(self, config: JobConfig) -> bool:
        """Create and schedule a new job.

        Args:
            config: Job configuration

        Returns:
            True if job was created successfully
        """
        ...

    @abstractmethod
    def update_job(self, job_id: str, updates: Dict[str, Any]) -> bool:
        """Update an existing job.

        Args:
            job_id: Job identifier
            updates: Dictionary of fields to update

        Returns:
            True if job was updated successfully
        """
        ...

    @abstractmethod
    def delete_job(self, job_id: str) -> bool:
        """Delete a scheduled job.

        Args:
            job_id: Job identifier

        Returns:
            True if job was deleted successfully
        """
        ...

    @abstractmethod
    def list_jobs(self) -> List[JobInfo]:
        """List all scheduled jobs.

        Returns:
            List of job information
        """
        ...

    @abstractmethod
    def get_job(self, job_id: str) -> Optional[JobInfo]:
        """Get information about a specific job.

        Args:
            job_id: Job identifier

        Returns:
            Job information or None if not found
        """
        ...

    @abstractmethod
    def manually_trigger(
        self,
        job_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """Manually trigger a job execution.

        Args:
            job_id: Job identifier
            context: Additional context for execution

        Returns:
            Execution ID or None if failed
        """
        ...

    @abstractmethod
    def get_execution_history(
        self,
        job_id: str,
        limit: int = 10
    ) -> List[JobExecution]:
        """Get execution history for a job.

        Args:
            job_id: Job identifier
            limit: Maximum number of records to return

        Returns:
            List of execution records
        """
        ...

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Configure agent with scheduler tools.

        Adds tools for scheduling, listing, and managing jobs.
        """
        tools: List[Tool] = [
            self._make_schedule_job_tool(),
            self._make_list_jobs_tool(),
            self._make_cancel_job_tool(),
            self._make_get_job_status_tool(),
        ]
        return agent.clone(tools=[*agent.tools, *tools])

    def _make_schedule_job_tool(self) -> Tool:
        """Create tool for scheduling jobs."""
        @function_tool
        def schedule_job(
            ctx: RunContextWrapper[AgentContext],
            name: str,
            schedule: Optional[str] = None,
            run_at: Optional[str] = None,
            message: str = "",
            priority: int = 5,
        ) -> ToolOutputText:
            """Schedule a new job.

            Args:
                name: Job name
                schedule: Cron expression (e.g., "0 9 * * *" for daily at 9 AM)
                run_at: ISO8601 datetime for one-time job (e.g., "2025-12-25T09:00:00")
                message: Message to send when job executes
                priority: Priority level (0-10, higher = more important)

            Returns:
                Confirmation message
            """
            if not schedule and not run_at:
                return ToolOutputText(text="Error: Must provide either 'schedule' or 'run_at'")

            # Generate job_id
            job_id = f"{name.lower().replace(' ', '_')}_{int(datetime.now().timestamp())}"

            # Create simple target callable that would execute agent
            def job_target(context: Dict[str, Any]) -> Any:
                # This will be overridden by concrete implementations
                # to properly execute the agent
                return context.get("message", "")

            # Extract user_id safely from context
            user_id = None
            if ctx and hasattr(ctx, 'context') and ctx.context:
                user_id = getattr(ctx.context, 'user_id', None)

            config = JobConfig(
                job_id=job_id,
                name=name,
                schedule=schedule,
                run_at=run_at,
                target=job_target,
                priority=priority,
                metadata={
                    "user_id": user_id or "system",
                    "message": message,
                }
            )

            success = self.create_job(config)
            if success:
                schedule_info = schedule or f"once at {run_at}"
                return ToolOutputText(
                    text=f"Job '{name}' scheduled: {schedule_info} (ID: {job_id})"
                )
            else:
                return ToolOutputText(text=f"Failed to schedule job '{name}'")

        return schedule_job

    def _make_list_jobs_tool(self) -> Tool:
        """Create tool for listing scheduled jobs."""
        @function_tool
        def list_scheduled_jobs(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            """List all scheduled jobs.

            Returns:
                List of scheduled jobs with their details
            """
            jobs = self.list_jobs()
            if not jobs:
                return ToolOutputText(text="No scheduled jobs found.")

            lines = ["Scheduled Jobs:"]
            for job in jobs:
                status = "enabled" if job.enabled else "disabled"
                schedule_info = job.schedule or f"once at {job.run_at}"
                lines.append(
                    f"- {job.name} (ID: {job.job_id}): {schedule_info} "
                    f"[priority={job.priority}, {status}]"
                )
                if job.next_run_time:
                    lines.append(f"  Next run: {job.next_run_time}")

            return ToolOutputText(text="\n".join(lines))

        return list_scheduled_jobs

    def _make_cancel_job_tool(self) -> Tool:
        """Create tool for cancelling scheduled jobs."""
        @function_tool
        def cancel_job(
            ctx: RunContextWrapper[AgentContext],
            job_id: str,
        ) -> ToolOutputText:
            """Cancel a scheduled job.

            Args:
                job_id: Job identifier to cancel

            Returns:
                Confirmation message
            """
            success = self.delete_job(job_id)
            if success:
                return ToolOutputText(text=f"Job '{job_id}' cancelled successfully.")
            else:
                return ToolOutputText(text=f"Failed to cancel job '{job_id}'. Job may not exist.")

        return cancel_job

    def _make_get_job_status_tool(self) -> Tool:
        """Create tool for getting job status and history."""
        @function_tool
        def get_job_status(
            ctx: RunContextWrapper[AgentContext],
            job_id: str,
            show_history: bool = False,
        ) -> ToolOutputText:
            """Get status and execution history for a job.

            Args:
                job_id: Job identifier
                show_history: Whether to include execution history

            Returns:
                Job status and optionally execution history
            """
            job = self.get_job(job_id)
            if not job:
                return ToolOutputText(text=f"Job '{job_id}' not found.")

            lines = [
                f"Job: {job.name} (ID: {job.job_id})",
                f"Schedule: {job.schedule or f'once at {job.run_at}'}",
                f"Priority: {job.priority}",
                f"Status: {'enabled' if job.enabled else 'disabled'}",
            ]

            if job.next_run_time:
                lines.append(f"Next run: {job.next_run_time}")

            if show_history:
                history = self.get_execution_history(job_id, limit=5)
                if history:
                    lines.append("\nRecent executions:")
                    for exec in history:
                        status_info = exec.status.value
                        if exec.start_time:
                            time_info = exec.start_time.strftime("%Y-%m-%d %H:%M:%S")
                            lines.append(f"- {time_info}: {status_info}")
                        if exec.error:
                            lines.append(f"  Error: {exec.error}")

            return ToolOutputText(text="\n".join(lines))

        return get_job_status
