"""APScheduler-based scheduler plugin implementation.

This module provides a concrete scheduler implementation using APScheduler
for job scheduling and execution.
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Union
from uuid import uuid4

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger

from .base import (
    JobConfig,
    JobExecution,
    JobInfo,
    JobStatus,
    RetryStrategy,
    SchedulerBackendPlugin,
)

logger = logging.getLogger(__name__)


class PriorityJobQueue:
    """Simple priority queue for job execution."""

    def __init__(self, max_concurrent: int = 5):
        self.max_concurrent = max_concurrent
        self._queue: List[tuple[int, float, str, Callable, Dict]] = []
        self._running: Set[str] = set()
        self._lock = threading.RLock()

    def enqueue(
        self,
        execution_id: str,
        target: Callable,
        context: Dict,
        priority: int
    ) -> None:
        """Add job to queue."""
        with self._lock:
            # Store as (priority, timestamp, execution_id, target, context)
            # Sort by priority (high to low), then timestamp (FIFO)
            self._queue.append((-priority, time.time(), execution_id, target, context))
            self._queue.sort()
            logger.debug(f"Job {execution_id} queued with priority {priority}")

    def dequeue(self) -> Optional[tuple[str, Callable, Dict]]:
        """Get next job if under concurrency limit."""
        with self._lock:
            if len(self._running) >= self.max_concurrent:
                return None

            if not self._queue:
                return None

            _, _, execution_id, target, context = self._queue.pop(0)
            self._running.add(execution_id)
            return execution_id, target, context

    def mark_completed(self, execution_id: str) -> None:
        """Mark job as completed."""
        with self._lock:
            self._running.discard(execution_id)


@dataclass
class APSchedulerBackendPlugin(SchedulerBackendPlugin):
    """APScheduler-based scheduler implementation.

    Supports simplified usage:
        agent = Agent(
            model="gpt-5-mini-2025-08-07",
            scheduler=APSchedulerBackendPlugin(
                agent_factory=True,  # Use same agent
                max_concurrent_jobs=3,
                start=True  # Auto-start
            )
        )
    """

    # Plugin metadata
    id: str = "apscheduler"
    name: str = "APScheduler Backend"
    version: str = "1.0.0"

    # Configuration
    agent_factory: Union[bool, Callable[[str], Any]] = None
    max_concurrent_jobs: int = 5
    history_file: Optional[str] = None
    auto_start: bool = False  # Auto-start flag (renamed from 'start' to avoid method conflict)

    # Internal state (not in init)
    _agent_instance: Optional[Any] = field(default=None, repr=False, init=False)
    _agent_factory: Optional[Callable[[str], Any]] = field(default=None, repr=False, init=False)
    _jobs: Dict[str, JobConfig] = field(default_factory=dict, repr=False, init=False)
    _history: Dict[str, List[JobExecution]] = field(default_factory=lambda: defaultdict(list), repr=False, init=False)
    _history_file: Optional[Path] = field(default=None, repr=False, init=False)
    _lock: threading.RLock = field(default_factory=threading.RLock, repr=False, init=False)
    _running: bool = field(default=False, repr=False, init=False)
    scheduler: Optional[BackgroundScheduler] = field(default=None, repr=False, init=False)
    queue: Optional[PriorityJobQueue] = field(default=None, repr=False, init=False)
    _worker_thread: Optional[threading.Thread] = field(default=None, repr=False, init=False)

    def __post_init__(self):
        """Initialize APScheduler backend after dataclass init."""
        # Store auto-start flag (no longer needed as separate field since we renamed to auto_start)

        # Handle agent_factory
        if self.agent_factory is True:
            # Will be set by Agent._build() as self._agent_instance
            pass
        elif callable(self.agent_factory):
            self._agent_factory = self.agent_factory
        elif self.agent_factory is None:
            # No agent factory provided
            pass

        # Initialize components
        self._jobs = {}
        self._history = defaultdict(list)
        self._history_file = Path(self.history_file) if self.history_file else None
        self._lock = threading.RLock()
        self._running = False

        # Initialize scheduler and queue
        self.scheduler = BackgroundScheduler(timezone="UTC")
        self.queue = PriorityJobQueue(max_concurrent=self.max_concurrent_jobs)

        # Worker thread
        self._worker_thread = None

        # Load history if file exists
        if self._history_file and self._history_file.exists():
            try:
                with open(self._history_file) as f:
                    data = json.load(f)
                    # Convert to JobExecution objects
                    for job_id, executions in data.items():
                        self._history[job_id] = [
                            JobExecution(
                                execution_id=e["execution_id"],
                                job_id=e["job_id"],
                                status=JobStatus(e["status"]),
                                start_time=datetime.fromisoformat(e["start_time"]) if e.get("start_time") else None,
                                end_time=datetime.fromisoformat(e["end_time"]) if e.get("end_time") else None,
                                output=e.get("output"),
                                error=e.get("error"),
                                retry_count=e.get("retry_count", 0),
                            )
                            for e in executions
                        ]
            except Exception as e:
                logger.warning(f"Failed to load history from {self._history_file}: {e}")

    def start(self) -> None:
        """Start the scheduler."""
        if not self._running:
            self.scheduler.start()
            self._running = True

            # Start worker thread
            self._worker_thread = threading.Thread(target=self._worker, daemon=True)
            self._worker_thread.start()

            logger.info("APScheduler backend started")

    def shutdown(self, wait: bool = True) -> None:
        """Shutdown the scheduler."""
        if self._running:
            self._running = False
            self.scheduler.shutdown(wait=wait)

            # Save history
            self._save_history()

            logger.info("APScheduler backend stopped")

    def _save_history(self) -> None:
        """Save execution history to file."""
        if not self._history_file:
            return

        try:
            data = {}
            for job_id, executions in self._history.items():
                data[job_id] = [
                    {
                        "execution_id": e.execution_id,
                        "job_id": e.job_id,
                        "status": e.status.value,
                        "start_time": e.start_time.isoformat() if e.start_time else None,
                        "end_time": e.end_time.isoformat() if e.end_time else None,
                        "output": e.output,
                        "error": e.error,
                        "retry_count": e.retry_count,
                    }
                    for e in executions
                ]

            self._history_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self._history_file, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save history: {e}")

    def _worker(self) -> None:
        """Worker thread that processes queued jobs."""
        while self._running:
            job_info = self.queue.dequeue()

            if job_info:
                execution_id, target, context = job_info
                self._execute_job(execution_id, target, context)
            else:
                time.sleep(0.1)

    def _execute_job(
        self,
        execution_id: str,
        target: Callable,
        context: Dict[str, Any]
    ) -> None:
        """Execute a job and record results."""
        job_id = context.get("job_id", "unknown")

        execution = JobExecution(
            execution_id=execution_id,
            job_id=job_id,
            status=JobStatus.RUNNING,
            start_time=datetime.now(timezone.utc),
        )

        try:
            # Execute target
            result = target(context)

            # Handle async results
            if asyncio.iscoroutine(result):
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    result = loop.run_until_complete(result)
                finally:
                    loop.close()

            execution.status = JobStatus.COMPLETED
            execution.output = str(result) if result else "Completed successfully"
            logger.info(f"Job {job_id} completed: {execution_id}")

        except Exception as e:
            execution.status = JobStatus.FAILED
            execution.error = str(e)
            logger.error(f"Job {job_id} failed: {e}", exc_info=True)

        finally:
            execution.end_time = datetime.now(timezone.utc)

            # Record execution
            with self._lock:
                self._history[job_id].append(execution)
                # Keep only last 100 executions per job
                if len(self._history[job_id]) > 100:
                    self._history[job_id] = self._history[job_id][-100:]

            self.queue.mark_completed(execution_id)

    def _schedule_job(self, job_id: str) -> None:
        """Callback when APScheduler fires a job."""
        with self._lock:
            config = self._jobs.get(job_id)
            if not config or not config.enabled:
                return

            # Create execution
            execution_id = f"{job_id}_{uuid4().hex[:8]}"
            context = {
                "job_id": job_id,
                **config.metadata,
            }

            # Enqueue for execution
            self.queue.enqueue(
                execution_id=execution_id,
                target=config.target,
                context=context,
                priority=config.priority
            )

    # ========================================================================
    # Abstract method implementations
    # ========================================================================

    def create_job(self, config: JobConfig) -> bool:
        """Create and schedule a new job."""
        with self._lock:
            if config.job_id in self._jobs:
                logger.error(f"Job {config.job_id} already exists")
                return False

            self._jobs[config.job_id] = config

            try:
                if config.schedule:
                    # Recurring job with CronTrigger
                    trigger = CronTrigger.from_crontab(
                        config.schedule,
                        timezone=config.timezone
                    )
                    self.scheduler.add_job(
                        func=self._schedule_job,
                        trigger=trigger,
                        args=[config.job_id],
                        id=config.job_id,
                        name=config.name,
                        replace_existing=True,
                    )
                elif config.run_at:
                    # One-time job with DateTrigger
                    run_at_dt = datetime.fromisoformat(config.run_at)
                    trigger = DateTrigger(
                        run_date=run_at_dt,
                        timezone=config.timezone
                    )
                    self.scheduler.add_job(
                        func=self._schedule_job,
                        trigger=trigger,
                        args=[config.job_id],
                        id=config.job_id,
                        name=config.name,
                        replace_existing=True,
                    )
                else:
                    logger.error(f"Job {config.job_id} has no schedule or run_at")
                    del self._jobs[config.job_id]
                    return False

                logger.info(f"Job {config.job_id} created successfully")
                return True

            except Exception as e:
                logger.error(f"Failed to create job {config.job_id}: {e}")
                if config.job_id in self._jobs:
                    del self._jobs[config.job_id]
                return False

    def update_job(self, job_id: str, updates: Dict[str, Any]) -> bool:
        """Update an existing job."""
        with self._lock:
            config = self._jobs.get(job_id)
            if not config:
                logger.error(f"Job {job_id} not found")
                return False

            try:
                # Update configuration
                for key, value in updates.items():
                    if hasattr(config, key):
                        setattr(config, key, value)

                # If schedule changed, reschedule
                if "schedule" in updates or "run_at" in updates or "enabled" in updates:
                    # Remove existing
                    try:
                        self.scheduler.remove_job(job_id)
                    except:
                        pass

                    # Re-add if enabled
                    if config.enabled and (config.schedule or config.run_at):
                        self.create_job(config)

                logger.info(f"Job {job_id} updated successfully")
                return True

            except Exception as e:
                logger.error(f"Failed to update job {job_id}: {e}")
                return False

    def delete_job(self, job_id: str) -> bool:
        """Delete a scheduled job."""
        with self._lock:
            if job_id not in self._jobs:
                logger.error(f"Job {job_id} not found")
                return False

            try:
                # Remove from APScheduler
                self.scheduler.remove_job(job_id)
            except:
                pass

            # Remove from config
            del self._jobs[job_id]

            logger.info(f"Job {job_id} deleted successfully")
            return True

    def list_jobs(self) -> List[JobInfo]:
        """List all scheduled jobs."""
        with self._lock:
            jobs = []
            for job_id, config in self._jobs.items():
                # Get next run time from APScheduler
                next_run = None
                try:
                    ap_job = self.scheduler.get_job(job_id)
                    if ap_job and ap_job.next_run_time:
                        next_run = ap_job.next_run_time.isoformat()
                except:
                    pass

                jobs.append(JobInfo(
                    job_id=config.job_id,
                    name=config.name,
                    schedule=config.schedule,
                    run_at=config.run_at,
                    priority=config.priority,
                    enabled=config.enabled,
                    next_run_time=next_run,
                ))

            return jobs

    def get_job(self, job_id: str) -> Optional[JobInfo]:
        """Get information about a specific job."""
        with self._lock:
            config = self._jobs.get(job_id)
            if not config:
                return None

            # Get next run time
            next_run = None
            try:
                ap_job = self.scheduler.get_job(job_id)
                if ap_job and ap_job.next_run_time:
                    next_run = ap_job.next_run_time.isoformat()
            except:
                pass

            return JobInfo(
                job_id=config.job_id,
                name=config.name,
                schedule=config.schedule,
                run_at=config.run_at,
                priority=config.priority,
                enabled=config.enabled,
                next_run_time=next_run,
            )

    def manually_trigger(
        self,
        job_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """Manually trigger a job execution."""
        with self._lock:
            config = self._jobs.get(job_id)
            if not config:
                logger.error(f"Job {job_id} not found")
                return None

            execution_id = f"{job_id}_manual_{uuid4().hex[:8]}"
            job_context = {
                "job_id": job_id,
                "manual": True,
                **config.metadata,
                **(context or {}),
            }

            self.queue.enqueue(
                execution_id=execution_id,
                target=config.target,
                context=job_context,
                priority=config.priority
            )

            logger.info(f"Job {job_id} manually triggered: {execution_id}")
            return execution_id

    def get_execution_history(
        self,
        job_id: str,
        limit: int = 10
    ) -> List[JobExecution]:
        """Get execution history for a job."""
        with self._lock:
            executions = self._history.get(job_id, [])
            return executions[-limit:]
