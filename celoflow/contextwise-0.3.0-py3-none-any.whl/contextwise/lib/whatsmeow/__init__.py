"""WhatsMeow plugin module for the contextwise agent.

This module provides WhatsMeow bridge integration for WhatsApp messaging
using a local Go-based WhatsApp client.

Exports:
    - Security utilities: validate_webhook_signature, is_development_mode, get_webhook_secret
    - Router utilities: create_whatsmeow_router, create_agent_message_handler
    - API utilities: typing_indicator, download_media, upload_media, send_text_message
    - Status utilities: check_server_status, check_webhook_health
"""

from .security import (
    is_development_mode,
    get_webhook_secret,
    get_verify_token,
    validate_webhook_signature,
    is_valid_jid,
)
from .router import (
    create_whatsmeow_router,
    create_agent_message_handler,
)
from .utils import (
    # Config
    get_whatsmeow_base_url,
    get_api_key,
    # Typing indicator
    typing_indicator,
    typing_indicator_async,
    # Media
    download_media,
    download_media_async,
    upload_media,
    upload_media_async,
    # Messages
    send_text_message,
    send_text_message_async,
    # Message utilities
    split_message_into_chunks,
    format_message_italics,
    WHATSMEOW_MAX_TEXT_LENGTH,
    # Server status
    check_server_status,
    check_server_status_async,
    check_webhook_health,
    check_webhook_health_async,
)

__all__ = [
    # Security utilities
    "is_development_mode",
    "get_webhook_secret",
    "get_verify_token",
    "validate_webhook_signature",
    "is_valid_jid",
    # Router utilities
    "create_whatsmeow_router",
    "create_agent_message_handler",
    # API utilities
    "get_whatsmeow_base_url",
    "get_api_key",
    "typing_indicator",
    "typing_indicator_async",
    "download_media",
    "download_media_async",
    "upload_media",
    "upload_media_async",
    "send_text_message",
    "send_text_message_async",
    # Message utilities
    "split_message_into_chunks",
    "format_message_italics",
    "WHATSMEOW_MAX_TEXT_LENGTH",
    # Server status
    "check_server_status",
    "check_server_status_async",
    "check_webhook_health",
    "check_webhook_health_async",
]
