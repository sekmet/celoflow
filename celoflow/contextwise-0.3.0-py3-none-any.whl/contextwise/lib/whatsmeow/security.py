"""Security utilities for WhatsMeow webhook validation.

This module provides functions for validating WhatsMeow webhook
signatures using HMAC-SHA256. It supports development mode
bypassing for easier local testing.

Functions:
    - is_development_mode: Check if APP_ENV is set to development
    - get_webhook_secret: Retrieve WHATSMEOW_WEBHOOK_SECRET from environment
    - validate_webhook_signature: Validate webhook payload signature
    - is_valid_jid: Validate WhatsApp JID format
"""

from __future__ import annotations

import hashlib
import hmac
import os
from typing import Optional


def is_development_mode() -> bool:
    """Check if the application is running in development mode.

    Development mode is determined by the APP_ENV environment variable.
    If not set, defaults to "development".

    Returns:
        True if APP_ENV is "development" (case-insensitive), False otherwise.
    """
    return os.getenv("APP_ENV", "development").lower() == "development"


def get_webhook_secret() -> str:
    """Get the WhatsMeow webhook secret from environment variables.

    Tries WHATSMEOW_WEBHOOK_SECRET first, then falls back to WEBHOOK_SECRET.

    Returns:
        The webhook secret environment variable value.

    Raises:
        ValueError: If neither WHATSMEOW_WEBHOOK_SECRET nor WEBHOOK_SECRET is set
            and not in development mode.
    """
    webhook_secret = os.getenv("WHATSMEOW_WEBHOOK_SECRET")
    if not webhook_secret:
        webhook_secret = os.getenv("WEBHOOK_SECRET")

    if not webhook_secret:
        if is_development_mode():
            return "development_secret"
        raise ValueError(
            "WHATSMEOW_WEBHOOK_SECRET or WEBHOOK_SECRET environment variable is not set"
        )

    return webhook_secret


def get_verify_token() -> str:
    """Get the WhatsMeow verify token from environment variables.

    Returns:
        The WHATSMEOW_VERIFY_TOKEN environment variable value.

    Raises:
        ValueError: If WHATSMEOW_VERIFY_TOKEN is not set and not in development mode.
    """
    verify_token = os.getenv("WHATSMEOW_VERIFY_TOKEN")

    if not verify_token:
        if is_development_mode():
            return "development_verify_token"
        raise ValueError("WHATSMEOW_VERIFY_TOKEN environment variable is not set")

    return verify_token


def validate_webhook_signature(
    payload: bytes,
    signature_header: Optional[str],
) -> bool:
    """Validate the webhook payload using SHA256 signature.

    In development mode, signature validation is bypassed to allow
    easier local testing without full API setup.

    Args:
        payload: The raw request payload bytes.
        signature_header: The X-Hub-Signature-256 header value.
            Expected format: "sha256=<hex_signature>"

    Returns:
        True if signature is valid or in development mode.
        False if signature is invalid or missing (in production).

    Security Notes:
        - Uses constant-time comparison to prevent timing attacks.
        - Development mode bypass should only be used for local testing.
    """
    # In development mode, bypass signature validation
    if is_development_mode():
        return True

    if not signature_header:
        return False

    # Extract signature from X-Hub-Signature-256 header format
    if signature_header.startswith("sha256="):
        expected_signature = signature_header[7:]
    else:
        expected_signature = signature_header

    try:
        webhook_secret = get_webhook_secret()
    except ValueError:
        return False

    # Calculate signature using HMAC-SHA256
    hmac_obj = hmac.new(
        webhook_secret.encode("utf-8"),
        payload,
        hashlib.sha256,
    )
    calculated_signature = hmac_obj.hexdigest()

    # Compare signatures using constant-time comparison to prevent timing attacks
    return hmac.compare_digest(calculated_signature, expected_signature)


def is_valid_jid(jid: str) -> bool:
    """Validate WhatsApp JID format.

    Args:
        jid: The JID string to validate.

    Returns:
        True if the JID format is valid, False otherwise.

    Examples:
        >>> is_valid_jid("5511999999999@s.whatsapp.net")
        True
        >>> is_valid_jid("123456789-1234567890@g.us")
        True
        >>> is_valid_jid("invalid")
        False
    """
    if not jid or not isinstance(jid, str):
        return False

    if "@" not in jid:
        return False

    local, domain = jid.split("@", 1)

    # Check valid domains
    #
    # In addition to classic WhatsApp JIDs, modern WhatsApp deployments can emit
    # LID (Linked ID) JIDs of the form: <numeric>@lid
    valid_domains = ["s.whatsapp.net", "g.us", "broadcast", "lid"]
    if domain not in valid_domains:
        return False

    # Check local part (basic validation)
    if not local or len(local) < 1:
        return False

    # For individual chats, local part should be numeric (allowing optional hyphens)
    if domain in ("s.whatsapp.net", "lid"):
        if not local.replace("-", "").isdigit():
            return False

    return True
