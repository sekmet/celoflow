"""FastAPI router for WhatsMeow webhook endpoints.

This module provides a factory function to create FastAPI routers for
handling WhatsMeow webhook events. It supports async message processing
with proper signature validation.

The router integrates utils functions for:
- typing_indicator: Show typing status on message receipt
- download_media: Download media attachments
- upload_media: Upload media for sending
- send_text_message: Send text responses
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional, TYPE_CHECKING

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request
from fastapi.responses import PlainTextResponse

from .security import validate_webhook_signature, get_verify_token, is_valid_jid
from .utils import (
    typing_indicator_async,
    download_media_async,
    send_text_message_async,
    check_server_status_async,
    normalize_whatsapp_jid,
)


if TYPE_CHECKING:
    from agents import Agent, Runner


logger = logging.getLogger(__name__)


def create_whatsmeow_router(
    channel: Any,
    *,
    async_message_handler: Optional[Callable[[Dict[str, Any]], Any]] = None,
    prefix: str = "",
) -> APIRouter:
    """Create a FastAPI router for WhatsMeow webhook endpoints.

    The router provides the following endpoints:
        - GET /status: Health check endpoint (proxies to WhatsMeow server)
        - GET /webhook: Webhook verification endpoint
        - POST /webhook: Message processing endpoint

    Args:
        channel: The WhatsmeowChannel instance with configuration.
        async_message_handler: Optional async handler for processing messages.
        prefix: Optional URL prefix for all routes.

    Returns:
        Configured FastAPI APIRouter instance.
    """
    router = APIRouter(prefix=prefix)

    @router.get("/status")
    async def status() -> Dict[str, Any]:
        """Health check endpoint that proxies to WhatsMeow server."""
        try:
            server_status = await check_server_status_async()
            return {
                "status": "available",
                "channel": "whatsmeow",
                "server": server_status,
            }
        except Exception as e:
            return {
                "status": "degraded",
                "channel": "whatsmeow",
                "error": str(e),
            }

    @router.get("/webhook")
    async def verify_webhook(request: Request) -> PlainTextResponse:
        """Handle WhatsMeow webhook verification.

        This implements the hub.mode/hub.verify_token/hub.challenge pattern
        used by Meta-style webhooks.
        """
        mode = request.query_params.get("hub.mode")
        token = request.query_params.get("hub.verify_token")
        challenge = request.query_params.get("hub.challenge")

        # Use channel's verify token if available, otherwise get from env
        verify_token = getattr(channel, "verify_token", None) or get_verify_token()

        if mode == "subscribe" and token == verify_token:
            if not challenge:
                raise HTTPException(status_code=400, detail="No challenge received")
            logger.info("Webhook verification successful")
            return PlainTextResponse(content=challenge)

        logger.warning(f"Webhook verification failed: mode={mode}, token mismatch")
        raise HTTPException(status_code=403, detail="Invalid verify token or mode")

    @router.post("/webhook")
    async def webhook(
        request: Request,
        background_tasks: BackgroundTasks,
    ) -> Dict[str, str]:
        """Handle incoming WhatsMeow messages.

        Validates signature, parses the CloudAPI-like webhook payload,
        and processes messages in background tasks.
        """
        try:
            payload = await request.body()
            signature = request.headers.get("X-Hub-Signature-256")

            if not validate_webhook_signature(payload, signature):
                logger.warning("Invalid webhook signature")
                raise HTTPException(status_code=403, detail="Invalid signature")

            body = await request.json()

            event_type = body.get("event_type")
            if event_type and event_type != "message":
                logger.debug(f"Ignoring non-message webhook event_type={event_type}")
                return {"status": "ignored"}

            # Validate WhatsMeow webhook data structure (CloudAPIWebhookPayload format)
            # Required fields: id, sender_jid, recipient_jid
            message_id = body.get("id")
            sender_jid = await normalize_whatsapp_jid(body.get("sender_jid"))
            recipient_jid = await normalize_whatsapp_jid(body.get("recipient_jid"))

            if not message_id or not sender_jid:
                logger.debug(f"Received webhook without required fields: {body}")
                return {"status": "ignored"}

            # Validate JID format
            if sender_jid and not is_valid_jid(sender_jid):
                logger.warning(f"Invalid sender JID format: {sender_jid}")
                return {"status": "ignored"}

            # Determine chat JID for responses
            is_from_me = body.get("is_from_me", False)
            if is_from_me:
                return {"status": "ignored"}
            chat_jid = sender_jid  # Already normalized

            # Build parsed message for handler
            parsed_message = {
                "id": message_id,
                "from": sender_jid,
                "to": recipient_jid,
                "chat_jid": chat_jid,
                "content": body.get("content", ""),
                "type": body.get("media_type", "text"),
                "media_type": body.get("media_type"),
                "is_group": body.get("is_group", False),
                "is_from_me": is_from_me,
                "timestamp": body.get("timestamp"),
                "raw": body,
            }

            # Process message
            if async_message_handler:
                background_tasks.add_task(async_message_handler, parsed_message)
            else:
                logger.info(
                    "Received WhatsMeow message",
                    extra={
                        "from": sender_jid,
                        "type": parsed_message.get("type"),
                        "content": parsed_message.get("content", "")[:100],
                    },
                )

            return {"status": "processing"}

        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Error processing webhook")
            raise HTTPException(status_code=500, detail=str(e))

    return router


def create_agent_message_handler(
    agent: "Agent",
    notification_plugin: Optional[Any] = None,
    *,
    use_typing_indicator: bool = True,
) -> Callable[[Dict[str, Any]], Any]:
    """Create an async message handler that runs the agent and sends response.

    This handler integrates:
        - typing_indicator_async: Shows typing before processing
        - download_media_async: Downloads media attachments
        - send_text_message_async: Sends text responses directly via API

    Args:
        agent: The contextwise agent to run.
        notification_plugin: Plugin for sending responses (uses send_text_message if None).
        use_typing_indicator: Whether to show typing indicator (default: True).

    Returns:
        Async message handler function.
    """

    async def handler(message: Dict[str, Any]) -> None:
        sender_jid = await normalize_whatsapp_jid(message.get("from", ""))
        chat_jid = await normalize_whatsapp_jid(message.get("chat_jid", sender_jid))
        content = message.get("content", "")
        message_id = message.get("id")
        message_type = message.get("type", "text")
        media_type = message.get("media_type")

        try:
            # Show typing indicator
            if use_typing_indicator and chat_jid:
                try:
                    await typing_indicator_async(chat_jid, typing=True)
                except Exception as e:
                    logger.warning(f"Typing indicator failed: {e}")

            # Handle media messages
            media_content = None
            if media_type and media_type not in ("text", None):
                # Media types: image/jpeg, image/png, video/mp4, audio/ogg, etc.
                try:
                    media_content = await download_media_async(message_id, chat_jid)
                    if isinstance(media_content, dict) and "error" in media_content:
                        logger.warning(f"Failed to download media: {media_content}")
                        media_content = None
                except Exception as e:
                    logger.warning(f"Failed to download media: {e}")

            # Run the agent
            response = await agent.chat_async(
                message=content,
                user_id=sender_jid,
                channel="whatsmeow",
                metadata={
                    "chat_jid": chat_jid,
                    "message_id": message_id,
                    "is_group": message.get("is_group", False),
                    "media_type": media_type,
                    "media_content": media_content,
                },
            )

            # Send response
            response_text = str(response) if response else ""

            if response_text:
                if notification_plugin:
                    await notification_plugin.send_message_async(
                        user_id=chat_jid,
                        text=response_text,
                        channel="whatsmeow",
                    )
                else:
                    error = await send_text_message_async(chat_jid, response_text)
                    if error:
                        logger.error(f"Failed to send message: {error}")

        except Exception:
            logger.exception("Error processing message")
            # Send error message
            error_msg = "Sorry, there was an error processing your message."
            try:
                if notification_plugin:
                    await notification_plugin.send_message_async(
                        user_id=chat_jid,
                        text=error_msg,
                        channel="whatsmeow",
                    )
                else:
                    await send_text_message_async(chat_jid, error_msg)
            except Exception:
                logger.exception("Failed to send error message")

        finally:
            if use_typing_indicator and chat_jid:
                try:
                    await typing_indicator_async(chat_jid, typing=False)
                except Exception as e:
                    logger.warning(f"Typing indicator failed: {e}")

    return handler
