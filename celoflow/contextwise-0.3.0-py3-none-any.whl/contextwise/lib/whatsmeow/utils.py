"""WhatsMeow API utility functions.

This module provides low-level utilities for interacting with the WhatsMeow
bridge server, including media handling, typing indicators, and message sending.

All functions use environment variables for configuration:
    - WHATSMEOW_BASE_URL: Base URL for the WhatsMeow server (default: http://localhost:8080/api)
    - WHATSMEOW_API_KEY: API key for authentication
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional, Union

import httpx
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# WhatsMeow message limits
WHATSMEOW_MAX_TEXT_LENGTH = 4096  # Maximum characters per text message
DEFAULT_BASE_URL = "http://localhost:8080/api"


def get_whatsmeow_base_url() -> str:
    """Get the WhatsMeow server base URL from environment.

    Returns:
        The WHATSMEOW_BASE_URL value or default.
    """
    return os.getenv("WHATSMEOW_BASE_URL", DEFAULT_BASE_URL)


def get_api_key() -> str:
    """Get WhatsMeow API key from environment.

    Returns:
        The WHATSMEOW_API_KEY value.

    Raises:
        ValueError: If WHATSMEOW_API_KEY is not set and not in development mode.
    """
    api_key = os.getenv("WHATSMEOW_API_KEY", "")
    if not api_key:
        if os.getenv("APP_ENV", "development").lower() == "development":
            return "development_api_key"
        raise ValueError("WHATSMEOW_API_KEY is not set")
    return api_key


def _get_auth_headers() -> Dict[str, str]:
    """Get authorization headers for WhatsMeow API requests.

    Returns:
        Headers dict with Authorization bearer token.
    """
    return {"Authorization": f"Bearer {get_api_key()}"}


def split_message_into_chunks(
    text: str,
    max_length: int = WHATSMEOW_MAX_TEXT_LENGTH,
    batch_size: int = 4000,
) -> list[str]:
    """Split a long message into chunks that fit WhatsMeow's character limit.

    Attempts to split on paragraph boundaries first, then sentences,
    then falls back to hard character splits.

    Args:
        text: The text to split.
        max_length: Maximum characters per chunk (default: 4096).
        batch_size: Target size for each batch (default: 4000).

    Returns:
        List of text chunks, each within max_length.
    """
    # Handle empty or whitespace-only text
    text = text.strip()
    if not text:
        return []

    if len(text) <= batch_size:
        return [text]

    chunks = []
    remaining = text

    while remaining:
        if len(remaining) <= batch_size:
            chunks.append(remaining)
            break

        # Try to find a good break point
        chunk = remaining[:batch_size]

        # Try paragraph break first
        break_pos = chunk.rfind("\n\n")
        if break_pos == -1 or break_pos < batch_size // 2:
            # Try sentence break
            for delimiter in [". ", "! ", "? ", "\n"]:
                pos = chunk.rfind(delimiter)
                if pos > batch_size // 2:
                    break_pos = pos + len(delimiter)
                    break

        if break_pos == -1 or break_pos < batch_size // 2:
            # Hard split at batch_size
            break_pos = batch_size

        chunks.append(remaining[:break_pos].strip())
        remaining = remaining[break_pos:].strip()

    return [c for c in chunks if c]  # Filter empty chunks


def format_message_italics(text: str) -> str:
    """Format message with WhatsApp italics (underscore wrapping).

    Args:
        text: The text to format.

    Returns:
        Text with each line wrapped in underscores for italics.
    """
    lines = text.split("\n")
    return "\n".join([f"_{line}_" if line.strip() else line for line in lines])


# ============================================================================
# Typing Indicator
# ============================================================================

def typing_indicator(chat_jid: str, typing: bool = True) -> Optional[Dict[str, Any]]:
    """Send a typing indicator to a chat.

    Args:
        chat_jid: The JID of the chat.
        typing: Whether to show typing (True) or stop (False).

    Returns:
        None on success, or an error dict on failure.
    """
    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/typing"
    headers = _get_auth_headers()

    data = {"chat_jid": chat_jid, "typing": typing}

    try:
        response = httpx.post(url, headers=headers, json=data, timeout=10.0)
        response.raise_for_status()
        return None
    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send typing indicator: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending typing indicator: {e}")
        return {"error": str(e)}


async def typing_indicator_async(
    chat_jid: str,
    typing: bool = True,
) -> Optional[Dict[str, Any]]:
    """Send a typing indicator to a chat (async).

    Args:
        chat_jid: The JID of the chat.
        typing: Whether to show typing (True) or stop (False).

    Returns:
        None on success, or an error dict on failure.
    """
    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/typing"
    headers = _get_auth_headers()

    data = {"chat_jid": chat_jid, "typing": typing}

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(url, headers=headers, json=data, timeout=10.0)
            response.raise_for_status()
            return None
    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send typing indicator: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending typing indicator: {e}")
        return {"error": str(e)}


# ============================================================================
# Media Functions
# ============================================================================

def download_media(message_id: str, chat_jid: str) -> Union[bytes, Dict[str, Any]]:
    """Download media from a WhatsMeow message.

    Args:
        message_id: The ID of the message containing media.
        chat_jid: The JID of the chat.

    Returns:
        The media content as bytes, or an error dict on failure.
    """
    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/download"
    headers = _get_auth_headers()

    data = {"message_id": message_id, "chat_jid": chat_jid}

    try:
        response = httpx.post(url, headers=headers, json=data, timeout=60.0)
        response.raise_for_status()
        result = response.json()

        if result.get("success") and result.get("path"):
            # Read the downloaded file
            with open(result["path"], "rb") as f:
                return f.read()
        return {"error": "Download failed or path not provided"}
    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to download media: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error downloading media: {e}")
        return {"error": str(e)}


async def download_media_async(
    message_id: str,
    chat_jid: str,
) -> Union[bytes, Dict[str, Any]]:
    """Download media from a WhatsMeow message (async).

    Args:
        message_id: The ID of the message containing media.
        chat_jid: The JID of the chat.

    Returns:
        The media content as bytes, or an error dict on failure.
    """
    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/download"
    headers = _get_auth_headers()

    data = {"message_id": message_id, "chat_jid": chat_jid}

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(url, headers=headers, json=data, timeout=60.0)
            response.raise_for_status()
            result = response.json()

            if result.get("success") and result.get("path"):
                # Read the downloaded file
                import aiofiles

                async with aiofiles.open(result["path"], "rb") as f:
                    return await f.read()
            return {"error": "Download failed or path not provided"}
    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to download media: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error downloading media: {e}")
        return {"error": str(e)}


def upload_media(
    media_data: bytes,
    mime_type: str,
    filename: str = "file",
) -> Union[str, Dict[str, Any]]:
    """Upload media to WhatsMeow server for sending.

    Args:
        media_data: The media content as bytes.
        mime_type: The MIME type of the media (e.g., "image/png").
        filename: The filename for the upload.

    Returns:
        The media path string on success, or an error dict on failure.
    """
    import tempfile

    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/upload"
    headers = _get_auth_headers()

    try:
        # Write to temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{filename}") as temp_file:
            temp_file.write(media_data)
            temp_path = temp_file.name

        try:
            with open(temp_path, "rb") as f:
                files = {"media": (filename, f, mime_type)}
                response = httpx.post(url, headers=headers, files=files, timeout=60.0)
                response.raise_for_status()
                result = response.json()
                media_path = result.get("path")
                if media_path:
                    return media_path
                return {"error": "Upload failed or path not provided"}
        finally:
            import os as os_module
            if os_module.path.exists(temp_path):
                os_module.unlink(temp_path)

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to upload media: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error uploading media: {e}")
        return {"error": str(e)}


async def upload_media_async(
    media_data: bytes,
    mime_type: str,
    filename: str = "file",
) -> Union[str, Dict[str, Any]]:
    """Upload media to WhatsMeow server for sending (async).

    Args:
        media_data: The media content as bytes.
        mime_type: The MIME type of the media (e.g., "image/png").
        filename: The filename for the upload.

    Returns:
        The media path string on success, or an error dict on failure.
    """
    import tempfile

    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/upload"
    headers = _get_auth_headers()

    try:
        # Write to temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{filename}") as temp_file:
            temp_file.write(media_data)
            temp_path = temp_file.name

        try:
            async with httpx.AsyncClient() as client:
                with open(temp_path, "rb") as f:
                    files = {"media": (filename, f, mime_type)}
                    response = await client.post(
                        url, headers=headers, files=files, timeout=60.0
                    )
                    response.raise_for_status()
                    result = response.json()
                    media_path = result.get("path")
                    if media_path:
                        return media_path
                    return {"error": "Upload failed or path not provided"}
        finally:
            import os as os_module
            if os_module.path.exists(temp_path):
                os_module.unlink(temp_path)

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to upload media: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error uploading media: {e}")
        return {"error": str(e)}


# ============================================================================
# Text Messages
# ============================================================================

def send_text_message(
    recipient: str,
    text: str,
    media_path: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Send a text message to a WhatsMeow recipient.

    Args:
        recipient: Recipient's JID (e.g., "5511999999999@s.whatsapp.net").
        text: The message text to send.
        media_path: Optional path to media file to attach.

    Returns:
        None on success, or an error dict on failure.
    """
    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/send"
    headers = _get_auth_headers()
    headers["Content-Type"] = "application/json"

    data = {"recipient": recipient, "message": text}
    if media_path:
        data["media_path"] = media_path

    try:
        response = httpx.post(url, headers=headers, json=data, timeout=30.0)
        response.raise_for_status()
        logger.debug(f"Text message sent to {recipient}")
        return None
    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send text message: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending text message: {e}")
        return {"error": str(e)}


async def send_text_message_async(
    recipient: str,
    text: str,
    media_path: Optional[str] = None,
    italics: bool = False,
) -> Optional[Dict[str, Any]]:
    """Send a text message to a WhatsMeow recipient (async).

    Automatically splits long messages into chunks if they exceed
    WhatsMeow's 4096 character limit.

    Args:
        recipient: Recipient's JID (e.g., "5511999999999@s.whatsapp.net").
        text: The message text to send.
        media_path: Optional path to media file to attach.
        italics: Whether to format the message in italics.

    Returns:
        None on success, or an error dict on failure.
    """
    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/send"
    headers = _get_auth_headers()
    headers["Content-Type"] = "application/json"

    # Split long messages into chunks
    chunks = split_message_into_chunks(text)
    if not chunks:
        return None

    try:
        async with httpx.AsyncClient() as client:
            for i, chunk in enumerate(chunks):
                # Format with italics if requested
                formatted_chunk = format_message_italics(chunk) if italics else chunk

                # Add batch prefix for multi-part messages
                if len(chunks) > 1:
                    formatted_chunk = f"[{i + 1}/{len(chunks)}] {formatted_chunk}"

                data = {"recipient": recipient, "message": formatted_chunk}

                # Only attach media to the first chunk
                if i == 0 and media_path:
                    data["media_path"] = media_path

                response = await client.post(
                    url, headers=headers, json=data, timeout=30.0
                )
                response.raise_for_status()

                if len(chunks) > 1:
                    logger.debug(
                        f"Text message chunk {i + 1}/{len(chunks)} sent to {recipient}"
                    )
                else:
                    logger.debug(f"Text message sent to {recipient}")

            return None

    except httpx.HTTPStatusError as e:
        logger.error(f"Failed to send text message: {e}")
        return {"error": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error sending text message: {e}")
        return {"error": str(e)}


# ============================================================================
# Server Status
# ============================================================================

def check_server_status() -> Dict[str, Any]:
    """Check if the WhatsMeow server is running and connected.

    Returns:
        Status dict with 'connected' boolean and optional 'error' message.
    """
    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/status"
    headers = _get_auth_headers()

    try:
        response = httpx.get(url, headers=headers, timeout=10.0)
        if response.status_code == 200:
            return response.json()
        return {"connected": False, "error": f"Status code: {response.status_code}"}
    except Exception as e:
        return {"connected": False, "error": str(e)}


async def check_server_status_async() -> Dict[str, Any]:
    """Check if the WhatsMeow server is running and connected (async).

    Returns:
        Status dict with 'connected' boolean and optional 'error' message.
    """
    base_url = get_whatsmeow_base_url()
    url = f"{base_url}/status"
    headers = _get_auth_headers()

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers, timeout=10.0)
            if response.status_code == 200:
                return response.json()
            return {"connected": False, "error": f"Status code: {response.status_code}"}
    except Exception as e:
        return {"connected": False, "error": str(e)}


def check_webhook_health() -> Dict[str, Any]:
    """Check if the WhatsMeow webhook endpoint is healthy.

    Returns:
        Health status dict.
    """
    # The webhook health endpoint is at /webhook/health (not /api/webhook/health)
    base_url = get_whatsmeow_base_url().replace("/api", "")
    url = f"{base_url}/webhook/health"

    try:
        response = httpx.get(url, timeout=10.0)
        if response.status_code == 200:
            return {"healthy": True, **response.json()}
        return {"healthy": False, "error": f"Status code: {response.status_code}"}
    except Exception as e:
        return {"healthy": False, "error": str(e)}


async def check_webhook_health_async() -> Dict[str, Any]:
    """Check if the WhatsMeow webhook endpoint is healthy (async).

    Returns:
        Health status dict.
    """
    # The webhook health endpoint is at /webhook/health (not /api/webhook/health)
    base_url = get_whatsmeow_base_url().replace("/api", "")
    url = f"{base_url}/webhook/health"

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, timeout=10.0)
            if response.status_code == 200:
                return {"healthy": True, **response.json()}
            return {"healthy": False, "error": f"Status code: {response.status_code}"}
    except Exception as e:
        return {"healthy": False, "error": str(e)}


class WhatsAppJIDConverter:
    """Client for WhatsApp JID Converter service."""
    
    def __init__(self, base_url: str = "http://localhost:9189"):
        self.base_url = base_url
        self.client = httpx.AsyncClient(timeout=30.0)
        self._cache: Dict[str, str] = {}  # phone -> lid cache
    
    async def health_check(self) -> bool:
        """Check if converter service is healthy and connected to WhatsApp."""
        try:
            response = await self.client.get(f"{self.base_url}/api/health")
            data = response.json()
            return (
                data.get("success", False) and 
                data.get("data", {}).get("whatsapp_connected", False)
            )
        except Exception as e:
            logger.error(f"JID Converter health check failed: {e}")
            return False
    
    async def phone_to_lid(self, phone_number: str) -> Optional[str]:
        """Convert phone number to LID format with caching."""
        # Check cache first
        if phone_number in self._cache:
            return self._cache[phone_number]
        
        try:
            payload = {"phone_number": phone_number}
            response = await self.client.post(
                f"{self.base_url}/api/convert/single",
                json=payload
            )
            data = response.json()
            
            if data.get("success"):
                # Use correct API field names: LIDUserID, not lid_user_id
                lid = data["data"].get("LIDUserID", "")
                if lid:
                    self._cache[phone_number] = lid
                    return lid
                else:
                    logger.warning(f"No LID found for phone {phone_number}")
                    return None
            else:
                logger.error(f"Conversion failed: {data.get('message')}")
                return None
                
        except Exception as e:
            logger.error(f"JID conversion error for {phone_number}: {e}")
            return None
    
    async def close(self):
        """Clean up HTTP client."""
        await self.client.aclose()


# Global converter instance
_jid_converter: Optional[WhatsAppJIDConverter] = None

async def get_jid_converter() -> WhatsAppJIDConverter:
    """Get or create global JID converter instance."""
    global _jid_converter
    if _jid_converter is None:
        # Load environment variables for configuration
        load_dotenv()
        base_url = os.getenv("WHATSAPP_JID_CONVERTER_URL", "http://localhost:9189")
        timeout = int(os.getenv("WHATSAPP_JID_CONVERTER_TIMEOUT", "30"))
        
        _jid_converter = WhatsAppJIDConverter(base_url=base_url)
        _jid_converter.client.timeout = timeout
        
        # Verify service is healthy
        if not await _jid_converter.health_check():
            logger.warning("JID Converter service not available")
    return _jid_converter

async def normalize_whatsapp_jid(jid: str) -> str:
    """Normalize WhatsApp JID to unified <ID>@lid format.
    
    This function handles the complex mapping between phone numbers (@s.whatsapp.net)
    and LIDs (@lid) using the WhatsApp JID Converter service.
    
    Args:
        jid: Original JID (either <ID>@lid or <PHONE>@s.whatsapp.net)
        
    Returns:
        Normalized JID in <ID>@lid format, or original JID if conversion fails
    """
    if not jid or '@' not in jid:
        return jid
    
    local_part, domain = jid.split('@', 1)
    
    # If already @lid, return as-is
    if domain == 'lid':
        return jid
    
    # Convert @s.whatsapp.net to @lid using converter service
    if domain == 's.whatsapp.net':
        converter = await get_jid_converter()
        if converter:
            lid = await converter.phone_to_lid(local_part)
            if lid:
                return f"{lid}@lid"
            else:
                # Conversion failed, return original
                logger.warning(f"Failed to convert {local_part} to LID, using original")
                return jid
        else:
            # Service not available, return original
            logger.warning("JID Converter service unavailable, using original JID")
            return jid
    
    # Handle other domains (group chats, broadcasts) - leave unchanged
    return jid
