"""Session management for Contextwise agents.

This module provides comprehensive session lifecycle management including:
- Session CRUD operations
- Session metadata tracking
- Session export/import for backup and migration
- Session pruning and cleanup policies
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from agents import TResponseInputItem

if TYPE_CHECKING:
    from ..storage import Storage

logger = logging.getLogger(__name__)


@dataclass
class SessionMetadata:
    """Metadata for a session."""
    
    session_id: str
    user_id: str
    created_at: datetime
    last_activity: datetime
    message_count: int = 0
    channel: str = "api"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        data = asdict(self)
        data['created_at'] = self.created_at.isoformat()
        data['last_activity'] = self.last_activity.isoformat()
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SessionMetadata:
        """Create from dictionary."""
        data = data.copy()
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['last_activity'] = datetime.fromisoformat(data['last_activity'])
        return cls(**data)


@dataclass
class SessionExport:
    """Exported session data for backup/migration."""
    
    metadata: SessionMetadata
    items: List[TResponseInputItem]
    export_time: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'metadata': self.metadata.to_dict(),
            'items': self.items,
            'export_time': self.export_time.isoformat(),
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SessionExport:
        """Create from dictionary."""
        return cls(
            metadata=SessionMetadata.from_dict(data['metadata']),
            items=data['items'],
            export_time=datetime.fromisoformat(data['export_time']),
        )
    
    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_json(cls, json_str: str) -> SessionExport:
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))


class SessionManager:
    """Manages session lifecycle and operations.
    
    Provides comprehensive session management including:
    - CRUD operations
    - Metadata tracking
    - Export/import capabilities
    - Session pruning and cleanup
    """
    
    def __init__(
        self,
        storage: Optional[Storage] = None,
        max_session_age_days: int = 30,
        max_inactive_days: int = 7,
    ):
        """Initialize session manager.
        
        Args:
            storage: Optional storage backend for persistent sessions
            max_session_age_days: Maximum age of sessions before pruning
            max_inactive_days: Maximum days of inactivity before pruning
        """
        self.storage = storage
        self.max_session_age_days = max_session_age_days
        self.max_inactive_days = max_inactive_days
        self._metadata_cache: Dict[str, SessionMetadata] = {}
        
        logger.info(
            f"SessionManager initialized with storage={storage is not None}, "
            f"max_age={max_session_age_days}d, max_inactive={max_inactive_days}d"
        )
    
    async def create_session(
        self,
        session_id: str,
        user_id: str,
        channel: str = "api",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> SessionMetadata:
        """Create a new session with metadata.
        
        Args:
            session_id: Unique session identifier
            user_id: User identifier
            channel: Communication channel (api, whatsapp, voice, etc.)
            metadata: Additional metadata
            
        Returns:
            SessionMetadata for the created session
        """
        now = datetime.now()
        session_meta = SessionMetadata(
            session_id=session_id,
            user_id=user_id,
            created_at=now,
            last_activity=now,
            message_count=0,
            channel=channel,
            metadata=metadata or {},
        )
        
        self._metadata_cache[session_id] = session_meta
        
        if self.storage:
            await self._persist_metadata(session_meta)
        
        logger.info(f"Created session {session_id} for user {user_id} on channel {channel}")
        return session_meta
    
    async def get_session_metadata(self, session_id: str) -> Optional[SessionMetadata]:
        """Get metadata for a session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            SessionMetadata if found, None otherwise
        """
        if session_id in self._metadata_cache:
            return self._metadata_cache[session_id]
        
        if self.storage:
            meta = await self._load_metadata(session_id)
            if meta:
                self._metadata_cache[session_id] = meta
            return meta
        
        return None
    
    async def update_session_activity(
        self,
        session_id: str,
        message_count_delta: int = 1,
    ) -> None:
        """Update session activity timestamp and message count.
        
        Args:
            session_id: Session identifier
            message_count_delta: Number of messages to add to count
        """
        meta = await self.get_session_metadata(session_id)
        if not meta:
            logger.warning(f"Cannot update activity for non-existent session {session_id}")
            return
        
        meta.last_activity = datetime.now()
        meta.message_count += message_count_delta
        
        if self.storage:
            await self._persist_metadata(meta)
    
    async def delete_session(self, session_id: str) -> bool:
        """Delete a session and its metadata.
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if session was deleted, False if not found
        """
        found = session_id in self._metadata_cache
        
        if found:
            del self._metadata_cache[session_id]
        
        if self.storage:
            await self._delete_metadata(session_id)
        
        if found:
            logger.info(f"Deleted session {session_id}")
        
        return found
    
    async def export_session(
        self,
        session_id: str,
        items: List[TResponseInputItem],
    ) -> Optional[SessionExport]:
        """Export session data for backup or migration.
        
        Args:
            session_id: Session identifier
            items: Session conversation items
            
        Returns:
            SessionExport if session exists, None otherwise
        """
        meta = await self.get_session_metadata(session_id)
        if not meta:
            logger.warning(f"Cannot export non-existent session {session_id}")
            return None
        
        export = SessionExport(metadata=meta, items=items)
        logger.info(f"Exported session {session_id} with {len(items)} items")
        return export
    
    async def import_session(self, export: SessionExport) -> SessionMetadata:
        """Import session data from export.
        
        Args:
            export: SessionExport data
            
        Returns:
            SessionMetadata for the imported session
        """
        session_id = export.metadata.session_id
        self._metadata_cache[session_id] = export.metadata
        
        if self.storage:
            await self._persist_metadata(export.metadata)
        
        logger.info(
            f"Imported session {session_id} with {len(export.items)} items "
            f"from {export.export_time.isoformat()}"
        )
        return export.metadata
    
    async def list_sessions(
        self,
        user_id: Optional[str] = None,
        channel: Optional[str] = None,
    ) -> List[SessionMetadata]:
        """List sessions with optional filtering.
        
        Args:
            user_id: Filter by user ID
            channel: Filter by channel
            
        Returns:
            List of SessionMetadata matching filters
        """
        sessions = list(self._metadata_cache.values())
        
        if user_id:
            sessions = [s for s in sessions if s.user_id == user_id]
        
        if channel:
            sessions = [s for s in sessions if s.channel == channel]
        
        return sessions
    
    async def prune_sessions(self) -> int:
        """Prune old or inactive sessions based on configured policies.
        
        Returns:
            Number of sessions pruned
        """
        now = datetime.now()
        max_age = timedelta(days=self.max_session_age_days)
        max_inactive = timedelta(days=self.max_inactive_days)
        
        to_prune = []
        for session_id, meta in self._metadata_cache.items():
            age = now - meta.created_at
            inactive = now - meta.last_activity
            
            if age > max_age or inactive > max_inactive:
                to_prune.append(session_id)
        
        for session_id in to_prune:
            await self.delete_session(session_id)
        
        if to_prune:
            logger.info(f"Pruned {len(to_prune)} sessions")
        
        return len(to_prune)
    
    async def _persist_metadata(self, meta: SessionMetadata) -> None:
        """Persist metadata to storage backend."""
        if not self.storage:
            return
        
        key = f"session_metadata:{meta.session_id}"
        await self.storage.set(key, meta.to_dict())
    
    async def _load_metadata(self, session_id: str) -> Optional[SessionMetadata]:
        """Load metadata from storage backend."""
        if not self.storage:
            return None
        
        key = f"session_metadata:{session_id}"
        data = await self.storage.get(key)
        
        if data:
            return SessionMetadata.from_dict(data)
        
        return None
    
    async def _delete_metadata(self, session_id: str) -> None:
        """Delete metadata from storage backend."""
        if not self.storage:
            return
        
        key = f"session_metadata:{session_id}"
        await self.storage.delete(key)
