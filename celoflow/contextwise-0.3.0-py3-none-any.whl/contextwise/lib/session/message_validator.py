"""Message validation for Contextwise agents.

This module provides message type validation to ensure proper message sequences
according to OpenAI Agents SDK patterns, preventing invalid conversation states.
"""

from __future__ import annotations

import logging
from typing import List, Optional, Tuple

from agents import TResponseInputItem

logger = logging.getLogger(__name__)


class MessageValidationError(Exception):
    """Raised when message validation fails."""
    pass


class MessageValidator:
    """Validates message sequences and types.
    
    Ensures that messages follow proper SDK patterns:
    - function_call messages must be followed by function_call_output
    - function_call_output must have a corresponding function_call
    - Message sequences maintain conversation integrity
    """
    
    def __init__(self, strict_mode: bool = True):
        """Initialize message validator.
        
        Args:
            strict_mode: If True, raise errors on validation failures.
                        If False, log warnings but allow invalid sequences.
        """
        self.strict_mode = strict_mode
        logger.info(f"MessageValidator initialized with strict_mode={strict_mode}")
    
    def validate_message(
        self,
        message: TResponseInputItem,
        previous_messages: Optional[List[TResponseInputItem]] = None,
    ) -> Tuple[bool, Optional[str]]:
        """Validate a single message in context of previous messages.
        
        Args:
            message: Message to validate
            previous_messages: Previous messages in the conversation
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if previous_messages is None:
            previous_messages = []
        
        message_type = message.get('type', 'unknown')
        
        if message_type == 'function_call_output':
            is_valid, error = self._validate_function_call_output(message, previous_messages)
            if not is_valid:
                return self._handle_validation_error(error)
        
        elif message_type == 'function_call':
            is_valid, error = self._validate_function_call(message)
            if not is_valid:
                return self._handle_validation_error(error)
        
        return True, None
    
    def validate_sequence(
        self,
        messages: List[TResponseInputItem],
    ) -> Tuple[bool, Optional[str]]:
        """Validate an entire message sequence.
        
        Args:
            messages: List of messages to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        pending_function_calls = {}
        
        for i, message in enumerate(messages):
            message_type = message.get('type', 'unknown')
            
            if message_type == 'function_call':
                call_id = message.get('call_id')
                if call_id:
                    pending_function_calls[call_id] = i
            
            elif message_type == 'function_call_output':
                call_id = message.get('call_id')
                if not call_id:
                    error = f"function_call_output at index {i} missing call_id"
                    return self._handle_validation_error(error)
                
                if call_id not in pending_function_calls:
                    error = (
                        f"function_call_output at index {i} has call_id '{call_id}' "
                        f"with no corresponding function_call"
                    )
                    return self._handle_validation_error(error)
                
                del pending_function_calls[call_id]
        
        if pending_function_calls:
            error = (
                f"Sequence has {len(pending_function_calls)} unresolved function_call(s): "
                f"{list(pending_function_calls.keys())}"
            )
            if self.strict_mode:
                logger.warning(error)
            return True, None
        
        return True, None
    
    def _validate_function_call(
        self,
        message: TResponseInputItem,
    ) -> Tuple[bool, Optional[str]]:
        """Validate a function_call message.
        
        Args:
            message: function_call message
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not message.get('call_id'):
            return False, "function_call message missing call_id"
        
        if not message.get('name'):
            return False, "function_call message missing function name"
        
        return True, None
    
    def _validate_function_call_output(
        self,
        message: TResponseInputItem,
        previous_messages: List[TResponseInputItem],
    ) -> Tuple[bool, Optional[str]]:
        """Validate a function_call_output message.
        
        Args:
            message: function_call_output message
            previous_messages: Previous messages in conversation
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        call_id = message.get('call_id')
        if not call_id:
            return False, "function_call_output message missing call_id"
        
        has_matching_call = any(
            msg.get('type') == 'function_call' and msg.get('call_id') == call_id
            for msg in previous_messages
        )
        
        if not has_matching_call:
            return False, f"function_call_output has call_id '{call_id}' with no matching function_call"
        
        return True, None
    
    def _handle_validation_error(
        self,
        error: str,
    ) -> Tuple[bool, Optional[str]]:
        """Handle a validation error based on strict_mode.
        
        Args:
            error: Error message
            
        Returns:
            Tuple of (is_valid, error_message)
            
        Raises:
            MessageValidationError: If strict_mode is True
        """
        if self.strict_mode:
            logger.error(f"Message validation failed: {error}")
            raise MessageValidationError(error)
        else:
            logger.warning(f"Message validation warning: {error}")
            return False, error
    
    def get_pending_function_calls(
        self,
        messages: List[TResponseInputItem],
    ) -> List[str]:
        """Get list of function call IDs that don't have outputs yet.
        
        Args:
            messages: List of messages to check
            
        Returns:
            List of call_ids for pending function calls
        """
        pending = {}
        
        for message in messages:
            message_type = message.get('type', 'unknown')
            
            if message_type == 'function_call':
                call_id = message.get('call_id')
                if call_id:
                    pending[call_id] = True
            
            elif message_type == 'function_call_output':
                call_id = message.get('call_id')
                if call_id and call_id in pending:
                    del pending[call_id]
        
        return list(pending.keys())
    
    def sanitize_sequence(
        self,
        messages: List[TResponseInputItem],
    ) -> List[TResponseInputItem]:
        """Remove invalid messages from a sequence to make it valid.
        
        This is a best-effort cleanup that removes:
        - function_call_output without matching function_call
        - Duplicate messages
        
        Args:
            messages: List of messages to sanitize
            
        Returns:
            Sanitized list of messages
        """
        sanitized = []
        seen_call_ids = set()
        pending_calls = {}
        
        for message in messages:
            message_type = message.get('type', 'unknown')
            
            if message_type == 'function_call':
                call_id = message.get('call_id')
                if call_id and call_id not in seen_call_ids:
                    sanitized.append(message)
                    pending_calls[call_id] = True
                    seen_call_ids.add(call_id)
            
            elif message_type == 'function_call_output':
                call_id = message.get('call_id')
                if call_id and call_id in pending_calls:
                    sanitized.append(message)
                    del pending_calls[call_id]
                else:
                    logger.warning(
                        f"Removing orphaned function_call_output with call_id '{call_id}'"
                    )
            
            else:
                sanitized.append(message)
        
        removed_count = len(messages) - len(sanitized)
        if removed_count > 0:
            logger.info(f"Sanitized sequence: removed {removed_count} invalid messages")
        
        return sanitized
