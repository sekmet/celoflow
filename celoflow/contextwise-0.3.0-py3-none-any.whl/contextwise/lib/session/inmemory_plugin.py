from __future__ import annotations

from typing import Dict, List, Optional

from agents import Agent, RunConfig, Session, SessionABC, TResponseInputItem

from ..context import AgentContext
from ..base import AgentPlugin


class InMemorySession(SessionABC):
    """Simple in-memory implementation of the Session protocol."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        self._items: List[TResponseInputItem] = []

    async def get_items(self, limit: Optional[int] = None) -> List[TResponseInputItem]:
        if limit is None or limit >= len(self._items):
            return list(self._items)
        return list(self._items[-limit:])

    async def add_items(self, items: List[TResponseInputItem]) -> None:
        self._items.extend(items)

    async def pop_item(self) -> Optional[TResponseInputItem]:
        if not self._items:
            return None
        return self._items.pop()

    async def clear_session(self) -> None:
        self._items.clear()


class InMemorySessionBackendPlugin(AgentPlugin):
    """Plugin that manages in-memory Session instances per user or session id."""

    id = "session-backend"
    name = "In-memory session backend plugin"

    def __init__(self) -> None:
        self._sessions: Dict[str, Session] = {}

    def get_session(self, context: AgentContext) -> Session:
        key = context.session_id or context.user_id
        session = self._sessions.get(key)
        if session is None:
            session = InMemorySession(session_id=key)
            self._sessions[key] = session
        return session

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        return agent

    def configure_run_config(
        self,
        context: AgentContext,
        base_config: Optional[RunConfig],
    ) -> RunConfig:
        if base_config is None:
            return RunConfig(workflow_name="Agent workflow")
        return base_config
