"""Chat history service for business logic.

This module provides a service layer for chat history operations,
abstracting storage details and providing high-level operations.
"""

from __future__ import annotations

import logging
import os
import time
import uuid
from typing import Any, Dict, List, Optional

from ..storage import ChatHistoryStorage
from ..storage.chat_history_models import ChatMessage, ChatSessionDetail, ChatSessionSummary

logger = logging.getLogger(__name__)


class ChatHistoryService:
    """Service layer for chat history operations.
    
    This class provides high-level operations for managing chat sessions
    and messages, abstracting the storage layer details.
    
    Attributes:
        storage: ChatHistoryStorage instance for persistence
    
    Example:
        >>> storage = ChatHistoryStorage(db_url="postgresql://...")
        >>> service = ChatHistoryService(storage)
        >>> session_id = await service.create_session("user123", "agent456")
        >>> await service.save_message(session_id, "user", "Hello!")
    """
    
    def __init__(self, storage: ChatHistoryStorage):
        """Initialize chat history service.
        
        Args:
            storage: ChatHistoryStorage instance for persistence
        """
        self.storage = storage
        # Ensure schema is upgraded
        self.storage.upgrade_schema()
        logger.info("ChatHistoryService initialized")
    
    async def create_session(
        self,
        user_id: str,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        provider_type: str = "openai",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Create a new chat session.
        
        Args:
            user_id: User who owns the session
            agent_id: Agent associated with the session
            session_id: Optional session ID (generated if not provided)
            provider_type: LLM provider type (openai, anthropic, etc.)
            metadata: Additional session metadata
            
        Returns:
            The created session ID
        """
        from ..storage.base import StorageSession
        
        session_id = session_id or str(uuid.uuid4())
        now = int(time.time())
        
        # Create base storage session
        session = StorageSession(
            session_id=session_id,
            user_id=user_id,
            agent_id=agent_id,
            channel="api",
            messages=[],
            session_data={
                "provider_type": provider_type,
                **(metadata or {})
            },
            created_at=now,
            updated_at=now,
        )
        
        # Save to storage
        self.storage.upsert(session)
        
        # Update chat-specific fields
        self.storage.update_session_metadata(session_id, {
            'session_status': 'active',
            'provider_type': provider_type,
            'last_message_at': now,
        })
        
        logger.info(f"Created chat session {session_id} for user {user_id}")
        return session_id
    
    async def get_session(self, session_id: str) -> Optional[ChatSessionDetail]:
        """Get detailed session information.
        
        Args:
            session_id: The session ID to retrieve
            
        Returns:
            ChatSessionDetail if found, None otherwise
        """
        return self.storage.get_chat_session(session_id)
    
    async def list_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        status: Optional[str] = "active",
        limit: int = 50,
        offset: int = 0,
    ) -> List[ChatSessionSummary]:
        """List chat sessions with filtering and pagination.
        
        Args:
            user_id: Filter by user ID
            agent_id: Filter by agent ID
            status: Filter by session status
            limit: Maximum number of sessions
            offset: Number of sessions to skip
            
        Returns:
            List of ChatSessionSummary objects
        """
        return self.storage.get_chat_sessions(
            user_id=user_id,
            agent_id=agent_id,
            status=status,
            limit=limit,
            offset=offset,
        )
    
    async def save_message(
        self,
        session_id: str,
        role: str,
        content: str,
        provider_message_id: Optional[str] = None,
        token_count: Optional[int] = None,
        latency_ms: Optional[int] = None,
        tool_calls: Optional[List[Dict[str, Any]]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ChatMessage:
        """Save a message to the session.
        
        Args:
            session_id: The session ID
            role: Message role (user, assistant, system, tool)
            content: Message content
            provider_message_id: Provider-specific message ID
            token_count: Token count for the message
            latency_ms: Generation latency (for assistant messages)
            tool_calls: Tool calls made by assistant
            metadata: Additional message metadata
            
        Returns:
            The created ChatMessage
        """
        message = ChatMessage(
            id=str(uuid.uuid4()),
            role=role,
            content=content,
            timestamp=int(time.time()),
            provider_message_id=provider_message_id,
            token_count=token_count,
            latency_ms=latency_ms,
            tool_calls=tool_calls,
            metadata=metadata or {},
        )
        
        success = self.storage.append_chat_message(session_id, message)
        
        if not success:
            raise ValueError(f"Failed to save message to session {session_id}")
        
        # Update token usage if provided
        if token_count:
            session = self.storage.get_chat_session(session_id)
            if session:
                new_usage = session.token_usage + token_count
                self.storage.update_session_metadata(session_id, {
                    'token_usage': new_usage
                })
        
        logger.debug(f"Saved {role} message to session {session_id}")
        return message
    
    async def get_conversation_history(
        self,
        session_id: str,
        max_messages: int = 50,
    ) -> List[Dict[str, str]]:
        """Get conversation history formatted for LLM context window.
        
        Args:
            session_id: The session ID
            max_messages: Maximum number of messages to return
            
        Returns:
            List of message dictionaries with role and content
        """
        return self.storage.get_conversation_history(session_id, max_messages)
    
    async def get_messages(
        self,
        session_id: str,
        limit: int = 100,
        before_timestamp: Optional[int] = None,
    ) -> List[ChatMessage]:
        """Get messages for a session with pagination.
        
        Args:
            session_id: The session ID
            limit: Maximum number of messages
            before_timestamp: Only get messages before this timestamp
            
        Returns:
            List of ChatMessage objects
        """
        session = self.storage.get_chat_session(session_id)
        if not session:
            return []
        
        messages = session.messages
        
        # Filter by timestamp if specified
        if before_timestamp is not None:
            messages = [m for m in messages if m.timestamp < before_timestamp]
        
        # Apply limit (most recent first)
        messages = messages[-limit:] if limit > 0 else messages
        
        return messages
    
    async def update_session_status(
        self,
        session_id: str,
        status: str,
    ) -> bool:
        """Update session status.
        
        Args:
            session_id: The session ID
            status: New status (active, archived, deleted)
            
        Returns:
            True if successful
        """
        return self.storage.update_session_metadata(session_id, {
            'session_status': status
        })
    
    async def update_provider_metadata(
        self,
        session_id: str,
        provider_type: str,
        thread_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Update provider metadata for the session.
        
        Args:
            session_id: The session ID
            provider_type: LLM provider type
            thread_id: Provider thread ID
            metadata: Additional provider metadata
            
        Returns:
            True if successful
        """
        return self.storage.update_provider_metadata(
            session_id, provider_type, thread_id, metadata
        )
    
    async def delete_session(
        self,
        session_id: str,
        soft_delete: bool = True,
    ) -> bool:
        """Delete a session.
        
        Args:
            session_id: The session ID
            soft_delete: If True, mark as deleted; if False, hard delete
            
        Returns:
            True if successful
        """
        if soft_delete:
            return await self.update_session_status(session_id, "deleted")
        else:
            self.storage.delete_session(session_id)
            return True
    
    async def sync_with_provider(
        self,
        session_id: str,
        provider_type: str,
    ) -> bool:
        """Sync local session with LLM provider.
        
        For providers with thread APIs (e.g., OpenAI Assistants),
        this syncs the local message history with the provider.
        
        Args:
            session_id: The session ID
            provider_type: Provider type to sync with
            
        Returns:
            True if sync was successful
        """
        session = await self.get_session(session_id)
        if not session:
            logger.warning(f"Session not found: {session_id}")
            return False
        
        # For now, this is a placeholder for provider-specific sync logic
        # Different providers will implement this differently
        
        if provider_type == "openai" and session.provider_thread_id:
            return await self._sync_with_openai_assistants(session_id, session)
        elif provider_type == "gemini" and session.provider_thread_id:
            return await self._sync_with_gemini_interactions(session_id, session)
        
        logger.debug(f"No sync available for provider {provider_type}")
        return False
    
    async def _sync_with_openai_assistants(self, session_id: str, session: ChatSessionDetail) -> bool:
        """Sync session with OpenAI Assistants API.
        
        Fetches messages from the OpenAI thread and updates local storage.
        This ensures local chat history stays in sync with OpenAI's thread state.
        
        Args:
            session_id: Local session ID
            session: ChatSessionDetail with provider thread information
            
        Returns:
            True if sync was successful, False otherwise
        """
        try:
            from openai import AsyncOpenAI
            
            # Get OpenAI API key from environment or session metadata
            api_key = None
            if hasattr(session, 'session_data') and session.session_data:
                api_key = session.session_data.get('openai_api_key')
            
            if not api_key:
                api_key = os.getenv('OPENAI_API_KEY')
            
            if not api_key:
                logger.warning("OpenAI API key not found for sync")
                return False
            
            client = AsyncOpenAI(api_key=api_key)
            
            # Fetch messages from the OpenAI thread
            thread_messages = await client.beta.threads.messages.list(
                thread_id=session.provider_thread_id,
                order="desc",  # Get newest first
                limit=100
            )
            
            # Convert OpenAI messages to ChatMessage format
            synced_messages = []
            for msg in thread_messages.data:
                role = "assistant" if msg.role == "assistant" else "user"
                
                # Extract content from text blocks
                content = ""
                if msg.content:
                    for content_block in msg.content:
                        if content_block.type == "text":
                            content += content_block.text.value
                
                # Create ChatMessage
                chat_message = ChatMessage(
                    id=msg.id or str(uuid.uuid4()),
                    role=role,
                    content=content,
                    timestamp=int(msg.created_at) if msg.created_at else int(time.time()),
                    provider_message_id=msg.id,
                    metadata={
                        "synced_from_openai": True,
                        "synced_at": int(time.time()),
                        "thread_id": session.provider_thread_id,
                        "message_metadata": msg.model_dump() if hasattr(msg, 'model_dump') else {}
                    }
                )
                synced_messages.append(chat_message)
            
            if synced_messages:
                # Update local storage with synced messages
                # First, clear existing messages to avoid duplicates
                self.storage.update_session_metadata(session_id, {"messages": []})
                
                # Add synced messages in chronological order (oldest first)
                for message in reversed(synced_messages):
                    self.storage.append_chat_message(session_id, message)
                
                # Update session metadata
                self.storage.update_session_metadata(session_id, {
                    "provider_metadata": {
                        **(session.provider_metadata or {}),
                        "last_sync_at": int(time.time()),
                        "synced_message_count": len(synced_messages)
                    }
                })
                
                logger.info(f"Synced {len(synced_messages)} messages from OpenAI thread {session.provider_thread_id}")
                return True
            else:
                logger.debug(f"No messages found in OpenAI thread {session.provider_thread_id}")
                return True
                
        except ImportError:
            logger.warning("OpenAI library not installed for sync")
            return False
        except Exception as e:
            logger.error(f"Failed to sync with OpenAI Assistants: {e}")
            return False
    
    async def _sync_with_gemini_interactions(self, session_id: str, session: ChatSessionDetail) -> bool:
        """Sync session with Google Gemini Interactions API.
        
        Fetches interaction details from Gemini and updates local storage.
        Note: Gemini API doesn't provide a list endpoint, so we sync individual interactions
        and rely on the provider_thread_id to track the conversation chain.
        
        Args:
            session_id: Local session ID
            session: ChatSessionDetail with provider thread information
            
        Returns:
            True if sync was successful, False otherwise
        """
        try:
            import google.generativeai as genai
            
            # Get Gemini API key from environment or session metadata
            api_key = None
            if hasattr(session, 'session_data') and session.session_data:
                api_key = session.session_data.get('gemini_api_key')
            
            if not api_key:
                api_key = os.getenv('GEMINI_API_KEY')
            
            if not api_key:
                logger.warning("Gemini API key not found for sync")
                return False
            
            # Configure the Gemini API
            genai.configure(api_key=api_key)
            
            # Parse the provider_thread_id which should contain the latest interaction ID
            # For Gemini, we store the latest interaction ID as the thread ID
            latest_interaction_id = session.provider_thread_id
            
            if not latest_interaction_id:
                logger.warning("No Gemini interaction ID found in provider_thread_id")
                return False
            
            # Get the interaction details using the REST API directly for more control
            import httpx
            
            api_url = f"https://generativelanguage.googleapis.com/v1beta/interactions/{latest_interaction_id}"
            headers = {"x-goog-api-key": api_key}
            
            async with httpx.AsyncClient() as client:
                response = await client.get(api_url, headers=headers)
                response.raise_for_status()
                interaction_data = response.json()
            
            # Convert Gemini interaction to ChatMessage format
            synced_messages = []
            
            # Extract input (user message)
            if 'input' in interaction_data and interaction_data['input']:
                user_content = ""
                if isinstance(interaction_data['input'], str):
                    user_content = interaction_data['input']
                elif isinstance(interaction_data['input'], dict) and 'content' in interaction_data['input']:
                    user_content = str(interaction_data['input']['content'])
                
                if user_content:
                    user_message = ChatMessage(
                        id=f"{latest_interaction_id}_user",
                        role="user",
                        content=user_content,
                        timestamp=int(time.time()),  # Gemini doesn't provide user timestamp
                        provider_message_id=latest_interaction_id,
                        metadata={
                            "synced_from_gemini": True,
                            "synced_at": int(time.time()),
                            "interaction_id": latest_interaction_id,
                            "interaction_data": {
                                "created": interaction_data.get("created"),
                                "model": interaction_data.get("model")
                            }
                        }
                    )
                    synced_messages.append(user_message)
            
            # Extract outputs (model responses)
            if 'outputs' in interaction_data and interaction_data['outputs']:
                for i, output in enumerate(interaction_data['outputs']):
                    assistant_content = ""
                    if output.get('type') == 'text' and 'text' in output:
                        assistant_content = output['text']
                    elif 'text' in output:
                        assistant_content = output['text']
                    
                    if assistant_content:
                        assistant_message = ChatMessage(
                            id=f"{latest_interaction_id}_assistant_{i}",
                            role="assistant",
                            content=assistant_content,
                            timestamp=int(time.time()),  # Use current time as fallback
                            provider_message_id=f"{latest_interaction_id}_output_{i}",
                            metadata={
                                "synced_from_gemini": True,
                                "synced_at": int(time.time()),
                                "interaction_id": latest_interaction_id,
                                "output_index": i,
                                "output_type": output.get('type', 'unknown'),
                                "interaction_data": {
                                    "created": interaction_data.get("created"),
                                    "updated": interaction_data.get("updated"),
                                    "model": interaction_data.get("model"),
                                    "status": interaction_data.get("status")
                                }
                            }
                        )
                        synced_messages.append(assistant_message)
            
            if synced_messages:
                # Update local storage with synced messages
                # For Gemini, we append messages rather than replacing to preserve local history
                for message in synced_messages:
                    self.storage.append_chat_message(session_id, message)
                
                # Update session metadata
                self.storage.update_session_metadata(session_id, {
                    "provider_metadata": {
                        **(session.provider_metadata or {}),
                        "last_sync_at": int(time.time()),
                        "synced_message_count": len(synced_messages),
                        "latest_interaction_id": latest_interaction_id
                    }
                })
                
                logger.info(f"Synced {len(synced_messages)} messages from Gemini interaction {latest_interaction_id}")
                return True
            else:
                logger.debug(f"No messages found in Gemini interaction {latest_interaction_id}")
                return True
                
        except ImportError:
            logger.warning("Google Generative AI library not installed for sync")
            return False
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error syncing with Gemini: {e.response.status_code} - {e.response.text}")
            return False
        except Exception as e:
            logger.error(f"Failed to sync with Gemini Interactions: {e}")
            return False
    
    async def get_session_stats(self, session_id: str) -> Dict[str, Any]:
        """Get statistics for a session.
        
        Args:
            session_id: The session ID
            
        Returns:
            Dictionary with session statistics
        """
        session = await self.get_session(session_id)
        if not session:
            return {}
        
        messages = session.messages
        
        # Calculate statistics
        user_messages = [m for m in messages if m.role == "user"]
        assistant_messages = [m for m in messages if m.role == "assistant"]
        
        total_latency = sum(m.latency_ms or 0 for m in assistant_messages)
        avg_latency = total_latency / len(assistant_messages) if assistant_messages else 0
        
        return {
            "session_id": session_id,
            "total_messages": len(messages),
            "user_messages": len(user_messages),
            "assistant_messages": len(assistant_messages),
            "token_usage": session.token_usage,
            "created_at": session.created_at,
            "last_message_at": session.last_message_at,
            "average_response_latency_ms": avg_latency,
            "provider_type": session.provider_type,
        }
