"""Chat History Plugin for Contextwise agents.

This plugin provides persistent chat history storage using PostgreSQL
through the ChatHistoryService.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from agents import Agent
from ..base import AgentPlugin
from ..context import AgentContext
from .chat_history_service import ChatHistoryService
from ..storage import ChatHistoryStorage

logger = logging.getLogger(__name__)


class ChatHistoryPlugin(AgentPlugin[AgentContext]):
    """Plugin for persistent chat history storage.
    
    This plugin automatically saves chat messages to PostgreSQL
    using the ChatHistoryService when the chat_history_db_url
    is configured on the Agent.
    
    Attributes:
        service: ChatHistoryService instance for persistence
        db_url: PostgreSQL database URL
        agent_name: Name of the agent (extracted during configuration)
        agent_id: ID of the agent (extracted during configuration)
    """
    
    id: str = "chat_history"
    name: str = "Chat History Plugin"
    version: str = "0.1.0"
    
    def __init__(self, db_url: str):
        """Initialize the chat history plugin.
        
        Args:
            db_url: PostgreSQL database URL for chat history storage
        """
        self.db_url = db_url
        self.service: Optional[ChatHistoryService] = None
        self._session_cache: Dict[str, str] = {}  # Maps context session_id to chat session_id
        self.agent_name: Optional[str] = None
        self.agent_id: Optional[str] = None
        
        # Initialize service immediately
        try:
            from ..storage import ChatHistoryStorage
            
            logger.info(f"Initializing chat history plugin with database: {self.db_url[:30]}...")
            storage = ChatHistoryStorage(db_url=self.db_url)
            self.service = ChatHistoryService(storage)
            logger.info("Chat history plugin initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize chat history plugin: {e}")
            # Don't raise here, let the plugin continue without service
            self.service = None
        
    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Configure the agent with chat history plugin.
        
        This plugin doesn't add tools, just hooks for saving chat history.
        Also extracts agent information for use in session creation.
        
        Args:
            agent: The agent to configure
            
        Returns:
            Configured agent
        """
        # Store agent information for use in session creation
        self.agent_name = getattr(agent, 'name', 'Unknown Agent')
        self.agent_id = getattr(agent, 'name', 'unknown_agent').lower().replace(' ', '_')
        
        # Detect provider type and native SDK usage
        self.provider_type = "unknown"
        self.use_native_sdk = False
        
        model = getattr(agent, 'model', None)
        if model:
            # Check if it's a Gemini model with native SDK
            if hasattr(model, 'provider') and model.provider == 'gemini':
                self.provider_type = "gemini"
                self.use_native_sdk = getattr(model, 'use_native_sdk', False)
                logger.info(f"ChatHistoryPlugin: Detected Gemini model with use_native_sdk={self.use_native_sdk}")
            elif hasattr(model, 'provider'):
                self.provider_type = model.provider
            elif isinstance(model, str) and 'gemini' in model.lower():
                self.provider_type = "gemini"
            # Add other provider detections as needed
            elif hasattr(model, 'provider') and model.provider == 'openai':
                self.provider_type = "openai"
        
        logger.info(f"ChatHistoryPlugin: Configured for agent '{self.agent_name}' (ID: {self.agent_id}) with provider '{self.provider_type}'")
        
        # Chat history plugin doesn't add tools, just hooks
        return agent
        
    def on_before_run(
        self,
        context: AgentContext,
        input: str,
    ) -> None:
        """Called before agent processes a message.
        
        Args:
            context: Agent context
            input: User message
        """
        # This is handled in on_before_run_async to ensure async operations
        pass
    
    async def on_before_run_async(
        self,
        context: AgentContext,
        input: str,
    ) -> None:
        """Called before agent processes a message (async version).
        
        Args:
            context: Agent context
            input: User message
        """
        logger.info(f"ChatHistoryPlugin.on_before_run_async called for session {context.session_id}")
        if not self.service:
            logger.warning("ChatHistoryService not available - skipping save")
            return
            
        try:
            # Get or create chat session
            session_id = self._get_or_create_session(context)
            logger.info(f"ChatHistoryPlugin: Using session_id {session_id}")
            
            # Ensure session exists in database before saving message
            await self._ensure_session_exists(context, session_id)
            
            # Save user message
            await self.service.save_message(
                session_id=session_id,
                role="user",
                content=input,
                metadata={
                    "channel": context.channel,
                    "locale": context.locale,
                    "user_id": context.user_id,
                }
            )
            
            logger.info(f"ChatHistoryPlugin: Saved user message for session {session_id}")
        except Exception as e:
            logger.error(f"ChatHistoryPlugin: Failed to save user message: {e}")
            raise
    
    def on_after_run(
        self,
        context: AgentContext,
        result: Any,
    ) -> None:
        """Called after agent processes a message.
        
        Args:
            context: Agent context
            result: Agent response result
        """
        # This is handled in on_after_run_async to ensure async operations
        pass
    
    async def on_after_run_async(
        self,
        context: AgentContext,
        result: Any,
    ) -> None:
        """Called after agent processes a message (async version).
        
        Args:
            context: Agent context
            result: Agent response result
        """
        logger.info(f"ChatHistoryPlugin.on_after_run_async called for session {context.session_id}")
        if not self.service:
            logger.warning("ChatHistoryService not available - skipping save")
            return
            
        try:
            # Get chat session
            session_id = self._session_cache.get(context.session_id)
            if not session_id:
                logger.warning(f"ChatHistoryPlugin: No session_id found for context.session_id {context.session_id}")
                return
                
            logger.info(f"ChatHistoryPlugin: Saving assistant response for session {session_id}")
            
            # Save assistant message
            response_text = getattr(result, 'final_output', '') or str(result)
            await self.service.save_message(
                session_id=session_id,
                role="assistant",
                content=response_text,
                metadata={
                    "channel": context.channel,
                    "locale": context.locale,
                    "user_id": context.user_id,
                }
            )
            
            logger.info(f"ChatHistoryPlugin: Saved assistant message for session {session_id}")
        except Exception as e:
            logger.error(f"ChatHistoryPlugin: Failed to save assistant message: {e}")
            raise
    
    def _get_or_create_session(self, context: AgentContext) -> str:
        """Get or create a chat session for the context.
        
        Args:
            context: Agent context
            
        Returns:
            Chat session ID
        """
        # Check cache first
        if context.session_id in self._session_cache:
            logger.info(f"ChatHistoryPlugin: Using cached session_id for {context.session_id}")
            return self._session_cache[context.session_id]
        
        # Create new session synchronously to ensure it exists before saving messages
        import uuid
        import asyncio
        
        chat_session_id = str(uuid.uuid4())
        self._session_cache[context.session_id] = chat_session_id
        logger.info(f"ChatHistoryPlugin: Created new chat_session_id {chat_session_id} for context.session_id {context.session_id}")
        
        # Create session immediately (synchronously)
        try:
            # Try to get the current event loop
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                # No running loop, create a new one
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            
            # Run the async session creation
            if loop.is_running():
                # If loop is running, create a task
                asyncio.create_task(self._create_session_async(context, chat_session_id))
            else:
                # If loop is not running, run the coroutine directly
                loop.run_until_complete(self._create_session_async(context, chat_session_id))
                
        except Exception as e:
            logger.error(f"ChatHistoryPlugin: Failed to create session async: {e}")
            # Continue anyway - the session will be created when needed
        
        return chat_session_id
    
    async def _ensure_session_exists(self, context: AgentContext, chat_session_id: str) -> None:
        """Ensure session exists in database before saving messages.
        
        Args:
            context: Agent context
            chat_session_id: Chat session ID
        """
        try:
            # Check if session exists
            session = await self.service.get_session(chat_session_id)
            if not session:
                # Create session if it doesn't exist
                await self.service.create_session(
                    user_id=context.user_id,
                    agent_id=self.agent_id or "unknown_agent",
                    session_id=chat_session_id,
                    provider_type=self.provider_type,
                    metadata={
                        "channel": context.channel,
                        "locale": context.locale,
                        "agent_name": self.agent_name or "Unknown Agent",
                        "use_native_sdk": self.use_native_sdk,
                    }
                )
                logger.info(f"ChatHistoryPlugin: Created new session {chat_session_id} in database")
            else:
                logger.debug(f"ChatHistoryPlugin: Session {chat_session_id} already exists")
        except Exception as e:
            logger.error(f"ChatHistoryPlugin: Failed to ensure session exists: {e}")
            raise
    
    async def _create_session_async(self, context: AgentContext, chat_session_id: str) -> None:
        """Create chat session asynchronously.
        
        Args:
            context: Agent context
            chat_session_id: Chat session ID
        """
        if not self.service:
            return
            
        try:
            await self.service.create_session(
                user_id=context.user_id,
                agent_id=self.agent_id or "unknown_agent",
                session_id=chat_session_id,
                provider_type=self.provider_type,
                metadata={
                    "channel": context.channel,
                    "locale": context.locale,
                    "agent_name": self.agent_name or "Unknown Agent",
                    "use_native_sdk": self.use_native_sdk,
                }
            )
            logger.debug(f"Created chat session {chat_session_id} for user {context.user_id}")
        except Exception as e:
            logger.error(f"Failed to create chat session: {e}")
    
    async def get_conversation_history(
        self, 
        session_id: str, 
        max_messages: int = 50
    ) -> List[Dict[str, str]]:
        """Get conversation history for a session.
        
        Args:
            session_id: Context session ID
            max_messages: Maximum number of messages to return
            
        Returns:
            List of message dictionaries with role and content
        """
        if not self.service:
            return []
            
        chat_session_id = self._session_cache.get(session_id)
        if not chat_session_id:
            return []
            
        try:
            return await self.service.get_conversation_history(chat_session_id, max_messages)
        except Exception as e:
            logger.error(f"Failed to get conversation history: {e}")
            return []
    
    async def close(self) -> None:
        """Close the chat history plugin."""
        if self.service:
            try:
                # Close the storage connection
                if hasattr(self.service.storage, 'close'):
                    self.service.storage.close()
                logger.info("Chat history plugin closed")
            except Exception as e:
                logger.error(f"Error closing chat history plugin: {e}")
