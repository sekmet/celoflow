"""Plugin permission model for TEE environments.

Defines an explicit permission system where each plugin must declare what
resources it needs access to. In TEE mode, undeclared access is denied.

Design decisions:
- Uses Python Flag enum for composable permissions (bitwise OR).
- PluginManifest provides static metadata for discovery and auditing.
- TEEAwarePlugin extends the existing AgentPlugin base class so it
  integrates seamlessly with the framework's PluginManager.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Flag, auto
from typing import TYPE_CHECKING

from ..base import AgentPlugin

if TYPE_CHECKING:
    pass


class PluginPermission(Flag):
    """Plugin permissions in TEE environment.

    Permissions are composable via bitwise OR::

        perms = PluginPermission.NETWORK_OPENAI | PluginPermission.STORAGE_READ_SESSION
    """

    # Network permissions
    NETWORK_AZURE_FORGE = auto()
    NETWORK_OPENAI = auto()
    NETWORK_WEB3 = auto()
    NETWORK_SUBGRAPH = auto()
    NETWORK_ALL = auto()

    # Storage permissions
    STORAGE_READ_SESSION = auto()
    STORAGE_WRITE_SESSION = auto()
    STORAGE_READ_MEMORY = auto()
    STORAGE_WRITE_MEMORY = auto()

    # TEE permissions
    TEE_SIGN = auto()
    TEE_ATTEST = auto()
    TEE_DERIVE_KEY = auto()

    # System permissions
    SYSTEM_EXEC = auto()
    SYSTEM_FILE_READ = auto()
    SYSTEM_FILE_WRITE = auto()


@dataclass
class PluginManifest:
    """Plugin manifest with permissions and metadata.

    Required for all plugins running in TEE mode.

    Attributes:
        name: Unique plugin name.
        version: Semantic version string.
        author: Author / contact email.
        permissions: Composed PluginPermission flags.
        trusted: If True, the plugin skips sandboxing.
    """

    name: str
    version: str
    author: str
    permissions: PluginPermission
    trusted: bool = False

    def validate(self) -> None:
        """Validate manifest contents.

        Raises:
            ValueError: If required fields are missing.
            PermissionError: If untrusted plugin requests NETWORK_ALL.
        """
        if not self.name:
            raise ValueError("Plugin name is required")
        if not self.version:
            raise ValueError("Plugin version is required")
        if (
            self.permissions & PluginPermission.NETWORK_ALL
            and not self.trusted
        ):
            raise PermissionError(
                "NETWORK_ALL permission requires trusted=True"
            )


class TEEAwarePlugin(AgentPlugin):
    """Base class for TEE-aware plugins.

    Subclasses **must** declare a ``MANIFEST`` class attribute
    of type :class:`PluginManifest`.

    Example::

        class MyPlugin(TEEAwarePlugin):
            MANIFEST = PluginManifest(
                name="MyPlugin",
                version="1.0.0",
                author="me@example.com",
                permissions=PluginPermission.NETWORK_OPENAI,
            )

            def configure_agent(self, agent):
                self.check_permission(PluginPermission.NETWORK_OPENAI)
                return agent
    """

    MANIFEST: PluginManifest

    def __init__(self) -> None:
        if not hasattr(self, "MANIFEST"):
            raise RuntimeError(
                f"Plugin {self.__class__.__name__} must declare a MANIFEST attribute"
            )
        self.MANIFEST.validate()
        super().__init__()

    def check_permission(self, permission: PluginPermission) -> None:
        """Check if plugin has the specified permission.

        Args:
            permission: Required permission flag.

        Raises:
            PermissionError: If the plugin lacks the permission.
        """
        if not (self.MANIFEST.permissions & permission):
            raise PermissionError(
                f"Plugin '{self.MANIFEST.name}' lacks permission: {permission.name}"
            )
