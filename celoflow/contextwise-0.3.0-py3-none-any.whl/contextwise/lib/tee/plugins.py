"""TEE-native plugins for Contextwise.

Built-in plugins that leverage TEE capabilities:
- TEEAuthPlugin: Agent identity, signing, and attestation tools.
- TEEMemoryPlugin: Encrypted fact storage scoped per user.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from cryptography.fernet import Fernet

from ..base import AgentPlugin
from .storage import EncryptedStorage

if TYPE_CHECKING:
    from .manager import TEEManager

logger = logging.getLogger(__name__)


class TEEAuthPlugin(AgentPlugin):
    """TEE authentication plugin (auto-enabled in TEE mode).

    Provides:
    - Agent identity from TEE
    - Signing capabilities
    - Attestation generation

    Args:
        tee_manager: TEEManager instance.
    """

    def __init__(self, tee_manager: TEEManager) -> None:
        self.tee_manager = tee_manager
        self.identity = tee_manager.derive_identity()

    def configure_agent(self, agent: Any) -> Any:
        """Add TEE tools to agent.

        Registers get_agent_address, sign_message, and generate_attestation
        as callable tools.
        """
        # Register TEE tools if agent supports tool registration
        if hasattr(agent, "tools") and isinstance(agent.tools, list):
            agent = agent.clone(
                tools=[
                    *agent.tools,
                    self.get_agent_address,
                    self.sign_message_tool,
                    self.generate_attestation,
                ],
            )
        return agent

    async def get_agent_address(self) -> str:
        """Get agent's address derived from TEE."""
        return self.identity.address

    async def sign_message_tool(self, message: str) -> str:
        """Sign message using TEE-derived key.

        Args:
            message: Message string to sign.

        Returns:
            Hex-encoded signature.
        """
        message_hash = hashlib.sha256(message.encode()).digest()
        signature = self.tee_manager.sign_message(message_hash)
        return signature.hex()

    async def generate_attestation(self, include_data: str = "") -> Dict[str, Any]:
        """Generate TEE attestation quote.

        Args:
            include_data: Optional data to include in attestation.

        Returns:
            Attestation dict with quote, event_log, and application_data.
        """
        app_data = include_data.encode() if include_data else b""
        return self.tee_manager.get_attestation(app_data)


class TEEMemoryPlugin(AgentPlugin):
    """TEE-aware memory plugin with encryption.

    Features:
    - Encrypted fact storage
    - User-scoped memories
    - Automatic encryption/decryption

    Args:
        tee_manager: TEEManager instance for key derivation.
    """

    def __init__(self, tee_manager: TEEManager) -> None:
        self.tee_manager = tee_manager
        encryption_key = Fernet.generate_key()
        self.storage = EncryptedStorage(encryption_key)

    def configure_agent(self, agent: Any) -> Any:
        """Add memory tools to agent."""
        if hasattr(agent, "tools") and isinstance(agent.tools, list):
            agent = agent.clone(
                tools=[
                    *agent.tools,
                    self.remember_fact,
                    self.recall_facts,
                    self.forget_fact,
                ],
            )
        return agent

    async def remember_fact(
        self,
        user_id: str,
        fact: str,
        category: str = "general",
    ) -> str:
        """Store user fact (encrypted).

        Args:
            user_id: User identifier.
            fact: Fact string to remember.
            category: Fact category for grouping.

        Returns:
            Confirmation message.
        """
        key = f"memory:{user_id}:{category}"
        facts: List[Dict[str, str]] = self.storage.get(key) or []
        facts.append({
            "fact": fact,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        self.storage.set(key, facts)
        return f"Remembered: {fact}"

    async def recall_facts(
        self,
        user_id: str,
        category: str = "general",
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Retrieve user facts (decrypted).

        Args:
            user_id: User identifier.
            category: Fact category.
            limit: Maximum number of facts to return.

        Returns:
            List of fact dicts.
        """
        key = f"memory:{user_id}:{category}"
        facts: List[Dict[str, Any]] = self.storage.get(key) or []
        return facts[-limit:]

    async def forget_fact(
        self,
        user_id: str,
        fact_index: int,
        category: str = "general",
    ) -> str:
        """Delete user fact by index.

        Args:
            user_id: User identifier.
            fact_index: Zero-based index of the fact to remove.
            category: Fact category.

        Returns:
            Confirmation or error message.
        """
        key = f"memory:{user_id}:{category}"
        facts: List[Dict[str, Any]] = self.storage.get(key) or []

        if 0 <= fact_index < len(facts):
            removed = facts.pop(fact_index)
            self.storage.set(key, facts)
            return f"Forgot: {removed['fact']}"
        else:
            return "Fact not found"
