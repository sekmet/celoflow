"""TEE Manager for Contextwise.

Central component that handles Dstack SDK lifecycle, key derivation,
attestation generation, and message signing.

Design decisions:
- Lazy-imports dstack_sdk and eth_account so the framework works without them.
- Falls back to a deterministic mock identity when the SDK is unavailable,
  allowing development and testing without a running TEE simulator.
- Uses deterministic key derivation path: "wallet/contextwise-{salt}" with
  domain as the purpose string, ensuring the same config always produces
  the same identity.

Failure points and mitigations:
- Dstack socket not running → clear error message pointing to simulator setup.
- eth-account not installed → graceful fallback with mock identity.
- Network timeout to Dstack → retry with exponential backoff in production.
"""

from __future__ import annotations

import hashlib
import logging
import os
from typing import Any, Dict, Optional, TYPE_CHECKING

from .identity import TEEIdentity

if TYPE_CHECKING:
    from .config import TEEConfig

logger = logging.getLogger(__name__)


class TEEManager:
    """Central TEE management for Contextwise agents.

    Responsibilities:
    - Dstack SDK client lifecycle
    - Deterministic key derivation and Ethereum account creation
    - TEE attestation quote generation
    - Message signing with TEE-derived keys

    Args:
        config: TEEConfig instance controlling TEE behavior.
    """

    def __init__(self, config: TEEConfig) -> None:
        self.config = config
        self._client: Any = None  # DstackClient when available
        self._account: Any = None  # eth_account.Account when available
        self._identity: Optional[TEEIdentity] = None
        self._using_mock: bool = False

        self._initialize_client()

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    def _initialize_client(self) -> None:
        """Initialize Dstack SDK client.

        Tries the configured endpoint first, then falls back to the
        DSTACK_SIMULATOR_ENDPOINT env var, then default socket.
        If dstack_sdk is not installed, sets _using_mock = True.
        """
        try:
            from dstack_sdk import DstackClient  # type: ignore[import-untyped]

            if self.config.dstack_endpoint:
                endpoint = self.config.dstack_endpoint
                if endpoint.startswith("unix:"):
                    endpoint = endpoint[5:]
                
                self._client = DstackClient(endpoint)
            else:
                endpoint = os.getenv("DSTACK_SIMULATOR_ENDPOINT")
                if endpoint:
                    if endpoint.startswith("unix:"):
                        endpoint = endpoint[5:]
                    self._client = DstackClient(endpoint)
                else:
                    self._client = DstackClient()

            logger.info("Dstack SDK client initialized")

        except ImportError:
            logger.warning(
                "dstack-sdk not installed — using mock TEE identity. "
                "Install with: uv add dstack-sdk"
            )
            self._using_mock = True
        except Exception as exc:
            logger.warning(f"Failed to connect to Dstack SDK: {exc} — using mock TEE identity")
            self._using_mock = True

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    def derive_identity(self) -> TEEIdentity:
        """Derive agent identity from TEE.

        Uses deterministic key derivation:
        - Path: ``wallet/contextwise-{salt}``
        - Purpose: ``domain``

        When running without the Dstack SDK, falls back to a deterministic
        mock identity derived from SHA-256 of domain+salt.

        Returns:
            TEEIdentity with address and public key.
        """
        if self._identity:
            return self._identity

        if self._using_mock:
            self._identity = self._derive_mock_identity()
            return self._identity

        # Real Dstack derivation
        path = f"wallet/contextwise-{self.config.salt}"
        purpose = self.config.domain

        try:
            key_result = self._client.get_key(path, purpose)
            private_key_bytes = key_result.decode_key()

            if isinstance(private_key_bytes, bytes):
                key_hex = "0x" + private_key_bytes.hex()
            else:
                key_hex = (
                    private_key_bytes
                    if private_key_bytes.startswith("0x")
                    else "0x" + private_key_bytes
                )

            from eth_account import Account  # type: ignore[import-untyped]

            self._account = Account.from_key(key_hex)

            self._identity = TEEIdentity(
                address=self._account.address,
                public_key=self._account.key.hex(),
                domain=self.config.domain,
                salt=self.config.salt,
            )
        except Exception as exc:
            logger.warning(f"Dstack key derivation failed: {exc} — falling back to mock")
            self._using_mock = True
            self._identity = self._derive_mock_identity()

        return self._identity

    def _derive_mock_identity(self) -> TEEIdentity:
        """Create a deterministic mock identity for development.

        Derives a fake Ethereum-style address from SHA-256 of domain+salt
        so the same config always produces the same identity.
        """
        seed = f"{self.config.domain}:{self.config.salt}"
        digest = hashlib.sha256(seed.encode()).hexdigest()
        mock_address = "0x" + digest[:40]
        mock_pubkey = digest

        logger.info(f"Mock TEE identity: {mock_address}")
        return TEEIdentity(
            address=mock_address,
            public_key=mock_pubkey,
            domain=self.config.domain,
            salt=self.config.salt,
        )

    # ------------------------------------------------------------------
    # Attestation
    # ------------------------------------------------------------------

    def get_attestation(self, application_data: bytes) -> Dict[str, Any]:
        """Generate TEE attestation quote.

        Args:
            application_data: Data to include in attestation (max 64 bytes).

        Returns:
            Dict with keys: quote, event_log, application_data, agent_address.
        """
        if self._using_mock:
            return self._get_mock_attestation(application_data)

        # Pad to 64 bytes
        padded_data = application_data.ljust(64, b"\x00")

        try:
            quote_result = self._client.get_quote(padded_data)
            return {
                "quote": quote_result.quote,
                "event_log": quote_result.event_log,
                "application_data": padded_data.hex(),
                "agent_address": self._identity.address if self._identity else None,
            }
        except Exception as exc:
            logger.error(f"Attestation generation failed: {exc}")
            return self._get_mock_attestation(application_data)

    def _get_mock_attestation(self, application_data: bytes) -> Dict[str, Any]:
        """Generate mock attestation for development."""
        padded_data = application_data.ljust(64, b"\x00")
        mock_quote = hashlib.sha256(b"mock-quote:" + padded_data).hexdigest()

        return {
            "quote": mock_quote,
            "event_log": "mock-event-log",
            "application_data": padded_data.hex(),
            "agent_address": self._identity.address if self._identity else None,
            "mock": True,
        }

    # ------------------------------------------------------------------
    # Signing
    # ------------------------------------------------------------------

    def sign_message(self, message: bytes) -> bytes:
        """Sign message using TEE-derived key.

        Args:
            message: Message hash to sign (32 bytes).

        Returns:
            Signature bytes (65 bytes for real, 32 bytes for mock).

        Raises:
            RuntimeError: If identity has not been derived yet.
        """
        if not self._identity:
            raise RuntimeError("TEE identity not initialized — call derive_identity() first")

        if self._using_mock or self._account is None:
            # Deterministic mock signature
            return hashlib.sha256(b"mock-sig:" + message).digest()

        signed = self._account.unsafe_sign_hash(message)
        return signed.signature

    def get_account(self) -> Any:
        """Get eth_account Account object.

        Returns:
            Account instance.

        Raises:
            RuntimeError: If identity has not been derived or running in mock mode.
        """
        if self._using_mock:
            raise RuntimeError("No real Account available in mock TEE mode")
        if not self._account:
            raise RuntimeError("TEE identity not initialized — call derive_identity() first")
        return self._account

    @property
    def is_mock(self) -> bool:
        """Whether the manager is operating in mock mode."""
        return self._using_mock
