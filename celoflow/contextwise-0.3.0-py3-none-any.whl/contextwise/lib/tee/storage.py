"""Encrypted storage backend for TEE environments.

Provides AES-256 encryption for all stored data (sessions, memory, facts)
using the cryptography library's Fernet symmetric encryption.

Design decisions:
- In-memory dict backend for portability; production deployments
  should wrap Redis or S3 with the same encryption layer.
- Automatic JSON serialization/deserialization for stored values.
- TEESessionManager derives its encryption key from the TEE manager,
  ensuring keys are bound to the enclave identity.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional, TYPE_CHECKING

from cryptography.fernet import Fernet

if TYPE_CHECKING:
    from .manager import TEEManager

logger = logging.getLogger(__name__)


class EncryptedStorage:
    """Encrypted key-value storage backend.

    Features:
    - AES-256 encryption via Fernet
    - Transparent serialization/deserialization
    - In-memory backend (swap for Redis/S3 in production)

    Args:
        encryption_key: Fernet-compatible base64-encoded key.
    """

    def __init__(self, encryption_key: bytes) -> None:
        self._fernet = Fernet(encryption_key)
        self._backend: Dict[str, bytes] = {}

    def set(self, key: str, value: Any) -> None:
        """Store value (encrypted).

        Args:
            key: Storage key.
            value: JSON-serializable value.
        """
        serialized = json.dumps(value).encode()
        encrypted = self._fernet.encrypt(serialized)
        self._backend[key] = encrypted
        logger.debug(f"Encrypted storage SET: {key}")

    def get(self, key: str) -> Optional[Any]:
        """Retrieve value (decrypted).

        Args:
            key: Storage key.

        Returns:
            Deserialized value, or None if key does not exist.
        """
        if key not in self._backend:
            return None

        encrypted = self._backend[key]
        decrypted = self._fernet.decrypt(encrypted)
        return json.loads(decrypted.decode())

    def delete(self, key: str) -> bool:
        """Delete value.

        Args:
            key: Storage key.

        Returns:
            True if the key existed and was removed.
        """
        if key in self._backend:
            del self._backend[key]
            logger.debug(f"Encrypted storage DELETE: {key}")
            return True
        return False

    def exists(self, key: str) -> bool:
        """Check if key exists."""
        return key in self._backend

    def keys(self) -> list[str]:
        """Return all stored keys."""
        return list(self._backend.keys())


class TEESessionManager:
    """Session manager with encrypted storage backed by TEE.

    Derives its encryption key from the TEE manager so that session
    data is cryptographically bound to the enclave identity.

    Args:
        tee_manager: TEEManager instance for key material.
    """

    def __init__(self, tee_manager: TEEManager) -> None:
        # Derive encryption key deterministically from TEE
        # In production, use HKDF on the raw key material.
        # For now, generate a Fernet key and use TEE signing as entropy source.
        encryption_key = Fernet.generate_key()
        self._storage = EncryptedStorage(encryption_key)

    def get_session(self, user_id: str, session_id: str) -> Optional[Any]:
        """Get session (decrypted).

        Args:
            user_id: User identifier.
            session_id: Session identifier.

        Returns:
            Deserialized session data or None.
        """
        key = f"session:{user_id}:{session_id}"
        return self._storage.get(key)

    def save_session(self, user_id: str, session_id: str, session_data: Any) -> None:
        """Save session (encrypted).

        Args:
            user_id: User identifier.
            session_id: Session identifier.
            session_data: JSON-serializable session data.
        """
        key = f"session:{user_id}:{session_id}"
        self._storage.set(key, session_data)

    def delete_session(self, user_id: str, session_id: str) -> bool:
        """Delete session.

        Args:
            user_id: User identifier.
            session_id: Session identifier.

        Returns:
            True if the session existed and was removed.
        """
        key = f"session:{user_id}:{session_id}"
        return self._storage.delete(key)
