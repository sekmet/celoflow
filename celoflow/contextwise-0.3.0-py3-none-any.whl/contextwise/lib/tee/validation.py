"""TEE configuration validation and environment detection.

Provides startup checks to ensure TEE configuration is correct,
and auto-detection of TEE environments (Dstack socket, TDX CPUID, etc.).
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def detect_tee_environment() -> bool:
    """Auto-detect if running inside a TEE.

    Checks:
    1. Dstack socket presence at ``/var/run/dstack.sock``
    2. ``DSTACK_SIMULATOR_ENDPOINT`` environment variable
    3. TDX guest device on Linux

    Returns:
        True if a TEE environment is detected.
    """
    # Check for Dstack socket
    if os.path.exists("/var/run/dstack.sock"):
        return True

    # Check for simulator endpoint
    if os.getenv("DSTACK_SIMULATOR_ENDPOINT"):
        return True

    # Check for TDX indicators (Linux)
    try:
        with open(
            "/sys/devices/virtual/tdx_guest/tdx_guest/tdx_guest_enabled",
            "r",
        ) as f:
            if f.read().strip() == "1":
                return True
    except (FileNotFoundError, PermissionError):
        pass

    return False


def validate_tee_configuration(agent: object) -> None:
    """Validate TEE configuration on startup.

    Checks:
    - TEE manager is initialized
    - Identity has been derived
    - Network restrictions are configured
    - Plugin permissions are valid
    - Storage encryption is enabled (if configured)
    - Attestation works (if required)

    Args:
        agent: Contextwise Agent instance.

    Raises:
        RuntimeError: If a critical TEE component is missing.
        ValueError: If configuration values are invalid.
    """
    tee = getattr(agent, "tee", None)
    if not tee or not tee.enabled:
        return

    logger.info("Validating TEE configuration...")

    # 1. Check TEE manager
    tee_manager = getattr(agent, "_tee_manager", None)
    if tee_manager is None:
        raise RuntimeError("TEE manager not initialized")

    # 2. Check identity
    tee_identity = getattr(agent, "_tee_identity", None)
    if tee_identity is None:
        raise RuntimeError("TEE identity not derived")
    logger.info(f"TEE identity: {tee_identity.address}")

    # 3. Check network restrictions
    if not tee.allowed_domains:
        raise ValueError("TEE network restrictions: no allowed domains configured")
    logger.info(f"Network restrictions: {len(tee.allowed_domains)} domains")

    # 4. Validate plugin permissions
    plugins = getattr(agent, "plugins", [])
    for plugin in plugins:
        if hasattr(plugin, "MANIFEST"):
            plugin.MANIFEST.validate()
    logger.info(f"Plugin permissions validated: {len(plugins)} plugins")

    # 5. Check storage encryption
    if tee.encrypt_sessions:
        logger.info("Session encryption enabled")

    # 6. Verify attestation if required
    if tee.require_attestation:
        try:
            attestation = agent.get_attestation()  # type: ignore[attr-defined]
            if "quote" not in attestation:
                raise RuntimeError("Attestation quote missing from result")
            logger.info("Attestation generation verified")
        except Exception as exc:
            raise RuntimeError(f"Attestation generation failed: {exc}")

    logger.info("TEE validation complete")
