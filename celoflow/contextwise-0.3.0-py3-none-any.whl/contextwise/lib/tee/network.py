"""Network restriction enforcement for TEE environments.

Provides domain whitelisting for outbound HTTP traffic. In TEE mode,
only requests to explicitly allowed domains are permitted.

Design decisions:
- Uses httpx event hooks for request-level validation rather than
  monkey-patching, so only TEE-managed clients are restricted.
- The global enforcement function patches httpx.AsyncClient methods
  as a last resort for frameworks that create their own HTTP clients.
"""

from __future__ import annotations

import logging
from typing import List, Optional
from urllib.parse import urlparse

import httpx

logger = logging.getLogger(__name__)


class TEENetworkRestrictor:
    """Enforces network egress restrictions in TEE.

    Features:
    - Domain whitelist enforcement
    - Egress proxy configuration
    - Request logging for audit
    - SSL certificate validation

    Args:
        allowed_domains: List of domain names (e.g., ["api.openai.com"]).
        egress_proxy: Optional HTTP proxy URL for all outbound traffic.
    """

    def __init__(
        self,
        allowed_domains: List[str],
        egress_proxy: Optional[str] = None,
    ) -> None:
        self.allowed_domains: set[str] = set(allowed_domains)
        self.egress_proxy = egress_proxy
        self._client: Optional[httpx.AsyncClient] = None

    def _create_client(self) -> httpx.AsyncClient:
        """Create HTTP client with domain restrictions."""
        transport = httpx.AsyncHTTPTransport(
            verify=True,
            retries=3,
        )

        restrictor = self  # capture for closure

        async def check_domain(request: httpx.Request) -> None:
            """Validate request domain against whitelist."""
            domain = urlparse(str(request.url)).netloc
            # Strip port if present
            domain = domain.split(":")[0]

            if domain not in restrictor.allowed_domains:
                raise PermissionError(
                    f"Domain '{domain}' not in TEE whitelist. "
                    f"Allowed: {sorted(restrictor.allowed_domains)}"
                )
            logger.debug(f"TEE egress: {request.method} {request.url}")

        proxy = self.egress_proxy
        return httpx.AsyncClient(
            transport=transport,
            proxy=proxy,
            event_hooks={"request": [check_domain]},
            timeout=30.0,
        )

    @property
    def client(self) -> httpx.AsyncClient:
        """Lazy-initialized restricted HTTP client."""
        if self._client is None:
            self._client = self._create_client()
        return self._client

    async def get(self, url: str, **kwargs: object) -> httpx.Response:
        """HTTP GET with domain validation."""
        return await self.client.get(url, **kwargs)

    async def post(self, url: str, **kwargs: object) -> httpx.Response:
        """HTTP POST with domain validation."""
        return await self.client.post(url, **kwargs)

    def add_allowed_domain(self, domain: str) -> None:
        """Add domain to whitelist at runtime."""
        self.allowed_domains.add(domain)
        logger.info(f"Added to TEE whitelist: {domain}")

    def is_domain_allowed(self, url: str) -> bool:
        """Check if a URL's domain is in the whitelist."""
        domain = urlparse(url).netloc.split(":")[0]
        return domain in self.allowed_domains

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None


# ---------------------------------------------------------------------------
# Global enforcement (use with caution)
# ---------------------------------------------------------------------------

_global_restrictor: Optional[TEENetworkRestrictor] = None


def enforce_tee_network_restrictions(
    allowed_domains: List[str],
    egress_proxy: Optional[str] = None,
) -> TEENetworkRestrictor:
    """Globally enforce network restrictions on all HTTP clients.

    .. warning::
        This patches ``httpx.AsyncClient`` globally.
        Use only in TEE environments.

    Args:
        allowed_domains: Domains to allow.
        egress_proxy: Optional egress proxy URL.

    Returns:
        The global TEENetworkRestrictor instance.
    """
    global _global_restrictor
    _global_restrictor = TEENetworkRestrictor(allowed_domains, egress_proxy)

    _original_get = httpx.AsyncClient.get
    _original_post = httpx.AsyncClient.post

    async def restricted_get(self: httpx.AsyncClient, url: str, **kwargs: object) -> httpx.Response:
        domain = urlparse(str(url)).netloc.split(":")[0]
        if _global_restrictor and domain not in _global_restrictor.allowed_domains:
            raise PermissionError(f"Domain '{domain}' blocked by TEE policy")
        return await _original_get(self, url, **kwargs)

    async def restricted_post(self: httpx.AsyncClient, url: str, **kwargs: object) -> httpx.Response:
        domain = urlparse(str(url)).netloc.split(":")[0]
        if _global_restrictor and domain not in _global_restrictor.allowed_domains:
            raise PermissionError(f"Domain '{domain}' blocked by TEE policy")
        return await _original_post(self, url, **kwargs)

    httpx.AsyncClient.get = restricted_get  # type: ignore[assignment]
    httpx.AsyncClient.post = restricted_post  # type: ignore[assignment]

    logger.info(
        f"TEE network restrictions enabled — {len(allowed_domains)} domains whitelisted"
    )
    return _global_restrictor
