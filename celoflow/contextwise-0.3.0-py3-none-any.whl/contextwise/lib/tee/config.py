"""TEE environment configuration for Contextwise agents.

Defines the TEEConfig dataclass that controls all TEE behavior:
network restrictions, plugin sandboxing, audit logging, attestation,
and encrypted storage.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass
class TEEConfig:
    """TEE environment configuration.

    Controls all TEE-specific behavior including key derivation,
    network restrictions, plugin security, and storage encryption.

    Attributes:
        enabled: Whether TEE mode is active.
        dstack_endpoint: Dstack SDK endpoint (Unix socket or HTTP URL).
            If None, auto-detected from environment.
        domain: Domain identifier used for key derivation context.
        salt: Salt string for deterministic key derivation.
        allowed_domains: List of domains permitted for outbound HTTP.
        egress_proxy: Optional HTTP proxy URL for all outbound traffic.
        enable_plugin_sandboxing: If True, untrusted plugins run in subprocesses.
        enable_audit_logging: If True, all agent actions are audit-logged.
        require_attestation: If True, TEE attestation is verified on startup.
        encrypt_sessions: If True, session data is encrypted at rest.
        encrypt_memory: If True, memory/fact data is encrypted at rest.
        storage_backend: Storage backend type (e.g., "encrypted-redis", "encrypted-s3").
    """

    enabled: bool = False
    dstack_endpoint: Optional[str] = None
    domain: str = "agent.contextwise"
    salt: str = "production-v1"

    # Network restrictions
    allowed_domains: List[str] = field(default_factory=lambda: [
        "social-syn-resource.services.ai.azure.com",
        "api.openai.com",
        "gateway.thegraph.com",
    ])
    egress_proxy: Optional[str] = None

    # Security
    enable_plugin_sandboxing: bool = True
    enable_audit_logging: bool = True
    require_attestation: bool = False

    # Storage
    encrypt_sessions: bool = True
    encrypt_memory: bool = True
    storage_backend: str = "encrypted-redis"

    def validate(self) -> None:
        """Validate configuration values.

        Raises:
            ValueError: If configuration is invalid.
        """
        if self.enabled and not self.domain:
            raise ValueError("TEEConfig.domain is required when TEE is enabled")

        if self.enabled and not self.salt:
            raise ValueError("TEEConfig.salt is required when TEE is enabled")

        if self.enabled and not self.allowed_domains:
            logger.warning(
                "TEEConfig has no allowed_domains — all outbound HTTP will be blocked"
            )

    def add_allowed_domain(self, domain: str) -> None:
        """Add a domain to the whitelist.

        Args:
            domain: Domain name to allow (e.g., "api.example.com").
        """
        if domain not in self.allowed_domains:
            self.allowed_domains.append(domain)
            logger.info(f"Added to TEE whitelist: {domain}")

    def remove_allowed_domain(self, domain: str) -> None:
        """Remove a domain from the whitelist.

        Args:
            domain: Domain name to remove.
        """
        if domain in self.allowed_domains:
            self.allowed_domains.remove(domain)
            logger.info(f"Removed from TEE whitelist: {domain}")
