"""Virtual filesystem for TEE environments.

Provides an in-memory, encrypted filesystem that avoids persistent
storage on the host, as required by TEE constraints.

Design decisions:
- All data is held in memory and encrypted at rest via Fernet.
- No actual filesystem I/O occurs, preventing host-level data leakage.
- Path-based API mirrors standard file operations for ease of use.
"""

from __future__ import annotations

import logging
from typing import Dict, List

from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)


class TEEFilesystem:
    """Virtual filesystem for TEE with encryption.

    Features:
    - In-memory file operations
    - Encryption at rest
    - No host filesystem access
    - Path-based API

    Args:
        encryption_key: Fernet-compatible base64-encoded key.
    """

    def __init__(self, encryption_key: bytes) -> None:
        self._files: Dict[str, bytes] = {}
        self._fernet = Fernet(encryption_key)

    def write(self, path: str, data: bytes) -> None:
        """Write file (encrypted).

        Args:
            path: Virtual file path.
            data: Raw file data.
        """
        encrypted = self._fernet.encrypt(data)
        self._files[path] = encrypted
        logger.debug(f"TEE FS write: {path} ({len(data)} bytes)")

    def read(self, path: str) -> bytes:
        """Read file (decrypted).

        Args:
            path: Virtual file path.

        Returns:
            Decrypted file data.

        Raises:
            FileNotFoundError: If the path does not exist.
        """
        if path not in self._files:
            raise FileNotFoundError(f"File not found in TEE FS: {path}")

        decrypted = self._fernet.decrypt(self._files[path])
        logger.debug(f"TEE FS read: {path} ({len(decrypted)} bytes)")
        return decrypted

    def exists(self, path: str) -> bool:
        """Check if file exists."""
        return path in self._files

    def delete(self, path: str) -> bool:
        """Delete file.

        Args:
            path: Virtual file path.

        Returns:
            True if the file existed and was removed.
        """
        if path in self._files:
            del self._files[path]
            logger.debug(f"TEE FS delete: {path}")
            return True
        return False

    def list_files(self) -> List[str]:
        """List all files in the virtual filesystem.

        Returns:
            Sorted list of file paths.
        """
        return sorted(self._files.keys())

    @property
    def file_count(self) -> int:
        """Number of files in the virtual filesystem."""
        return len(self._files)
