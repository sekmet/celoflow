"""TEE identity representation.

An agent's cryptographic identity derived from the TEE enclave
via deterministic key derivation through Dstack SDK.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TEEIdentity:
    """Agent identity derived from TEE key derivation.

    Attributes:
        address: Ethereum-style hex address (e.g., "0xAbC...").
        public_key: Hex-encoded public key.
        domain: Domain used during key derivation.
        salt: Salt used during key derivation.
    """

    address: str
    public_key: str
    domain: str
    salt: str

    def __str__(self) -> str:
        return f"TEEIdentity(address={self.address}, domain={self.domain})"
