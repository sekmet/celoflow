"""TEE (Trusted Execution Environment) support for Contextwise.

Provides TEE-native authentication, plugin sandboxing, network restrictions,
attestation support, audit logging, and encrypted storage via Dstack SDK.
"""

from .config import TEEConfig
from .identity import TEEIdentity
from .manager import TEEManager
from .network import TEENetworkRestrictor, enforce_tee_network_restrictions
from .sandbox import PluginSandbox, SandboxedPlugin
from .permissions import PluginPermission, PluginManifest, TEEAwarePlugin
from .audit import AuditEvent, AuditLog
from .storage import EncryptedStorage, TEESessionManager
from .filesystem import TEEFilesystem
from .validation import validate_tee_configuration, detect_tee_environment
from .plugins import TEEAuthPlugin, TEEMemoryPlugin

__all__ = [
    # Config
    "TEEConfig",
    # Identity
    "TEEIdentity",
    # Manager
    "TEEManager",
    # Network
    "TEENetworkRestrictor",
    "enforce_tee_network_restrictions",
    # Sandbox
    "PluginSandbox",
    "SandboxedPlugin",
    # Permissions
    "PluginPermission",
    "PluginManifest",
    "TEEAwarePlugin",
    # Audit
    "AuditEvent",
    "AuditLog",
    # Storage
    "EncryptedStorage",
    "TEESessionManager",
    # Filesystem
    "TEEFilesystem",
    # Validation
    "validate_tee_configuration",
    "detect_tee_environment",
    # Plugins
    "TEEAuthPlugin",
    "TEEMemoryPlugin",
]
