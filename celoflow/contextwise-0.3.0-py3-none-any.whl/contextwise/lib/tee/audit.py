"""Audit logging for TEE environments.

Provides an immutable, hash-chained audit trail for all agent actions.
Each event references the hash of the previous event, forming a tamper-evident
chain similar to a blockchain.

Design decisions:
- Append-only list (no deletions or mutations).
- SHA-256 hash chain for integrity verification.
- JSON-serializable events for easy compliance export.
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class AuditEvent:
    """Single audit log entry.

    Attributes:
        timestamp: ISO-8601 UTC timestamp.
        event_type: Category (e.g., "agent.lifecycle", "plugin.action").
        agent_id: Agent address or identifier.
        user_id: Optional user identifier.
        action: Human-readable action description.
        details: Arbitrary structured data.
        previous_hash: SHA-256 hash of the previous event in the chain.
    """

    timestamp: str
    event_type: str
    agent_id: str
    user_id: Optional[str]
    action: str
    details: Dict[str, Any]
    previous_hash: str

    def compute_hash(self) -> str:
        """Compute SHA-256 hash for chain integrity."""
        data = asdict(self)
        data_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()


class AuditLog:
    """Immutable audit log with hash-chain verification.

    Features:
    - Cryptographic chain integrity
    - Append-only structure
    - Export for compliance

    Args:
        agent_id: Agent address or identifier for tagging events.
    """

    def __init__(self, agent_id: str) -> None:
        self.agent_id = agent_id
        self._events: List[AuditEvent] = []
        self._last_hash: str = "genesis"

    def log(
        self,
        event_type: str,
        action: str,
        details: Dict[str, Any],
        user_id: Optional[str] = None,
    ) -> AuditEvent:
        """Add event to audit log.

        Args:
            event_type: Event category string.
            action: Action description.
            details: Arbitrary structured data.
            user_id: Optional user identifier.

        Returns:
            The created AuditEvent.
        """
        event = AuditEvent(
            timestamp=datetime.now(timezone.utc).isoformat(),
            event_type=event_type,
            agent_id=self.agent_id,
            user_id=user_id,
            action=action,
            details=details,
            previous_hash=self._last_hash,
        )

        event_hash = event.compute_hash()
        self._last_hash = event_hash

        self._events.append(event)

        logger.debug(f"Audit: {event_type} - {action}")
        return event

    def verify_integrity(self) -> bool:
        """Verify audit log chain integrity.

        Returns:
            True if the hash chain is intact (no tampering detected).
        """
        expected_hash = "genesis"
        for event in self._events:
            if event.previous_hash != expected_hash:
                return False
            expected_hash = event.compute_hash()
        return True

    def export(self) -> List[Dict[str, Any]]:
        """Export audit log for compliance.

        Returns:
            List of serialized audit events.
        """
        return [asdict(event) for event in self._events]

    @property
    def event_count(self) -> int:
        """Number of events in the audit log."""
        return len(self._events)

    @property
    def last_hash(self) -> str:
        """Hash of the most recent event (or 'genesis')."""
        return self._last_hash
