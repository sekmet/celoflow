"""
Markdown Behavior Plugin for Contextwise v0.3.0

Auto-activated when Agent.workspace is set. Loads markdown files and injects
them as dynamic instructions. Falls back to agent.instructions if files missing.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Any, Optional
import time
import hashlib

from contextwise.lib.base import AgentPlugin
from contextwise.lib.context import AgentContext

from .loader import (
    BootstrapLoader,
    BootstrapFile,
    SessionType,
    parse_markdown_with_frontmatter,
    should_load_file,
    evaluate_condition,
)
from .processor import ContentProcessor
from .builder import PromptBuilder
from .hooks import HookManager

import logging
logger = logging.getLogger(__name__)


@dataclass
class MarkdownBehaviorPlugin(AgentPlugin[AgentContext]):
    """
    Loads markdown files from workspace and injects as dynamic instructions.

    Auto-activated when Agent.workspace is set. Uses existing Agent fallback
    mechanism via context.metadata["dynamic_instructions"].

    Behavior:
    - If workspace exists with .md files -> Enhanced instructions
    - If workspace empty or files missing -> Fallback to agent.instructions
    - If workspace doesn't exist -> Fallback to agent.instructions
    - If error loading files -> Fallback to agent.instructions (logged)

    The plugin is completely transparent - users just set Agent.workspace.
    """

    # Plugin metadata
    id: str = "markdown_behavior"
    name: str = "Markdown Behavior Plugin"
    version: str = "3.0.0"
    description: str = "Auto-activated markdown behavior from workspace files"

    # Configuration
    workspace_dir: Path = field(default_factory=lambda: Path("/data/workspace-default"))
    session_type: str = "main"  # "main" | "subagent" | "group"
    cache_ttl: int = 300  # 5 minutes
    max_file_size: int = 20000  # chars before trimming
    fallback_to_instructions: bool = True  # Always True for auto-activation

    # Internal state
    _loader: Optional[BootstrapLoader] = field(default=None, init=False, repr=False)
    _processor: Optional[ContentProcessor] = field(default=None, init=False, repr=False)
    _builder: Optional[PromptBuilder] = field(default=None, init=False, repr=False)
    _hook_manager: Optional[HookManager] = field(default=None, init=False, repr=False)
    _cache: Dict[str, tuple] = field(default_factory=dict, init=False, repr=False)
    _base_instructions: Optional[str] = field(default=None, init=False, repr=False)
    _voice_enabled: bool = field(default=False, init=False, repr=False)
    _voice_config: Optional[Any] = field(default=None, init=False, repr=False)

    def __post_init__(self):
        """Initialize plugin components."""
        self._loader = BootstrapLoader(self.workspace_dir)
        self._processor = ContentProcessor(max_chars=self.max_file_size)
        self._builder = PromptBuilder()
        self._hook_manager = HookManager()

        logger.debug(
            f"MarkdownBehaviorPlugin initialized: workspace={self.workspace_dir}"
        )

    def configure_agent(self, agent: Any) -> Any:
        """
        Store base instructions and detect voice capabilities.

        Called during agent initialization by PluginManager.
        Voice detection happens ONCE here and is stored for the plugin lifetime.

        Args:
            agent: SDK Agent instance

        Returns:
            Unchanged agent
        """
        self._base_instructions = agent.instructions

        # Detect voice configuration from the Contextwise Agent wrapper
        # The agent passed here is the SDK agent, but the Contextwise Agent
        # that wraps it stores voice config. We check via the plugin manager's
        # reference or via the contextwise agent that created us.
        contextwise_agent = getattr(agent, '_contextwise_agent', None)
        if contextwise_agent is not None:
            self._voice_enabled = getattr(contextwise_agent, 'voice', None) is not None
            self._voice_config = getattr(contextwise_agent, 'voice', None)
        else:
            # Fallback: check if agent itself has voice attribute (Contextwise Agent)
            self._voice_enabled = getattr(agent, 'voice', None) is not None
            self._voice_config = getattr(agent, 'voice', None)

        if self._voice_enabled:
            logger.info(
                f"Voice mode detected for agent '{getattr(agent, 'name', 'unknown')}'. "
                f"VOICE.md will be loaded if present."
            )
        else:
            logger.debug(
                f"Voice mode not configured for agent '{getattr(agent, 'name', 'unknown')}'"
            )

        logger.debug(
            f"Stored base instructions ({len(self._base_instructions)} chars) "
            f"for fallback"
        )

        return agent

    async def on_before_run_async(self, context: AgentContext, input: str) -> None:
        """
        Load workspace files and inject as dynamic instructions.

        THIS IS THE CORE INTEGRATION POINT. We load markdown files and inject
        them into context.metadata["dynamic_instructions"]. The Agent class
        automatically handles this (see Agent.chat_async).

        Fallback Behavior (all automatic):
        1. Workspace doesn't exist -> Skip (use base instructions)
        2. Workspace empty (no .md files) -> Skip (use base instructions)
        3. Files exist but error loading -> Log + skip (use base instructions)
        4. Files loaded successfully -> Inject enhanced instructions

        Args:
            context: Agent context with user_id, session_id, channel, etc.
            input: User's input message
        """
        try:
            # Check 1: Does workspace exist?
            if not self.workspace_dir.exists():
                logger.debug(
                    f"Workspace not found: {self.workspace_dir}, "
                    f"using base instructions"
                )
                return  # Fallback: don't set dynamic_instructions

            # Check 2: Load workspace files (cached)
            bootstrap_files = await self._get_or_load_files(context)

            # Check 3: Were any files actually loaded?
            loaded_files = [f for f in bootstrap_files if not f.missing and f.content]

            if not loaded_files:
                logger.debug(
                    f"No markdown files in workspace {self.workspace_dir}, "
                    f"using base instructions"
                )
                return  # Fallback: don't set dynamic_instructions

            # Files found! Build enhanced instructions
            enhanced_instructions = self._build_enhanced_instructions(
                bootstrap_files,
                context
            )

            # CRITICAL: Inject into context.metadata["dynamic_instructions"]
            # Agent.chat_async will automatically use this
            context.metadata["dynamic_instructions"] = enhanced_instructions

            # Store metadata for debugging
            context.metadata["markdown_files"] = bootstrap_files
            context.metadata["markdown_files_loaded"] = len(loaded_files)

            logger.info(
                f"Markdown behavior activated: {len(enhanced_instructions)} chars, "
                f"{len(loaded_files)} files loaded"
            )

        except Exception as e:
            # Check 4: Error loading files
            logger.error(
                f"Error loading markdown files: {e}, "
                f"falling back to base instructions",
                exc_info=True
            )

            # Store error for debugging
            context.metadata["markdown_load_error"] = str(e)

            # Fallback: don't set dynamic_instructions
            return

    async def _get_or_load_files(self, context: AgentContext) -> List[BootstrapFile]:
        """
        Get bootstrap files from cache or load from filesystem.

        Cache key includes: workspace + session_type + session_id
        """
        cache_key = self._generate_cache_key(context)
        current_time = time.time()

        # Check cache
        if cache_key in self._cache:
            cached_files, timestamp = self._cache[cache_key]
            if current_time - timestamp < self.cache_ttl:
                logger.debug(f"Cache hit: {cache_key}")
                return cached_files

        # Cache miss - load fresh
        logger.debug(f"Cache miss, loading files: {cache_key}")
        files = await self._load_and_process_files(context)

        # Update cache
        self._cache[cache_key] = (files, current_time)

        return files

    async def _load_and_process_files(self, context: AgentContext) -> List[BootstrapFile]:
        """
        Load and process bootstrap files:
        1. Load all .md files from workspace (voice-aware)
        2. Filter by session type (main/subagent/group)
        3. Apply hooks (custom modifications)
        4. Trim large files
        """
        # 1. Load all files (pass voice_enabled for conditional VOICE.md loading)
        all_files = self._loader.load_bootstrap_files(
            voice_enabled=self._voice_enabled,
        )
        
        # 1.5. Load shared files (WORKING.md, WORKFLOW.md)
        shared_files = self._loader.get_shared_files()
        all_files.extend(shared_files)

        # 2. Filter by session type
        session_type = SessionType.from_string(
            context.metadata.get("session_type", self.session_type)
        )
        filtered_files = self._loader.filter_for_session(all_files, session_type)

        # 3. Apply hooks
        modified_files = await self._hook_manager.apply_hooks_async(
            filtered_files,
            context=context,
            workspace_dir=self.workspace_dir
        )

        # 4. Process content (trimming)
        processed_files = self._processor.process_files(modified_files)

        return processed_files

    def _build_enhanced_instructions(
        self,
        files: List[BootstrapFile],
        context: AgentContext
    ) -> str:
        """
        Build enhanced instructions by combining base + markdown.

        Structure:
        1. Base instructions (ALWAYS PRESERVED)
        2. Markdown files section
        3. Individual file contents
        """
        return self._builder.build_enhanced_prompt(
            base_instructions=self._base_instructions or "",
            bootstrap_files=files,
            context=context
        )

    def _generate_cache_key(self, context: AgentContext) -> str:
        """Generate cache key from context (includes voice flag for isolation)."""
        key_parts = [
            str(self.workspace_dir),
            context.metadata.get("session_type", self.session_type),
            context.session_id or "default",
            f"voice={self._voice_enabled}",
        ]
        key_string = ":".join(key_parts)
        return hashlib.md5(key_string.encode()).hexdigest()

    # Plugin interface methods

    def get_tools(self) -> List[Any]:
        """No tools provided."""
        return []

    def dependencies(self) -> List[str]:
        """No dependencies."""
        return []

    # Cache management

    def clear_cache(self) -> None:
        """Clear file cache (for hot-reloading)."""
        self._cache.clear()
        logger.info("Cleared markdown file cache")

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            "entries": len(self._cache),
            "ttl_seconds": self.cache_ttl,
            "workspace": str(self.workspace_dir),
        }


__all__ = ["MarkdownBehaviorPlugin"]
