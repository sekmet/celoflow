"""
Hook system for markdown behavior extensibility.

Allows custom modifications to markdown files before injection.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Dict, Any
from pathlib import Path

from ..loader import BootstrapFile
from contextwise.lib.context import AgentContext

import logging
logger = logging.getLogger(__name__)


@dataclass
class HookContext:
    """Context passed to hooks."""
    workspace_dir: Path
    session_id: str
    session_type: str
    agent_context: AgentContext
    metadata: Dict[str, Any]


class BootstrapHook(ABC):
    """
    Base class for bootstrap hooks.

    Hooks modify files before they're injected into the prompt.
    """

    @abstractmethod
    async def process_async(
        self,
        files: List[BootstrapFile],
        context: HookContext
    ) -> List[BootstrapFile]:
        """
        Process bootstrap files.

        Args:
            files: Current bootstrap files
            context: Hook context

        Returns:
            Modified bootstrap files
        """
        pass

    @property
    def priority(self) -> int:
        """Hook priority (higher = earlier). Default: 50"""
        return 50


class HookManager:
    """
    Manages and executes bootstrap hooks.

    Hooks run in priority order (highest first).
    """

    def __init__(self):
        """Initialize hook manager."""
        self.hooks: List[BootstrapHook] = []

    def register(self, hook: BootstrapHook) -> None:
        """
        Register a hook.

        Args:
            hook: Hook to register
        """
        self.hooks.append(hook)
        self.hooks.sort(key=lambda h: h.priority, reverse=True)

        logger.debug(f"Registered hook: {hook.__class__.__name__} (priority: {hook.priority})")

    async def apply_hooks_async(
        self,
        files: List[BootstrapFile],
        context: AgentContext,
        workspace_dir: Path
    ) -> List[BootstrapFile]:
        """
        Apply all hooks to files.

        Args:
            files: Bootstrap files
            context: Agent context
            workspace_dir: Workspace directory

        Returns:
            Modified files
        """
        hook_context = HookContext(
            workspace_dir=workspace_dir,
            session_id=context.session_id or "default",
            session_type=context.metadata.get("session_type", "main"),
            agent_context=context,
            metadata=context.metadata
        )

        processed_files = files

        for hook in self.hooks:
            try:
                processed_files = await hook.process_async(processed_files, hook_context)
                logger.debug(f"Applied hook: {hook.__class__.__name__}")
            except Exception as e:
                logger.error(f"Hook {hook.__class__.__name__} failed: {e}", exc_info=True)

        return processed_files


__all__ = ["HookManager", "BootstrapHook", "HookContext"]
