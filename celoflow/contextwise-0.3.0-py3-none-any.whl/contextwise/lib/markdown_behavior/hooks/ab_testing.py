"""
A/B testing hook for personality variants.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Callable
import hashlib

from ..hooks import BootstrapHook, HookContext
from ..loader import BootstrapFile

import logging
logger = logging.getLogger(__name__)


@dataclass
class ABTestingHook(BootstrapHook):
    """Test personality variants."""

    variants: Dict[str, str]
    assignment_func: Optional[Callable] = None

    async def process_async(
        self,
        files: List[BootstrapFile],
        context: HookContext
    ) -> List[BootstrapFile]:
        """Assign user to variant."""

        variant_name = self._assign_variant(
            context.agent_context.user_id,
            list(self.variants.keys())
        )

        variant_text = self.variants.get(variant_name, "")
        if not variant_text:
            return files

        # Inject into SOUL.md
        for file in files:
            if file.name == "SOUL.md" and not file.missing:
                if file.content is None:
                    file.content = ""

                file.content += f"\n\n## A/B Variant: {variant_name}\n\n{variant_text}"

                logger.info(f"User assigned to: {variant_name}")
                context.metadata["ab_variant"] = variant_name

        return files

    def _assign_variant(self, user_id: str, variants: List[str]) -> str:
        """Deterministic assignment via hash."""
        if self.assignment_func:
            return self.assignment_func(user_id, variants)

        hash_val = int(hashlib.md5(user_id.encode()).hexdigest(), 16)
        return variants[hash_val % len(variants)]

    @property
    def priority(self) -> int:
        return 70


__all__ = ["ABTestingHook"]
