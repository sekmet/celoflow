"""
Content processor for markdown files.

Trims large files and formats content for prompt injection.
"""

from dataclasses import dataclass
from typing import List
import math

import logging
logger = logging.getLogger(__name__)


@dataclass
class TrimResult:
    """Result of content trimming."""
    content: str
    truncated: bool
    original_length: int
    trimmed_length: int
    head_chars: int
    tail_chars: int


class ContentProcessor:
    """
    Processes markdown content for prompt injection.

    Features:
    - Trims large files (head + tail strategy)
    - Adds truncation markers
    - Preserves markdown structure
    """

    # Trimming ratios (head + tail + marker = 100%)
    HEAD_RATIO = 0.70  # Keep 70% from start
    TAIL_RATIO = 0.20  # Keep 20% from end
    # 10% reserved for truncation marker

    def __init__(self, max_chars: int = 20000):
        """
        Initialize processor.

        Args:
            max_chars: Maximum chars per file before trimming
        """
        self.max_chars = max_chars

    def process_files(self, files: List['BootstrapFile']) -> List['BootstrapFile']:
        """
        Process all bootstrap files.

        Args:
            files: List of bootstrap files

        Returns:
            List of processed files
        """
        processed = []

        for file in files:
            if file.missing or not file.content:
                processed.append(file)
                continue

            trim_result = self.trim_content(file.content, file.name)

            file.content = trim_result.content
            file.metadata["original_length"] = trim_result.original_length
            file.metadata["trimmed"] = trim_result.truncated

            processed.append(file)

            if trim_result.truncated:
                logger.info(
                    f"Trimmed {file.name}: {trim_result.original_length} -> "
                    f"{trim_result.trimmed_length} chars"
                )

        return processed

    def trim_content(self, content: str, filename: str) -> TrimResult:
        """
        Trim content using head-tail strategy.

        Strategy:
        - Keep 70% from beginning
        - Keep 20% from end
        - Add truncation marker in middle

        Args:
            content: Original content
            filename: Filename (for marker)

        Returns:
            TrimResult with processed content
        """
        trimmed = content.rstrip()

        if len(trimmed) <= self.max_chars:
            return TrimResult(
                content=trimmed,
                truncated=False,
                original_length=len(trimmed),
                trimmed_length=len(trimmed),
                head_chars=len(trimmed),
                tail_chars=0
            )

        head_chars = math.floor(self.max_chars * self.HEAD_RATIO)
        tail_chars = math.floor(self.max_chars * self.TAIL_RATIO)

        head = trimmed[:head_chars]
        tail = trimmed[-tail_chars:] if tail_chars > 0 else ""

        marker_lines = [
            "",
            f"[...truncated, read {filename} for full content...]",
            f"(kept {head_chars}+{tail_chars} chars of {len(trimmed)})",
            "",
        ]
        marker = "\n".join(marker_lines)

        final_content = head + marker + tail

        return TrimResult(
            content=final_content,
            truncated=True,
            original_length=len(trimmed),
            trimmed_length=len(final_content),
            head_chars=head_chars,
            tail_chars=tail_chars
        )


__all__ = ["ContentProcessor", "TrimResult"]
