"""
System prompt builder.

Combines base instructions with markdown files.
"""

from dataclasses import dataclass
from typing import List

from .loader import BootstrapFile
from contextwise.lib.context import AgentContext

import logging
logger = logging.getLogger(__name__)


@dataclass
class PromptSection:
    """A section of the system prompt."""
    name: str
    content: str
    priority: int  # Higher = earlier in prompt


class PromptBuilder:
    """
    Builds enhanced system prompts.

    Combines base instructions with markdown files while preserving
    base instructions for proper fallback.
    """

    def build_enhanced_prompt(
        self,
        base_instructions: str,
        bootstrap_files: List[BootstrapFile],
        context: AgentContext
    ) -> str:
        """
        Build enhanced prompt: base instructions + markdown files.

        Structure:
        1. Base instructions (ALWAYS FIRST)
        2. Markdown separator
        3. SOUL.md notice (if present)
        4. Project context with all markdown files

        Args:
            base_instructions: Original agent.instructions
            bootstrap_files: Loaded markdown files
            context: Agent context

        Returns:
            Complete enhanced prompt
        """
        sections = []

        # 1. Base instructions (HIGHEST PRIORITY)
        if base_instructions:
            sections.append(PromptSection(
                name="base_instructions",
                content=base_instructions.strip(),
                priority=100
            ))

        loaded_files = [f for f in bootstrap_files if not f.missing and f.content]

        if loaded_files:
            # 2. Separator
            sections.append(PromptSection(
                name="separator",
                content="---\n# Enhanced Behavior (from Workspace)",
                priority=90
            ))

            # 3. SOUL.md notice
            has_soul = any(
                f.name.lower() == "soul.md" and not f.missing
                for f in bootstrap_files
            )

            if has_soul:
                soul_notice = (
                    "IMPORTANT: SOUL.md defines your personality. "
                    "Embody its persona and tone while following the "
                    "core instructions above."
                )
                sections.append(PromptSection(
                    name="soul_notice",
                    content=soul_notice,
                    priority=85
                ))

            # 4. Project context
            context_content = self._build_context_section(bootstrap_files)
            sections.append(PromptSection(
                name="project_context",
                content=context_content,
                priority=80
            ))

        # Sort by priority and combine
        sections.sort(key=lambda s: s.priority, reverse=True)

        prompt_parts = [s.content for s in sections]
        final_prompt = "\n\n".join(prompt_parts)

        logger.info(
            f"Built enhanced prompt: {len(final_prompt)} chars, "
            f"{len(loaded_files)} files"
        )

        return final_prompt

    def _build_context_section(self, files: List[BootstrapFile]) -> str:
        """
        Build project context section.

        Format:
        # Project Context

        ## SOUL.md
        [content]

        ## AGENTS.md
        [content]
        """
        lines = [
            "# Project Context",
            "",
            "The following workspace files define your behavior:",
            ""
        ]

        for file in files:
            if file.missing or not file.content:
                continue

            lines.append(f"## {file.name}")
            lines.append("")
            lines.append(file.content.strip())
            lines.append("")

        return "\n".join(lines)


__all__ = ["PromptBuilder"]
