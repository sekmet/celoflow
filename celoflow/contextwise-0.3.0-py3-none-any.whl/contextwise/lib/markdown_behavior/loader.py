"""
Bootstrap file loader for markdown behavior.

Loads .md files from workspace directory with session-type filtering.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Optional, Any
from enum import Enum

import yaml
import logging
logger = logging.getLogger(__name__)


class SessionType(Enum):
    """Session types with different file access patterns."""
    MAIN = "main"           # Full access
    SUBAGENT = "subagent"   # Limited (AGENTS.md, TOOLS.md only)
    GROUP = "group"         # Privacy-filtered (exclude USER.md, MEMORY.md)

    @classmethod
    def from_string(cls, value: str) -> "SessionType":
        """Convert string to SessionType."""
        try:
            return cls(value.lower())
        except ValueError:
            logger.warning(f"Unknown session type '{value}', defaulting to MAIN")
            return cls.MAIN


def parse_markdown_with_frontmatter(raw_content: str) -> tuple:
    """
    Parse markdown content with optional YAML frontmatter.

    Frontmatter is delimited by --- at the start and end:
        ---
        summary: "description"
        read_when:
          - condition1
        ---
        # Markdown content here

    Args:
        raw_content: Raw file content

    Returns:
        Tuple of (frontmatter_dict, markdown_content).
        If no frontmatter found, returns ({}, original_content).
        If frontmatter is malformed, returns ({}, original_content) with warning logged.
    """
    if not raw_content or not raw_content.strip().startswith('---'):
        return {}, raw_content

    stripped = raw_content.strip()
    # Find the closing --- delimiter (skip the opening one)
    second_delimiter = stripped.find('---', 3)
    if second_delimiter == -1:
        logger.warning("Frontmatter opening delimiter found but no closing delimiter")
        return {}, raw_content

    frontmatter_text = stripped[3:second_delimiter].strip()
    markdown_content = stripped[second_delimiter + 3:].strip()

    try:
        frontmatter = yaml.safe_load(frontmatter_text)
        if not isinstance(frontmatter, dict):
            logger.warning(
                f"Frontmatter parsed but is not a dict (got {type(frontmatter).__name__}), "
                f"treating as no frontmatter"
            )
            return {}, raw_content

        logger.debug(f"Parsed frontmatter with keys: {list(frontmatter.keys())}")
        return frontmatter, markdown_content

    except yaml.YAMLError as e:
        logger.warning(f"Malformed YAML frontmatter, falling back to raw content: {e}")
        return {}, raw_content


def should_load_file(frontmatter: Dict[str, Any], context: Dict[str, Any]) -> bool:
    """
    Determine if a file should be loaded based on frontmatter read_when conditions.

    If no read_when conditions exist, the file is always loaded (backward compatible).
    If read_when conditions exist, at least one must match the current context.

    Args:
        frontmatter: Parsed frontmatter dictionary
        context: Current loading context with keys like 'is_bootstrap', 'session_type', etc.

    Returns:
        True if the file should be loaded
    """
    if not frontmatter:
        return True

    read_when = frontmatter.get('read_when')
    if not read_when:
        return True

    if not isinstance(read_when, list):
        read_when = [read_when]

    for condition in read_when:
        if evaluate_condition(condition, context):
            return True

    logger.debug(f"File skipped: no read_when conditions matched (conditions={read_when})")
    return False


def evaluate_condition(condition: str, context: Dict[str, Any]) -> bool:
    """
    Evaluate a single read_when condition against the current context.

    Supported conditions:
    - "Bootstrapping a workspace manually" -> context.get('is_bootstrap', False)
    - "Using the dev gateway templates" -> context.get('is_dev_mode', False)
    - "Updating the default dev agent identity" -> context.get('is_dev_mode', False)
    - "Adding a BOOT.md checklist" -> context.get('has_boot_checklist', False)
    - "always" -> True (always load)

    Unknown conditions default to True for backward compatibility.

    Args:
        condition: Condition string from frontmatter
        context: Current loading context

    Returns:
        True if condition is met
    """
    if not isinstance(condition, str):
        return True

    condition_lower = condition.strip().lower()

    condition_map = {
        "bootstrapping a workspace manually": lambda ctx: ctx.get('is_bootstrap', True),
        "using the dev gateway templates": lambda ctx: ctx.get('is_dev_mode', False),
        "updating the default dev agent identity": lambda ctx: ctx.get('is_dev_mode', False),
        "adding a boot.md checklist": lambda ctx: ctx.get('has_boot_checklist', False),
        "always": lambda ctx: True,
    }

    evaluator = condition_map.get(condition_lower)
    if evaluator:
        return evaluator(context)

    # Unknown conditions default to True for backward compatibility
    logger.debug(f"Unknown read_when condition '{condition}', defaulting to True")
    return True


@dataclass
class BootstrapFile:
    """
    Single bootstrap markdown file.

    Attributes:
        name: Filename (e.g., "SOUL.md")
        path: Full filesystem path
        content: File content (None if missing)
        missing: True if file doesn't exist
        metadata: Additional metadata
        frontmatter: Parsed YAML frontmatter dictionary
    """
    name: str
    path: Path
    content: Optional[str] = None
    missing: bool = False
    metadata: Dict = None
    frontmatter: Dict = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
        if self.frontmatter is None:
            self.frontmatter = {}


class BootstrapLoader:
    """
    Loads bootstrap markdown files from workspace.

    Features:
    - Discovers .md files in workspace
    - Session-based filtering
    - Error handling for missing files
    """

    # Standard bootstrap file names
    DEFAULT_FILES = {
        "soul": "SOUL.md",
        "agents": "AGENTS.md",
        "user": "USER.md",
        "memory": "MEMORY.md",
        "heartbeat": "HEARTBEAT.md",
        "tools": "TOOLS.md",
        "identity": "IDENTITY.md",
        "bootstrap": "BOOTSTRAP.md",
        "voice": "VOICE.md",
    }

    # Voice-only files (loaded only when agent.voice is configured)
    VOICE_ONLY_FILES = {"VOICE.md"}

    # Subagent access control (security)
    SUBAGENT_ALLOWLIST = {"AGENTS.md", "TOOLS.md"}

    # Group chat privacy (exclude personal data)
    GROUP_BLOCKLIST = {"USER.md", "MEMORY.md"}

    def __init__(self, workspace_dir: Path):
        """
        Initialize loader.

        Args:
            workspace_dir: Path to workspace directory
        """
        self.workspace_dir = workspace_dir

        if not workspace_dir.exists():
            logger.debug(f"Workspace does not exist: {workspace_dir}")

    def load_bootstrap_files(
        self,
        loading_context: Optional[Dict[str, Any]] = None,
        voice_enabled: bool = False,
    ) -> List[BootstrapFile]:
        """
        Load all bootstrap files from workspace.

        Parses YAML frontmatter from each file and applies conditional
        loading based on read_when conditions in frontmatter.
        VOICE.md is only loaded when voice_enabled=True.

        Args:
            loading_context: Optional context for evaluating read_when conditions.
                Keys: is_bootstrap, is_dev_mode, has_boot_checklist, session_type.
                If None, all files are loaded (backward compatible).
            voice_enabled: Whether the agent has voice configured.
                When False, VOICE.md is skipped even if present.

        Returns:
            List of BootstrapFile objects (includes missing files)
        """
        files = []
        ctx = loading_context or {}

        for logical_name, filename in self.DEFAULT_FILES.items():
            filepath = self.workspace_dir / filename

            # Skip voice-only files when voice is not configured
            if filename in self.VOICE_ONLY_FILES and not voice_enabled:
                logger.debug(f"Skipping {filename} - voice not configured")
                continue

            try:
                if filepath.exists() and filepath.is_file():
                    with open(filepath, 'r', encoding='utf-8') as f:
                        raw_content = f.read()

                    # Parse frontmatter
                    frontmatter, content = parse_markdown_with_frontmatter(raw_content)

                    # Evaluate conditional loading
                    if ctx and not should_load_file(frontmatter, ctx):
                        logger.debug(
                            f"Skipped (read_when not met): {filename}"
                        )
                        files.append(BootstrapFile(
                            name=filename,
                            path=filepath,
                            content=None,
                            missing=True,
                            metadata={"logical_name": logical_name, "skipped": True},
                            frontmatter=frontmatter,
                        ))
                        continue

                    files.append(BootstrapFile(
                        name=filename,
                        path=filepath,
                        content=content,
                        missing=False,
                        metadata={"logical_name": logical_name},
                        frontmatter=frontmatter,
                    ))

                    logger.debug(
                        f"Loaded: {filename} ({len(content)} chars, "
                        f"frontmatter_keys={list(frontmatter.keys())})"
                    )
                else:
                    # For VOICE.md, log a helpful warning when voice is enabled but file missing
                    if filename in self.VOICE_ONLY_FILES and voice_enabled:
                        logger.warning(
                            f"Voice enabled but {filename} not found at {filepath}. "
                            f"Consider creating {filename} for rich voice guidance."
                        )

                    files.append(BootstrapFile(
                        name=filename,
                        path=filepath,
                        content=None,
                        missing=True,
                        metadata={"logical_name": logical_name}
                    ))

                    logger.debug(f"Missing: {filename}")

            except Exception as e:
                logger.error(f"Error loading {filename}: {e}")
                files.append(BootstrapFile(
                    name=filename,
                    path=filepath,
                    content=None,
                    missing=True,
                    metadata={"logical_name": logical_name, "error": str(e)}
                ))

        loaded_count = len([f for f in files if not f.missing])
        logger.info(f"Loaded {loaded_count} of {len(self.DEFAULT_FILES)} files")

        return files

    def filter_for_session(
        self,
        files: List[BootstrapFile],
        session_type: SessionType
    ) -> List[BootstrapFile]:
        """
        Filter files by session type.

        Session types:
        - MAIN: All files
        - SUBAGENT: Only AGENTS.md, TOOLS.md (security)
        - GROUP: Exclude USER.md, MEMORY.md (privacy)

        Args:
            files: All loaded files
            session_type: Session type

        Returns:
            Filtered file list
        """
        if session_type == SessionType.MAIN:
            return files

        elif session_type == SessionType.SUBAGENT:
            filtered = [f for f in files if f.name in self.SUBAGENT_ALLOWLIST]
            logger.debug(f"Subagent filter: {len(filtered)} files")
            return filtered

        elif session_type == SessionType.GROUP:
            filtered = [f for f in files if f.name not in self.GROUP_BLOCKLIST]
            logger.debug(f"Group filter: {len(filtered)} files")
            return filtered

        else:
            logger.warning(f"Unknown session type: {session_type}")
            return files

    def get_shared_files(self) -> List[BootstrapFile]:
        """
        Load files from shared/ directory (symlinked).

        Returns:
            List of shared files (WORKING.md, WORKFLOW.md)
        """
        shared_dir = self.workspace_dir / "shared"

        if not shared_dir.exists():
            return []

        shared_files = []

        for filename in ["WORKING.md", "WORKFLOW.md"]:
            filepath = shared_dir / filename

            try:
                if filepath.exists():
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()

                    shared_files.append(BootstrapFile(
                        name=f"shared/{filename}",
                        path=filepath,
                        content=content,
                        missing=False,
                        metadata={"shared": True}
                    ))
            except Exception as e:
                logger.error(f"Error loading shared file {filename}: {e}")

        return shared_files


__all__ = [
    "BootstrapLoader",
    "BootstrapFile",
    "SessionType",
    "parse_markdown_with_frontmatter",
    "should_load_file",
    "evaluate_condition",
]
