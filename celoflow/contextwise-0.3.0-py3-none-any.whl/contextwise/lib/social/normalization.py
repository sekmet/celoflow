"""Event normalization for social network channels.

This module provides a standard format for inbound events from different
social platforms, making them compatible with Contextwise's channel interface.
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class NormalizedEvent:
    """Normalized representation of an inbound social network event.

    Attributes:
        platform_event_id: Unique event identifier from the platform
        sender_id: Platform-scoped sender identifier
        text: Message content to send to the agent
        timestamp: Event timestamp (Unix timestamp or ISO string)
        raw: Full payload slice for additional context
        metadata: Additional platform-specific metadata
    """

    platform_event_id: Optional[str]
    sender_id: str
    text: str
    timestamp: Optional[Any]
    raw: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None


def normalize_meta_event(
    payload: Dict[str, Any],
    platform: str = "instagram"
) -> Optional[NormalizedEvent]:
    """Normalize Meta (Instagram/Facebook) webhook payload.

    Args:
        payload: The webhook payload from Meta
        platform: Either "instagram" or "facebook"

    Returns:
        NormalizedEvent or None if no valid message found

    Example:
        >>> payload = {
        ...     "object": "instagram",
        ...     "entry": [{
        ...         "messaging": [{
        ...             "sender": {"id": "123"},
        ...             "message": {"text": "Hello", "mid": "msg_123"}
        ...         }]
        ...     }]
        ... }
        >>> event = normalize_meta_event(payload, "instagram")
        >>> event.text
        'Hello'
    """
    # Validate object type
    expected_object = "instagram" if platform == "instagram" else "page"
    if payload.get("object") != expected_object:
        return None

    # Parse entry array
    for entry in payload.get("entry", []):
        # Instagram and Facebook use different structures

        # Instagram messaging format
        messaging = entry.get("messaging", [])
        if messaging:
            message_data = messaging[0]
            sender = message_data.get("sender", {})
            message = message_data.get("message", {})

            if not message:
                continue

            text = message.get("text", "")
            if not text:
                # Handle attachments
                attachments = message.get("attachments", [])
                if attachments:
                    attachment_type = attachments[0].get("type", "attachment")
                    text = f"[{attachment_type} received]"
                else:
                    continue

            return NormalizedEvent(
                platform_event_id=message.get("mid"),
                sender_id=sender.get("id", ""),
                text=text,
                timestamp=message_data.get("timestamp"),
                raw=message_data,
                metadata={
                    "platform": platform,
                    "recipient_id": message_data.get("recipient", {}).get("id"),
                }
            )

        # Facebook Page messaging format (changes array)
        changes = entry.get("changes", [])
        if changes:
            change = changes[0]
            value = change.get("value", {})

            # Check for message
            message = value.get("message")
            if message:
                # Handle message as string or dict
                if isinstance(message, str):
                    text = message
                    message_id = value.get("mid")
                else:
                    text = message.get("message", "")
                    message_id = message.get("mid")

                if not text:
                    continue

                return NormalizedEvent(
                    platform_event_id=message_id,
                    sender_id=value.get("sender_id", ""),
                    text=text,
                    timestamp=value.get("created_time"),
                    raw=value,
                    metadata={
                        "platform": platform,
                        "post_id": value.get("post_id"),
                        "comment_id": value.get("comment_id"),
                    }
                )

            # Check for comment
            item = value.get("item")
            if item == "comment":
                comment_text = value.get("message", "")
                if not comment_text:
                    continue

                from_field = value.get("from", {})
                sender_id = from_field.get("id", "") if isinstance(from_field, dict) else ""

                return NormalizedEvent(
                    platform_event_id=value.get("comment_id"),
                    sender_id=sender_id,
                    text=comment_text,
                    timestamp=value.get("created_time"),
                    raw=value,
                    metadata={
                        "platform": platform,
                        "post_id": value.get("post_id"),
                        "comment_id": value.get("comment_id"),
                        "parent_id": value.get("parent_id"),
                    }
                )

    return None


def normalize_tiktok_event(payload: Dict[str, Any]) -> Optional[NormalizedEvent]:
    """Normalize TikTok webhook payload.

    TikTok primarily supports comment and mention events.

    Args:
        payload: The webhook payload from TikTok

    Returns:
        NormalizedEvent or None if no valid event found

    Example:
        >>> payload = {
        ...     "event": "comment.created",
        ...     "data": {
        ...         "comment_id": "123",
        ...         "text": "Nice video!",
        ...         "user": {"id": "user_123"},
        ...         "video_id": "video_456"
        ...     }
        ... }
        >>> event = normalize_tiktok_event(payload)
        >>> event.text
        'Nice video!'
    """
    event_type = payload.get("event", "")
    data = payload.get("data", {})

    # Handle comment events
    if event_type in ("comment.created", "comment"):
        comment_text = data.get("text") or data.get("comment_text", "")
        if not comment_text:
            return None

        user = data.get("user", {})
        user_id = user.get("id") or user.get("open_id") or data.get("user_id", "")

        return NormalizedEvent(
            platform_event_id=data.get("comment_id"),
            sender_id=user_id,
            text=comment_text,
            timestamp=data.get("create_time") or data.get("timestamp"),
            raw=data,
            metadata={
                "platform": "tiktok",
                "video_id": data.get("video_id"),
                "comment_id": data.get("comment_id"),
                "parent_comment_id": data.get("parent_comment_id"),
            }
        )

    # Handle mention events
    if event_type in ("mention.created", "mention"):
        mention_text = data.get("text") or data.get("caption", "")
        if not mention_text:
            return None

        user = data.get("user", {})
        user_id = user.get("id") or user.get("open_id") or data.get("user_id", "")

        return NormalizedEvent(
            platform_event_id=data.get("video_id"),
            sender_id=user_id,
            text=mention_text,
            timestamp=data.get("create_time") or data.get("timestamp"),
            raw=data,
            metadata={
                "platform": "tiktok",
                "video_id": data.get("video_id"),
                "mention_type": "video",
            }
        )

    # Handle direct message events (if supported)
    if event_type in ("message.created", "direct_message"):
        message_text = data.get("text") or data.get("message", "")
        if not message_text:
            return None

        user = data.get("sender", {}) or data.get("user", {})
        user_id = user.get("id") or user.get("open_id") or data.get("sender_id", "")

        return NormalizedEvent(
            platform_event_id=data.get("message_id"),
            sender_id=user_id,
            text=message_text,
            timestamp=data.get("create_time") or data.get("timestamp"),
            raw=data,
            metadata={
                "platform": "tiktok",
                "conversation_id": data.get("conversation_id"),
                "message_id": data.get("message_id"),
            }
        )

    return None
