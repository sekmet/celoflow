"""Rate limiter for social network API calls.

This module provides a simple token bucket rate limiter for managing
API call rates to social platforms.
"""

import asyncio
import time
from typing import Optional


class RateLimiter:
    """Token bucket rate limiter for API calls.

    Implements a feedback loop to balance API usage against platform limits.

    Attributes:
        max_tokens: Maximum number of tokens (concurrent requests)
        refill_rate: Tokens added per second
        tokens: Current token count
        last_refill: Last refill timestamp
    """

    def __init__(
        self,
        max_tokens: int = 10,
        refill_rate: float = 1.0,
    ):
        """Initialize rate limiter.

        Args:
            max_tokens: Maximum burst size
            refill_rate: Tokens per second refill rate
        """
        self.max_tokens = max_tokens
        self.refill_rate = refill_rate
        self.tokens = float(max_tokens)
        self.last_refill = time.time()
        self._lock = asyncio.Lock()

    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.time()
        elapsed = now - self.last_refill

        # Add tokens based on elapsed time
        new_tokens = elapsed * self.refill_rate
        self.tokens = min(self.max_tokens, self.tokens + new_tokens)
        self.last_refill = now

    async def acquire(self, tokens: int = 1) -> None:
        """Acquire tokens from the bucket.

        Blocks until enough tokens are available.

        Args:
            tokens: Number of tokens to acquire
        """
        async with self._lock:
            while True:
                self._refill()

                if self.tokens >= tokens:
                    self.tokens -= tokens
                    return

                # Calculate wait time
                needed = tokens - self.tokens
                wait_time = needed / self.refill_rate

                # Release lock while waiting
                await asyncio.sleep(wait_time)

    def try_acquire(self, tokens: int = 1) -> bool:
        """Try to acquire tokens without blocking.

        Args:
            tokens: Number of tokens to acquire

        Returns:
            True if tokens were acquired, False otherwise
        """
        self._refill()

        if self.tokens >= tokens:
            self.tokens -= tokens
            return True

        return False

    def reset(self) -> None:
        """Reset the rate limiter to full capacity."""
        self.tokens = float(self.max_tokens)
        self.last_refill = time.time()
