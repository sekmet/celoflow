"""Security utilities for social network channels.

This module provides signature verification for Meta (Instagram/Facebook)
and other social platforms.
"""

import hashlib
import hmac
from typing import Optional


def verify_meta_signature(
    payload: bytes,
    signature: str,
    app_secret: str,
) -> bool:
    """Verify Meta (Instagram/Facebook) webhook signature.

    Meta uses HMAC SHA256 with the app secret to sign webhook payloads.
    The signature is sent in the X-Hub-Signature-256 header.

    Args:
        payload: Raw request body bytes
        signature: Signature from X-Hub-Signature-256 header
        app_secret: App secret from Meta developer console

    Returns:
        True if signature is valid, False otherwise

    Example:
        >>> payload = b'{"object": "page"}'
        >>> signature = "sha256=abc123..."
        >>> app_secret = "my_app_secret"
        >>> verify_meta_signature(payload, signature, app_secret)
        True
    """
    if not signature or not app_secret:
        return False

    # Remove 'sha256=' prefix if present
    if signature.startswith("sha256="):
        signature = signature[7:]

    # Compute expected signature
    expected = hmac.new(
        app_secret.encode("utf-8"),
        payload,
        hashlib.sha256
    ).hexdigest()

    # Constant-time comparison
    return hmac.compare_digest(expected, signature)


def create_meta_signature(payload: bytes, app_secret: str) -> str:
    """Create Meta webhook signature for testing.

    Args:
        payload: Raw request body bytes
        app_secret: App secret from Meta developer console

    Returns:
        Signature string with 'sha256=' prefix

    Example:
        >>> payload = b'{"test": "data"}'
        >>> signature = create_meta_signature(payload, "secret")
        >>> signature.startswith("sha256=")
        True
    """
    signature = hmac.new(
        app_secret.encode("utf-8"),
        payload,
        hashlib.sha256
    ).hexdigest()

    return f"sha256={signature}"


def verify_tiktok_signature(
    payload: bytes,
    signature: str,
    client_secret: str,
) -> bool:
    """Verify TikTok webhook signature.

    TikTok's signature verification depends on the specific API product.
    This is a placeholder implementation that should be updated based on
    actual TikTok webhook documentation.

    Args:
        payload: Raw request body bytes
        signature: Signature from request header
        client_secret: Client secret from TikTok developer console

    Returns:
        True if signature is valid, False otherwise
    """
    if not signature or not client_secret:
        return False

    # TikTok signature verification (simplified - update based on docs)
    expected = hmac.new(
        client_secret.encode("utf-8"),
        payload,
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(expected, signature)
