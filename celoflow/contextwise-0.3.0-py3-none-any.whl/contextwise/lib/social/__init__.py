"""Shared social network utilities for Contextwise v0.3.0.

This module provides common abstractions and utilities for social network
channel plugins (Instagram, Facebook, TikTok).
"""

from .normalization import (
    NormalizedEvent,
    normalize_meta_event,
    normalize_tiktok_event,
)
from .security import (
    verify_meta_signature,
    create_meta_signature,
)
from .http_client import SocialHTTPClient
from .rate_limiter import RateLimiter

__all__ = [
    # Normalization
    "NormalizedEvent",
    "normalize_meta_event",
    "normalize_tiktok_event",
    # Security
    "verify_meta_signature",
    "create_meta_signature",
    # HTTP Client
    "SocialHTTPClient",
    # Rate Limiter
    "RateLimiter",
]
