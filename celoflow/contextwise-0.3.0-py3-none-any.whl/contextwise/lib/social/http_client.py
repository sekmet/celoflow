"""HTTP client for social network API calls.

This module provides a reusable HTTP client with retry logic and
structured logging for social platform API calls.
"""

import logging
from typing import Any, Dict, Optional
import httpx


logger = logging.getLogger(__name__)


class SocialHTTPClient:
    """Async HTTP client with retry logic for social network APIs.

    Attributes:
        timeout: Request timeout in seconds
        max_retries: Maximum number of retries for transient errors
        retry_status_codes: HTTP status codes that trigger retries
    """

    def __init__(
        self,
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_status_codes: Optional[set] = None,
    ):
        """Initialize HTTP client.

        Args:
            timeout: Request timeout in seconds
            max_retries: Maximum number of retries
            retry_status_codes: Status codes to retry (default: 429, 500, 502, 503, 504)
        """
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_status_codes = retry_status_codes or {429, 500, 502, 503, 504}

    async def post(
        self,
        url: str,
        headers: Dict[str, str],
        json_data: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Send POST request with retry logic.

        Args:
            url: Target URL
            headers: Request headers
            json_data: JSON payload
            data: Form data payload

        Returns:
            Response JSON or None on error

        Raises:
            httpx.HTTPError: On non-retriable errors
        """
        attempt = 0
        last_error = None

        while attempt < self.max_retries:
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    response = await client.post(
                        url,
                        headers=headers,
                        json=json_data,
                        data=data,
                    )

                    # Check if we should retry
                    if response.status_code in self.retry_status_codes:
                        attempt += 1
                        logger.warning(
                            f"Request failed with status {response.status_code}, "
                            f"retry {attempt}/{self.max_retries}"
                        )
                        continue

                    # Raise for other error status codes
                    response.raise_for_status()

                    # Try to parse JSON response
                    try:
                        return response.json()
                    except ValueError:
                        return {"status": "ok", "text": response.text}

            except httpx.HTTPError as e:
                last_error = e
                attempt += 1
                logger.warning(
                    f"HTTP error: {e}, retry {attempt}/{self.max_retries}"
                )

                if attempt >= self.max_retries:
                    logger.error(f"Max retries exceeded for {url}: {e}")
                    raise

        # Should not reach here, but handle it
        if last_error:
            raise last_error

        return None

    async def get(
        self,
        url: str,
        headers: Dict[str, str],
        params: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Send GET request with retry logic.

        Args:
            url: Target URL
            headers: Request headers
            params: Query parameters

        Returns:
            Response JSON or None on error

        Raises:
            httpx.HTTPError: On non-retriable errors
        """
        attempt = 0
        last_error = None

        while attempt < self.max_retries:
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    response = await client.get(
                        url,
                        headers=headers,
                        params=params,
                    )

                    # Check if we should retry
                    if response.status_code in self.retry_status_codes:
                        attempt += 1
                        logger.warning(
                            f"Request failed with status {response.status_code}, "
                            f"retry {attempt}/{self.max_retries}"
                        )
                        continue

                    # Raise for other error status codes
                    response.raise_for_status()

                    # Try to parse JSON response
                    try:
                        return response.json()
                    except ValueError:
                        return {"status": "ok", "text": response.text}

            except httpx.HTTPError as e:
                last_error = e
                attempt += 1
                logger.warning(
                    f"HTTP error: {e}, retry {attempt}/{self.max_retries}"
                )

                if attempt >= self.max_retries:
                    logger.error(f"Max retries exceeded for {url}: {e}")
                    raise

        # Should not reach here, but handle it
        if last_error:
            raise last_error

        return None
