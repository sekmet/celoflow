"""SQLite storage implementation for contextwise.

This module provides a persistent storage backend using SQLite
via SQLAlchemy for session management.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import List, Literal, Optional

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)

try:
    from sqlalchemy.dialects import sqlite
    from sqlalchemy.engine import Engine, create_engine
    from sqlalchemy.inspection import inspect
    from sqlalchemy.orm import Session as SqlSession
    from sqlalchemy.orm import sessionmaker
    from sqlalchemy.schema import Column, MetaData, Table
    from sqlalchemy.sql import text
    from sqlalchemy.sql.expression import select
    from sqlalchemy.types import String
    
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False


class SqliteStorage(Storage):
    """SQLite storage backend using SQLAlchemy.
    
    This storage implementation persists sessions to a SQLite database,
    providing durability across restarts.
    
    Attributes:
        table_name: Name of the database table.
        db_file: Path to the SQLite database file.
        db_engine: SQLAlchemy engine instance.
    
    Example:
        >>> storage = SqliteStorage(
        ...     table_name="agent_sessions",
        ...     db_file="data/sessions.db",
        ...     auto_upgrade_schema=True,
        ... )
        >>> storage.create()
        >>> session = StorageSession(
        ...     session_id="sess1",
        ...     user_id="user1",
        ... )
        >>> storage.upsert(session)
    """
    
    def __init__(
        self,
        table_name: str = "agent_sessions",
        db_url: Optional[str] = None,
        db_file: Optional[str] = None,
        db_engine: Optional["Engine"] = None,
        schema_version: int = 1,
        auto_upgrade_schema: bool = False,
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
    ):
        """Initialize SQLite storage.
        
        Args:
            table_name: Name of the table to store sessions.
            db_url: SQLAlchemy database URL.
            db_file: Path to SQLite database file.
            db_engine: Existing SQLAlchemy engine.
            schema_version: Schema version for migrations.
            auto_upgrade_schema: Auto-upgrade schema on startup.
            mode: Storage mode (agent, team, workflow).
        
        Raises:
            ImportError: If sqlalchemy is not installed.
            ValueError: If no database connection is specified.
        """
        if not SQLALCHEMY_AVAILABLE:
            raise ImportError(
                "sqlalchemy not installed. Install with: uv add sqlalchemy"
            )
        
        super().__init__(mode)
        
        _engine: Optional[Engine] = db_engine
        if _engine is None and db_url is not None:
            _engine = create_engine(db_url)
        elif _engine is None and db_file is not None:
            db_path = Path(db_file).resolve()
            db_path.parent.mkdir(parents=True, exist_ok=True)
            _engine = create_engine(f"sqlite:///{db_path}")
        elif _engine is None:
            # In-memory database
            _engine = create_engine("sqlite://")
        
        self.table_name = table_name
        self.db_url = db_url
        self.db_file = db_file
        self.db_engine: Engine = _engine
        self.metadata = MetaData()
        self.inspector = inspect(self.db_engine)
        
        self.schema_version = schema_version
        self.auto_upgrade_schema = auto_upgrade_schema
        self._schema_up_to_date = False
        
        self.SqlSession: sessionmaker[SqlSession] = sessionmaker(bind=self.db_engine)
        self.table: Table = self._get_table()
        
        logger.debug(f"SqliteStorage initialized: {table_name}")
    
    def _get_table(self) -> Table:
        """Define the table schema.
        
        Returns:
            SQLAlchemy Table object.
        """
        columns = [
            Column("session_id", String, primary_key=True),
            Column("user_id", String, index=True),
            Column("agent_id", String, index=True),
            Column("channel", String),
            Column("locale", String),
            Column("messages", sqlite.JSON),
            Column("memory", sqlite.JSON),
            Column("session_data", sqlite.JSON),
            Column("extra_data", sqlite.JSON),
            Column("created_at", sqlite.INTEGER, default=lambda: int(time.time())),
            Column("updated_at", sqlite.INTEGER, onupdate=lambda: int(time.time())),
        ]
        
        return Table(
            self.table_name,
            self.metadata,
            *columns,
            extend_existing=True,
        )
    
    def table_exists(self) -> bool:
        """Check if the table exists.
        
        Returns:
            True if table exists.
        """
        try:
            with self.SqlSession() as sess:
                result = sess.execute(
                    text("SELECT name FROM sqlite_master WHERE type='table' AND name=:table_name"),
                    {"table_name": self.table_name},
                ).scalar()
                return result is not None
        except Exception as e:
            logger.error(f"Error checking table existence: {e}")
            return False
    
    def create(self) -> None:
        """Create the table if it doesn't exist."""
        if not self.table_exists():
            logger.debug(f"Creating table: {self.table_name}")
            try:
                self.table.create(self.db_engine, checkfirst=True)
                logger.info(f"Table '{self.table_name}' created")
            except Exception as e:
                logger.error(f"Error creating table: {e}")
                raise
    
    def read(
        self, 
        session_id: str, 
        user_id: Optional[str] = None,
    ) -> Optional[StorageSession]:
        """Read a session from the database.
        
        Args:
            session_id: The session ID to read.
            user_id: Optional user ID for filtering.
            
        Returns:
            StorageSession if found, None otherwise.
        """
        try:
            with self.SqlSession() as sess:
                stmt = select(self.table).where(self.table.c.session_id == session_id)
                if user_id:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                result = sess.execute(stmt).fetchone()
                
                if result is not None:
                    return StorageSession.from_dict(dict(result._mapping))
                return None
        except Exception as e:
            if "no such table" in str(e):
                logger.debug(f"Table does not exist: {self.table_name}")
                self.create()
            else:
                logger.debug(f"Error reading session: {e}")
            return None
    
    def get_all_session_ids(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[str]:
        """Get all session IDs, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of session IDs.
        """
        try:
            with self.SqlSession() as sess:
                stmt = select(self.table.c.session_id)
                
                if user_id is not None:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                if agent_id is not None:
                    stmt = stmt.where(self.table.c.agent_id == agent_id)
                
                stmt = stmt.order_by(self.table.c.created_at.desc())
                rows = sess.execute(stmt).fetchall()
                
                return [row[0] for row in rows] if rows else []
        except Exception as e:
            if "no such table" in str(e):
                self.create()
            else:
                logger.debug(f"Error getting session IDs: {e}")
            return []
    
    def get_all_sessions(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[StorageSession]:
        """Get all sessions, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of sessions.
        """
        try:
            with self.SqlSession() as sess:
                stmt = select(self.table)
                
                if user_id is not None:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                if agent_id is not None:
                    stmt = stmt.where(self.table.c.agent_id == agent_id)
                
                stmt = stmt.order_by(self.table.c.created_at.desc())
                rows = sess.execute(stmt).fetchall()
                
                if rows:
                    return [StorageSession.from_dict(dict(row._mapping)) for row in rows]
                return []
        except Exception as e:
            if "no such table" in str(e):
                self.create()
            else:
                logger.debug(f"Error getting sessions: {e}")
            return []
    
    def get_recent_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> List[StorageSession]:
        """Get the most recent sessions.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            limit: Maximum number of sessions to return.
            
        Returns:
            List of recent sessions, ordered by created_at descending.
        """
        try:
            with self.SqlSession() as sess:
                stmt = select(self.table)
                
                if user_id is not None:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                if agent_id is not None:
                    stmt = stmt.where(self.table.c.agent_id == agent_id)
                
                stmt = stmt.order_by(self.table.c.created_at.desc())
                if limit is not None:
                    stmt = stmt.limit(limit)
                
                rows = sess.execute(stmt).fetchall()
                
                if rows:
                    return [StorageSession.from_dict(dict(row._mapping)) for row in rows]
                return []
        except Exception as e:
            if "no such table" in str(e):
                self.create()
            else:
                logger.debug(f"Error getting recent sessions: {e}")
            return []
    
    def upsert(
        self, 
        session: StorageSession, 
        create_and_retry: bool = True,
    ) -> Optional[StorageSession]:
        """Insert or update a session.
        
        Args:
            session: The session to upsert.
            create_and_retry: Retry if table doesn't exist.
            
        Returns:
            The upserted session, or None on failure.
        """
        if self.auto_upgrade_schema and not self._schema_up_to_date:
            self.upgrade_schema()
        
        try:
            with self.SqlSession() as sess, sess.begin():
                stmt = sqlite.insert(self.table).values(
                    session_id=session.session_id,
                    user_id=session.user_id,
                    agent_id=session.agent_id,
                    channel=session.channel,
                    locale=session.locale,
                    messages=session.messages,
                    memory=session.memory,
                    session_data=session.session_data,
                    extra_data=session.extra_data,
                    created_at=session.created_at or int(time.time()),
                    updated_at=int(time.time()),
                )
                
                stmt = stmt.on_conflict_do_update(
                    index_elements=["session_id"],
                    set_=dict(
                        user_id=session.user_id,
                        agent_id=session.agent_id,
                        channel=session.channel,
                        locale=session.locale,
                        messages=session.messages,
                        memory=session.memory,
                        session_data=session.session_data,
                        extra_data=session.extra_data,
                        updated_at=int(time.time()),
                    ),
                )
                
                sess.execute(stmt)
            
            return self.read(session.session_id)
        except Exception as e:
            if create_and_retry and "no such table" in str(e):
                logger.debug("Table does not exist, creating...")
                self.create()
                return self.upsert(session, create_and_retry=False)
            else:
                logger.warning(f"Error upserting session: {e}")
                return None
    
    def delete_session(self, session_id: str) -> None:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete.
        """
        try:
            with self.SqlSession() as sess, sess.begin():
                delete_stmt = self.table.delete().where(
                    self.table.c.session_id == session_id
                )
                result = sess.execute(delete_stmt)
                
                if result.rowcount == 0:
                    logger.debug(f"No session found: {session_id}")
                else:
                    logger.debug(f"Deleted session: {session_id}")
        except Exception as e:
            logger.error(f"Error deleting session: {e}")
    
    def drop(self) -> None:
        """Drop the table from the database."""
        if self.table_exists():
            logger.debug(f"Dropping table: {self.table_name}")
            self.table.drop(self.db_engine, checkfirst=True)
            self.metadata = MetaData()
            self.table = self._get_table()
    
    def upgrade_schema(self) -> None:
        """Upgrade the schema if needed."""
        if not self.auto_upgrade_schema:
            logger.debug("Auto schema upgrade disabled")
            return
        
        self._schema_up_to_date = True
        logger.debug("Schema upgrade completed")
    
    def close(self) -> None:
        """Close database connections."""
        try:
            self.db_engine.dispose()
            logger.debug("SqliteStorage connections closed")
        except Exception as e:
            logger.warning(f"Error closing connections: {e}")
