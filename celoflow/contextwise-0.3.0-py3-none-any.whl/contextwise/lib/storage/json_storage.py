"""JSON file-based storage implementation for contextwise.

This module provides a persistent storage backend that stores
sessions as JSON files in a directory.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import List, Literal, Optional, Union

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)


class JsonStorage(Storage):
    """JSON file-based storage backend.
    
    This storage implementation persists each session as a separate
    JSON file in a specified directory.
    
    Attributes:
        dir_path: Directory path for storing JSON files.
    
    Example:
        >>> storage = JsonStorage(dir_path="data/sessions")
        >>> session = StorageSession(
        ...     session_id="sess1",
        ...     user_id="user1",
        ... )
        >>> storage.upsert(session)
        >>> # Creates: data/sessions/sess1.json
    """
    
    def __init__(
        self,
        dir_path: Union[str, Path] = "data/sessions",
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
    ):
        """Initialize JSON storage.
        
        Args:
            dir_path: Directory path for JSON files.
            mode: Storage mode (agent, team, workflow).
        """
        super().__init__(mode)
        self.dir_path = Path(dir_path)
        self.dir_path.mkdir(parents=True, exist_ok=True)
        logger.debug(f"JsonStorage initialized: {self.dir_path}")
    
    def _serialize(self, data: dict) -> str:
        """Serialize data to JSON string."""
        return json.dumps(data, ensure_ascii=False, indent=2)
    
    def _deserialize(self, data: str) -> dict:
        """Deserialize JSON string to dict."""
        return json.loads(data)
    
    def _get_file_path(self, session_id: str) -> Path:
        """Get file path for a session."""
        return self.dir_path / f"{session_id}.json"
    
    def create(self) -> None:
        """Create the storage directory if it doesn't exist."""
        if not self.dir_path.exists():
            self.dir_path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created directory: {self.dir_path}")
    
    def read(
        self, 
        session_id: str, 
        user_id: Optional[str] = None,
    ) -> Optional[StorageSession]:
        """Read a session from storage.
        
        Args:
            session_id: The session ID to read.
            user_id: Optional user ID for filtering.
            
        Returns:
            StorageSession if found, None otherwise.
        """
        try:
            file_path = self._get_file_path(session_id)
            if not file_path.exists():
                return None
            
            with open(file_path, "r", encoding="utf-8") as f:
                data = self._deserialize(f.read())
            
            if user_id and data.get("user_id") != user_id:
                return None
            
            return StorageSession.from_dict(data)
        except FileNotFoundError:
            return None
        except Exception as e:
            logger.error(f"Error reading session {session_id}: {e}")
            return None
    
    def get_all_session_ids(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[str]:
        """Get all session IDs, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of session IDs.
        """
        session_ids = []
        
        for file in self.dir_path.glob("*.json"):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    data = self._deserialize(f.read())
                
                include = True
                if user_id and data.get("user_id") != user_id:
                    include = False
                if agent_id and data.get("agent_id") != agent_id:
                    include = False
                
                if include:
                    session_ids.append(data.get("session_id", file.stem))
            except Exception as e:
                logger.warning(f"Error reading {file}: {e}")
        
        return session_ids
    
    def get_all_sessions(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[StorageSession]:
        """Get all sessions, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of sessions.
        """
        sessions: List[StorageSession] = []
        
        for file in self.dir_path.glob("*.json"):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    data = self._deserialize(f.read())
                
                include = True
                if user_id and data.get("user_id") != user_id:
                    include = False
                if agent_id and data.get("agent_id") != agent_id:
                    include = False
                
                if include:
                    sessions.append(StorageSession.from_dict(data))
            except Exception as e:
                logger.warning(f"Error reading {file}: {e}")
        
        return sessions
    
    def get_recent_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> List[StorageSession]:
        """Get the most recent sessions.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            limit: Maximum number of sessions to return.
            
        Returns:
            List of recent sessions, ordered by created_at descending.
        """
        session_data: List[tuple[int, dict]] = []
        
        for file in self.dir_path.glob("*.json"):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    data = self._deserialize(f.read())
                
                if user_id and data.get("user_id") != user_id:
                    continue
                if agent_id and data.get("agent_id") != agent_id:
                    continue
                
                created_at = data.get("created_at", 0)
                session_data.append((created_at, data))
            except Exception as e:
                logger.warning(f"Error reading {file}: {e}")
        
        # Sort by created_at descending
        session_data.sort(key=lambda x: x[0], reverse=True)
        
        # Apply limit
        if limit is not None:
            session_data = session_data[:limit]
        
        # Convert to sessions
        sessions: List[StorageSession] = []
        for _, data in session_data:
            try:
                sessions.append(StorageSession.from_dict(data))
            except Exception as e:
                logger.warning(f"Error parsing session: {e}")
        
        return sessions
    
    def upsert(self, session: StorageSession) -> Optional[StorageSession]:
        """Insert or update a session.
        
        Args:
            session: The session to upsert.
            
        Returns:
            The upserted session, or None on failure.
        """
        try:
            data = session.to_dict()
            data["updated_at"] = int(time.time())
            if not data.get("created_at"):
                data["created_at"] = data["updated_at"]
            
            file_path = self._get_file_path(session.session_id)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(self._serialize(data))
            
            return session
        except Exception as e:
            logger.error(f"Error upserting session: {e}")
            return None
    
    def delete_session(self, session_id: str) -> None:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete.
        """
        try:
            file_path = self._get_file_path(session_id)
            file_path.unlink(missing_ok=True)
            logger.debug(f"Deleted session: {session_id}")
        except Exception as e:
            logger.error(f"Error deleting session: {e}")
    
    def drop(self) -> None:
        """Drop all sessions from storage."""
        for file in self.dir_path.glob("*.json"):
            try:
                file.unlink()
            except Exception as e:
                logger.warning(f"Error deleting {file}: {e}")
        logger.debug(f"Dropped all sessions from {self.dir_path}")
