"""Storage plugin for contextwise agents.

This module provides a plugin wrapper for storage backends,
integrating them with the contextwise plugin system.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from agents import Agent

from ..base import AgentPlugin
from ..context import AgentContext
from .base import Storage, StorageSession

logger = logging.getLogger(__name__)


@dataclass
class StoragePlugin(AgentPlugin[AgentContext]):
    """Plugin for integrating storage backends with agents.
    
    This plugin wraps a Storage backend and provides automatic
    session management for agent conversations.
    
    Attributes:
        id: Plugin identifier.
        name: Human-readable plugin name.
        version: Plugin version.
        storage: The storage backend to use.
        auto_save: Automatically save after each message.
    
    Example:
        >>> from contextwise.lib.storage import SqliteStorage, StoragePlugin
        >>> 
        >>> storage = SqliteStorage(
        ...     table_name="sessions",
        ...     db_file="data/sessions.db",
        ... )
        >>> plugin = StoragePlugin(storage=storage)
        >>> 
        >>> plugin_manager = PluginManager(
        ...     base_agent=agent,
        ...     plugins=[plugin],
        ... )
    """
    
    # Plugin metadata
    id: str = "storage"
    name: str = "Storage Plugin"
    version: str = "1.0.0"
    
    # Configuration
    storage: Optional[Storage] = None
    auto_save: bool = True
    
    # Internal cache
    _session_cache: Dict[str, StorageSession] = field(default_factory=dict, repr=False)
    
    def __post_init__(self):
        """Initialize the plugin."""
        if self.storage is not None:
            self.storage.create()
    
    def dependencies(self) -> List[str]:
        """Return plugin IDs that must be loaded before this plugin."""
        return []
    
    def get_session(self, context: AgentContext) -> StorageSession:
        """Get or create a session for the context.
        
        Args:
            context: Agent context.
            
        Returns:
            StorageSession for the context.
        """
        session_id = context.session_id or context.user_id
        
        # Check cache first
        if session_id in self._session_cache:
            return self._session_cache[session_id]
        
        # Try to read from storage
        if self.storage is not None:
            session = self.storage.read(session_id, user_id=context.user_id)
            if session is not None:
                self._session_cache[session_id] = session
                return session
        
        # Create new session
        session = StorageSession(
            session_id=session_id,
            user_id=context.user_id,
            channel=context.channel,
            locale=context.locale,
        )
        self._session_cache[session_id] = session
        return session
    
    def save_session(self, session: StorageSession) -> Optional[StorageSession]:
        """Save a session to storage.
        
        Args:
            session: The session to save.
            
        Returns:
            The saved session, or None on failure.
        """
        if self.storage is None:
            return session
        
        result = self.storage.upsert(session)
        if result is not None:
            self._session_cache[session.session_id] = result
        return result
    
    def on_before_run(
        self, 
        context: AgentContext, 
        input_text: str,
    ) -> None:
        """Store user message before agent run.
        
        Args:
            context: Agent context.
            input_text: User's input message.
        """
        session = self.get_session(context)
        session.add_message("user", input_text)
        
        if self.auto_save:
            self.save_session(session)
    
    def on_after_run(
        self, 
        context: AgentContext, 
        result: Any,
    ) -> None:
        """Store assistant response after agent run.
        
        Args:
            context: Agent context.
            result: Run result.
        """
        if hasattr(result, "final_output") and result.final_output:
            session = self.get_session(context)
            session.add_message("assistant", result.final_output)
            
            if self.auto_save:
                self.save_session(session)
    
    def get_messages(
        self, 
        context: AgentContext, 
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Get messages for context.
        
        Args:
            context: Agent context.
            limit: Maximum number of messages.
            
        Returns:
            List of messages.
        """
        session = self.get_session(context)
        return session.get_messages(limit)
    
    def configure_agent(
        self, 
        agent: Agent[AgentContext],
    ) -> Agent[AgentContext]:
        """Configure agent (no-op for storage plugin).
        
        Args:
            agent: The agent to configure.
            
        Returns:
            Unchanged agent.
        """
        return agent
    
    def clear_cache(self) -> None:
        """Clear the session cache."""
        self._session_cache.clear()
        logger.debug("Session cache cleared")
    
    def close(self) -> None:
        """Close storage connections."""
        if self.storage is not None:
            self.storage.close()


# Backwards compatibility alias
StorageBackendPlugin = StoragePlugin
