"""Storage migration tools for contextwise.

This module provides utilities for migrating data between different storage
backends, exporting/importing sessions, and creating backups.

Example:
    >>> from contextwise.lib.storage import SqliteStorage, PostgresStorage
    >>> from contextwise.lib.storage.migration import migrate_storage
    >>>
    >>> # Migrate from SQLite to PostgreSQL
    >>> source = SqliteStorage(db_path="sessions.db")
    >>> target = PostgresStorage(host="localhost", database="agent_db", ...)
    >>> await migrate_storage(source, target, progress=True)
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)


@dataclass
class MigrationResult:
    """Result of a storage migration operation."""

    users_migrated: int = 0
    sessions_migrated: int = 0
    errors: List[Dict[str, Any]] = field(default_factory=list)
    duration_seconds: float = 0.0
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    @property
    def success(self) -> bool:
        """Check if migration completed without errors."""
        return len(self.errors) == 0

    @property
    def summary(self) -> str:
        """Get migration summary string."""
        status = "✓ Success" if self.success else f"⚠ {len(self.errors)} errors"
        return (
            f"Migration {status}\n"
            f"  Users: {self.users_migrated}\n"
            f"  Sessions: {self.sessions_migrated}\n"
            f"  Duration: {self.duration_seconds:.2f}s"
        )


@dataclass
class MigrationConfig:
    """Configuration for storage migration."""

    batch_size: int = 100
    skip_existing: bool = False
    validate_data: bool = True
    dry_run: bool = False
    progress_callback: Optional[Callable[[int, int], None]] = None


async def migrate_storage(
    source: Storage,
    target: Storage,
    config: Optional[MigrationConfig] = None,
    progress: bool = False,
) -> MigrationResult:
    """Migrate all data from source storage to target storage.

    Args:
        source: Source storage backend to migrate from.
        target: Target storage backend to migrate to.
        config: Migration configuration options.
        progress: If True, print progress messages.

    Returns:
        MigrationResult with migration statistics and any errors.

    Example:
        >>> source = SqliteStorage("old.db")
        >>> target = PostgresStorage(...)
        >>> result = await migrate_storage(source, target, progress=True)
        >>> print(result.summary)
    """
    if config is None:
        config = MigrationConfig()

    result = MigrationResult(start_time=datetime.now())
    start_time = asyncio.get_event_loop().time()

    try:
        # Get all user IDs from source
        if progress:
            print("Discovering users...")

        user_ids = await _get_all_users(source)
        result.users_migrated = len(user_ids)

        if progress:
            print(f"Found {len(user_ids)} users")

        # Migrate sessions for each user
        total_sessions = 0
        for user_idx, user_id in enumerate(user_ids, 1):
            if progress:
                print(f"Migrating user {user_idx}/{len(user_ids)}: {user_id}")

            try:
                # Get all sessions for this user
                session_ids = await source.list_sessions(user_id)

                for session_id in session_ids:
                    total_sessions += 1

                    try:
                        # Check if should skip existing
                        if config.skip_existing:
                            existing = await target.get_session(user_id, session_id)
                            if existing:
                                if progress:
                                    print(f"  Skipping existing session: {session_id}")
                                continue

                        # Get session from source
                        session = await source.get_session(user_id, session_id)
                        if not session:
                            logger.warning(f"Session {session_id} not found for user {user_id}")
                            continue

                        # Validate data if requested
                        if config.validate_data:
                            _validate_session(session)

                        # Save to target (unless dry run)
                        if not config.dry_run:
                            await target.save_session(user_id, session_id, session)

                        result.sessions_migrated += 1

                        if progress and total_sessions % 10 == 0:
                            print(f"  Migrated {total_sessions} sessions...")

                        # Progress callback
                        if config.progress_callback:
                            config.progress_callback(total_sessions, len(session_ids))

                    except Exception as e:
                        error = {
                            "user_id": user_id,
                            "session_id": session_id,
                            "error": str(e),
                        }
                        result.errors.append(error)
                        logger.error(f"Error migrating session {session_id}: {e}")

            except Exception as e:
                error = {
                    "user_id": user_id,
                    "error": str(e),
                }
                result.errors.append(error)
                logger.error(f"Error migrating user {user_id}: {e}")

        # Calculate duration
        end_time = asyncio.get_event_loop().time()
        result.duration_seconds = end_time - start_time
        result.end_time = datetime.now()

        if progress:
            print(f"\n{result.summary}")

    except Exception as e:
        logger.error(f"Migration failed: {e}")
        result.errors.append({"error": str(e)})

    return result


async def export_sessions(
    storage: Storage,
    output_path: Path,
    user_ids: Optional[List[str]] = None,
    format: str = "json",
) -> int:
    """Export sessions from storage to a file.

    Args:
        storage: Storage backend to export from.
        output_path: Path to output file.
        user_ids: Optional list of user IDs to export. If None, exports all.
        format: Export format ('json' or 'jsonl').

    Returns:
        Number of sessions exported.

    Example:
        >>> storage = SqliteStorage("sessions.db")
        >>> count = await export_sessions(storage, Path("backup.json"))
        >>> print(f"Exported {count} sessions")
    """
    if user_ids is None:
        user_ids = await _get_all_users(storage)

    exported_count = 0
    export_data = []

    for user_id in user_ids:
        session_ids = await storage.list_sessions(user_id)

        for session_id in session_ids:
            session = await storage.get_session(user_id, session_id)
            if session:
                export_item = {
                    "user_id": user_id,
                    "session_id": session_id,
                    "messages": session.messages,
                    "metadata": session.metadata,
                    "created_at": session.created_at.isoformat(),
                    "updated_at": session.updated_at.isoformat(),
                }
                export_data.append(export_item)
                exported_count += 1

    # Write to file
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if format == "jsonl":
        # JSON Lines format (one JSON object per line)
        with output_path.open("w") as f:
            for item in export_data:
                f.write(json.dumps(item) + "\n")
    else:
        # Standard JSON format
        with output_path.open("w") as f:
            json.dump(export_data, f, indent=2)

    logger.info(f"Exported {exported_count} sessions to {output_path}")
    return exported_count


async def import_sessions(
    storage: Storage,
    input_path: Path,
    format: str = "json",
    skip_existing: bool = False,
) -> int:
    """Import sessions from a file into storage.

    Args:
        storage: Storage backend to import into.
        input_path: Path to input file.
        format: Import format ('json' or 'jsonl').
        skip_existing: If True, skip sessions that already exist.

    Returns:
        Number of sessions imported.

    Example:
        >>> storage = PostgresStorage(...)
        >>> count = await import_sessions(storage, Path("backup.json"))
        >>> print(f"Imported {count} sessions")
    """
    imported_count = 0

    # Read from file
    if format == "jsonl":
        # JSON Lines format
        import_data = []
        with input_path.open("r") as f:
            for line in f:
                if line.strip():
                    import_data.append(json.loads(line))
    else:
        # Standard JSON format
        with input_path.open("r") as f:
            import_data = json.load(f)

    # Import each session
    for item in import_data:
        user_id = item["user_id"]
        session_id = item["session_id"]

        # Check if should skip existing
        if skip_existing:
            existing = await storage.get_session(user_id, session_id)
            if existing:
                logger.debug(f"Skipping existing session: {session_id}")
                continue

        # Create session object
        session = StorageSession(
            messages=item["messages"],
            metadata=item["metadata"],
            created_at=datetime.fromisoformat(item["created_at"]),
            updated_at=datetime.fromisoformat(item["updated_at"]),
        )

        # Save session
        await storage.save_session(user_id, session_id, session)
        imported_count += 1

    logger.info(f"Imported {imported_count} sessions from {input_path}")
    return imported_count


async def backup_storage(
    storage: Storage,
    backup_path: Path,
    compress: bool = True,
) -> Path:
    """Create a backup of all storage data.

    Args:
        storage: Storage backend to backup.
        backup_path: Path to backup directory.
        compress: If True, compress backup with gzip.

    Returns:
        Path to created backup file.

    Example:
        >>> storage = SqliteStorage("sessions.db")
        >>> backup_file = await backup_storage(storage, Path("backups"))
        >>> print(f"Backup created: {backup_file}")
    """
    # Create backup filename with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"storage_backup_{timestamp}.json"
    if compress:
        filename += ".gz"

    output_path = backup_path / filename
    backup_path.mkdir(parents=True, exist_ok=True)

    # Export sessions
    if compress:
        import gzip
        # Export to temp file first
        temp_path = backup_path / f"temp_{timestamp}.json"
        await export_sessions(storage, temp_path)

        # Compress
        with temp_path.open("rb") as f_in:
            with gzip.open(output_path, "wb") as f_out:
                f_out.writelines(f_in)

        # Remove temp file
        temp_path.unlink()
    else:
        await export_sessions(storage, output_path)

    logger.info(f"Backup created: {output_path}")
    return output_path


async def restore_storage(
    storage: Storage,
    backup_path: Path,
    skip_existing: bool = True,
) -> int:
    """Restore storage data from a backup.

    Args:
        storage: Storage backend to restore into.
        backup_path: Path to backup file.
        skip_existing: If True, skip sessions that already exist.

    Returns:
        Number of sessions restored.

    Example:
        >>> storage = PostgresStorage(...)
        >>> count = await restore_storage(
        ...     storage,
        ...     Path("backups/storage_backup_20240101_120000.json")
        ... )
        >>> print(f"Restored {count} sessions")
    """
    # Check if compressed
    if backup_path.suffix == ".gz":
        import gzip
        # Decompress to temp file
        temp_path = backup_path.parent / f"temp_{backup_path.stem}"

        with gzip.open(backup_path, "rb") as f_in:
            with temp_path.open("wb") as f_out:
                f_out.write(f_in.read())

        # Import from temp file
        count = await import_sessions(storage, temp_path, skip_existing=skip_existing)

        # Remove temp file
        temp_path.unlink()
    else:
        count = await import_sessions(storage, backup_path, skip_existing=skip_existing)

    logger.info(f"Restored {count} sessions from {backup_path}")
    return count


async def validate_storage(storage: Storage) -> Dict[str, Any]:
    """Validate storage data integrity.

    Args:
        storage: Storage backend to validate.

    Returns:
        Dictionary with validation results.

    Example:
        >>> storage = SqliteStorage("sessions.db")
        >>> results = await validate_storage(storage)
        >>> print(f"Valid: {results['valid']}")
        >>> print(f"Issues: {results['issues']}")
    """
    results = {
        "valid": True,
        "users": 0,
        "sessions": 0,
        "issues": [],
    }

    user_ids = await _get_all_users(storage)
    results["users"] = len(user_ids)

    for user_id in user_ids:
        session_ids = await storage.list_sessions(user_id)

        for session_id in session_ids:
            results["sessions"] += 1

            try:
                session = await storage.get_session(user_id, session_id)
                if not session:
                    results["valid"] = False
                    results["issues"].append({
                        "user_id": user_id,
                        "session_id": session_id,
                        "issue": "Session not found"
                    })
                    continue

                # Validate session data
                try:
                    _validate_session(session)
                except ValueError as e:
                    results["valid"] = False
                    results["issues"].append({
                        "user_id": user_id,
                        "session_id": session_id,
                        "issue": str(e)
                    })

            except Exception as e:
                results["valid"] = False
                results["issues"].append({
                    "user_id": user_id,
                    "session_id": session_id,
                    "issue": f"Error reading session: {e}"
                })

    return results


# Helper functions

async def _get_all_users(storage: Storage) -> List[str]:
    """Get all unique user IDs from storage.

    This is a helper that attempts various methods since the Storage
    interface doesn't have a standard list_users method.
    """
    # Try different methods based on storage type
    if hasattr(storage, "list_users"):
        return await storage.list_users()

    # Fallback: try to discover users through storage-specific methods
    if hasattr(storage, "_conn") or hasattr(storage, "_pool"):
        # SQL-based storage
        return await _get_users_from_sql_storage(storage)
    elif hasattr(storage, "_data"):
        # In-memory or file-based storage
        return list(storage._data.keys())
    else:
        logger.warning("Unable to list users, returning empty list")
        return []


async def _get_users_from_sql_storage(storage: Storage) -> List[str]:
    """Get user IDs from SQL-based storage."""
    # This is storage-specific and would need to be implemented
    # based on the actual table schema
    raise NotImplementedError("SQL storage user listing not implemented")


def _validate_session(session: StorageSession) -> None:
    """Validate session data structure.

    Raises:
        ValueError: If session data is invalid.
    """
    if not isinstance(session.messages, list):
        raise ValueError("Session messages must be a list")

    if not isinstance(session.metadata, dict):
        raise ValueError("Session metadata must be a dictionary")

    if not isinstance(session.created_at, datetime):
        raise ValueError("Session created_at must be a datetime")

    if not isinstance(session.updated_at, datetime):
        raise ValueError("Session updated_at must be a datetime")

    # Validate messages structure
    for i, msg in enumerate(session.messages):
        if not isinstance(msg, dict):
            raise ValueError(f"Message {i} must be a dictionary")

        if "role" not in msg or "content" not in msg:
            raise ValueError(f"Message {i} missing required fields (role, content)")
