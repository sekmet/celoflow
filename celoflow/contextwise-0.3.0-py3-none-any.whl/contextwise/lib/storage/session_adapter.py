"""Storage session adapter for SDK Session integration.

This module provides an adapter that bridges Contextwise StorageSession
and the SDK SessionABC interface, enabling storage backends to work
with Agent.chat() session management.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional

from agents import Session, SessionABC, TResponseInputItem

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)


class StorageSessionBackend(SessionABC):
    """SDK SessionABC implementation backed by Contextwise Storage.

    This class wraps a StorageSession and provides the SessionABC interface
    expected by the agents SDK. It handles conversion between StorageSession.messages
    (dict format) and SDK TResponseInputItem objects.

    Attributes:
        session_id: Unique session identifier
        storage: Storage backend for persistence
        storage_session: The underlying StorageSession

    Example:
        >>> storage = SqliteStorage(db_file="sessions.db")
        >>> storage.create()
        >>> backend = StorageSessionBackend(
        ...     session_id="user123_session",
        ...     user_id="user123",
        ...     storage=storage
        ... )
        >>> await backend.add_items([{"role": "user", "content": "Hello"}])
        >>> items = await backend.get_items()
    """

    def __init__(
        self,
        session_id: str,
        user_id: str,
        storage: Storage,
        channel: str = "api",
        locale: str = "en",
    ):
        """Initialize storage-backed session.

        Args:
            session_id: Unique session identifier
            user_id: User identifier
            storage: Storage backend for persistence
            channel: Communication channel (default: "api")
            locale: User locale (default: "en")
        """
        self.session_id = session_id
        self._user_id = user_id
        self._storage = storage
        self._channel = channel
        self._locale = locale

        # Try to load existing session
        self.storage_session = storage.read(session_id, user_id=user_id)

        # Create new session if not found
        if self.storage_session is None:
            self.storage_session = StorageSession(
                session_id=session_id,
                user_id=user_id,
                channel=channel,
                locale=locale,
            )
            # Persist the new session
            storage.upsert(self.storage_session)

    async def get_items(self, limit: Optional[int] = None) -> List[TResponseInputItem]:
        """Get conversation items from storage.

        Args:
            limit: Maximum number of items to return (most recent)

        Returns:
            List of response input items
        """
        messages = self.storage_session.get_messages(limit)
        # Convert dict messages to TResponseInputItem format
        # The SDK expects items that can be serialized/deserialized
        # We'll use the dict format directly as it's compatible
        return messages  # type: ignore

    async def add_items(self, items: List[TResponseInputItem]) -> None:
        """Add conversation items to storage.

        Args:
            items: List of items to add
        """
        # Convert items to dict format for storage
        for item in items:
            # Handle different item types
            if isinstance(item, dict):
                # Already in dict format
                role = item.get("role", "assistant")
                content = item.get("content", "")
                if content:  # Only add items with content
                    self.storage_session.add_message(role, content, **{
                        k: v for k, v in item.items()
                        if k not in ("role", "content")
                    })
            else:
                # Complex type - serialize to JSON for storage
                try:
                    # Try to get dict representation
                    if hasattr(item, "model_dump"):
                        item_dict = item.model_dump()
                    elif hasattr(item, "to_dict"):
                        item_dict = item.to_dict()
                    elif hasattr(item, "__dict__"):
                        item_dict = item.__dict__
                    else:
                        item_dict = {"type": str(type(item)), "value": str(item)}

                    # Store as assistant message with metadata
                    role = item_dict.get("role", "assistant")
                    content = item_dict.get("content") or json.dumps(item_dict)
                    self.storage_session.add_message(role, content)
                except Exception as e:
                    logger.warning(f"Failed to serialize item {item}: {e}")
                    # Store as string fallback
                    self.storage_session.add_message("assistant", str(item))

        # Persist to storage
        self._storage.upsert(self.storage_session)

    async def pop_item(self) -> Optional[TResponseInputItem]:
        """Remove and return the last item.

        Returns:
            Last item or None if empty
        """
        if not self.storage_session.messages:
            return None

        item = self.storage_session.messages.pop()
        # Persist changes
        self._storage.upsert(self.storage_session)
        return item  # type: ignore

    async def clear_session(self) -> None:
        """Clear all items from the session."""
        self.storage_session.messages.clear()
        # Persist changes
        self._storage.upsert(self.storage_session)


class StorageBackendAdapter:
    """Adapter providing get_session() for Agent integration.

    This adapter wraps a Storage backend and provides the get_session()
    method expected by Agent.chat(). It creates StorageSessionBackend
    instances that implement the SDK SessionABC interface.

    Attributes:
        storage: The underlying storage backend

    Example:
        >>> storage = SqliteStorage(db_file="sessions.db")
        >>> storage.create()
        >>> adapter = StorageBackendAdapter(storage)
        >>>
        >>> # Use with Agent
        >>> agent = Agent(
        ...     model="gpt-4o-mini",
        ...     instructions="You are helpful",
        ...     storage=adapter
        ... )
    """

    def __init__(self, storage: Storage):
        """Initialize the adapter.

        Args:
            storage: Storage backend to wrap
        """
        self.storage = storage
        # Ensure storage is initialized
        storage.create()

    def get_session(self, user_id: str, session_id: str) -> Session:
        """Get or create a session for the user.

        This method is called by Agent.chat() to get a Session instance
        for managing conversation state.

        Args:
            user_id: User identifier
            session_id: Session identifier

        Returns:
            Session instance backed by storage
        """
        # Create StorageSessionBackend which implements SessionABC
        backend = StorageSessionBackend(
            session_id=session_id,
            user_id=user_id,
            storage=self.storage,
        )
        # Return as Session (SessionABC is compatible)
        return backend  # type: ignore

    def __getattr__(self, name: str) -> Any:
        """Proxy other methods to the underlying storage."""
        return getattr(self.storage, name)
