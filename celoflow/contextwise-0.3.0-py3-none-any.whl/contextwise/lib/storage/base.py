"""Base storage classes for contextwise.

This module provides the abstract base class for all storage backends
and the StorageSession dataclass for session management.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Literal, Optional


@dataclass
class StorageSession:
    """Session data for storage.
    
    This class represents a conversation session that can be persisted
    across restarts. It stores messages, metadata, and timestamps.
    
    Attributes:
        session_id: Unique identifier for the session.
        user_id: Unique identifier for the user.
        agent_id: Identifier for the agent (optional).
        channel: Communication channel (api, whatsapp, etc.).
        locale: User's locale.
        messages: List of conversation messages.
        memory: Structured memory data (dict).
        session_data: Additional session data.
        extra_data: Extra metadata.
        created_at: Unix timestamp of creation.
        updated_at: Unix timestamp of last update.
    
    Example:
        >>> session = StorageSession(
        ...     session_id="user123-session1",
        ...     user_id="user123",
        ...     agent_id="assistant",
        ...     messages=[{"role": "user", "content": "Hello"}],
        ... )
    """
    
    session_id: str
    user_id: str
    agent_id: Optional[str] = None
    channel: str = "api"
    locale: str = "en"
    messages: List[Dict[str, Any]] = field(default_factory=list)
    memory: Optional[Dict[str, Any]] = None
    session_data: Optional[Dict[str, Any]] = None
    extra_data: Optional[Dict[str, Any]] = None
    created_at: Optional[int] = None
    updated_at: Optional[int] = None
    
    def __post_init__(self):
        """Initialize timestamps if not provided."""
        now = int(time.time())
        if self.created_at is None:
            self.created_at = now
        if self.updated_at is None:
            self.updated_at = now
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert session to dictionary.
        
        Returns:
            Dict representation of the session.
        """
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StorageSession":
        """Create session from dictionary.
        
        Args:
            data: Dictionary with session data.
            
        Returns:
            StorageSession instance.
        """
        # Filter to only known fields
        known_fields = {
            "session_id", "user_id", "agent_id", "channel", "locale",
            "messages", "memory", "session_data", "extra_data",
            "created_at", "updated_at"
        }
        filtered_data = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered_data)
    
    def add_message(self, role: str, content: str, **kwargs) -> None:
        """Add a message to the session.
        
        Args:
            role: Message role (user, assistant, system).
            content: Message content.
            **kwargs: Additional message metadata.
        """
        message = {"role": role, "content": content, **kwargs}
        self.messages.append(message)
        self.updated_at = int(time.time())
    
    def get_messages(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get messages from the session.
        
        Args:
            limit: Maximum number of messages to return.
            
        Returns:
            List of messages (most recent last).
        """
        if limit is not None:
            return self.messages[-limit:]
        return self.messages


class Storage(ABC):
    """Abstract base class for storage backends.
    
    All storage implementations must inherit from this class and
    implement the abstract methods.
    
    Attributes:
        mode: Storage mode (agent, team, workflow).
    
    Example:
        >>> class MyStorage(Storage):
        ...     def create(self) -> None:
        ...         pass  # Initialize storage
        ...     def read(self, session_id: str, user_id: Optional[str] = None) -> Optional[StorageSession]:
        ...         pass  # Read session
        ...     # ... implement other methods
    """
    
    def __init__(
        self, 
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
    ):
        """Initialize storage.
        
        Args:
            mode: Storage mode (agent, team, workflow).
        """
        self._mode: Literal["agent", "team", "workflow"] = "agent" if mode is None else mode
    
    @property
    def mode(self) -> Literal["agent", "team", "workflow"]:
        """Get the storage mode."""
        return self._mode
    
    @mode.setter
    def mode(self, value: Optional[Literal["agent", "team", "workflow"]]) -> None:
        """Set the storage mode."""
        self._mode = "agent" if value is None else value
    
    @abstractmethod
    def create(self) -> None:
        """Create the storage if it doesn't exist.
        
        This method should initialize any necessary resources
        like database tables, files, or connections.
        """
        raise NotImplementedError
    
    @abstractmethod
    def read(
        self, 
        session_id: str, 
        user_id: Optional[str] = None,
    ) -> Optional[StorageSession]:
        """Read a session from storage.
        
        Args:
            session_id: The session ID to read.
            user_id: Optional user ID for filtering.
            
        Returns:
            StorageSession if found, None otherwise.
        """
        raise NotImplementedError
    
    @abstractmethod
    def get_all_session_ids(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[str]:
        """Get all session IDs, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of session IDs.
        """
        raise NotImplementedError
    
    @abstractmethod
    def get_all_sessions(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[StorageSession]:
        """Get all sessions, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of sessions.
        """
        raise NotImplementedError
    
    @abstractmethod
    def get_recent_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> List[StorageSession]:
        """Get the most recent sessions.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            limit: Maximum number of sessions to return.
            
        Returns:
            List of recent sessions, ordered by created_at descending.
        """
        raise NotImplementedError
    
    @abstractmethod
    def upsert(self, session: StorageSession) -> Optional[StorageSession]:
        """Insert or update a session.
        
        Args:
            session: The session to upsert.
            
        Returns:
            The upserted session, or None on failure.
        """
        raise NotImplementedError
    
    @abstractmethod
    def delete_session(self, session_id: str) -> None:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete.
        """
        raise NotImplementedError
    
    @abstractmethod
    def drop(self) -> None:
        """Drop all sessions from storage.
        
        Warning: This permanently deletes all data.
        """
        raise NotImplementedError
    
    def upgrade_schema(self) -> None:
        """Upgrade the storage schema.
        
        Override this method to handle schema migrations.
        """
        pass
    
    def close(self) -> None:
        """Close storage connections.
        
        Override this method to cleanup resources.
        """
        pass
