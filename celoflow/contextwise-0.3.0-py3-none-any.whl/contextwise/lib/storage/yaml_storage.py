"""YAML storage implementation for contextwise.

This module provides a file-based storage backend using YAML files
for session management.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Union

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False


class YamlStorage(Storage):
    """YAML file-based storage backend.
    
    This storage implementation persists sessions as individual YAML files
    in a directory, providing human-readable session data storage.
    
    Attributes:
        dir_path: Path to the directory storing YAML files.
    
    Example:
        >>> storage = YamlStorage(dir_path="data/sessions")
        >>> storage.create()
        >>> session = StorageSession(
        ...     session_id="sess1",
        ...     user_id="user1",
        ... )
        >>> storage.upsert(session)
    """
    
    def __init__(
        self,
        dir_path: Union[str, Path],
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
    ):
        """Initialize YAML storage.
        
        Args:
            dir_path: Path to the directory for storing YAML files.
            mode: Storage mode (agent, team, workflow).
        
        Raises:
            ImportError: If PyYAML is not installed.
        """
        if not YAML_AVAILABLE:
            raise ImportError(
                "PyYAML not installed. Install with: uv add pyyaml"
            )
        
        super().__init__(mode)
        self.dir_path = Path(dir_path)
        self.dir_path.mkdir(parents=True, exist_ok=True)
        
        logger.debug(f"YamlStorage initialized: {self.dir_path}")
    
    def _get_file_path(self, session_id: str) -> Path:
        """Get file path for a session.
        
        Args:
            session_id: Session identifier.
            
        Returns:
            Path to the YAML file.
        """
        return self.dir_path / f"{session_id}.yaml"
    
    def _serialize(self, data: Dict[str, Any]) -> str:
        """Serialize data to YAML string.
        
        Args:
            data: Dictionary to serialize.
            
        Returns:
            YAML string.
        """
        return yaml.dump(data, default_flow_style=False, allow_unicode=True)
    
    def _deserialize(self, data: str) -> Dict[str, Any]:
        """Deserialize YAML string to dictionary.
        
        Args:
            data: YAML string to deserialize.
            
        Returns:
            Dictionary.
        """
        return yaml.safe_load(data)
    
    def create(self) -> None:
        """Create the storage directory if it doesn't exist."""
        if not self.dir_path.exists():
            self.dir_path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created directory: {self.dir_path}")
    
    def read(
        self, 
        session_id: str, 
        user_id: Optional[str] = None,
    ) -> Optional[StorageSession]:
        """Read a session from YAML file.
        
        Args:
            session_id: The session ID to read.
            user_id: Optional user ID for filtering.
            
        Returns:
            StorageSession if found, None otherwise.
        """
        try:
            file_path = self._get_file_path(session_id)
            if not file_path.exists():
                return None
            
            with open(file_path, "r", encoding="utf-8") as f:
                data = self._deserialize(f.read())
            
            if user_id and data.get("user_id") != user_id:
                return None
            
            return StorageSession.from_dict(data)
        except FileNotFoundError:
            return None
        except Exception as e:
            logger.error(f"Error reading session: {e}")
            return None
    
    def get_all_session_ids(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[str]:
        """Get all session IDs, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of session IDs.
        """
        session_ids: List[str] = []
        
        for file in self.dir_path.glob("*.yaml"):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    data = self._deserialize(f.read())
                
                # Apply filters
                if user_id and data.get("user_id") != user_id:
                    continue
                if agent_id and data.get("agent_id") != agent_id:
                    continue
                
                session_ids.append(data.get("session_id", file.stem))
            except Exception as e:
                logger.warning(f"Error reading file {file}: {e}")
        
        return session_ids
    
    def get_all_sessions(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[StorageSession]:
        """Get all sessions, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of sessions.
        """
        sessions: List[StorageSession] = []
        
        for file in self.dir_path.glob("*.yaml"):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    data = self._deserialize(f.read())
                
                # Apply filters
                if user_id and data.get("user_id") != user_id:
                    continue
                if agent_id and data.get("agent_id") != agent_id:
                    continue
                
                sessions.append(StorageSession.from_dict(data))
            except Exception as e:
                logger.warning(f"Error reading file {file}: {e}")
        
        return sessions
    
    def get_recent_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> List[StorageSession]:
        """Get the most recent sessions.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            limit: Maximum number of sessions to return.
            
        Returns:
            List of recent sessions, ordered by created_at descending.
        """
        session_data: List[tuple[int, Dict[str, Any]]] = []
        
        for file in self.dir_path.glob("*.yaml"):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    data = self._deserialize(f.read())
                
                # Apply filters
                if user_id and data.get("user_id") != user_id:
                    continue
                if agent_id and data.get("agent_id") != agent_id:
                    continue
                
                created_at = data.get("created_at", 0)
                session_data.append((created_at, data))
            except Exception as e:
                logger.warning(f"Error reading file {file}: {e}")
        
        # Sort by created_at descending
        session_data.sort(key=lambda x: x[0], reverse=True)
        
        # Apply limit
        if limit is not None:
            session_data = session_data[:limit]
        
        # Convert to sessions
        sessions: List[StorageSession] = []
        for _, data in session_data:
            try:
                sessions.append(StorageSession.from_dict(data))
            except Exception as e:
                logger.warning(f"Error parsing session: {e}")
        
        return sessions
    
    def upsert(self, session: StorageSession) -> Optional[StorageSession]:
        """Insert or update a session.
        
        Args:
            session: The session to upsert.
            
        Returns:
            The upserted session, or None on failure.
        """
        try:
            data = session.to_dict()
            data["updated_at"] = int(time.time())
            if not data.get("created_at"):
                data["created_at"] = data["updated_at"]
            
            file_path = self._get_file_path(session.session_id)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(self._serialize(data))
            
            return session
        except Exception as e:
            logger.error(f"Error upserting session: {e}")
            return None
    
    def delete_session(self, session_id: str) -> None:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete.
        """
        if session_id is None:
            return
        
        try:
            file_path = self._get_file_path(session_id)
            file_path.unlink(missing_ok=True)
            logger.debug(f"Deleted session: {session_id}")
        except Exception as e:
            logger.error(f"Error deleting session: {e}")
    
    def drop(self) -> None:
        """Drop all sessions from storage."""
        for file in self.dir_path.glob("*.yaml"):
            try:
                file.unlink()
            except Exception as e:
                logger.warning(f"Error deleting file {file}: {e}")
        logger.debug(f"Dropped all sessions from: {self.dir_path}")
    
    def upgrade_schema(self) -> None:
        """No-op for YAML storage (schema-less)."""
        pass
    
    def close(self) -> None:
        """No-op for YAML storage (file-based)."""
        pass
