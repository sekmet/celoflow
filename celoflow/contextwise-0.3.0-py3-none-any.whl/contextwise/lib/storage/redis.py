"""Redis storage implementation for contextwise.

This module provides a persistent storage backend using Redis
for fast key-value session management.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List, Literal, Optional
from uuid import UUID

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)

try:
    from redis import ConnectionError, Redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False


class UUIDEncoder(json.JSONEncoder):
    """JSON encoder that handles UUID objects."""
    
    def default(self, obj: Any) -> Any:
        if isinstance(obj, UUID):
            return str(obj)
        return super().default(obj)


class RedisStorage(Storage):
    """Redis storage backend.
    
    This storage implementation persists sessions to Redis,
    providing fast access and optional TTL for session expiration.
    
    Attributes:
        prefix: Key prefix for namespacing sessions.
        redis_client: Redis client instance.
        expire: Optional TTL in seconds.
    
    Example:
        >>> storage = RedisStorage(
        ...     prefix="agent_sessions",
        ...     host="localhost",
        ...     port=6379,
        ...     expire=3600,  # 1 hour TTL
        ... )
        >>> storage.create()
        >>> session = StorageSession(
        ...     session_id="sess1",
        ...     user_id="user1",
        ... )
        >>> storage.upsert(session)
    """
    
    def __init__(
        self,
        prefix: str = "contextwise",
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        ssl: bool = False,
        expire: Optional[int] = None,
        redis_url: Optional[str] = None,
        redis_client: Optional["Redis"] = None,
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
    ):
        """Initialize Redis storage.
        
        Args:
            prefix: Key prefix for namespacing sessions.
            host: Redis host address.
            port: Redis port number.
            db: Redis database number.
            password: Redis password for authentication.
            ssl: Whether to use SSL connection.
            expire: TTL in seconds for keys (None = no expiration).
            redis_url: Redis connection URL (overrides host/port/db).
            redis_client: Existing Redis client instance.
            mode: Storage mode (agent, team, workflow).
        
        Raises:
            ImportError: If redis is not installed.
        """
        if not REDIS_AVAILABLE:
            raise ImportError(
                "redis not installed. Install with: uv add redis"
            )
        
        super().__init__(mode)
        
        self.prefix = prefix
        self.expire = expire
        
        if redis_client is not None:
            self.redis_client = redis_client
        elif redis_url is not None:
            self.redis_client = Redis.from_url(redis_url, decode_responses=True)
        else:
            self.redis_client = Redis(
                host=host,
                port=port,
                db=db,
                password=password,
                decode_responses=True,
                ssl=ssl,
            )
        
        logger.debug(f"RedisStorage initialized with prefix: {self.prefix}")
    
    def _get_key(self, session_id: str) -> str:
        """Generate Redis key for a session.
        
        Args:
            session_id: Session identifier.
            
        Returns:
            Redis key string.
        """
        return f"{self.prefix}:{session_id}"
    
    def _serialize(self, data: Dict[str, Any]) -> str:
        """Serialize data to JSON string.
        
        Args:
            data: Dictionary to serialize.
            
        Returns:
            JSON string.
        """
        return json.dumps(data, ensure_ascii=False, cls=UUIDEncoder)
    
    def _deserialize(self, data: str) -> Dict[str, Any]:
        """Deserialize JSON string to dictionary.
        
        Args:
            data: JSON string to deserialize.
            
        Returns:
            Dictionary.
        """
        return json.loads(data)
    
    def create(self) -> None:
        """Test Redis connection.
        
        Raises:
            ConnectionError: If cannot connect to Redis.
        """
        try:
            self.redis_client.ping()
            logger.debug("Redis connection successful")
        except ConnectionError as e:
            logger.error(f"Could not connect to Redis: {e}")
            raise
    
    def read(
        self, 
        session_id: str, 
        user_id: Optional[str] = None,
    ) -> Optional[StorageSession]:
        """Read a session from Redis.
        
        Args:
            session_id: The session ID to read.
            user_id: Optional user ID for filtering.
            
        Returns:
            StorageSession if found, None otherwise.
        """
        try:
            data = self.redis_client.get(self._get_key(session_id))
            if data is None:
                return None
            
            session_data = self._deserialize(data)
            
            if user_id and session_data.get("user_id") != user_id:
                return None
            
            return StorageSession.from_dict(session_data)
        except Exception as e:
            logger.error(f"Error reading session: {e}")
            return None
    
    def get_all_session_ids(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[str]:
        """Get all session IDs, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of session IDs.
        """
        session_ids: List[str] = []
        
        try:
            pattern = f"{self.prefix}:*"
            
            for key in self.redis_client.scan_iter(match=pattern):
                data_str = self.redis_client.get(key)
                if data_str is None:
                    continue
                    
                data = self._deserialize(data_str)
                
                # Apply filters
                if user_id and data.get("user_id") != user_id:
                    continue
                if agent_id and data.get("agent_id") != agent_id:
                    continue
                
                session_ids.append(data.get("session_id", key.split(":")[-1]))
        except Exception as e:
            logger.error(f"Error getting session IDs: {e}")
        
        return session_ids
    
    def get_all_sessions(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[StorageSession]:
        """Get all sessions, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of sessions.
        """
        sessions: List[StorageSession] = []
        
        try:
            pattern = f"{self.prefix}:*"
            
            for key in self.redis_client.scan_iter(match=pattern):
                data_str = self.redis_client.get(key)
                if data_str is None:
                    continue
                    
                data = self._deserialize(data_str)
                
                # Apply filters
                if user_id and data.get("user_id") != user_id:
                    continue
                if agent_id and data.get("agent_id") != agent_id:
                    continue
                
                try:
                    sessions.append(StorageSession.from_dict(data))
                except Exception as e:
                    logger.warning(f"Error parsing session: {e}")
        except Exception as e:
            logger.error(f"Error getting all sessions: {e}")
        
        return sessions
    
    def get_recent_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> List[StorageSession]:
        """Get the most recent sessions.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            limit: Maximum number of sessions to return.
            
        Returns:
            List of recent sessions, ordered by created_at descending.
        """
        session_data: List[tuple[int, Dict[str, Any]]] = []
        
        try:
            pattern = f"{self.prefix}:*"
            
            for key in self.redis_client.scan_iter(match=pattern):
                data_str = self.redis_client.get(key)
                if data_str is None:
                    continue
                    
                data = self._deserialize(data_str)
                
                # Apply filters
                if user_id and data.get("user_id") != user_id:
                    continue
                if agent_id and data.get("agent_id") != agent_id:
                    continue
                
                created_at = data.get("created_at", 0)
                session_data.append((created_at, data))
            
            # Sort by created_at descending
            session_data.sort(key=lambda x: x[0], reverse=True)
            
            # Apply limit
            if limit is not None:
                session_data = session_data[:limit]
            
            # Convert to sessions
            sessions: List[StorageSession] = []
            for _, data in session_data:
                try:
                    sessions.append(StorageSession.from_dict(data))
                except Exception as e:
                    logger.warning(f"Error parsing session: {e}")
            
            return sessions
        except Exception as e:
            logger.error(f"Error getting recent sessions: {e}")
            return []
    
    def upsert(self, session: StorageSession) -> Optional[StorageSession]:
        """Insert or update a session.
        
        Args:
            session: The session to upsert.
            
        Returns:
            The upserted session, or None on failure.
        """
        try:
            data = session.to_dict()
            data["updated_at"] = int(time.time())
            if not data.get("created_at"):
                data["created_at"] = data["updated_at"]
            
            key = self._get_key(session.session_id)
            
            if self.expire is not None:
                self.redis_client.set(key, self._serialize(data), ex=self.expire)
            else:
                self.redis_client.set(key, self._serialize(data))
            
            return session
        except Exception as e:
            logger.error(f"Error upserting session: {e}")
            return None
    
    def delete_session(self, session_id: str) -> None:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete.
        """
        try:
            key = self._get_key(session_id)
            self.redis_client.delete(key)
            logger.debug(f"Deleted session: {session_id}")
        except Exception as e:
            logger.error(f"Error deleting session: {e}")
    
    def drop(self) -> None:
        """Drop all sessions with the configured prefix."""
        try:
            pattern = f"{self.prefix}:*"
            for key in self.redis_client.scan_iter(match=pattern):
                self.redis_client.delete(key)
            logger.debug(f"Dropped all sessions with prefix: {self.prefix}")
        except Exception as e:
            logger.error(f"Error dropping sessions: {e}")
    
    def upgrade_schema(self) -> None:
        """No-op for Redis (schema-less)."""
        pass
    
    def close(self) -> None:
        """Close Redis connection."""
        try:
            self.redis_client.close()
            logger.debug("RedisStorage connection closed")
        except Exception as e:
            logger.warning(f"Error closing connection: {e}")
