"""Models for chat history storage.

This module provides dataclasses for chat messages and session summaries
used by the ChatHistoryStorage and ChatHistoryService.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ChatMessage:
    """Represents a single chat message.
    
    Attributes:
        id: Unique message identifier (UUID)
        role: Message role (user, assistant, system, tool)
        content: Message content text
        timestamp: Unix timestamp of message creation
        provider_message_id: Provider-specific message ID (e.g., OpenAI message ID)
        token_count: Number of tokens in the message
        latency_ms: Latency for generating this message (for assistant messages)
        tool_calls: Tool calls made by the assistant
        metadata: Additional message metadata
    """
    id: str
    role: str  # user | assistant | system | tool
    content: str
    timestamp: int
    provider_message_id: Optional[str] = None
    token_count: Optional[int] = None
    latency_ms: Optional[int] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary for storage."""
        return {
            "id": self.id,
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp,
            "provider_message_id": self.provider_message_id,
            "token_count": self.token_count,
            "latency_ms": self.latency_ms,
            "tool_calls": self.tool_calls,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChatMessage":
        """Create message from dictionary."""
        return cls(
            id=data.get("id", ""),
            role=data.get("role", ""),
            content=data.get("content", ""),
            timestamp=data.get("timestamp", 0),
            provider_message_id=data.get("provider_message_id"),
            token_count=data.get("token_count"),
            latency_ms=data.get("latency_ms"),
            tool_calls=data.get("tool_calls"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class ChatSessionSummary:
    """Summary of a chat session for listing.
    
    Attributes:
        session_id: Unique session identifier
        user_id: User who owns the session
        agent_id: Agent associated with the session
        status: Session status (active, archived, deleted)
        message_count: Total number of messages
        created_at: Unix timestamp of session creation
        last_message_at: Unix timestamp of last message
        preview: Preview text from the last message
        provider_type: LLM provider type (openai, anthropic, etc.)
        provider_thread_id: Provider-specific thread ID
        token_usage: Total token usage for the session
    """
    session_id: str
    user_id: str
    agent_id: Optional[str] = None
    status: str = "active"
    message_count: int = 0
    created_at: int = 0
    last_message_at: int = 0
    preview: str = ""
    provider_type: Optional[str] = None
    provider_thread_id: Optional[str] = None
    token_usage: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert summary to dictionary."""
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "agent_id": self.agent_id,
            "status": self.status,
            "message_count": self.message_count,
            "created_at": self.created_at,
            "last_message_at": self.last_message_at,
            "preview": self.preview,
            "provider_type": self.provider_type,
            "provider_thread_id": self.provider_thread_id,
            "token_usage": self.token_usage,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChatSessionSummary":
        """Create summary from dictionary."""
        return cls(
            session_id=data.get("session_id", ""),
            user_id=data.get("user_id", ""),
            agent_id=data.get("agent_id"),
            status=data.get("status", "active"),
            message_count=data.get("message_count", 0),
            created_at=data.get("created_at", 0),
            last_message_at=data.get("last_message_at", 0),
            preview=data.get("preview", ""),
            provider_type=data.get("provider_type"),
            provider_thread_id=data.get("provider_thread_id"),
            token_usage=data.get("token_usage", 0),
        )


@dataclass
class ChatSessionDetail(ChatSessionSummary):
    """Detailed chat session with full message list.
    
    Extends ChatSessionSummary with the complete message history.
    """
    messages: List[ChatMessage] = field(default_factory=list)
    session_data: Dict[str, Any] = field(default_factory=dict)
    extra_data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert detail to dictionary."""
        base = super().to_dict()
        base.update({
            "messages": [m.to_dict() for m in self.messages],
            "session_data": self.session_data,
            "extra_data": self.extra_data,
        })
        return base
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChatSessionDetail":
        """Create detail from dictionary."""
        base_data = {
            "session_id": data.get("session_id", ""),
            "user_id": data.get("user_id", ""),
            "agent_id": data.get("agent_id"),
            "status": data.get("status", "active"),
            "message_count": data.get("message_count", 0),
            "created_at": data.get("created_at", 0),
            "last_message_at": data.get("last_message_at", 0),
            "preview": data.get("preview", ""),
            "provider_type": data.get("provider_type"),
            "provider_thread_id": data.get("provider_thread_id"),
            "token_usage": data.get("token_usage", 0),
        }
        
        return cls(
            **base_data,
            messages=[ChatMessage.from_dict(m) for m in data.get("messages", [])],
            session_data=data.get("session_data", {}),
            extra_data=data.get("extra_data", {}),
        )
