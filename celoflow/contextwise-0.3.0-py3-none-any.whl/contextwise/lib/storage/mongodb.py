"""MongoDB storage implementation for contextwise.

This module provides a persistent storage backend using MongoDB
for document-based session management.
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional
from uuid import UUID

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)

try:
    from pymongo import MongoClient
    from pymongo.collection import Collection
    from pymongo.database import Database
    from pymongo.errors import PyMongoError
    MONGODB_AVAILABLE = True
except ImportError:
    MONGODB_AVAILABLE = False


class UUIDEncoder(json.JSONEncoder):
    """JSON encoder that handles UUID objects."""
    
    def default(self, obj: Any) -> Any:
        if isinstance(obj, UUID):
            return str(obj)
        return super().default(obj)


class MongoDbStorage(Storage):
    """MongoDB storage backend.
    
    This storage implementation persists sessions to MongoDB,
    providing flexible document-based storage with powerful querying.
    
    Attributes:
        collection_name: Name of the MongoDB collection.
        db_name: Name of the MongoDB database.
        db: MongoDB database instance.
        collection: MongoDB collection instance.
    
    Example:
        >>> storage = MongoDbStorage(
        ...     collection_name="agent_sessions",
        ...     db_url="mongodb://localhost:27017",
        ...     db_name="contextwise",
        ... )
        >>> storage.create()
        >>> session = StorageSession(
        ...     session_id="sess1",
        ...     user_id="user1",
        ... )
        >>> storage.upsert(session)
    """
    
    def __init__(
        self,
        collection_name: str,
        db_url: Optional[str] = None,
        db_name: str = "contextwise",
        client: Optional["MongoClient"] = None,
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
    ):
        """Initialize MongoDB storage.
        
        Args:
            collection_name: Name of the collection to store sessions.
            db_url: MongoDB connection URL.
            db_name: Name of the database.
            client: Optional existing MongoDB client.
            mode: Storage mode (agent, team, workflow).
        
        Raises:
            ImportError: If pymongo is not installed.
            ValueError: If neither db_url nor client is provided.
        """
        if not MONGODB_AVAILABLE:
            raise ImportError(
                "pymongo not installed. Install with: uv add pymongo"
            )
        
        super().__init__(mode)
        
        self._client: Optional[MongoClient] = client
        if self._client is None and db_url is not None:
            self._client = MongoClient(db_url)
        elif self._client is None:
            self._client = MongoClient()
        
        if self._client is None:
            raise ValueError("Must provide either db_url or client")
        
        self.collection_name: str = collection_name
        self.db_name: str = db_name
        self.db: Database = self._client[self.db_name]
        self.collection: Collection = self.db[self.collection_name]
        
        logger.debug(f"MongoDbStorage initialized: {self.db_name}.{self.collection_name}")
    
    def create(self) -> None:
        """Create necessary indexes for the collection."""
        try:
            self.collection.create_index("session_id", unique=True)
            self.collection.create_index("user_id")
            self.collection.create_index("created_at")
            if self.mode == "agent":
                self.collection.create_index("agent_id")
            logger.debug("MongoDB indexes created successfully")
        except PyMongoError as e:
            logger.error(f"Error creating indexes: {e}")
            raise
    
    def read(
        self, 
        session_id: str, 
        user_id: Optional[str] = None,
    ) -> Optional[StorageSession]:
        """Read a session from MongoDB.
        
        Args:
            session_id: The session ID to read.
            user_id: Optional user ID for filtering.
            
        Returns:
            StorageSession if found, None otherwise.
        """
        try:
            query = {"session_id": session_id}
            if user_id:
                query["user_id"] = user_id
            
            doc = self.collection.find_one(query)
            if doc:
                doc.pop("_id", None)
                return StorageSession.from_dict(doc)
            return None
        except PyMongoError as e:
            logger.error(f"Error reading session: {e}")
            return None
    
    def get_all_session_ids(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[str]:
        """Get all session IDs, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of session IDs.
        """
        try:
            query: Dict[str, Any] = {}
            if user_id is not None:
                query["user_id"] = user_id
            if agent_id is not None:
                query["agent_id"] = agent_id
            
            cursor = self.collection.find(query, {"session_id": 1}).sort("created_at", -1)
            return [str(doc["session_id"]) for doc in cursor]
        except PyMongoError as e:
            logger.error(f"Error getting session IDs: {e}")
            return []
    
    def get_all_sessions(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[StorageSession]:
        """Get all sessions, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of sessions.
        """
        sessions: List[StorageSession] = []
        try:
            query: Dict[str, Any] = {}
            if user_id is not None:
                query["user_id"] = user_id
            if agent_id is not None:
                query["agent_id"] = agent_id
            
            cursor = self.collection.find(query).sort("created_at", -1)
            for doc in cursor:
                doc.pop("_id", None)
                try:
                    sessions.append(StorageSession.from_dict(doc))
                except Exception as e:
                    logger.warning(f"Error parsing session: {e}")
        except PyMongoError as e:
            logger.error(f"Error getting sessions: {e}")
        
        return sessions
    
    def get_recent_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> List[StorageSession]:
        """Get the most recent sessions.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            limit: Maximum number of sessions to return.
            
        Returns:
            List of recent sessions, ordered by created_at descending.
        """
        sessions: List[StorageSession] = []
        try:
            query: Dict[str, Any] = {}
            if user_id is not None:
                query["user_id"] = user_id
            if agent_id is not None:
                query["agent_id"] = agent_id
            
            cursor = self.collection.find(query).sort("created_at", -1)
            if limit is not None:
                cursor = cursor.limit(limit)
            
            for doc in cursor:
                doc.pop("_id", None)
                try:
                    sessions.append(StorageSession.from_dict(doc))
                except Exception as e:
                    logger.warning(f"Error parsing session: {e}")
        except PyMongoError as e:
            logger.error(f"Error getting recent sessions: {e}")
        
        return sessions
    
    def upsert(self, session: StorageSession) -> Optional[StorageSession]:
        """Insert or update a session.
        
        Args:
            session: The session to upsert.
            
        Returns:
            The upserted session, or None on failure.
        """
        try:
            session_dict = session.to_dict()
            now = datetime.now(timezone.utc)
            timestamp = int(now.timestamp())
            
            # Handle UUID serialization
            if isinstance(session.session_id, UUID):
                session_dict["session_id"] = str(session.session_id)
            
            # Add version field for optimistic locking
            if "_version" not in session_dict:
                session_dict["_version"] = 1
            else:
                session_dict["_version"] += 1
            
            update_data = {**session_dict, "updated_at": timestamp}
            
            # Check if exists for created_at
            query = {"session_id": session_dict["session_id"]}
            doc = self.collection.find_one(query)
            if not doc:
                update_data["created_at"] = timestamp
            
            result = self.collection.update_one(query, {"$set": update_data}, upsert=True)
            
            if result.acknowledged:
                return self.read(session_id=session_dict["session_id"])
            return None
        except PyMongoError as e:
            logger.warning(f"Error upserting session: {e}")
            return None
    
    def delete_session(self, session_id: str) -> None:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete.
        """
        if session_id is None:
            logger.warning("No session_id provided for deletion")
            return
        
        try:
            result = self.collection.delete_one({"session_id": session_id})
            if result.deleted_count == 0:
                logger.debug(f"No session found with session_id: {session_id}")
            else:
                logger.debug(f"Successfully deleted session: {session_id}")
        except PyMongoError as e:
            logger.error(f"Error deleting session: {e}")
    
    def drop(self) -> None:
        """Drop the collection."""
        try:
            self.collection.drop()
            logger.debug(f"Dropped collection: {self.collection_name}")
        except PyMongoError as e:
            logger.error(f"Error dropping collection: {e}")
    
    def upgrade_schema(self) -> None:
        """No-op for MongoDB (schema-less)."""
        pass
    
    def close(self) -> None:
        """Close MongoDB connection."""
        try:
            if self._client:
                self._client.close()
            logger.debug("MongoDbStorage connection closed")
        except Exception as e:
            logger.warning(f"Error closing connection: {e}")
    
    def __deepcopy__(self, memo):
        """Create a deep copy of the MongoDbStorage instance."""
        from copy import deepcopy
        
        cls = self.__class__
        copied_obj = cls.__new__(cls)
        memo[id(self)] = copied_obj
        
        for k, v in self.__dict__.items():
            if k in {"_client", "db", "collection"}:
                setattr(copied_obj, k, v)
            else:
                setattr(copied_obj, k, deepcopy(v, memo))
        
        return copied_obj
