"""Storage module for contextwise.

This module provides persistent storage backends for agent sessions,
enabling conversation memory and state persistence across restarts.

Available storage backends:
    - InMemoryStorage: Fast, non-persistent storage (default)
    - SqliteStorage: File-based persistent storage
    - JsonStorage: File-based JSON storage
    - PostgresStorage: PostgreSQL database storage (requires sqlalchemy)
    - MySQLStorage: MySQL database storage (requires sqlalchemy)
    - MongoDbStorage: MongoDB storage (requires pymongo)
    - RedisStorage: Redis key-value storage (requires redis)
    - YamlStorage: File-based YAML storage (requires pyyaml)

Example:
    ```python
    from contextwise import AgentBuilder
    from contextwise.lib.storage import SqliteStorage
    
    builder = AgentBuilder(
        name="Personal Assistant",
        instructions="You are helpful",
        storage=SqliteStorage(
            table_name="agent_sessions",
            db_file="data/sessions.db",
        ),
    )
    ```
"""

from .base import Storage, StorageSession
from .in_memory import InMemoryStorage
from .sqlite import SqliteStorage
from .json_storage import JsonStorage
from .postgres import PostgresStorage
from .redis import RedisStorage
from .mongodb import MongoDbStorage
from .mysql import MySQLStorage
from .yaml_storage import YamlStorage
from .plugin import StoragePlugin, StorageBackendPlugin
from .session_adapter import StorageBackendAdapter, StorageSessionBackend
from .migration import (
    migrate_storage,
    export_sessions,
    import_sessions,
    backup_storage,
    restore_storage,
    validate_storage,
    MigrationResult,
    MigrationConfig,
)

# Chat history storage
from .chat_history import ChatHistoryStorage
from .chat_history_models import ChatMessage, ChatSessionDetail, ChatSessionSummary

__all__ = [
    # Base classes
    "Storage",
    "StorageSession",
    # Storage implementations
    "InMemoryStorage",
    "SqliteStorage",
    "JsonStorage",
    "PostgresStorage",
    "RedisStorage",
    "MongoDbStorage",
    "MySQLStorage",
    "YamlStorage",
    # Plugins
    "StoragePlugin",
    "StorageBackendPlugin",
    # Adapters
    "StorageBackendAdapter",
    "StorageSessionBackend",
    # Migration tools
    "migrate_storage",
    "export_sessions",
    "import_sessions",
    "backup_storage",
    "restore_storage",
    "validate_storage",
    "MigrationResult",
    "MigrationConfig",
    # Chat history
    "ChatHistoryStorage",
    "ChatMessage",
    "ChatSessionDetail",
    "ChatSessionSummary",
]
