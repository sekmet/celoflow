"""In-memory storage implementation for contextwise.

This module provides a fast, non-persistent storage backend
that stores sessions in memory (Python dictionary).
"""

from __future__ import annotations

import logging
import time
from typing import Dict, List, Literal, Optional

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)


class InMemoryStorage(Storage):
    """In-memory storage backend.
    
    This storage implementation keeps all sessions in a Python dictionary.
    Data is lost when the process ends. Useful for testing or short-lived
    sessions.
    
    Attributes:
        storage: Internal dictionary storing sessions.
    
    Example:
        >>> storage = InMemoryStorage()
        >>> session = StorageSession(
        ...     session_id="sess1",
        ...     user_id="user1",
        ...     messages=[{"role": "user", "content": "Hello"}],
        ... )
        >>> storage.upsert(session)
        >>> retrieved = storage.read("sess1")
        >>> print(retrieved.messages)
        [{'role': 'user', 'content': 'Hello'}]
    """
    
    def __init__(
        self,
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
        storage_dict: Optional[Dict[str, Dict]] = None,
    ):
        """Initialize in-memory storage.
        
        Args:
            mode: Storage mode (agent, team, workflow).
            storage_dict: Optional existing dictionary to use.
        """
        super().__init__(mode)
        self.storage: Dict[str, Dict] = storage_dict if storage_dict is not None else {}
        logger.debug("InMemoryStorage initialized")
    
    def create(self) -> None:
        """Create storage (no-op for in-memory)."""
        pass
    
    def read(
        self, 
        session_id: str, 
        user_id: Optional[str] = None,
    ) -> Optional[StorageSession]:
        """Read a session from storage.
        
        Args:
            session_id: The session ID to read.
            user_id: Optional user ID for filtering.
            
        Returns:
            StorageSession if found, None otherwise.
        """
        try:
            data = self.storage.get(session_id)
            if data is None:
                return None
            
            if user_id and data.get("user_id") != user_id:
                return None
            
            return StorageSession.from_dict(data)
        except Exception as e:
            logger.error(f"Error reading session {session_id}: {e}")
            return None
    
    def get_all_session_ids(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[str]:
        """Get all session IDs, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of session IDs.
        """
        session_ids = []
        
        for session_id, data in self.storage.items():
            if user_id and agent_id:
                if data.get("user_id") == user_id and data.get("agent_id") == agent_id:
                    session_ids.append(session_id)
            elif user_id and data.get("user_id") == user_id:
                session_ids.append(session_id)
            elif agent_id and data.get("agent_id") == agent_id:
                session_ids.append(session_id)
            elif not user_id and not agent_id:
                session_ids.append(session_id)
        
        return session_ids
    
    def get_all_sessions(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[StorageSession]:
        """Get all sessions, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of sessions.
        """
        sessions: List[StorageSession] = []
        
        for session_id, data in self.storage.items():
            include = False
            
            if user_id and agent_id:
                include = data.get("user_id") == user_id and data.get("agent_id") == agent_id
            elif user_id:
                include = data.get("user_id") == user_id
            elif agent_id:
                include = data.get("agent_id") == agent_id
            else:
                include = True
            
            if include:
                try:
                    sessions.append(StorageSession.from_dict(data))
                except Exception as e:
                    logger.warning(f"Error parsing session {session_id}: {e}")
        
        return sessions
    
    def get_recent_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> List[StorageSession]:
        """Get the most recent sessions.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            limit: Maximum number of sessions to return.
            
        Returns:
            List of recent sessions, ordered by created_at descending.
        """
        # Collect (created_at, data) tuples
        session_data: List[tuple[int, dict]] = []
        
        for session_id, data in self.storage.items():
            include = False
            
            if user_id and data.get("user_id") != user_id:
                continue
            if agent_id and data.get("agent_id") != agent_id:
                continue
            
            created_at = data.get("created_at", 0)
            session_data.append((created_at, data))
        
        # Sort by created_at descending
        session_data.sort(key=lambda x: x[0], reverse=True)
        
        # Apply limit
        if limit is not None:
            session_data = session_data[:limit]
        
        # Convert to sessions
        sessions: List[StorageSession] = []
        for _, data in session_data:
            try:
                sessions.append(StorageSession.from_dict(data))
            except Exception as e:
                logger.warning(f"Error parsing session: {e}")
        
        return sessions
    
    def upsert(self, session: StorageSession) -> Optional[StorageSession]:
        """Insert or update a session.
        
        Args:
            session: The session to upsert.
            
        Returns:
            The upserted session, or None on failure.
        """
        try:
            data = session.to_dict()
            data["updated_at"] = int(time.time())
            if not data.get("created_at"):
                data["created_at"] = data["updated_at"]
            
            self.storage[session.session_id] = data
            return session
        except Exception as e:
            logger.error(f"Error upserting session: {e}")
            return None
    
    def delete_session(self, session_id: str) -> None:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete.
        """
        try:
            self.storage.pop(session_id, None)
        except Exception as e:
            logger.error(f"Error deleting session: {e}")
    
    def drop(self) -> None:
        """Drop all sessions from storage."""
        self.storage.clear()
        logger.debug("InMemoryStorage cleared")
    
    def __len__(self) -> int:
        """Get number of sessions in storage."""
        return len(self.storage)
    
    def __contains__(self, session_id: str) -> bool:
        """Check if session exists."""
        return session_id in self.storage
