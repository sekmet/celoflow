"""MySQL storage implementation for contextwise.

This module provides a persistent storage backend using MySQL
for session management with SQLAlchemy ORM.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List, Literal, Optional
from uuid import UUID

from .base import Storage, StorageSession

logger = logging.getLogger(__name__)

try:
    from sqlalchemy import JSON, BigInteger, String, Text
    from sqlalchemy.dialects import mysql
    from sqlalchemy.engine import Engine, create_engine
    from sqlalchemy.inspection import inspect
    from sqlalchemy.orm import scoped_session, sessionmaker
    from sqlalchemy.schema import Column, MetaData, Table
    from sqlalchemy.sql.expression import select, text
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False


class UUIDEncoder(json.JSONEncoder):
    """JSON encoder that handles UUID objects."""
    
    def default(self, obj: Any) -> Any:
        if isinstance(obj, UUID):
            return str(obj)
        return super().default(obj)


class MySQLStorage(Storage):
    """MySQL storage backend.
    
    This storage implementation persists sessions to MySQL database
    using SQLAlchemy ORM with proper connection pooling and transactions.
    
    Attributes:
        table_name: Name of the MySQL table.
        schema: MySQL schema (database) name.
        db_engine: SQLAlchemy engine instance.
        table: SQLAlchemy Table object.
    
    Example:
        >>> storage = MySQLStorage(
        ...     table_name="agent_sessions",
        ...     schema="contextwise",
        ...     db_url="mysql+pymysql://user:pass@localhost/contextwise",
        ... )
        >>> storage.create()
        >>> session = StorageSession(
        ...     session_id="sess1",
        ...     user_id="user1",
        ... )
        >>> storage.upsert(session)
    """
    
    def __init__(
        self,
        table_name: str,
        schema: Optional[str] = "ai",
        db_url: Optional[str] = None,
        db_engine: Optional[Engine] = None,
        schema_version: int = 1,
        auto_upgrade_schema: bool = False,
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
    ):
        """Initialize MySQL storage.
        
        Args:
            table_name: Name of the table to store sessions.
            schema: MySQL schema (database) name.
            db_url: MySQL connection URL.
            db_engine: Optional existing SQLAlchemy engine.
            schema_version: Version of the table schema.
            auto_upgrade_schema: Whether to auto-upgrade schema.
            mode: Storage mode (agent, team, workflow).
        
        Raises:
            ImportError: If sqlalchemy is not installed.
            ValueError: If neither db_url nor db_engine is provided.
        """
        if not SQLALCHEMY_AVAILABLE:
            raise ImportError(
                "sqlalchemy not installed. Install with: uv add sqlalchemy pymysql"
            )
        
        super().__init__(mode)
        
        _engine: Optional[Engine] = db_engine
        if _engine is None and db_url is not None:
            _engine = create_engine(db_url)
        
        if _engine is None:
            raise ValueError("Must provide either db_url or db_engine")
        
        self.table_name: str = table_name
        self.schema: Optional[str] = schema
        self.db_url: Optional[str] = db_url
        self.db_engine: Engine = _engine
        self.metadata: MetaData = MetaData(schema=self.schema)
        self.inspector = inspect(self.db_engine)
        
        self.schema_version: int = schema_version
        self.auto_upgrade_schema: bool = auto_upgrade_schema
        self._schema_up_to_date: bool = False
        
        self.Session: scoped_session = scoped_session(sessionmaker(bind=self.db_engine))
        self.table: Table = self._get_table()
        
        logger.debug(f"MySQLStorage initialized: {self.schema}.{self.table_name}")
    
    def _get_table(self) -> Table:
        """Get the table schema.
        
        Returns:
            SQLAlchemy Table object.
        """
        columns = [
            Column("session_id", String(255), primary_key=True),
            Column("user_id", String(255), index=True),
            Column("agent_id", String(255), index=True, nullable=True),
            Column("messages", JSON),
            Column("memory", JSON),
            Column("metadata", JSON),
            Column("extra_data", JSON),
            Column("created_at", BigInteger, server_default=text("UNIX_TIMESTAMP()")),
            Column("updated_at", BigInteger, server_onupdate=text("UNIX_TIMESTAMP()")),
        ]
        
        table = Table(
            self.table_name,
            self.metadata,
            *columns,
            extend_existing=True,
            schema=self.schema,
        )
        
        return table
    
    def table_exists(self) -> bool:
        """Check if the table exists.
        
        Returns:
            True if table exists, False otherwise.
        """
        try:
            with self.Session() as sess:
                if self.schema is not None:
                    exists_query = text(
                        "SELECT 1 FROM information_schema.tables "
                        "WHERE table_schema = :schema AND table_name = :table"
                    )
                    exists = sess.execute(
                        exists_query, 
                        {"schema": self.schema, "table": self.table_name}
                    ).scalar() is not None
                else:
                    exists_query = text(
                        "SELECT 1 FROM information_schema.tables WHERE table_name = :table"
                    )
                    exists = sess.execute(
                        exists_query, 
                        {"table": self.table_name}
                    ).scalar() is not None
            
            logger.debug(f"Table '{self.table_name}' exists: {exists}")
            return exists
        except Exception as e:
            logger.error(f"Error checking if table exists: {e}")
            return False
    
    def create(self) -> None:
        """Create the table if it does not exist."""
        self.table = self._get_table()
        if not self.table_exists():
            try:
                with self.Session() as sess, sess.begin():
                    if self.schema is not None:
                        logger.debug(f"Creating schema: {self.schema}")
                        sess.execute(text(f"CREATE SCHEMA IF NOT EXISTS `{self.schema}`;"))
                
                logger.debug(f"Creating table: {self.table_name}")
                self.table.create(self.db_engine, checkfirst=True)
                
            except Exception as e:
                logger.error(f"Could not create table: {e}")
                raise
    
    def read(
        self, 
        session_id: str, 
        user_id: Optional[str] = None,
    ) -> Optional[StorageSession]:
        """Read a session from MySQL.
        
        Args:
            session_id: The session ID to read.
            user_id: Optional user ID for filtering.
            
        Returns:
            StorageSession if found, None otherwise.
        """
        try:
            with self.Session() as sess:
                stmt = select(self.table).where(self.table.c.session_id == session_id)
                if user_id:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                result = sess.execute(stmt).fetchone()
                if result is not None:
                    return self._row_to_session(result._mapping)
        except Exception as e:
            if "doesn't exist" in str(e):
                logger.debug(f"Table does not exist: {self.table_name}")
                self.create()
            else:
                logger.debug(f"Exception reading from table: {e}")
        return None
    
    def _row_to_session(self, row: Dict[str, Any]) -> StorageSession:
        """Convert a database row to StorageSession.
        
        Args:
            row: Database row as dictionary.
            
        Returns:
            StorageSession object.
        """
        return StorageSession(
            session_id=row.get("session_id", ""),
            user_id=row.get("user_id", ""),
            agent_id=row.get("agent_id"),
            messages=row.get("messages", []),
            memory=row.get("memory", {}),
            metadata=row.get("metadata", {}),
            created_at=row.get("created_at", 0),
            updated_at=row.get("updated_at", 0),
        )
    
    def get_all_session_ids(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[str]:
        """Get all session IDs, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of session IDs.
        """
        try:
            with self.Session() as sess, sess.begin():
                stmt = select(self.table.c.session_id)
                if user_id is not None:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                if agent_id is not None:
                    stmt = stmt.where(self.table.c.agent_id == agent_id)
                stmt = stmt.order_by(self.table.c.created_at.desc())
                rows = sess.execute(stmt).fetchall()
                return [row[0] for row in rows] if rows else []
        except Exception as e:
            logger.debug(f"Exception reading from table: {e}")
            self.create()
        return []
    
    def get_all_sessions(
        self, 
        user_id: Optional[str] = None, 
        agent_id: Optional[str] = None,
    ) -> List[StorageSession]:
        """Get all sessions, optionally filtered.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            
        Returns:
            List of sessions.
        """
        try:
            with self.Session() as sess, sess.begin():
                stmt = select(self.table)
                if user_id is not None:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                if agent_id is not None:
                    stmt = stmt.where(self.table.c.agent_id == agent_id)
                stmt = stmt.order_by(self.table.c.created_at.desc())
                rows = sess.execute(stmt).fetchall()
                if rows:
                    return [self._row_to_session(row._mapping) for row in rows]
        except Exception as e:
            logger.debug(f"Exception reading from table: {e}")
            self.create()
        return []
    
    def get_recent_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> List[StorageSession]:
        """Get the most recent sessions.
        
        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            limit: Maximum number of sessions to return.
            
        Returns:
            List of recent sessions, ordered by created_at descending.
        """
        try:
            with self.Session() as sess, sess.begin():
                stmt = select(self.table)
                if user_id is not None:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                if agent_id is not None:
                    stmt = stmt.where(self.table.c.agent_id == agent_id)
                stmt = stmt.order_by(self.table.c.created_at.desc())
                if limit is not None:
                    stmt = stmt.limit(limit)
                rows = sess.execute(stmt).fetchall()
                if rows:
                    return [self._row_to_session(row._mapping) for row in rows]
        except Exception as e:
            if "doesn't exist" in str(e):
                self.create()
            else:
                logger.debug(f"Exception reading from table: {e}")
        return []
    
    def upsert(self, session: StorageSession) -> Optional[StorageSession]:
        """Insert or update a session.
        
        Args:
            session: The session to upsert.
            
        Returns:
            The upserted session, or None on failure.
        """
        if self.auto_upgrade_schema and not self._schema_up_to_date:
            self.upgrade_schema()
        
        try:
            with self.Session() as sess, sess.begin():
                stmt = mysql.insert(self.table).values(
                    session_id=session.session_id,
                    user_id=session.user_id,
                    agent_id=session.agent_id,
                    messages=session.messages,
                    memory=session.memory,
                    metadata=session.metadata,
                    extra_data=getattr(session, "extra_data", {}),
                )
                
                stmt = stmt.on_duplicate_key_update(
                    user_id=session.user_id,
                    agent_id=session.agent_id,
                    messages=session.messages,
                    memory=session.memory,
                    metadata=session.metadata,
                    extra_data=getattr(session, "extra_data", {}),
                    updated_at=int(time.time()),
                )
                sess.execute(stmt)
        except Exception as e:
            if not self.table_exists():
                logger.debug(f"Table does not exist: {self.table_name}")
                self.create()
                return self.upsert(session)
            else:
                logger.warning(f"Exception upserting into table: {e}")
                return None
        return self.read(session_id=session.session_id)
    
    def delete_session(self, session_id: str) -> None:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete.
        """
        if session_id is None:
            logger.warning("No session_id provided for deletion.")
            return
        
        try:
            with self.Session() as sess, sess.begin():
                delete_stmt = self.table.delete().where(
                    self.table.c.session_id == session_id
                )
                result = sess.execute(delete_stmt)
                if result.rowcount == 0:
                    logger.debug(f"No session found with session_id: {session_id}")
                else:
                    logger.debug(f"Successfully deleted session: {session_id}")
        except Exception as e:
            logger.error(f"Error deleting session: {e}")
    
    def drop(self) -> None:
        """Drop the table from the database."""
        if self.table_exists():
            logger.debug(f"Dropping table: {self.table_name}")
            self.table.drop(self.db_engine, checkfirst=True)
            self.metadata = MetaData(schema=self.schema)
            self.table = self._get_table()
    
    def upgrade_schema(self) -> None:
        """Upgrade the schema to the latest version."""
        if not self.auto_upgrade_schema:
            logger.debug("Auto schema upgrade disabled. Skipping upgrade.")
            return
        
        self._schema_up_to_date = True
    
    def close(self) -> None:
        """Close database connections."""
        try:
            self.Session.remove()
            self.db_engine.dispose()
            logger.debug("MySQLStorage connections closed")
        except Exception as e:
            logger.warning(f"Error closing connections: {e}")
    
    def __deepcopy__(self, memo):
        """Create a deep copy of the MySQLStorage instance."""
        from copy import deepcopy
        
        cls = self.__class__
        copied_obj = cls.__new__(cls)
        memo[id(self)] = copied_obj
        
        for k, v in self.__dict__.items():
            if k in {"metadata", "table", "inspector"}:
                continue
            elif k in {"db_engine", "Session"}:
                setattr(copied_obj, k, v)
            else:
                setattr(copied_obj, k, deepcopy(v, memo))
        
        copied_obj.metadata = MetaData(schema=copied_obj.schema)
        copied_obj.inspector = inspect(copied_obj.db_engine)
        copied_obj.table = copied_obj._get_table()
        
        return copied_obj
