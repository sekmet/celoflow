"""PostgreSQL storage implementation for chat history.

This module extends the existing PostgresStorage to provide chat history
specific operations while maintaining compatibility with the base storage
architecture.
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Dict, List, Literal, Optional

from .postgres import PostgresStorage
from .chat_history_models import ChatMessage, ChatSessionDetail, ChatSessionSummary

logger = logging.getLogger(__name__)

try:
    from sqlalchemy import text
    from sqlalchemy.sql import select
    from sqlalchemy.schema import Column
    from sqlalchemy.types import BigInteger, String
    from sqlalchemy.dialects import postgresql

    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False


class ChatHistoryStorage(PostgresStorage):
    """Extended PostgreSQL storage for chat history with provider tracking.
    
    This class extends PostgresStorage to add chat history specific operations
    including message pagination, provider session tracking, and session metadata
    management.
    
    Attributes:
        table_name: Name of the database table (default: "agent_sessions")
        schema: PostgreSQL schema name (default: "public")
        db_engine: SQLAlchemy engine instance
    
    Example:
        >>> storage = ChatHistoryStorage(
        ...     db_url="postgresql://user:pass@localhost/db",
        ...     schema="public",
        ... )
        >>> storage.create()
        >>> storage.upgrade_schema()  # Add chat history columns
    """
    
    def __init__(
        self,
        table_name: str = "agent_sessions",
        schema: Optional[str] = "public",  # Changed from "ai" to "public"
        db_url: Optional[str] = None,
        db_engine: Optional[Any] = None,
        mode: Optional[Literal["agent", "team", "workflow"]] = "agent",
    ):
        """Initialize chat history storage.
        
        Args:
            table_name: Name of the table to store sessions
            schema: PostgreSQL schema name (default: "public")
            db_url: PostgreSQL connection URL
            db_engine: Existing SQLAlchemy engine
            mode: Storage mode (agent, team, workflow)
        """
        super().__init__(
            table_name=table_name,
            schema=schema,
            db_url=db_url,
            db_engine=db_engine,
            mode=mode,
        )
        self._schema_upgraded = False

    def _get_table(self) -> Any:
        """Get or create table definition with chat history columns.

        This overrides the base class method to include chat history specific columns.
        """
        from sqlalchemy.schema import Column, Table
        from sqlalchemy.types import BigInteger, Integer, String
        from sqlalchemy.dialects import postgresql

        columns = [
            Column("session_id", String, primary_key=True),
            Column("user_id", String, index=True),
            Column("agent_id", String, index=True),
            Column("channel", String),
            Column("locale", String),
            Column("messages", postgresql.JSONB),
            Column("memory", postgresql.JSONB),
            Column("session_data", postgresql.JSONB),
            Column("extra_data", postgresql.JSONB),
            Column("created_at", BigInteger),
            Column("updated_at", BigInteger),
            # Chat history specific columns
            Column("session_status", String),
            Column("provider_type", String),
            Column("provider_thread_id", String),
            Column("provider_metadata", postgresql.JSONB),
            Column("token_usage", Integer),
            Column("last_message_at", BigInteger),
        ]

        return Table(
            self.table_name,
            self.metadata,
            *columns,
            extend_existing=True,
            schema=self.schema,
        )

    def upgrade_schema(self) -> None:
        """Upgrade schema to add chat history specific columns.
        
        This method adds the necessary columns for chat history tracking:
        - session_status: Session state (active, archived, deleted)
        - provider_type: LLM provider (openai, anthropic, etc.)
        - provider_thread_id: Provider-specific thread ID
        - provider_metadata: JSONB for provider-specific data
        - token_usage: Total token count for the session
        - last_message_at: Timestamp of last message
        """
        if self._schema_upgraded:
            return
            
        if not SQLALCHEMY_AVAILABLE:
            raise ImportError("SQLAlchemy is required for schema upgrades")
        
        try:
            with self.Session() as sess, sess.begin():
                # Add columns if they don't exist
                columns_to_add = [
                    ("session_status", "TEXT DEFAULT 'active'"),
                    ("provider_type", "TEXT DEFAULT 'unknown'"),
                    ("provider_thread_id", "TEXT"),
                    ("provider_metadata", "JSONB DEFAULT '{}'"),
                    ("token_usage", "INTEGER DEFAULT 0"),
                    ("last_message_at", "BIGINT"),
                ]
                
                for col_name, col_type in columns_to_add:
                    try:
                        sess.execute(text(f"""
                            ALTER TABLE {self.schema}.{self.table_name} 
                            ADD COLUMN IF NOT EXISTS {col_name} {col_type}
                        """))
                        logger.debug(f"Added column {col_name}")
                    except Exception as e:
                        logger.warning(f"Column {col_name} may already exist: {e}")
                
                # Update existing records to fill NULL values with defaults
                updates = [
                    ("session_status", "'active'"),
                    ("provider_type", "'unknown'"),
                    ("provider_metadata", "'{}'::jsonb"),
                    ("token_usage", "0"),
                ]
                
                for col_name, default_val in updates:
                    try:
                        sess.execute(text(f"""
                            UPDATE {self.schema}.{self.table_name} 
                            SET {col_name} = {default_val} 
                            WHERE {col_name} IS NULL
                        """))
                        logger.debug(f"Updated NULL {col_name} values to default")
                    except Exception as e:
                        logger.warning(f"Failed to update {col_name} defaults: {e}")
                
                # Create indexes
                indexes = [
                    ("idx_agent_sessions_user_status", "user_id, session_status"),
                    ("idx_agent_sessions_last_message", "last_message_at DESC"),
                    ("idx_agent_sessions_provider", "provider_type, provider_thread_id"),
                ]
                
                for idx_name, idx_cols in indexes:
                    try:
                        sess.execute(text(f"""
                            CREATE INDEX IF NOT EXISTS {idx_name} 
                            ON {self.schema}.{self.table_name} ({idx_cols})
                        """))
                        logger.debug(f"Created index {idx_name}")
                    except Exception as e:
                        logger.warning(f"Index {idx_name} may already exist: {e}")
                
                self._schema_upgraded = True
                logger.info("Chat history schema upgraded successfully")
                
        except Exception as e:
            logger.error(f"Failed to upgrade schema: {e}")
            raise
    
    def get_chat_sessions(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[ChatSessionSummary]:
        """List chat sessions with filtering and pagination.
        
        Args:
            user_id: Filter by user ID
            agent_id: Filter by agent ID
            status: Filter by session status (active, archived, deleted)
            limit: Maximum number of sessions to return
            offset: Number of sessions to skip
            
        Returns:
            List of ChatSessionSummary objects
        """
        try:
            with self.Session() as sess:
                # Select specific columns for summary
                columns = [
                    self.table.c.session_id,
                    self.table.c.user_id,
                    self.table.c.agent_id,
                    self.table.c.session_status,
                    self.table.c.provider_type,
                    self.table.c.provider_thread_id,
                    self.table.c.token_usage,
                    self.table.c.created_at,
                    self.table.c.last_message_at,
                    self.table.c.messages,
                ]
                
                stmt = select(*columns)
                
                # Apply filters
                if user_id is not None:
                    stmt = stmt.where(self.table.c.user_id == user_id)
                if agent_id is not None:
                    stmt = stmt.where(self.table.c.agent_id == agent_id)
                if status is not None:
                    stmt = stmt.where(self.table.c.session_status == status)
                
                # Order by last message (most recent first)
                stmt = stmt.order_by(self.table.c.last_message_at.desc().nullslast())
                
                # Apply pagination
                stmt = stmt.limit(limit).offset(offset)
                
                rows = sess.execute(stmt).fetchall()
                
                sessions = []
                for row in rows:
                    # Calculate message count and preview from messages JSONB
                    messages = row.messages or []
                    message_count = len(messages)
                    preview = ""
                    if messages:
                        last_msg = messages[-1]
                        content = last_msg.get("content", "")
                        preview = content[:100] + "..." if len(content) > 100 else content
                    
                    sessions.append(ChatSessionSummary(
                        session_id=row.session_id,
                        user_id=row.user_id,
                        agent_id=row.agent_id,
                        status=row.session_status or "active",
                        message_count=message_count,
                        created_at=row.created_at or 0,
                        last_message_at=row.last_message_at or 0,
                        preview=preview,
                        provider_type=row.provider_type,
                        provider_thread_id=row.provider_thread_id,
                        token_usage=row.token_usage or 0,
                    ))
                
                return sessions
                
        except Exception as e:
            logger.error(f"Error getting chat sessions: {e}")
            return []
    
    def get_chat_session(self, session_id: str) -> Optional[ChatSessionDetail]:
        """Get detailed chat session with all messages.
        
        Args:
            session_id: The session ID to retrieve
            
        Returns:
            ChatSessionDetail if found, None otherwise
        """
        try:
            with self.Session() as sess:
                stmt = select(self.table).where(self.table.c.session_id == session_id)
                row = sess.execute(stmt).fetchone()
                
                if row is None:
                    return None
                
                # Convert messages from JSONB to ChatMessage objects
                messages_data = row.messages or []
                messages = [ChatMessage.from_dict(m) for m in messages_data]
                
                # Get preview from last message
                preview = ""
                if messages:
                    last_content = messages[-1].content
                    preview = last_content[:100] + "..." if len(last_content) > 100 else last_content
                
                return ChatSessionDetail(
                    session_id=row.session_id,
                    user_id=row.user_id,
                    agent_id=row.agent_id,
                    status=getattr(row, 'session_status', "active") or "active",
                    message_count=len(messages),
                    created_at=row.created_at or 0,
                    last_message_at=getattr(row, 'last_message_at', 0) or 0,
                    preview=preview,
                    provider_type=getattr(row, 'provider_type', None),
                    provider_thread_id=getattr(row, 'provider_thread_id', None),
                    token_usage=getattr(row, 'token_usage', 0) or 0,
                    messages=messages,
                    session_data=row.session_data or {},
                    extra_data=row.extra_data or {},
                )
                
        except Exception as e:
            logger.error(f"Error getting chat session: {e}")
            return None
    
    def append_chat_message(
        self,
        session_id: str,
        message: ChatMessage,
    ) -> bool:
        """Append a message to session history.
        
        Args:
            session_id: The session ID to update
            message: The ChatMessage to append
            
        Returns:
            True if successful, False otherwise
        """
        try:
            with self.Session() as sess, sess.begin():
                # Get current messages
                stmt = select(self.table.c.messages).where(
                    self.table.c.session_id == session_id
                )
                row = sess.execute(stmt).fetchone()
                
                if row is None:
                    logger.warning(f"Session not found: {session_id}")
                    return False
                
                messages = row.messages or []
                messages.append(message.to_dict())
                
                # Update session
                update_stmt = (
                    self.table.update()
                    .where(self.table.c.session_id == session_id)
                    .values(
                        messages=messages,
                        last_message_at=message.timestamp,
                        updated_at=int(time.time()),
                    )
                )
                sess.execute(update_stmt)
                
                logger.debug(f"Appended message to session {session_id}")
                return True
                
        except Exception as e:
            logger.error(f"Error appending chat message: {e}")
            return False
    
    def update_session_metadata(
        self,
        session_id: str,
        updates: Dict[str, Any],
    ) -> bool:
        """Update session metadata fields.
        
        Args:
            session_id: The session ID to update
            updates: Dictionary of fields to update
            
        Returns:
            True if successful, False otherwise
        """
        try:
            with self.Session() as sess, sess.begin():
                # Filter to only valid columns
                valid_columns = {
                    'session_status', 'provider_type', 'provider_thread_id',
                    'provider_metadata', 'token_usage', 'last_message_at',
                    'agent_id', 'session_data', 'extra_data'
                }
                filtered_updates = {
                    k: v for k, v in updates.items() 
                    if k in valid_columns
                }
                
                if not filtered_updates:
                    logger.warning("No valid fields to update")
                    return False
                
                filtered_updates['updated_at'] = int(time.time())
                
                update_stmt = (
                    self.table.update()
                    .where(self.table.c.session_id == session_id)
                    .values(**filtered_updates)
                )
                result = sess.execute(update_stmt)
                
                if result.rowcount == 0:
                    logger.warning(f"Session not found: {session_id}")
                    return False
                
                logger.debug(f"Updated session {session_id} metadata")
                return True
                
        except Exception as e:
            logger.error(f"Error updating session metadata: {e}")
            return False
    
    def update_provider_metadata(
        self,
        session_id: str,
        provider_type: str,
        thread_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Update LLM provider session tracking.
        
        Args:
            session_id: The session ID to update
            provider_type: LLM provider type (openai, anthropic, etc.)
            thread_id: Provider-specific thread ID
            metadata: Additional provider metadata
            
        Returns:
            True if successful, False otherwise
        """
        updates = {
            'provider_type': provider_type,
            'provider_thread_id': thread_id,
        }
        if metadata:
            updates['provider_metadata'] = metadata
        
        return self.update_session_metadata(session_id, updates)
    
    def get_conversation_history(
        self,
        session_id: str,
        limit: int = 50,
    ) -> List[Dict[str, str]]:
        """Get conversation history formatted for LLM context window.
        
        Args:
            session_id: The session ID
            limit: Maximum number of messages to return
            
        Returns:
            List of message dictionaries with role and content
        """
        session = self.get_chat_session(session_id)
        if not session:
            return []
        
        messages = session.messages[-limit:] if limit > 0 else session.messages
        
        return [
            {"role": m.role, "content": m.content}
            for m in messages
            if m.role in ("user", "assistant", "system")
        ]
