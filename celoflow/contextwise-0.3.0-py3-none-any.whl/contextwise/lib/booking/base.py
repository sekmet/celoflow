from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Optional

from agents import RunContextWrapper, Tool, ToolOutputText, function_tool, Agent

from ..context import AgentContext
from ..base import AgentPlugin


@dataclass
class Service:
    id: str
    name: str
    duration_minutes: int
    base_price: float


@dataclass
class Stylist:
    id: str
    name: str
    is_active: bool = True


@dataclass
class TimeSlot:
    start: datetime
    end: datetime
    stylist_id: Optional[str]


@dataclass
class Booking:
    id: str
    user_id: str
    service_id: str
    stylist_id: Optional[str]
    start: datetime
    end: datetime
    status: str


class BookingBackendPlugin(AgentPlugin, ABC):
    """Base plugin for appointment scheduling backends."""

    @abstractmethod
    def list_services(self) -> List[Service]:
        ...

    @abstractmethod
    def list_stylists(self) -> List[Stylist]:
        ...

    @abstractmethod
    def find_available_slots(
        self,
        user_id: str,
        service_id: Optional[str],
        preferred_start: Optional[datetime],
        preferred_end: Optional[datetime],
    ) -> List[TimeSlot]:
        ...

    @abstractmethod
    def create_booking(
        self,
        context: AgentContext,
        user_id: str,
        service_id: str,
        stylist_id: Optional[str],
        slot: TimeSlot,
        notes: Optional[str] = None,
    ) -> Booking:
        ...

    @abstractmethod
    def cancel_booking(self, booking_id: str, user_id: str) -> Booking:
        ...

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        tools: List[Tool] = [
            self._make_list_services_tool(),
            self._make_find_slots_tool(),
            self._make_create_booking_tool(),
            self._make_cancel_booking_tool(),
        ]
        return agent.clone(tools=[*agent.tools, *tools])

    def _make_list_services_tool(self) -> Tool:
        @function_tool
        def list_services_tool(
            ctx: RunContextWrapper[AgentContext],
        ) -> ToolOutputText:
            services = self.list_services()
            lines = [
                f"{svc.name} ({svc.duration_minutes} min) - ${svc.base_price:.2f}"
                for svc in services
            ]
            text = "\n".join(lines) if lines else "No services configured."
            return ToolOutputText(text=text)

        return list_services_tool

    def _make_find_slots_tool(self) -> Tool:
        @function_tool
        def find_time_slots_tool(
            ctx: RunContextWrapper[AgentContext],
            service_id: Optional[str] = None,
            preferred_start_iso: Optional[str] = None,
            preferred_end_iso: Optional[str] = None,
        ) -> ToolOutputText:
            preferred_start = (
                datetime.fromisoformat(preferred_start_iso)
                if preferred_start_iso
                else None
            )
            preferred_end = (
                datetime.fromisoformat(preferred_end_iso)
                if preferred_end_iso
                else None
            )
            slots = self.find_available_slots(
                user_id=ctx.context.user_id,
                service_id=service_id,
                preferred_start=preferred_start,
                preferred_end=preferred_end,
            )
            if not slots:
                return ToolOutputText(text="No available time slots found.")
            lines = []
            for slot in slots:
                lines.append(
                    f"{slot.start.isoformat()} - {slot.end.isoformat()}"
                    f" (stylist={slot.stylist_id or 'auto'})",
                )
            return ToolOutputText(text="\n".join(lines))

        return find_time_slots_tool

    def _make_create_booking_tool(self) -> Tool:
        @function_tool
        def create_booking_tool(
            ctx: RunContextWrapper[AgentContext],
            service_id: str,
            stylist_id: Optional[str] = None,
            start_iso: str = "",
            notes: Optional[str] = None,
        ) -> ToolOutputText:
            if not start_iso:
                raise ValueError("start_iso is required to create a booking")
            start = datetime.fromisoformat(start_iso)
            service = next(
                (s for s in self.list_services() if s.id == service_id),
                None,
            )
            if service is None:
                raise ValueError(f"Unknown service id '{service_id}'")
            end = start + timedelta(minutes=service.duration_minutes)
            slot = TimeSlot(start=start, end=end, stylist_id=stylist_id)
            booking = self.create_booking(
                context=ctx.context,
                user_id=ctx.context.user_id,
                service_id=service_id,
                stylist_id=stylist_id,
                slot=slot,
                notes=notes,
            )
            text = (
                f"Booking {booking.id} confirmed for {booking.start.isoformat()}"
                f" ({service.name})."
            )
            return ToolOutputText(text=text)

        return create_booking_tool

    def _make_cancel_booking_tool(self) -> Tool:
        @function_tool
        def cancel_booking_tool(
            ctx: RunContextWrapper[AgentContext],
            booking_id: str,
        ) -> ToolOutputText:
            booking = self.cancel_booking(booking_id=booking_id, user_id=ctx.context.user_id)
            text = f"Booking {booking.id} cancelled."
            return ToolOutputText(text=text)

        return cancel_booking_tool
