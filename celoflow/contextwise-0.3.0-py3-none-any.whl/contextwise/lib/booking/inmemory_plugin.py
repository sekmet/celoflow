from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Sequence, Any
from uuid import uuid4

from .base import Booking, BookingBackendPlugin, Service, Stylist, TimeSlot
from ..context import AgentContext


class InMemoryBookingBackendPlugin(BookingBackendPlugin):
    """Concrete in-memory implementation of the booking backend."""

    id = "inmemory-booking"
    name = "In-memory booking backend"

    def __init__(
        self,
        *,
        notification_plugins: Optional[Sequence[Any]] = None,
    ) -> None:
        self._services: List[Service] = [
            Service(id="cut", name="Corte de pelo", duration_minutes=45, base_price=30.0),
            Service(id="color", name="Color completo", duration_minutes=90, base_price=70.0),
            Service(id="treatment", name="Tratamiento capilar", duration_minutes=60, base_price=50.0),
        ]
        self._stylists: List[Stylist] = [
            Stylist(id="guille", name="Guillermo"),
            Stylist(id="ana", name="Ana"),
        ]
        self._bookings: Dict[str, Booking] = {}
        self._notification_plugins: List[Any] = list(notification_plugins or [])

    def list_services(self) -> List[Service]:
        return list(self._services)

    def list_stylists(self) -> List[Stylist]:
        return list(self._stylists)

    def find_available_slots(
        self,
        user_id: str,
        service_id: Optional[str],
        preferred_start: Optional[datetime],
        preferred_end: Optional[datetime],
    ) -> List[TimeSlot]:
        """Return naive time slots for the next day, ignoring conflicts for now."""

        base = preferred_start or datetime.now().replace(minute=0, second=0, microsecond=0)
        end_boundary = preferred_end or (base + timedelta(days=1))
        slots: List[TimeSlot] = []
        step = timedelta(hours=1)
        cursor = base
        while cursor + step <= end_boundary:
            slots.append(
                TimeSlot(start=cursor, end=cursor + step, stylist_id=None),
            )
            cursor += step
        return slots[:8]

    def create_booking(
        self,
        context: AgentContext,
        user_id: str,
        service_id: str,
        stylist_id: Optional[str],
        slot: TimeSlot,
        notes: Optional[str] = None,
    ) -> Booking:
        booking_id = uuid4().hex
        booking = Booking(
            id=booking_id,
            user_id=user_id,
            service_id=service_id,
            stylist_id=stylist_id,
            start=slot.start,
            end=slot.end,
            status="confirmed",
        )
        self._bookings[booking_id] = booking
        self._notify_booking_confirmed(context, booking)
        return booking

    def cancel_booking(self, booking_id: str, user_id: str) -> Booking:
        booking = self._bookings.get(booking_id)
        if booking is None:
            raise ValueError(f"Unknown booking id '{booking_id}'")
        if booking.user_id != user_id:
            raise ValueError("Booking does not belong to this user")
        booking.status = "cancelled"
        self._bookings[booking_id] = booking
        return booking

    def _notify_booking_confirmed(
        self,
        context: AgentContext,
        booking: Booking,
    ) -> None:
        for plugin in self._notification_plugins:
            handler = getattr(plugin, "on_booking_confirmed", None)
            if callable(handler):
                handler(context, booking)

