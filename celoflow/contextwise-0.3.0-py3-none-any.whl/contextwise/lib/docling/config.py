"""Configuration for Docling integration.

This module defines configuration classes for the Docling plugin,
controlling conversion, chunking, and indexing behavior.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import List, Optional

from ..vector.base import VectorDb
from ..vector.chunker import ChunkConfig, ChunkStrategy
from ..embedder.base import Embedder


class ExportFormat(str, Enum):
    """Export format for converted documents."""
    MARKDOWN = "markdown"
    TEXT = "text"
    HTML = "html"
    JSON = "json"


class ChunkingMode(str, Enum):
    """Chunking strategy mode."""
    DOCLING_NATIVE = "docling_native"
    CONTEXTWISE_MARKDOWN = "contextwise_markdown"


class DoclingChunker(str, Enum):
    """Docling native chunker types."""
    HIERARCHICAL = "hierarchical"
    HYBRID = "hybrid"


@dataclass
class DoclingConfig:
    """Configuration for Docling plugin.

    This configuration controls all aspects of document conversion,
    chunking, and indexing behavior for the Docling plugin.

    Attributes:
        # Conversion settings
        allowed_formats: Whitelist of allowed formats (None = allow all)
        pdf_do_ocr: Enable OCR for PDFs
        pdf_do_table_structure: Enable table structure extraction for PDFs
        artifacts_path: Path to offline model artifacts
        enable_remote_services: Allow remote service calls (default: False)
        allow_external_plugins: Allow external Docling plugins (default: False)

        # Output settings
        export_format: Default export format

        # Chunking settings
        chunking_mode: Chunking strategy to use
        docling_chunker: Docling native chunker type (if using docling_native mode)
        contextwise_chunker_config: Contextwise chunker config (if using contextwise_markdown mode)

        # Indexing settings (optional)
        vector_db: Vector database for indexing chunks
        embedder: Embedder for generating embeddings
        collection_name: Collection/table name in vector DB
        namespace: Namespace for organizing documents

        # Storage settings
        artifacts_dir: Directory for storing document artifacts

    Example:
        >>> from contextwise.lib.docling import DoclingConfig
        >>> from contextwise.lib.vector import ChunkConfig, ChunkStrategy
        >>>
        >>> config = DoclingConfig(
        ...     pdf_do_ocr=True,
        ...     chunking_mode=ChunkingMode.CONTEXTWISE_MARKDOWN,
        ...     contextwise_chunker_config=ChunkConfig(
        ...         strategy=ChunkStrategy.PARAGRAPH,
        ...         chunk_size=1000,
        ...     ),
        ... )
    """

    # Conversion settings
    allowed_formats: Optional[List[str]] = None
    pdf_do_ocr: bool = False
    pdf_do_table_structure: bool = True
    artifacts_path: Optional[Path] = None
    enable_remote_services: bool = False
    allow_external_plugins: bool = False

    # Output settings
    export_format: ExportFormat = ExportFormat.MARKDOWN

    # Chunking settings
    chunking_mode: ChunkingMode = ChunkingMode.CONTEXTWISE_MARKDOWN
    docling_chunker: DoclingChunker = DoclingChunker.HIERARCHICAL
    contextwise_chunker_config: ChunkConfig = field(
        default_factory=lambda: ChunkConfig(
            strategy=ChunkStrategy.PARAGRAPH,
            chunk_size=1000,
            chunk_overlap=200,
        )
    )

    # Indexing settings (optional)
    vector_db: Optional[VectorDb] = None
    embedder: Optional[Embedder] = None
    collection_name: str = "docling_documents"
    namespace: str = "default"

    # Storage settings
    artifacts_dir: Path = field(
        default_factory=lambda: Path(".contextwise/documents")
    )

    def __post_init__(self):
        """Validate configuration after initialization."""
        # Convert string paths to Path objects
        if isinstance(self.artifacts_path, str):
            self.artifacts_path = Path(self.artifacts_path)

        if isinstance(self.artifacts_dir, str):
            self.artifacts_dir = Path(self.artifacts_dir)

        # Validate vector DB configuration
        if self.vector_db is not None and self.embedder is None:
            raise ValueError("embedder is required when vector_db is configured")

        # Create artifacts directory if it doesn't exist
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)

    def is_format_allowed(self, format: str) -> bool:
        """Check if a file format is allowed.

        Args:
            format: File format to check (e.g., 'pdf', 'docx')

        Returns:
            True if format is allowed
        """
        if self.allowed_formats is None:
            return True
        return format.lower() in [f.lower() for f in self.allowed_formats]

    def get_document_dir(self, document_id: str) -> Path:
        """Get the directory for a specific document's artifacts.

        Args:
            document_id: Document identifier

        Returns:
            Path to document directory
        """
        doc_dir = self.artifacts_dir / document_id
        doc_dir.mkdir(parents=True, exist_ok=True)
        return doc_dir
