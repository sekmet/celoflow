"""Docling service for document conversion and processing.

This module provides the core service for converting documents,
exporting to various formats, chunking, and indexing.
"""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import List, Optional, Union

from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions

from .config import ChunkingMode, DoclingConfig, ExportFormat
from .models import ChunkArtifact, ConversionArtifact
from ..vector.base import Document
from ..vector.chunker import DocumentChunker

logger = logging.getLogger(__name__)


class DoclingService:
    """Service for document conversion, chunking, and indexing.

    This service encapsulates all Docling operations and integrates
    with Contextwise vector databases and embedders.

    Attributes:
        config: Docling configuration
        converter: Cached DocumentConverter instance

    Example:
        >>> from contextwise.lib.docling import DoclingService, DoclingConfig
        >>>
        >>> config = DoclingConfig(pdf_do_ocr=True)
        >>> service = DoclingService(config)
        >>>
        >>> artifact = service.convert("document.pdf")
        >>> print(f"Converted {artifact.num_chunks} chunks")
    """

    def __init__(self, config: Optional[DoclingConfig] = None):
        """Initialize the service.

        Args:
            config: Docling configuration (uses defaults if None)
        """
        self.config = config or DoclingConfig()
        self._converter: Optional[DocumentConverter] = None

    @property
    def converter(self) -> DocumentConverter:
        """Get or create the DocumentConverter instance.

        The converter is cached to avoid repeated initialization.

        Returns:
            DocumentConverter instance
        """
        if self._converter is None:
            self._converter = self._create_converter()
        return self._converter

    def _create_converter(self) -> DocumentConverter:
        """Create a new DocumentConverter with configured options.

        Returns:
            Configured DocumentConverter
        """
        # Configure PDF options
        pdf_options = PdfFormatOption(
            pipeline_options=PdfPipelineOptions(
                do_ocr=self.config.pdf_do_ocr,
                do_table_structure=self.config.pdf_do_table_structure,
                artifacts_path=self.config.artifacts_path,
                generate_picture_images=False,
            )
        )

        # Set remote services policy
        if hasattr(pdf_options.pipeline_options, 'enable_remote_services'):
            pdf_options.pipeline_options.enable_remote_services = (
                self.config.enable_remote_services
            )

        # Set external plugins policy
        if hasattr(pdf_options.pipeline_options, 'allow_external_plugins'):
            pdf_options.pipeline_options.allow_external_plugins = (
                self.config.allow_external_plugins
            )

        # Create converter with format options
        converter = DocumentConverter(
            format_options={
                InputFormat.PDF: pdf_options,
            }
        )

        logger.info("Created DocumentConverter with PDF OCR=%s", self.config.pdf_do_ocr)
        return converter

    def convert(
        self,
        source: Union[str, Path],
        user_id: Optional[str] = None,
    ) -> ConversionArtifact:
        """Convert a document to normalized representation.

        This performs the complete conversion pipeline:
        1. Convert to DoclingDocument
        2. Export to configured format (default: markdown)
        3. Chunk the exported text
        4. Optionally index into vector DB
        5. Persist artifacts

        Args:
            source: Path to source document
            user_id: Optional user ID for namespacing

        Returns:
            ConversionArtifact with all conversion outputs

        Raises:
            ValueError: If format is not allowed
            RuntimeError: If conversion fails
        """
        source_path = Path(source)
        if not source_path.exists():
            raise FileNotFoundError(f"Source file not found: {source}")

        # Check if format is allowed
        source_format = source_path.suffix.lstrip('.').lower()
        if not self.config.is_format_allowed(source_format):
            raise ValueError(
                f"Format '{source_format}' is not allowed. "
                f"Allowed formats: {self.config.allowed_formats}"
            )

        # Generate stable document ID
        document_id = self._generate_document_id(source_path, user_id)

        # Check if already converted
        existing = self.load_artifact(document_id)
        if existing is not None:
            logger.info("Using cached conversion for document %s", document_id)
            return existing

        logger.info("Converting document: %s (format: %s)", source, source_format)

        # Convert document
        try:
            result = self.converter.convert(str(source_path))
            dl_doc = result.document
        except Exception as e:
            logger.error("Conversion failed for %s: %s", source, e)
            raise RuntimeError(f"Docling conversion failed: {e}") from e

        # Export to configured format
        exported_text = self.export(dl_doc)

        # Extract metadata
        num_pages = None
        if hasattr(dl_doc, 'pages') and dl_doc.pages:
            num_pages = len(dl_doc.pages)

        # Create base artifact
        artifact = ConversionArtifact(
            document_id=document_id,
            source_uri=str(source_path),
            source_format=source_format,
            export_format=self.config.export_format.value,
            exported_text=exported_text,
            num_pages=num_pages,
            metadata={
                "user_id": user_id,
                "source_name": source_path.name,
            },
        )

        # Chunk the document
        chunks = self.chunk(artifact, dl_doc)
        artifact.chunks = chunks
        artifact.num_chunks = len(chunks)

        # Index into vector DB if configured
        if self.config.vector_db is not None:
            chunk_ids = self.index(chunks)
            logger.info("Indexed %d chunks into vector DB", len(chunk_ids))

        # Persist artifact
        self.save_artifact(artifact)

        logger.info(
            "Conversion complete: %s (%d chunks)",
            document_id,
            artifact.num_chunks
        )

        return artifact

    def export(self, dl_doc) -> str:
        """Export DoclingDocument to configured format.

        Args:
            dl_doc: DoclingDocument to export

        Returns:
            Exported text string
        """
        export_format = self.config.export_format

        if export_format == ExportFormat.MARKDOWN:
            return dl_doc.export_to_markdown()
        elif export_format == ExportFormat.TEXT:
            # Use markdown export and strip formatting as fallback
            # Docling doesn't have a dedicated text export
            markdown = dl_doc.export_to_markdown()
            # Simple markdown stripping (basic implementation)
            import re
            text = re.sub(r'[#*_`\[\]()]', '', markdown)
            return text
        elif export_format == ExportFormat.HTML:
            # Docling doesn't have HTML export, use markdown
            logger.warning("HTML export not available, using markdown")
            return dl_doc.export_to_markdown()
        elif export_format == ExportFormat.JSON:
            # Export as JSON
            return dl_doc.export_to_json()
        else:
            # Default to markdown
            return dl_doc.export_to_markdown()

    def chunk(
        self,
        artifact: ConversionArtifact,
        dl_doc=None,
    ) -> List[ChunkArtifact]:
        """Chunk a document using configured strategy.

        Args:
            artifact: Conversion artifact with exported text
            dl_doc: Optional DoclingDocument (required for docling_native mode)

        Returns:
            List of chunk artifacts
        """
        if self.config.chunking_mode == ChunkingMode.CONTEXTWISE_MARKDOWN:
            return self._chunk_contextwise(artifact)
        elif self.config.chunking_mode == ChunkingMode.DOCLING_NATIVE:
            if dl_doc is None:
                logger.warning(
                    "Docling native chunking requires DoclingDocument, "
                    "falling back to contextwise chunking"
                )
                return self._chunk_contextwise(artifact)
            return self._chunk_docling_native(artifact, dl_doc)
        else:
            logger.warning("Unknown chunking mode, using contextwise")
            return self._chunk_contextwise(artifact)

    def _chunk_contextwise(
        self,
        artifact: ConversionArtifact,
    ) -> List[ChunkArtifact]:
        """Chunk using Contextwise DocumentChunker.

        Args:
            artifact: Conversion artifact

        Returns:
            List of chunk artifacts
        """
        # Create a temporary Document for chunking
        temp_doc = Document(
            id=artifact.document_id,
            name=artifact.source_uri,
            content=artifact.exported_text,
            metadata=artifact.metadata,
        )

        # Chunk using contextwise chunker
        chunker = DocumentChunker(self.config.contextwise_chunker_config)
        doc_chunks = chunker.chunk_document(temp_doc)

        # Convert to ChunkArtifact
        chunk_artifacts = []
        for i, doc_chunk in enumerate(doc_chunks):
            chunk_artifact = ChunkArtifact(
                chunk_id=doc_chunk.id,
                document_id=artifact.document_id,
                content=doc_chunk.content,
                chunk_index=i,
                total_chunks=len(doc_chunks),
                metadata=doc_chunk.metadata,
            )
            chunk_artifacts.append(chunk_artifact)

        return chunk_artifacts

    def _chunk_docling_native(
        self,
        artifact: ConversionArtifact,
        dl_doc,
    ) -> List[ChunkArtifact]:
        """Chunk using Docling native chunkers.

        Args:
            artifact: Conversion artifact
            dl_doc: DoclingDocument

        Returns:
            List of chunk artifacts
        """
        try:
            from docling_core.transforms.chunker import HierarchicalChunker

            # Create chunker
            chunker = HierarchicalChunker()

            # Chunk document
            chunks = list(chunker.chunk(dl_doc))

            # Convert to ChunkArtifact
            chunk_artifacts = []
            for i, chunk in enumerate(chunks):
                # Get text from chunk
                chunk_text = chunker.serialize(chunk)

                chunk_artifact = ChunkArtifact(
                    chunk_id=f"{artifact.document_id}_chunk_{i}",
                    document_id=artifact.document_id,
                    content=chunk_text,
                    chunk_index=i,
                    total_chunks=len(chunks),
                    metadata={
                        "chunker": "docling_hierarchical",
                        **artifact.metadata,
                    },
                )
                chunk_artifacts.append(chunk_artifact)

            return chunk_artifacts

        except ImportError:
            logger.warning(
                "docling-core[chunking] not installed, "
                "falling back to contextwise chunking"
            )
            return self._chunk_contextwise(artifact)

    def index(self, chunks: List[ChunkArtifact]) -> List[str]:
        """Index chunks into vector database.

        Args:
            chunks: Chunks to index

        Returns:
            List of chunk IDs that were indexed

        Raises:
            RuntimeError: If vector DB or embedder not configured
        """
        if self.config.vector_db is None or self.config.embedder is None:
            raise RuntimeError("Vector DB and embedder must be configured for indexing")

        # Convert chunks to Documents
        documents = []
        for chunk in chunks:
            # Generate embedding
            embedding = self.config.embedder.embed(chunk.content)

            doc = Document(
                id=chunk.chunk_id,
                name=chunk.document_id,
                content=chunk.content,
                embedding=embedding,
                metadata=chunk.metadata,
                filters={
                    "document_id": chunk.document_id,
                    "chunk_index": chunk.chunk_index,
                    "namespace": self.config.namespace,
                },
            )
            documents.append(doc)

        # Insert into vector DB
        self.config.vector_db.insert(documents)

        return [chunk.chunk_id for chunk in chunks]

    def query(
        self,
        query: str,
        document_id: Optional[str] = None,
        limit: int = 5,
    ) -> List[ChunkArtifact]:
        """Query documents using semantic search.

        Args:
            query: Search query
            document_id: Optional document ID to filter by
            limit: Maximum results to return

        Returns:
            List of matching chunk artifacts with scores
        """
        if self.config.vector_db is None:
            # Fallback to keyword search in stored artifacts
            return self._keyword_search(query, document_id, limit)

        # Build filters
        filters = {"namespace": self.config.namespace}
        if document_id:
            filters["document_id"] = document_id

        # Semantic search
        results = self.config.vector_db.search(query, limit=limit, filters=filters)

        # Convert to ChunkArtifact
        chunk_artifacts = []
        for doc in results:
            chunk = ChunkArtifact(
                chunk_id=doc.id,
                document_id=doc.metadata.get("parent_doc_id", doc.name or ""),
                content=doc.content,
                chunk_index=doc.metadata.get("chunk_index", 0),
                total_chunks=doc.metadata.get("total_chunks", 1),
                metadata=doc.metadata,
                score=doc.score,
            )
            chunk_artifacts.append(chunk)

        return chunk_artifacts

    def _keyword_search(
        self,
        query: str,
        document_id: Optional[str],
        limit: int,
    ) -> List[ChunkArtifact]:
        """Fallback keyword search in stored artifacts.

        Args:
            query: Search query
            document_id: Optional document ID filter
            limit: Maximum results

        Returns:
            List of matching chunks
        """
        results = []
        query_lower = query.lower()

        # Get all document IDs to search
        if document_id:
            doc_ids = [document_id]
        else:
            doc_ids = self.list_documents()

        # Search through chunks
        for doc_id in doc_ids:
            artifact = self.load_artifact(doc_id)
            if artifact is None:
                continue

            for chunk in artifact.chunks:
                if query_lower in chunk.content.lower():
                    # Simple relevance score based on occurrence count
                    score = chunk.content.lower().count(query_lower) / len(chunk.content)
                    chunk.score = score
                    results.append(chunk)

        # Sort by score and limit
        results.sort(key=lambda c: c.score or 0, reverse=True)
        return results[:limit]

    def save_artifact(self, artifact: ConversionArtifact) -> None:
        """Save conversion artifact to disk.

        Args:
            artifact: Artifact to save
        """
        doc_dir = self.config.get_document_dir(artifact.document_id)

        # Save metadata and chunks as JSON
        metadata_file = doc_dir / "artifact.json"
        with open(metadata_file, 'w') as f:
            json.dump(artifact.to_dict(), f, indent=2)

        # Save exported text separately
        if artifact.export_format == "markdown":
            text_file = doc_dir / "document.md"
        elif artifact.export_format == "json":
            text_file = doc_dir / "document.json"
        elif artifact.export_format == "html":
            text_file = doc_dir / "document.html"
        else:
            text_file = doc_dir / "document.txt"

        with open(text_file, 'w') as f:
            f.write(artifact.exported_text)

        logger.debug("Saved artifact to %s", doc_dir)

    def load_artifact(self, document_id: str) -> Optional[ConversionArtifact]:
        """Load conversion artifact from disk.

        Args:
            document_id: Document identifier

        Returns:
            ConversionArtifact if found, None otherwise
        """
        doc_dir = self.config.get_document_dir(document_id)
        metadata_file = doc_dir / "artifact.json"

        if not metadata_file.exists():
            return None

        try:
            with open(metadata_file, 'r') as f:
                data = json.load(f)
            return ConversionArtifact.from_dict(data)
        except Exception as e:
            logger.error("Failed to load artifact %s: %s", document_id, e)
            return None

    def list_documents(self, user_id: Optional[str] = None) -> List[str]:
        """List all document IDs.

        Args:
            user_id: Optional user ID filter

        Returns:
            List of document IDs
        """
        doc_ids = []

        if not self.config.artifacts_dir.exists():
            return doc_ids

        for doc_dir in self.config.artifacts_dir.iterdir():
            if not doc_dir.is_dir():
                continue

            # Load artifact to check user_id filter
            if user_id:
                artifact = self.load_artifact(doc_dir.name)
                if artifact and artifact.metadata.get("user_id") == user_id:
                    doc_ids.append(doc_dir.name)
            else:
                doc_ids.append(doc_dir.name)

        return doc_ids

    def get_document_markdown(self, document_id: str) -> Optional[str]:
        """Get the markdown export of a document.

        Args:
            document_id: Document identifier

        Returns:
            Markdown text if available, None otherwise
        """
        artifact = self.load_artifact(document_id)
        if artifact is None:
            return None

        if artifact.export_format == "markdown":
            return artifact.exported_text

        # Try to read from markdown file
        doc_dir = self.config.get_document_dir(document_id)
        md_file = doc_dir / "document.md"
        if md_file.exists():
            return md_file.read_text()

        return None

    def _generate_document_id(
        self,
        source_path: Path,
        user_id: Optional[str],
    ) -> str:
        """Generate a stable document ID.

        Args:
            source_path: Source file path
            user_id: Optional user ID

        Returns:
            Document ID (hash-based)
        """
        # Use file path and user_id to generate stable ID
        id_parts = [str(source_path.absolute())]
        if user_id:
            id_parts.append(user_id)

        id_string = "|".join(id_parts)
        doc_hash = hashlib.sha256(id_string.encode()).hexdigest()[:16]

        # Include filename for readability
        filename = source_path.stem
        return f"{filename}_{doc_hash}"
