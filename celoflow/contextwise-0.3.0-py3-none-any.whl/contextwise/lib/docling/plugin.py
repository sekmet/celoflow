"""Docling plugin for Contextwise agents.

This module provides the plugin implementation that integrates
Docling document processing into Contextwise agents.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List, Optional

from agents import Agent

from ..base import AgentPlugin
from ..context import AgentContext
from .config import DoclingConfig
from .service import DoclingService
from .tools import create_docling_tools

logger = logging.getLogger(__name__)


@dataclass
class DoclingPlugin(AgentPlugin[AgentContext]):
    """Plugin for integrating Docling document processing with agents.

    This plugin adds document conversion, chunking, and search capabilities
    to Contextwise agents using Docling.

    Attributes:
        id: Plugin identifier
        name: Human-readable plugin name
        version: Plugin version
        config: Docling configuration
        service: Docling service instance (created automatically)

    Example:
        Basic usage without vector DB:
        >>> from contextwise.lib.docling import DoclingPlugin, DoclingConfig
        >>>
        >>> config = DoclingConfig(pdf_do_ocr=True)
        >>> plugin = DoclingPlugin(config=config)
        >>>
        >>> # Use with PluginManager
        >>> from contextwise.lib.base import PluginManager
        >>> manager = PluginManager(
        ...     base_agent=agent,
        ...     plugins=[plugin],
        ... )

        With vector database for semantic search:
        >>> from contextwise.lib.docling import DoclingPlugin, DoclingConfig
        >>> from contextwise.lib.vector import PgVectorDb
        >>> from contextwise.lib.embedder import FastEmbedEmbedder
        >>>
        >>> # Configure vector DB and embedder
        >>> vector_db = PgVectorDb(
        ...     collection_name="documents",
        ...     connection_string="postgresql://...",
        ... )
        >>> embedder = FastEmbedEmbedder()
        >>>
        >>> # Configure plugin with indexing
        >>> config = DoclingConfig(
        ...     pdf_do_ocr=True,
        ...     vector_db=vector_db,
        ...     embedder=embedder,
        ... )
        >>> plugin = DoclingPlugin(config=config)
    """

    # Plugin metadata
    id: str = "docling"
    name: str = "Docling Document Processing"
    version: str = "1.0.0"

    # Configuration
    config: Optional[DoclingConfig] = None

    # Service (created automatically)
    service: Optional[DoclingService] = None

    def __post_init__(self):
        """Initialize the plugin."""
        # Create config if not provided
        if self.config is None:
            self.config = DoclingConfig()

        # Create service
        self.service = DoclingService(self.config)

        # Initialize vector DB if configured
        if self.config.vector_db is not None:
            if not self.config.vector_db.exists():
                logger.info("Creating vector DB collection: %s", self.config.collection_name)
                self.config.vector_db.create()

    def dependencies(self) -> List[str]:
        """Return plugin IDs that must be loaded before this plugin.

        Returns:
            Empty list (no dependencies)
        """
        return []

    def configure_agent(self, agent: Agent[AgentContext]) -> Agent[AgentContext]:
        """Configure an agent with Docling tools.

        This adds the following tools to the agent:
        - docling_convert_document: Convert documents to searchable format
        - docling_list_documents: List all converted documents
        - docling_query_documents: Search documents
        - docling_get_document_markdown: Get full markdown of a document

        Args:
            agent: Agent to configure

        Returns:
            Configured agent with Docling tools
        """
        if self.service is None:
            raise RuntimeError("Service not initialized")

        # Create tools
        tools = create_docling_tools(self.service)

        # Add tools to agent
        agent = agent.clone(
            tools=list(agent.tools or []) + tools,
        )

        logger.info(
            "Configured agent with %d Docling tools (OCR=%s, Vector DB=%s)",
            len(tools),
            self.config.pdf_do_ocr,
            self.config.vector_db is not None,
        )

        return agent

    def on_before_run(
        self,
        context: AgentContext,
        input_text: str,
    ) -> None:
        """Hook invoked before each agent run.

        Args:
            context: Agent context
            input_text: User input
        """
        # Nothing to do before run
        pass

    def on_after_run(
        self,
        context: AgentContext,
        result,
    ) -> None:
        """Hook invoked after each agent run.

        Args:
            context: Agent context
            result: Run result
        """
        # Nothing to do after run
        pass

    def get_service(self) -> DoclingService:
        """Get the Docling service instance.

        Returns:
            DoclingService instance

        Raises:
            RuntimeError: If service not initialized
        """
        if self.service is None:
            raise RuntimeError("Service not initialized")
        return self.service

    def close(self) -> None:
        """Close resources used by the plugin."""
        if self.config and self.config.vector_db:
            # Vector DBs may have cleanup needs
            pass
