"""Agent tools for Docling document processing.

This module provides function tools that agents can use to convert,
query, and manage documents using Docling.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from agents import function_tool

if TYPE_CHECKING:
    from .service import DoclingService

logger = logging.getLogger(__name__)


def create_docling_tools(service: "DoclingService"):
    """Create Docling tools for an agent.

    Args:
        service: DoclingService instance to use

    Returns:
        List of function tools
    """

    @function_tool
    def docling_convert_document(
        source_file: str,
        user_id: str = "default",
    ) -> str:
        """Convert a document (PDF, DOCX, HTML, etc.) to searchable format.

        This tool converts documents to markdown, chunks them, and optionally
        indexes them into a vector database for semantic search.

        Args:
            source_file: Path to the document file to convert
            user_id: User identifier for namespacing documents

        Returns:
            Summary of the conversion including document ID and chunk count

        Example:
            Convert a PDF document:
            docling_convert_document(source_file="/path/to/document.pdf", user_id="user123")
        """
        try:
            logger.info("Converting document: %s for user: %s", source_file, user_id)
            artifact = service.convert(source_file, user_id=user_id)

            summary = f"""Document converted successfully!

{artifact.get_summary()}

You can now:
- Query this document using docling_query_documents()
- Get the full markdown using docling_get_document_markdown()
- List all documents using docling_list_documents()
"""
            return summary

        except FileNotFoundError as e:
            return f"Error: File not found - {e}"
        except ValueError as e:
            return f"Error: Invalid input - {e}"
        except Exception as e:
            logger.error("Document conversion failed: %s", e, exc_info=True)
            return f"Error: Conversion failed - {e}"

    @function_tool
    def docling_list_documents(user_id: str = "default") -> str:
        """List all converted documents for a user.

        Args:
            user_id: User identifier to filter documents

        Returns:
            List of document IDs and their metadata

        Example:
            List all documents for a user:
            docling_list_documents(user_id="user123")
        """
        try:
            doc_ids = service.list_documents(user_id=user_id)

            if not doc_ids:
                return f"No documents found for user: {user_id}"

            # Load metadata for each document
            results = [f"Found {len(doc_ids)} documents:\n"]

            for doc_id in doc_ids:
                artifact = service.load_artifact(doc_id)
                if artifact:
                    results.append(f"- {doc_id}")
                    results.append(f"  Source: {artifact.source_uri}")
                    results.append(f"  Format: {artifact.source_format}")
                    results.append(f"  Chunks: {artifact.num_chunks}")
                    if artifact.num_pages:
                        results.append(f"  Pages: {artifact.num_pages}")
                    results.append("")

            return "\n".join(results)

        except Exception as e:
            logger.error("Failed to list documents: %s", e, exc_info=True)
            return f"Error: Failed to list documents - {e}"

    @function_tool
    def docling_query_documents(
        query: str,
        document_id: str = "",
        limit: int = 5,
    ) -> str:
        """Search for relevant content in converted documents.

        This tool performs semantic search (if vector DB is configured)
        or keyword search across converted documents.

        Args:
            query: Search query
            document_id: Optional document ID to search within (empty = search all)
            limit: Maximum number of results to return

        Returns:
            Relevant document chunks with their content

        Example:
            Search across all documents:
            docling_query_documents(query="machine learning algorithms", limit=3)

            Search within a specific document:
            docling_query_documents(
                query="neural networks",
                document_id="report_abc123",
                limit=5
            )
        """
        try:
            # Convert empty string to None for document_id
            doc_id = document_id if document_id else None

            logger.info(
                "Querying documents: query='%s', document_id=%s, limit=%d",
                query, doc_id, limit
            )

            chunks = service.query(query, document_id=doc_id, limit=limit)

            if not chunks:
                return f"No results found for query: {query}"

            # Format results
            results = [f"Found {len(chunks)} relevant chunks:\n"]

            for i, chunk in enumerate(chunks, 1):
                results.append(f"Result {i}:")
                results.append(f"Document: {chunk.document_id}")
                results.append(f"Chunk: {chunk.chunk_index + 1}/{chunk.total_chunks}")

                if chunk.score is not None:
                    results.append(f"Score: {chunk.score:.4f}")

                # Truncate content if too long
                content = chunk.content
                if len(content) > 500:
                    content = content[:500] + "..."

                results.append(f"Content:\n{content}\n")

            return "\n".join(results)

        except Exception as e:
            logger.error("Query failed: %s", e, exc_info=True)
            return f"Error: Query failed - {e}"

    @function_tool
    def docling_get_document_markdown(document_id: str) -> str:
        """Get the full markdown export of a converted document.

        Args:
            document_id: Document identifier

        Returns:
            Full markdown text of the document

        Example:
            Get markdown for a document:
            docling_get_document_markdown(document_id="report_abc123")
        """
        try:
            markdown = service.get_document_markdown(document_id)

            if markdown is None:
                return f"Error: Document not found: {document_id}"

            # Truncate if extremely long
            if len(markdown) > 50000:
                return (
                    f"Document is very large ({len(markdown)} characters). "
                    f"Showing first 50000 characters:\n\n"
                    f"{markdown[:50000]}\n\n... (truncated)"
                )

            return markdown

        except Exception as e:
            logger.error("Failed to get markdown: %s", e, exc_info=True)
            return f"Error: Failed to get markdown - {e}"

    return [
        docling_convert_document,
        docling_list_documents,
        docling_query_documents,
        docling_get_document_markdown,
    ]
