"""Data models for Docling artifacts.

This module defines data structures for document conversion
and chunking artifacts.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class ChunkArtifact:
    """Metadata and content for a document chunk.

    Attributes:
        chunk_id: Unique identifier for the chunk
        document_id: Parent document identifier
        content: Text content of the chunk
        chunk_index: Index of chunk in document (0-based)
        total_chunks: Total number of chunks in document
        metadata: Additional metadata
        embedding: Optional vector embedding
        score: Optional relevance score (for search results)
    """

    chunk_id: str
    document_id: str
    content: str
    chunk_index: int = 0
    total_chunks: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    score: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "chunk_id": self.chunk_id,
            "document_id": self.document_id,
            "content": self.content,
            "chunk_index": self.chunk_index,
            "total_chunks": self.total_chunks,
            "metadata": self.metadata,
            "embedding": self.embedding,
            "score": self.score,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ChunkArtifact:
        """Create from dictionary."""
        return cls(
            chunk_id=data["chunk_id"],
            document_id=data["document_id"],
            content=data["content"],
            chunk_index=data.get("chunk_index", 0),
            total_chunks=data.get("total_chunks", 1),
            metadata=data.get("metadata", {}),
            embedding=data.get("embedding"),
            score=data.get("score"),
        )


@dataclass
class ConversionArtifact:
    """Complete artifact from document conversion.

    This contains all outputs from converting a document:
    - Metadata about the conversion
    - Exported text (markdown/text/html/json)
    - Chunks (if chunking was performed)
    - Optional Docling document JSON

    Attributes:
        document_id: Stable document identifier
        source_uri: Original source path/URL
        source_format: File format (pdf, docx, etc.)
        export_format: Export format used (markdown, text, etc.)
        exported_text: Exported document text
        chunks: List of document chunks
        docling_document_json: Optional serialized DoclingDocument
        docling_confidence: Conversion confidence score
        metadata: Additional metadata
        created_at: Timestamp of creation
        num_pages: Number of pages (if applicable)
        num_chunks: Number of chunks created
    """

    document_id: str
    source_uri: str
    source_format: str
    export_format: str
    exported_text: str
    chunks: List[ChunkArtifact] = field(default_factory=list)
    docling_document_json: Optional[str] = None
    docling_confidence: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    num_pages: Optional[int] = None
    num_chunks: int = 0

    def __post_init__(self):
        """Update computed fields after initialization."""
        if not self.num_chunks:
            self.num_chunks = len(self.chunks)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document_id": self.document_id,
            "source_uri": self.source_uri,
            "source_format": self.source_format,
            "export_format": self.export_format,
            "exported_text": self.exported_text,
            "chunks": [c.to_dict() for c in self.chunks],
            "docling_document_json": self.docling_document_json,
            "docling_confidence": self.docling_confidence,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "num_pages": self.num_pages,
            "num_chunks": self.num_chunks,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ConversionArtifact:
        """Create from dictionary."""
        chunks = [
            ChunkArtifact.from_dict(c) for c in data.get("chunks", [])
        ]

        created_at = data.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        elif created_at is None:
            created_at = datetime.now()

        return cls(
            document_id=data["document_id"],
            source_uri=data["source_uri"],
            source_format=data["source_format"],
            export_format=data["export_format"],
            exported_text=data["exported_text"],
            chunks=chunks,
            docling_document_json=data.get("docling_document_json"),
            docling_confidence=data.get("docling_confidence"),
            metadata=data.get("metadata", {}),
            created_at=created_at,
            num_pages=data.get("num_pages"),
            num_chunks=data.get("num_chunks", len(chunks)),
        )

    def get_summary(self) -> str:
        """Get a human-readable summary of the conversion.

        Returns:
            Summary string
        """
        summary_parts = [
            f"Document ID: {self.document_id}",
            f"Source: {self.source_uri}",
            f"Format: {self.source_format} -> {self.export_format}",
            f"Chunks: {self.num_chunks}",
        ]

        if self.num_pages:
            summary_parts.append(f"Pages: {self.num_pages}")

        if self.docling_confidence is not None:
            summary_parts.append(f"Confidence: {self.docling_confidence:.2f}")

        return "\n".join(summary_parts)
