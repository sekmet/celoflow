"""Docling integration for Contextwise.

This module provides document conversion, chunking, and indexing
capabilities using Docling, integrated as a Contextwise plugin.
"""

from .config import (
    ChunkingMode,
    DoclingChunker,
    DoclingConfig,
    ExportFormat,
)
from .models import ChunkArtifact, ConversionArtifact

# Lazy imports to avoid circular dependencies and import errors in tests
def __getattr__(name: str):
    """Lazy import for plugin and service."""
    if name == "DoclingPlugin":
        from .plugin import DoclingPlugin
        return DoclingPlugin
    elif name == "DoclingService":
        from .service import DoclingService
        return DoclingService
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


__all__ = [
    "ChunkingMode",
    "ChunkArtifact",
    "ConversionArtifact",
    "DoclingChunker",
    "DoclingConfig",
    "DoclingPlugin",
    "DoclingService",
    "ExportFormat",
]
