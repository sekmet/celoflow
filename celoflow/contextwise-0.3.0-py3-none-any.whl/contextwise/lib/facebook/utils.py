"""Utility functions for Facebook Messenger API.

This module provides functions for sending messages via Facebook Send API.
"""

import logging
import os
from typing import Optional

import httpx

from ..social import SocialHTTPClient, RateLimiter


logger = logging.getLogger(__name__)

# Rate limiter for Facebook API (10 requests/sec default)
_rate_limiter = RateLimiter(max_tokens=10, refill_rate=10.0)

# HTTP client for Facebook API
_http_client = SocialHTTPClient()


def get_access_token() -> str:
    """Get Facebook access token from environment.

    Returns:
        Access token from FACEBOOK_ACCESS_TOKEN env var

    Raises:
        ValueError: If token not configured
    """
    token = os.getenv("FACEBOOK_ACCESS_TOKEN", "")
    if not token:
        raise ValueError("FACEBOOK_ACCESS_TOKEN not configured")
    return token


def get_page_id() -> str:
    """Get Facebook Page ID from environment.

    Returns:
        Page ID from FACEBOOK_PAGE_ID env var

    Raises:
        ValueError: If page ID not configured
    """
    page_id = os.getenv("FACEBOOK_PAGE_ID", "")
    if not page_id:
        raise ValueError("FACEBOOK_PAGE_ID not configured")
    return page_id


def send_facebook_message(
    recipient_id: str,
    text: str,
    access_token: Optional[str] = None,
) -> Optional[str]:
    """Send a text message via Facebook Messenger (synchronous).

    Args:
        recipient_id: Facebook user PSID
        text: Message text
        access_token: Access token (defaults to env var)

    Returns:
        Error message if failed, None if successful

    Example:
        >>> error = send_facebook_message("123456", "Hello!")
        >>> if error:
        ...     print(f"Failed: {error}")
    """
    access_token = access_token or get_access_token()

    url = f"https://graph.facebook.com/v18.0/me/messages"

    headers = {
        "Content-Type": "application/json",
    }

    payload = {
        "recipient": {"id": recipient_id},
        "message": {"text": text},
        "access_token": access_token,
    }

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            logger.info(f"Facebook message sent to {recipient_id}")
            return None

    except httpx.HTTPError as e:
        error_msg = f"Failed to send Facebook message: {e}"
        logger.error(error_msg)
        return error_msg


async def send_facebook_message_async(
    recipient_id: str,
    text: str,
    access_token: Optional[str] = None,
) -> Optional[str]:
    """Send a text message via Facebook Messenger (asynchronous).

    Args:
        recipient_id: Facebook user PSID
        text: Message text
        access_token: Access token (defaults to env var)

    Returns:
        Error message if failed, None if successful

    Example:
        >>> error = await send_facebook_message_async("123456", "Hello!")
        >>> if error:
        ...     print(f"Failed: {error}")
    """
    access_token = access_token or get_access_token()

    # Acquire rate limit token
    await _rate_limiter.acquire()

    url = f"https://graph.facebook.com/v18.0/me/messages"

    headers = {
        "Content-Type": "application/json",
    }

    payload = {
        "recipient": {"id": recipient_id},
        "message": {"text": text},
        "access_token": access_token,
    }

    try:
        result = await _http_client.post(url, headers, json_data=payload)
        logger.info(f"Facebook message sent to {recipient_id}")
        return None

    except httpx.HTTPError as e:
        error_msg = f"Failed to send Facebook message: {e}"
        logger.error(error_msg)
        return error_msg
