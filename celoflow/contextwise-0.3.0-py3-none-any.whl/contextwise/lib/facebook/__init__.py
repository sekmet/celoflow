"""Facebook channel plugin for Contextwise v0.3.0.

This module provides Facebook Messenger API integration as a Contextwise
channel plugin, including webhook handling and message sending.
"""

from .utils import send_facebook_message, send_facebook_message_async
from .router import create_facebook_router

__all__ = [
    "send_facebook_message",
    "send_facebook_message_async",
    "create_facebook_router",
]
