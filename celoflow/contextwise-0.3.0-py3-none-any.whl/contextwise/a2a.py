"""A2A (Agent-to-Agent) Protocol for Contextwise v0.3.0.

This module implements the A2A protocol for standardized agent communication
over HTTP, enabling agents to discover and interact with each other.

Based on Google's Agent-to-Agent specification.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from .agent import Agent

logger = logging.getLogger(__name__)


@dataclass
class A2ASkill:
    """Represents a skill that an agent can perform.
    
    Attributes:
        id: Unique skill identifier
        name: Human-readable skill name
        description: Detailed description of what the skill does
        input_modes: Supported input formats (e.g., "text", "audio")
        output_modes: Supported output formats
    """
    id: str
    name: str
    description: str
    input_modes: List[str] = field(default_factory=lambda: ["text"])
    output_modes: List[str] = field(default_factory=lambda: ["text"])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "inputModes": self.input_modes,
            "outputModes": self.output_modes,
        }


@dataclass
class A2AAgentCard:
    """Agent card describing an A2A agent's capabilities.
    
    Attributes:
        name: Agent name
        description: Agent description
        url: Agent endpoint URL
        version: Protocol version
        skills: List of skills the agent can perform
        authentication: Authentication requirements
    """
    name: str
    description: str
    url: str
    version: str = "1.0"
    skills: List[A2ASkill] = field(default_factory=list)
    authentication: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "url": self.url,
            "version": self.version,
            "skills": [s.to_dict() for s in self.skills],
            "authentication": self.authentication,
        }


@dataclass
class A2AMessage:
    """A2A protocol message.
    
    Attributes:
        role: Message role (user, assistant, system)
        content: Message content
        parts: Multi-part content (for multimodal)
    """
    role: str
    content: str
    parts: Optional[List[Dict[str, Any]]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "role": self.role,
            "content": self.content,
        }
        if self.parts:
            result["parts"] = self.parts
        return result


@dataclass
class A2ATask:
    """A2A task representing a unit of work.
    
    Attributes:
        id: Unique task ID
        skill_id: ID of the skill to invoke
        messages: Conversation messages
        status: Task status (pending, running, completed, failed)
        result: Task result when completed
    """
    id: str
    skill_id: str
    messages: List[A2AMessage] = field(default_factory=list)
    status: str = "pending"
    result: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "skillId": self.skill_id,
            "messages": [m.to_dict() for m in self.messages],
            "status": self.status,
            "result": self.result,
        }


@dataclass
class A2AServer:
    """A2A server configuration for exposing an agent.
    
    Attributes:
        url: Server base URL
        skills: List of skills to expose
        auth_token: Optional authentication token
    """
    url: Optional[str] = None
    skills: List[A2ASkill] = field(default_factory=list)
    auth_token: Optional[str] = None
    
    _agent: Optional["Agent"] = field(default=None, repr=False, init=False)
    _tasks: Dict[str, A2ATask] = field(default_factory=dict, repr=False, init=False)
    
    def bind(self, agent: "Agent") -> None:
        """Bind this server to an agent."""
        self._agent = agent
        
        # Auto-generate skills from agent if none provided
        if not self.skills:
            self.skills = [
                A2ASkill(
                    id="chat",
                    name="Chat",
                    description=agent.description or f"Chat with {agent.name}",
                    input_modes=["text"],
                    output_modes=["text"],
                )
            ]
    
    def get_agent_card(self) -> A2AAgentCard:
        """Get the agent card for this server."""
        if not self._agent:
            raise ValueError("Server not bound to an agent")
        
        return A2AAgentCard(
            name=self._agent.name,
            description=self._agent.description or "",
            url=self.url or "http://localhost:8000",
            skills=self.skills,
        )
    
    async def handle_task(self, task: A2ATask) -> A2ATask:
        """Handle an incoming A2A task.
        
        Args:
            task: The task to process
            
        Returns:
            Updated task with result
        """
        if not self._agent:
            task.status = "failed"
            task.result = {"error": "Server not bound to an agent"}
            return task
        
        task.status = "running"
        self._tasks[task.id] = task
        
        try:
            # Extract user message from task messages
            user_message = ""
            for msg in reversed(task.messages):
                if msg.role == "user":
                    user_message = msg.content
                    break
            
            if not user_message:
                task.status = "failed"
                task.result = {"error": "No user message in task"}
                return task
            
            # Run the agent
            response = await self._agent.chat_async(
                message=user_message,
                user_id=f"a2a_{task.id}",
            )
            
            # Add response to task
            task.messages.append(A2AMessage(
                role="assistant",
                content=response,
            ))
            
            task.status = "completed"
            task.result = {
                "response": response,
            }
            
        except Exception as e:
            logger.exception(f"Error handling A2A task {task.id}")
            task.status = "failed"
            task.result = {"error": str(e)}
        
        return task
    
    def create_router(self):
        """Create FastAPI router for A2A endpoints.
        
        Returns:
            FastAPI APIRouter with A2A endpoints
        """
        from fastapi import APIRouter, HTTPException
        from pydantic import BaseModel
        from typing import List
        import uuid
        
        router = APIRouter(prefix="/a2a", tags=["a2a"])
        
        class TaskRequest(BaseModel):
            skill_id: str
            messages: List[Dict[str, Any]]
        
        @router.get("/.well-known/agent.json")
        async def get_agent_card():
            """Return the agent card."""
            return self.get_agent_card().to_dict()
        
        @router.post("/tasks")
        async def create_task(request: TaskRequest):
            """Create and execute a new task."""
            task = A2ATask(
                id=str(uuid.uuid4()),
                skill_id=request.skill_id,
                messages=[
                    A2AMessage(**m) for m in request.messages
                ],
            )
            
            result = await self.handle_task(task)
            return result.to_dict()
        
        @router.get("/tasks/{task_id}")
        async def get_task(task_id: str):
            """Get task status."""
            if task_id not in self._tasks:
                raise HTTPException(status_code=404, detail="Task not found")
            return self._tasks[task_id].to_dict()
        
        @router.get("/skills")
        async def list_skills():
            """List available skills."""
            return [s.to_dict() for s in self.skills]
        
        return router


@dataclass
class A2AClient:
    """Client for communicating with A2A agents.
    
    Attributes:
        url: Agent endpoint URL
        auth_token: Optional authentication token
    """
    url: str
    auth_token: Optional[str] = None
    
    _agent_card: Optional[A2AAgentCard] = field(default=None, repr=False, init=False)
    
    async def discover(self) -> A2AAgentCard:
        """Discover the agent by fetching its agent card.
        
        Returns:
            Agent card describing the agent's capabilities
        """
        import httpx
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.url}/.well-known/agent.json",
                headers=self._get_headers(),
            )
            response.raise_for_status()
            
            data = response.json()
            self._agent_card = A2AAgentCard(
                name=data["name"],
                description=data["description"],
                url=data["url"],
                version=data.get("version", "1.0"),
                skills=[
                    A2ASkill(
                        id=s["id"],
                        name=s["name"],
                        description=s["description"],
                        input_modes=s.get("inputModes", ["text"]),
                        output_modes=s.get("outputModes", ["text"]),
                    )
                    for s in data.get("skills", [])
                ],
            )
            
            return self._agent_card
    
    async def send_task(
        self,
        skill_id: str,
        message: str,
    ) -> A2ATask:
        """Send a task to the agent.
        
        Args:
            skill_id: ID of the skill to invoke
            message: User message
            
        Returns:
            Task result
        """
        import httpx
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.url}/a2a/tasks",
                json={
                    "skill_id": skill_id,
                    "messages": [
                        {"role": "user", "content": message}
                    ],
                },
                headers=self._get_headers(),
            )
            response.raise_for_status()
            
            data = response.json()
            return A2ATask(
                id=data["id"],
                skill_id=data["skillId"],
                messages=[
                    A2AMessage(
                        role=m["role"],
                        content=m["content"],
                    )
                    for m in data.get("messages", [])
                ],
                status=data["status"],
                result=data.get("result"),
            )
    
    async def chat(self, message: str, skill_id: str = "chat") -> str:
        """Send a chat message to the agent.
        
        Args:
            message: User message
            skill_id: Skill to use (default: "chat")
            
        Returns:
            Agent response
        """
        task = await self.send_task(skill_id, message)
        
        if task.status == "completed" and task.result:
            return task.result.get("response", "")
        elif task.status == "failed" and task.result:
            raise RuntimeError(task.result.get("error", "Task failed"))
        else:
            return ""
    
    def as_tool(self) -> Callable:
        """Convert this client to a tool function for use in other agents.
        
        Returns:
            Async function that can be used as an agent tool
        """
        async def a2a_agent_tool(message: str) -> str:
            """Call the A2A agent with a message."""
            return await self.chat(message)
        
        # Set metadata for tool registration
        agent_name = self._agent_card.name if self._agent_card else "A2A Agent"
        a2a_agent_tool.__name__ = f"call_{agent_name.lower().replace(' ', '_')}"
        a2a_agent_tool.__doc__ = (
            f"Call the {agent_name} agent. "
            f"{self._agent_card.description if self._agent_card else ''}"
        )
        
        return a2a_agent_tool
    
    def _get_headers(self) -> Dict[str, str]:
        """Get request headers including authentication."""
        headers = {"Content-Type": "application/json"}
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        return headers
