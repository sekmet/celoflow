"""Model abstraction classes for Contextwise v0.3.0.

This module provides unified model classes that can be used with the Agent class.
Models can be instantiated directly or passed as string IDs for convenience.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
import os
from dotenv import load_dotenv

from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Union

logger = logging.getLogger(__name__)

load_dotenv()

@dataclass
class Model:
    """Base class for model configuration.

    This class provides a common interface for configuring different LLM providers.
    """

    id: str
    provider: str = "openai"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    temperature: float = 0.7
    max_tokens: Optional[int] = None

    def __str__(self) -> str:
        return f"{self.provider}/{self.id}"


@dataclass
class OpenAIModel(Model):
    """OpenAI model configuration.

    Examples:
        >>> model = OpenAIModel("gpt-4o-mini")
        >>> model = OpenAIModel("gpt-4o", temperature=0.9)
    """

    provider: str = "openai"

    def __init__(
        self,
        id: str = "gpt-4o-mini",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        self.id = id
        self.provider = "openai"
        self.api_key = api_key
        self.base_url = base_url
        self.temperature = temperature
        self.max_tokens = max_tokens


@dataclass
class GroqModel(Model):
    """Groq model configuration.

    Examples:
        >>> model = GroqModel("llama-3.3-70b-versatile")
        >>> model = GroqModel("mixtral-8x7b-32768", temperature=0.5)
    """

    provider: str = "groq"
    base_url: str = "https://api.groq.com/openai/v1"

    def __init__(
        self,
        id: str = "llama-3.3-70b-versatile",
        api_key: Optional[str] = None,
        base_url: str = "https://api.groq.com/openai/v1",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        self.id = id
        self.provider = "groq"
        self.api_key = api_key
        self.base_url = base_url
        self.temperature = temperature
        self.max_tokens = max_tokens


@dataclass
class AnthropicModel(Model):
    """Anthropic (Claude) model configuration.

    Examples:
        >>> model = AnthropicModel("claude-3-5-sonnet-20241022")
        >>> model = AnthropicModel("claude-3-opus-20240229", temperature=1.0)
    """

    provider: str = "anthropic"
    base_url: str = "https://api.anthropic.com"

    def __init__(
        self,
        id: str = "claude-3-5-sonnet-20241022",
        api_key: Optional[str] = None,
        base_url: str = "https://api.anthropic.com",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        self.id = id
        self.provider = "anthropic"
        self.api_key = api_key
        self.base_url = base_url
        self.temperature = temperature
        self.max_tokens = max_tokens


@dataclass
class OllamaModel(Model):
    """Ollama model configuration for local inference.

    Examples:
        >>> model = OllamaModel("llama3.2:latest")
        >>> model = OllamaModel("mistral:latest", temperature=0.5)
    """

    provider: str = "ollama"
    base_url: str = "http://localhost:11434/v1"

    def __init__(
        self,
        id: str = "llama3.2:latest",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        self.id = id
        self.provider = "ollama"
        self.api_key = api_key
        self.base_url = base_url or os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1")
        self.temperature = temperature
        self.max_tokens = max_tokens


@dataclass
class CloudflareModel(Model):
    """Cloudflare Workers AI model configuration for edge inference.

    Examples:
        >>> model = CloudflareModel("@cf/meta/llama-3.1-8b-instruct")
        >>> model = CloudflareModel("@cf/openai/gpt-oss-120b", temperature=0.5)
    """

    provider: str = "cloudflare"
    account_id: Optional[str] = None

    def __init__(
        self,
        id: str = "@cf/meta/llama-3.1-8b-instruct",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        account_id: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        self.id = id
        self.provider = "cloudflare"
        self.api_key = api_key
        self.account_id = account_id or os.environ.get("CLOUDFLARE_ACCOUNT_ID")
        if base_url:
            self.base_url = base_url
        else:
            env_url = os.environ.get("CLOUDFLARE_BASE_URL")
            if env_url:
                self.base_url = env_url
            elif self.account_id:
                self.base_url = f"https://api.cloudflare.com/client/v4/accounts/{self.account_id}/ai/v1"
            else:
                self.base_url = None
        self.temperature = temperature
        self.max_tokens = max_tokens


@dataclass
class AzureForgeModel(Model):
    """Azure AI Forge model configuration for enterprise inference.

    Supports multiple Azure endpoint patterns:
    - cognitiveservices.azure.com/openai/v1/
    - services.ai.azure.com/openai/v1/

    Examples:
        >>> model = AzureForgeModel("gpt-5-mini")
        >>> model = AzureForgeModel("grok-4-fast-reasoning", temperature=0.5)
    """

    provider: str = "azure_forge"
    base_url: str = os.environ.get("AZURE_FORGE_ENDPOINT", "")
    
    def __init__(
        self,
        id: str = "gpt-5-mini",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        self.id = id
        self.provider = "azure_forge"
        self.api_key = api_key
        self.base_url = base_url or os.environ.get(
            "AZURE_FORGE_ENDPOINT",
            "https://context-wz-resource.cognitiveservices.azure.com/openai/v1/"
        )
        self.temperature = temperature
        self.max_tokens = max_tokens


@dataclass
class CerebrasModel(Model):
    """Cerebras model configuration for high-performance inference.

    Cerebras-specific features:
    - reasoning_effort: "low", "medium", "high" (gpt-oss-120b only)
    - clear_thinking: bool (zai-glm-4.7 only)
    - Does NOT support frequency_penalty, logit_bias, presence_penalty

    Examples:
        >>> model = CerebrasModel("llama-3.3-70b")
        >>> model = CerebrasModel("gpt-oss-120b", temperature=0.5)
    """

    provider: str = "cerebras"
    base_url: str = "https://api.cerebras.ai/v1"
    reasoning_effort: Optional[str] = None
    clear_thinking: Optional[bool] = None

    def __init__(
        self,
        id: str = "llama-3.3-70b",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        reasoning_effort: Optional[str] = None,
        clear_thinking: Optional[bool] = None,
    ):
        self.id = id
        self.provider = "cerebras"
        self.api_key = api_key
        self.base_url = base_url or os.environ.get("CEREBRAS_BASE_URL", "https://api.cerebras.ai/v1")
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.reasoning_effort = reasoning_effort
        self.clear_thinking = clear_thinking


# Gemini OpenAI-compatible endpoint
GEMINI_OPENAI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"

try:
    from openai import DEFAULT_MAX_RETRIES, AsyncOpenAI, OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

# Google GenAI SDK (native)
try:
    from google import genai
    from google.genai import types as genai_types
    GOOGLE_GENAI_AVAILABLE = True
except ImportError:
    GOOGLE_GENAI_AVAILABLE = False
    genai = None  # type: ignore
    genai_types = None  # type: ignore

# Google GenAI SDK native support (handles thought_signature automatically)
try:
    from .lib.models.gemini_adk import (
        GeminiADKRunner,
        GeminiNativeClient,
        is_adk_available,
        convert_openai_tools_to_genai,
    )
    GOOGLE_ADK_AVAILABLE = is_adk_available()
except ImportError:
    GOOGLE_ADK_AVAILABLE = False
    GeminiADKRunner = None  # type: ignore
    GeminiNativeClient = None  # type: ignore
    convert_openai_tools_to_genai = None  # type: ignore

# Optional integration with the agents SDK (used by demos)
try:
    from agents.models import _openai_shared as agents_openai_shared

    AGENTS_OPENAI_SHARED_AVAILABLE = True
except ImportError:  # pragma: no cover - optional dependency
    AGENTS_OPENAI_SHARED_AVAILABLE = False
    agents_openai_shared = None  # type: ignore[misc,assignment]


# Base classes for ModelResponse and ModelMessage
@dataclass
class ModelMessage:
    """Message model for chat completions."""
    role: str
    content: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format."""
        return {"role": self.role, "content": self.content}


@dataclass
class ModelResponse:
    """Response model for chat completions."""
    content: str
    role: str = "assistant"
    tool_calls: Optional[List[Dict[str, Any]]] = None
    usage: Optional[Dict[str, Any]] = None
    model: Optional[str] = None
    finish_reason: Optional[str] = None
    raw_response: Optional[Any] = None


@dataclass
class GeminiModel(Model):
    """Google Gemini chat model with dual SDK support.
    
    This model supports two modes:
    1. OpenAI-compatible API (default) - uses OpenAI SDK with Google's endpoint
    2. Native Google GenAI SDK - for gemini-3 models that require thought_signature
    
    For gemini-3 models (gemini-3-flash-preview, gemini-3-pro-preview), set
    `use_native_sdk=True` to enable proper thought_signature handling.
    
    Attributes:
        id: Model identifier (e.g., "gemini-2.0-flash", "gemini-3-flash-preview").
        api_key: Google API key.
        use_native_sdk: Use native Google GenAI SDK (required for gemini-3 models).
        base_url: API endpoint (only used when use_native_sdk=False).
        temperature: Sampling temperature (0-2).
        max_tokens: Maximum tokens in response.
    
    Example (OpenAI-compatible mode):
        >>> model = GeminiModel(
        ...     id="gemini-2.0-flash",
        ...     api_key="...",
        ... )
        >>> response = model.chat([
        ...     ModelMessage(role="user", content="Hello!"),
        ... ])
        >>> print(response.content)
    
    Example (Native SDK mode for gemini-3):
        >>> model = GeminiModel(
        ...     id="gemini-3-flash-preview",
        ...     api_key="...",
        ...     use_native_sdk=True,  # Required for gemini-3 models
        ... )
    """

    provider: str = "gemini"
    base_url: str = GEMINI_OPENAI_BASE_URL
    name: str = "Gemini"
    
    # SDK mode selection
    use_native_sdk: bool = False  # Set True for gemini-3 models
    
    # API configuration - uses OpenAI SDK with Gemini's endpoint (when use_native_sdk=False)
    timeout: Optional[float] = None
    max_retries: Optional[int] = None
    
    # Additional request parameters
    top_p: Optional[float] = None
    stop: Optional[Union[str, List[str]]] = None
    
    # Client instances
    _client: Optional[Any] = field(default=None, repr=False)
    _async_client: Optional[Any] = field(default=None, repr=False)
    _genai_client: Optional[Any] = field(default=None, repr=False)
    _adk_runner: Optional[Any] = field(default=None, repr=False)

    def __init__(
        self,
        id: str = "gemini-2.0-flash",
        name: str = "Gemini",
        api_key: Optional[str] = None,
        base_url: str = GEMINI_OPENAI_BASE_URL,
        use_native_sdk: bool = False,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        stop: Optional[Union[str, list]] = None,
    ):
        """Initialize GeminiModel with backward compatibility."""
        self.id = id
        self.name = name
        self.provider = "gemini"
        self.api_key = api_key
        self.base_url = base_url
        self.use_native_sdk = use_native_sdk
        self.timeout = timeout
        self.max_retries = max_retries
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.top_p = top_p
        self.stop = stop
        
        # Initialize client instances
        self._client = None
        self._async_client = None
        self._genai_client = None
        self._adk_runner = None
        
        # Run post_init validation
        self.__post_init__()

    def __post_init__(self):
        """Validate dependencies are available."""
        # Validate SDK availability based on mode
        if self.use_native_sdk:
            if not GOOGLE_ADK_AVAILABLE:
                raise ImportError(
                    "google-adk not installed. Install with: uv add google-adk"
                )
            if not GOOGLE_GENAI_AVAILABLE:
                raise ImportError(
                    "google-genai not installed. Install with: uv add google-genai"
                )
        else:
            if not OPENAI_AVAILABLE:
                raise ImportError(
                    "openai not installed. Install with: uv add openai"
                )
        
        # Auto-detect gemini-3 models and warn if not using native SDK
        if "gemini-3" in self.id and not self.use_native_sdk:
            logger.warning(
                f"Model {self.id} is a gemini-3 model which requires thought_signature. "
                f"Consider setting use_native_sdk=True for proper function calling support."
            )
        
        # Get API key from environment if not provided
        if not self.api_key:
            self.api_key = os.environ.get("GEMINI_API_KEY")

        # Provide defaults for the agents SDK so MultiProvider can route Gemini calls
        # without requiring OPENAI_API_KEY. Do not change the global responses/chat
        # default here; the builder plugin will choose the correct API per provider.
        if AGENTS_OPENAI_SHARED_AVAILABLE and self.api_key:
            try:
                current_key = agents_openai_shared.get_default_openai_key()
                if current_key is None:
                    agents_openai_shared.set_default_openai_key(self.api_key)

                current_client = agents_openai_shared.get_default_openai_client()
                if current_client is None:
                    gemini_client = AsyncOpenAI(
                        api_key=self.api_key,
                        base_url=self.base_url,
                        timeout=self.timeout,
                        max_retries=self._resolved_max_retries,
                    )
                    agents_openai_shared.set_default_openai_client(gemini_client)
            except Exception as exc:  # pragma: no cover - best-effort integration
                logger.warning(
                    "Could not register Gemini client with agents SDK defaults: %s", exc
                )
    
    @property
    def client(self) -> "OpenAI":
        """Get or create the OpenAI client with Gemini base_url."""
        if self._client is None:
            client_params = {
                "api_key": self.api_key,
                "base_url": self.base_url,
                "timeout": self.timeout,
                "max_retries": self._resolved_max_retries,
            }
            client_params = {k: v for k, v in client_params.items() if v is not None}
            self._client = OpenAI(**client_params)
        return self._client
    
    @property
    def async_client(self) -> "AsyncOpenAI":
        """Get or create the async OpenAI client with Gemini base_url."""
        if self._async_client is None:
            client_params = {
                "api_key": self.api_key,
                "base_url": self.base_url,
                "timeout": self.timeout,
                "max_retries": self._resolved_max_retries,
            }
            client_params = {k: v for k, v in client_params.items() if v is not None}
            self._async_client = AsyncOpenAI(**client_params)
        return self._async_client

    @property
    def _resolved_max_retries(self) -> Optional[int]:
        """Return a max_retries value acceptable by OpenAI SDK."""
        if self.max_retries is None:
            return DEFAULT_MAX_RETRIES
        return self.max_retries

    @property
    def genai_client(self) -> Any:
        """Get or create the native Google GenAI client."""
        if self._genai_client is None:
            if not GOOGLE_GENAI_AVAILABLE:
                raise ImportError("google-genai not installed")
            self._genai_client = genai.Client(api_key=self.api_key)
        return self._genai_client
    
    @property
    def adk_runner(self) -> Any:
        """Get or create the Google ADK runner for tool-enabled calls."""
        if self._adk_runner is None:
            if not GOOGLE_ADK_AVAILABLE:
                raise ImportError("google-adk not installed")
            self._adk_runner = GeminiADKRunner(
                model_id=self.id,
                api_key=self.api_key,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
        return self._adk_runner

    def _convert_messages_to_genai(
        self,
        messages: List[ModelMessage],
    ) -> tuple[Optional[str], List[Dict[str, Any]]]:
        """Convert ModelMessage list to Google GenAI format.
        
        Returns:
            Tuple of (system_instruction, contents)
        """
        system_instruction = None
        contents = []
        
        for msg in messages:
            if msg.role == "system":
                system_instruction = msg.content
            elif msg.role == "user":
                contents.append({
                    "role": "user",
                    "parts": [{"text": msg.content}]
                })
            elif msg.role == "assistant":
                contents.append({
                    "role": "model",
                    "parts": [{"text": msg.content}]
                })
        
        return system_instruction, contents

    def _parse_genai_response(self, response: Any) -> ModelResponse:
        """Parse native GenAI response to ModelResponse."""
        candidate = response.candidates[0]
        content = candidate.content
        
        # Extract text from parts
        text_content = ""
        for part in content.parts:
            if hasattr(part, 'text'):
                text_content += part.text
        
        # Extract usage metadata
        usage = None
        if hasattr(response, 'usage_metadata'):
            usage = {
                "prompt_tokens": response.usage_metadata.prompt_token_count,
                "completion_tokens": response.usage_metadata.candidates_token_count,
                "total_tokens": response.usage_metadata.total_token_count,
            }
        
        return ModelResponse(
            content=text_content,
            role="assistant",
            usage=usage,
            model=self.id,
            finish_reason=str(candidate.finish_reason) if candidate.finish_reason else None,
            raw_response=response,
        )
    
    def _build_request_params(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> Dict[str, Any]:
        """Build request parameters for API call."""
        params: Dict[str, Any] = {
            "model": self.id,
            "messages": [m.to_dict() for m in messages],
        }
        
        # Add optional parameters
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.max_tokens is not None:
            params["max_tokens"] = self.max_tokens
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.stop is not None:
            params["stop"] = self.stop
        
        # Override with kwargs
        params.update(kwargs)
        
        return params
    
    def _parse_response(self, response: Any) -> ModelResponse:
        """Parse OpenAI response to ModelResponse."""
        choice = response.choices[0]
        message = choice.message
        
        usage = None
        if response.usage:
            usage = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            }
        
        tool_calls = None
        if message.tool_calls:
            tool_calls = [
                {
                    "id": tc.id,
                    "type": tc.type,
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in message.tool_calls
            ]
        
        return ModelResponse(
            content=message.content or "",
            role=message.role,
            tool_calls=tool_calls,
            usage=usage,
            model=response.model,
            finish_reason=choice.finish_reason,
            raw_response=response,
        )
    
    def chat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Generate a chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Gemini-specific parameters.
            
        Returns:
            ModelResponse with the completion.
        """
        if self.use_native_sdk:
            return self._chat_native(messages, **kwargs)
        return self._chat_openai(messages, **kwargs)

    def _chat_openai(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Chat using OpenAI-compatible API."""
        try:
            params = self._build_request_params(messages, **kwargs)
            response = self.client.chat.completions.create(**params)
            return self._parse_response(response)
        except Exception as e:
            logger.error(f"Error in Gemini chat completion (OpenAI mode): {e}")
            raise

    def _chat_native(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Chat using native Google ADK/GenAI SDK.
        
        Uses Google ADK Runner when tools are provided for proper thought_signature
        handling. Falls back to GenAI SDK for simple chat without tools.
        """
        try:
            tools = kwargs.get("tools")
            
            # Use ADK Runner for tool-enabled calls (Gemini 3+ models)
            if tools and GOOGLE_ADK_AVAILABLE:
                return self._chat_with_adk(messages, tools, **kwargs)
            
            # Fall back to GenAI SDK for simple chat
            system_instruction, contents = self._convert_messages_to_genai(messages)
            
            # Build generation config
            config = {}
            if self.temperature is not None:
                config["temperature"] = self.temperature
            if self.max_tokens is not None:
                config["max_output_tokens"] = self.max_tokens
            if self.top_p is not None:
                config["top_p"] = self.top_p
            if self.stop is not None:
                config["stop_sequences"] = self.stop if isinstance(self.stop, list) else [self.stop]
            
            response = self.genai_client.models.generate_content(
                model=self.id,
                contents=contents,
                config=genai_types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    **config,
                ) if config or system_instruction else None,
            )
            return self._parse_genai_response(response)
        except Exception as e:
            logger.error(f"Error in Gemini chat completion (native mode): {e}")
            raise
    
    def _chat_with_adk(
        self,
        messages: List[ModelMessage],
        tools: List[Any],
        **kwargs,
    ) -> ModelResponse:
        """Chat using native Google GenAI SDK for tool-enabled calls.
        
        The GenAI SDK handles thought_signature automatically.
        
        Args:
            messages: List of conversation messages
            tools: List of tools in OpenAI format
            **kwargs: Additional parameters
            
        Returns:
            ModelResponse with the completion
        """
        # Extract system instruction and user message
        system_instruction = None
        user_message = ""
        
        for msg in messages:
            if msg.role == "system":
                system_instruction = msg.content
            elif msg.role == "user":
                user_message = msg.content
        
        # Update runner instructions if system instruction provided
        if system_instruction:
            self.adk_runner.instructions = system_instruction
        
        # Run through native GenAI SDK (handles thought_signature automatically)
        result = self.adk_runner.run_sync(
            message=user_message,
            tools=tools,  # Pass tools directly, runner handles conversion
        )
        
        return ModelResponse(
            content=result.get("content", ""),
            role=result.get("role", "assistant"),
            tool_calls=result.get("tool_calls"),
            model=result.get("model", self.id),
        )
    
    async def achat(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Async chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Gemini-specific parameters.
            
        Returns:
            ModelResponse with the completion.
        """
        if self.use_native_sdk:
            return await self._achat_native(messages, **kwargs)
        return await self._achat_openai(messages, **kwargs)

    async def _achat_openai(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Async chat using OpenAI-compatible API."""
        try:
            params = self._build_request_params(messages, **kwargs)
            response = await self.async_client.chat.completions.create(**params)
            return self._parse_response(response)
        except Exception as e:
            logger.error(f"Error in async Gemini chat completion (OpenAI mode): {e}")
            raise

    async def _achat_native(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Async chat using native Google ADK/GenAI SDK.
        
        Uses Google ADK Runner when tools are provided for proper thought_signature
        handling. Falls back to GenAI SDK for simple chat without tools.
        """
        try:
            tools = kwargs.get("tools")
            
            # Use ADK Runner for tool-enabled calls (Gemini 3+ models)
            if tools and GOOGLE_ADK_AVAILABLE:
                # Remove tools from kwargs to avoid duplicate parameter
                kwargs_without_tools = {k: v for k, v in kwargs.items() if k != 'tools'}
                return await self._achat_with_adk(messages, tools, **kwargs_without_tools)
            
            # Fall back to GenAI SDK for simple chat
            system_instruction, contents = self._convert_messages_to_genai(messages)
            
            # Build generation config
            config = {}
            if self.temperature is not None:
                config["temperature"] = self.temperature
            if self.max_tokens is not None:
                config["max_output_tokens"] = self.max_tokens
            if self.top_p is not None:
                config["top_p"] = self.top_p
            if self.stop is not None:
                config["stop_sequences"] = self.stop if isinstance(self.stop, list) else [self.stop]
            
            response = await self.genai_client.aio.models.generate_content(
                model=self.id,
                contents=contents,
                config=genai_types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    **config,
                ) if config or system_instruction else None,
            )
            return self._parse_genai_response(response)
        except Exception as e:
            logger.error(f"Error in async Gemini chat completion (native mode): {e}")
            raise
    
    async def _achat_with_adk(
        self,
        messages: List[ModelMessage],
        tools: List[Any],
        **kwargs,
    ) -> ModelResponse:
        """Async chat using native Google GenAI SDK for tool-enabled calls.
        
        The GenAI SDK handles thought_signature automatically.
        
        Args:
            messages: List of conversation messages
            tools: List of tools in OpenAI format
            **kwargs: Additional parameters
            
        Returns:
            ModelResponse with the completion
        """
        # Extract system instruction and user message
        system_instruction = None
        user_message = ""
        
        for msg in messages:
            if msg.role == "system":
                system_instruction = msg.content
            elif msg.role == "user":
                user_message = msg.content
        
        # Update runner instructions if system instruction provided
        if system_instruction:
            self.adk_runner.instructions = system_instruction
        
        # Run through native GenAI SDK async (handles thought_signature automatically)
        result = await self.adk_runner.run_async(
            message=user_message,
            tools=tools,  # Pass tools directly, runner handles conversion
        )
        
        return ModelResponse(
            content=result.get("content", ""),
            role=result.get("role", "assistant"),
            tool_calls=result.get("tool_calls"),
            model=result.get("model", self.id),
        )
    
    def _convert_tools_to_genai(self, openai_tools: List[Dict[str, Any]]) -> List[Any]:
        """Convert OpenAI tool format to Gemini tool format.
        
        Args:
            openai_tools: List of tools in OpenAI format
            
        Returns:
            List of tools in Gemini format
        """
        if not GOOGLE_GENAI_AVAILABLE:
            return []
            
        gemini_tools = []
        for tool in openai_tools:
            if tool.get("type") == "function":
                function_spec = tool.get("function", {})
                gemini_tool = genai_types.Tool(
                    function_declarations=[
                        genai_types.FunctionDeclaration(
                            name=function_spec.get("name"),
                            description=function_spec.get("description"),
                            parameters=function_spec.get("parameters", {}),
                        )
                    ]
                )
                gemini_tools.append(gemini_tool)
        
        return gemini_tools
    
    def chat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> Iterator[ModelResponse]:
        """Generate a streaming chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Gemini-specific parameters.
            
        Yields:
            ModelResponse chunks.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            params["stream"] = True
            
            stream = self.client.chat.completions.create(**params)
            
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield ModelResponse(
                        content=chunk.choices[0].delta.content,
                        role="assistant",
                        model=chunk.model,
                    )
        except Exception as e:
            logger.error(f"Error in Gemini streaming chat: {e}")
            raise
    
    def get_response(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> ModelResponse:
        """Get response from the model (synchronous wrapper for async).
        
        This method is required by the agents SDK and routes to the appropriate
        async method based on the use_native_sdk setting.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional provider-specific parameters.
            
        Returns:
            ModelResponse with the completion.
        """
        logger.info(f"GeminiModel.get_response called with use_native_sdk={self.use_native_sdk}")
        
        import asyncio
        
        try:
            # Try to get the current event loop
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                # No running loop, create a new one
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            
            # Run the async method
            if loop.is_running():
                # If loop is running, we need to run in a thread
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(asyncio.run, self.achat(messages, **kwargs))
                    result = future.result()
                    logger.info(f"GeminiModel.get_response completed via thread pool")
                    return result
            else:
                # If loop is not running, run directly
                result = loop.run_until_complete(self.achat(messages, **kwargs))
                logger.info(f"GeminiModel.get_response completed directly")
                return result
                
        except Exception as e:
            logger.error(f"Error in Gemini get_response: {e}")
            raise
    
    async def achat_stream(
        self,
        messages: List[ModelMessage],
        **kwargs,
    ) -> AsyncIterator[ModelResponse]:
        """Async streaming chat completion.
        
        Args:
            messages: List of conversation messages.
            **kwargs: Additional Gemini-specific parameters.
            
        Yields:
            ModelResponse chunks.
        """
        try:
            params = self._build_request_params(messages, **kwargs)
            params["stream"] = True
            
            stream = await self.async_client.chat.completions.create(**params)
            
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield ModelResponse(
                        content=chunk.choices[0].delta.content,
                        role="assistant",
                        model=chunk.model,
                    )
        except Exception as e:
            logger.error(f"Error in async Gemini streaming chat: {e}")
            raise


def parse_provider_model(spec: str) -> tuple[str, str]:
    """Parse 'provider/model' format.

    Args:
        spec: Model specification string

    Returns:
        Tuple of (provider, model_id)

    Examples:
        >>> parse_provider_model('groq/whisper-large-v3-turbo')
        ('groq', 'whisper-large-v3-turbo')
        >>> parse_provider_model('openai/gpt-4o-mini')
        ('openai', 'gpt-4o-mini')
        >>> parse_provider_model('gpt-4o-mini')
        ('openai', 'gpt-4o-mini')
    """
    if "/" in spec:
        provider, model = spec.split("/", 1)
        return provider, model
    return "openai", spec  # Default to OpenAI
