"""Server utilities for Contextwise v0.3.0.

This module provides utilities for creating FastAPI servers for agents,
compatible with both OpenAI API format and v0.1.0 contextwise format.

Features:
    - OpenAI-compatible chat endpoints (/chat, /v1/chat/completions)
    - Simple API endpoints (/api/chat, /api/info, /api/session/create)
    - v0.1.0-compatible endpoints (create_v1_app)
    - Structured error handling via apiexception
    - ResponseModel envelopes for /api/* endpoints
    - DEBUG logging flag for development/debugging
"""

from __future__ import annotations

import os
import time
import uuid
import logging
import json
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Optional, List, Dict, Any, AsyncGenerator, Callable

from fastapi import FastAPI, APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

# Observability integration
#try:
#    from .lib.observability import OpikConfig, initialize_opik#
#    OPIK_AVAILABLE = True
#except ImportError:
#    OPIK_AVAILABLE = False
#    OpikConfig = None
#    initialize_opik = None

# APIException integration
try:
    from apiexception import (
        APIException,
        ResponseModel,
        ResponseFormat,
        register_exception_handlers,
    )
    from .errors import ContextwiseExceptionCode, DEFAULT_ISE_CODE
    APIEXCEPTION_AVAILABLE = True
except ImportError:
    try:
        from api_exception import (
            APIException,
            ResponseModel,
            ResponseFormat,
            register_exception_handlers,
        )
        from .errors import ContextwiseExceptionCode, DEFAULT_ISE_CODE
        APIEXCEPTION_AVAILABLE = True
    except ImportError:
        APIEXCEPTION_AVAILABLE = False
        APIException = None
        ResponseModel = None
        ResponseFormat = None
        register_exception_handlers = None
        ContextwiseExceptionCode = None
        DEFAULT_ISE_CODE = None

if TYPE_CHECKING:
    from .agent import Agent

logger = logging.getLogger(__name__)


# =========================
# DEBUG Flag Configuration
# =========================

def get_debug_flag(debug: Optional[bool] = None) -> bool:
    """Resolve the effective DEBUG flag value.
    
    Resolution order (highest to lowest precedence):
    1. Explicit debug argument
    2. CONTEXTWISE_DEBUG environment variable
    3. DEBUG environment variable
    4. Default: False
    
    Args:
        debug: Explicit debug flag (optional)
        
    Returns:
        True if debug mode should be enabled, False otherwise
    """
    # Explicit argument takes highest precedence
    if debug is not None:
        return debug
    
    # Check CONTEXTWISE_DEBUG environment variable
    contextwise_debug = os.environ.get('CONTEXTWISE_DEBUG', '').lower()
    if contextwise_debug in ('1', 'true', 'yes', 'on'):
        return True
    if contextwise_debug in ('0', 'false', 'no', 'off'):
        return False
    
    # Check DEBUG environment variable
    debug_env = os.environ.get('DEBUG', '').lower()
    if debug_env in ('1', 'true', 'yes', 'on'):
        return True
    
    return False


def configure_logging(agent: "Agent", debug: bool) -> None:
    """Configure logging for the contextwise server.
    
    Args:
        agent: Agent instance (for context in log messages)
        debug: If True, sets DEBUG level; otherwise INFO level
    """
    # Configure contextwise logger
    contextwise_logger = logging.getLogger('contextwise')
    level = logging.DEBUG if debug else logging.INFO
    contextwise_logger.setLevel(level)
    
    # Prevent propagation to root logger to avoid duplicate log entries
    # when basicConfig is called elsewhere (e.g., in example scripts)
    contextwise_logger.propagate = False
    
    # Only add handler if not already configured
    if not contextwise_logger.handlers:
        handler = logging.StreamHandler()
        handler.setLevel(level)
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        contextwise_logger.addHandler(handler)
    else:
        # Update existing handlers' levels
        for handler in contextwise_logger.handlers:
            handler.setLevel(level)
    
    if debug:
        logger.info(f"DEBUG logging enabled for agent: {agent.name}")


# =========================
# Sensitive Field Redaction
# =========================

# Fields to redact from request/response bodies
SENSITIVE_FIELDS = frozenset([
    'api_key', 'apikey', 'api-key',
    'authorization', 'auth_token', 'authtoken',
    'password', 'secret', 'token', 'access_token',
    'refresh_token', 'private_key', 'secret_key',
])

# Headers to never log
SENSITIVE_HEADERS = frozenset([
    'authorization', 'x-api-key', 'api-key',
    'cookie', 'set-cookie', 'x-auth-token',
])

# Headers safe to log
SAFE_HEADERS = frozenset([
    'x-request-id', 'user-agent', 'content-type',
    'accept', 'x-correlation-id', 'x-trace-id',
])


def sanitize_value(value: Any, max_length: int = 200) -> Any:
    """Sanitize a value for logging.
    
    Truncates long strings and redacts obvious secrets.
    """
    if value is None:
        return None
    if isinstance(value, str):
        if len(value) > max_length:
            return value[:max_length] + '...[truncated]'
        return value
    if isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, (list, tuple)):
        return [sanitize_value(v, max_length) for v in value[:10]]  # Limit array items
    if isinstance(value, dict):
        return sanitize_dict(value, max_length)
    return str(value)[:max_length]


def sanitize_dict(data: Dict[str, Any], max_length: int = 200) -> Dict[str, Any]:
    """Recursively sanitize a dictionary for logging."""
    result = {}
    for key, value in data.items():
        lower_key = key.lower()
        if lower_key in SENSITIVE_FIELDS:
            result[key] = '[REDACTED]'
        elif isinstance(value, dict):
            result[key] = sanitize_dict(value, max_length)
        else:
            result[key] = sanitize_value(value, max_length)
    return result


def create_debug_middleware(agent: "Agent") -> Callable:
    """Create HTTP debug middleware for logging request/response details.
    
    Args:
        agent: Agent instance for context
        
    Returns:
        FastAPI middleware function
    """
    async def debug_middleware(request: Request, call_next: Callable) -> Any:
        """Log HTTP request/response details when DEBUG is enabled."""
        start_time = time.time()
        request_id = request.headers.get('x-request-id', str(uuid.uuid4())[:8])
        
        # Log request IN
        method = request.method
        path = request.url.path
        query_string = str(request.url.query) if request.url.query else ''
        
        # Extract safe headers
        safe_headers = {
            k: v for k, v in request.headers.items()
            if k.lower() in SAFE_HEADERS
        }
        
        # Try to read and log request body (for non-binary requests)
        # Skip body reading for streaming endpoints to avoid conflicts with SSE
        body_preview = None
        content_type = request.headers.get('content-type', '')
        is_streaming_endpoint = path.startswith('/agui') or 'text/event-stream' in request.headers.get('accept', '')
        
        if 'application/json' in content_type and method in ('POST', 'PUT', 'PATCH') and not is_streaming_endpoint:
            try:
                body_bytes = await request.body()
                if body_bytes:
                    body_data = json.loads(body_bytes)
                    body_preview = sanitize_dict(body_data)
                # Reset body for downstream handlers
                async def receive():
                    return {"type": "http.request", "body": body_bytes}
                request._receive = receive
            except Exception:
                body_preview = '[Unable to parse body]'
        
        logger.debug(
            f"[{request_id}] ▶ {method} {path}"
            f"{f'?{query_string}' if query_string else ''} "
            f"headers={safe_headers} "
            f"body={json.dumps(body_preview) if body_preview else '[no body]'}"
        )
        
        # Call the actual endpoint
        response = await call_next(request)
        
        # Calculate elapsed time
        elapsed_ms = (time.time() - start_time) * 1000
        
        # Log response OUT
        status_code = response.status_code
        
        # Try to capture response body for logging (only for JSON responses)
        response_preview = None
        response_content_type = response.headers.get('content-type', '')
        
        # Note: Reading streaming response body is complex; skip for streams
        if 'application/json' in response_content_type and hasattr(response, 'body'):
            try:
                # For standard responses, try to get body
                if hasattr(response, 'body'):
                    response_body = response.body
                    if isinstance(response_body, bytes):
                        response_data = json.loads(response_body)
                        response_preview = sanitize_dict(response_data)
            except Exception:
                response_preview = '[Unable to parse response]'
        
        logger.debug(
            f"[{request_id}] ◀ {status_code} ({elapsed_ms:.1f}ms) "
            f"{f'body={json.dumps(response_preview)}' if response_preview else ''}"
        )
        
        return response
    
    return debug_middleware


# =========================
# v0.1.0 Compatible Models
# =========================

class V1ChatRequest(BaseModel):
    """v0.1.0 compatible chat request."""
    conversation_id: Optional[str] = None
    message: str


class MessageResponse(BaseModel):
    """Message response from agent."""
    content: str
    agent: str


class AgentEvent(BaseModel):
    """Agent event during processing."""
    id: str
    type: str  # message, handoff, tool_call, tool_output, context_update
    agent: str
    content: str
    metadata: Optional[Dict[str, Any]] = None
    timestamp: Optional[float] = None


class V1ChatResponse(BaseModel):
    """v0.1.0 compatible chat response."""
    conversation_id: str
    current_agent: str
    messages: List[MessageResponse]
    events: List[AgentEvent]
    context: Dict[str, Any]
    agents: List[Dict[str, Any]]


# =========================
# Agent Registry
# =========================

agent_registry: Dict[str, "Agent"] = {}
default_agent_name = "default"


def register_agent(name: str, agent: "Agent") -> None:
    """Register an agent with the global registry.
    
    Args:
        name: Agent name for registry
        agent: Agent instance
    """
    agent_registry[name] = agent
    logger.info(f"Registered agent: {name}")


def get_agent(name: str) -> "Agent":
    """Get an agent by name from registry.
    
    Args:
        name: Agent name
        
    Returns:
        Agent instance
        
    Raises:
        ValueError: If no agents registered
    """
    if name in agent_registry:
        return agent_registry[name]
    
    default_agent = agent_registry.get(default_agent_name)
    if default_agent is not None:
        return default_agent
    
    if agent_registry:
        return next(iter(agent_registry.values()))
    
    raise ValueError("No agents registered in agent_registry")


# =========================
# OpenAI-Compatible Models
# =========================

class ChatMessage(BaseModel):
    """OpenAI-compatible chat message."""
    role: str
    content: str
    name: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None


class ChatCompletionRequest(BaseModel):
    """OpenAI-compatible chat completion request."""
    model: Optional[str] = None
    messages: List[ChatMessage]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    stream: Optional[bool] = False
    user: Optional[str] = None
    
    # Extended fields for contextwise
    conversation_id: Optional[str] = None


class ChatCompletionChoice(BaseModel):
    """OpenAI-compatible chat completion choice."""
    index: int
    message: ChatMessage
    finish_reason: str = "stop"


class Usage(BaseModel):
    """Token usage stats."""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatCompletionResponse(BaseModel):
    """OpenAI-compatible chat completion response."""
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatCompletionChoice]
    usage: Usage = Field(default_factory=Usage)
    
    # Extended fields for contextwise
    conversation_id: Optional[str] = None


# =========================
# Conversation Store
# =========================

class ConversationStore:
    """In-memory conversation state store."""
    _conversations: Dict[str, Dict[str, Any]] = {}

    def get(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        return self._conversations.get(conversation_id)

    def save(self, conversation_id: str, state: Dict[str, Any]):
        self._conversations[conversation_id] = state

    def delete(self, conversation_id: str) -> None:
        self._conversations.pop(conversation_id, None)

    def list_all(self) -> Dict[str, Dict[str, Any]]:
        return dict(self._conversations)


# Global conversation store
conversation_store = ConversationStore()

# Chat history service (initialized if CHAT_HISTORY_DB_URL is set)
chat_history_service: Optional[Any] = None


def initialize_chat_history(db_url: Optional[str] = None) -> bool:
    """Initialize chat history service with persistent storage.
    
    Args:
        db_url: PostgreSQL connection URL (defaults to CHAT_HISTORY_DB_URL env var)
        
    Returns:
        True if successfully initialized
    """
    global chat_history_service
    
    if chat_history_service is not None:
        return True
    
    db_url = db_url or os.environ.get("CHAT_HISTORY_DB_URL")
    if not db_url:
        logger.debug("CHAT_HISTORY_DB_URL not set, chat history persistence disabled")
        return False
    
    try:
        from .lib.storage import ChatHistoryStorage
        from .lib.session import ChatHistoryService
        
        logger.info(f"Initializing chat history storage with URL: {db_url[:30]}...")
        storage = ChatHistoryStorage(db_url=db_url)
        storage.create()
        logger.debug("Chat history storage table created")
        storage.upgrade_schema()
        logger.debug("Chat history schema upgraded")
        chat_history_service = ChatHistoryService(storage)
        logger.info("Chat history service initialized successfully")
        return True
    except ImportError as e:
        logger.error(f"Failed to import chat history dependencies: {e}")
        return False
    except Exception as e:
        logger.error(f"Failed to initialize chat history service: {e}", exc_info=True)
        return False


async def _register_mcp_tools_with_codemode(codemode_plugin: Any, mcp_servers: List[Any]) -> None:
    """Register MCP tools with CodeModeProxy after servers are connected.
    
    This function is called during server startup after MCP servers have connected
    and fetched their tools. It registers each tool with the CodeModeProxy so that
    sandboxed Python code can call MCP tools via _call_tool.
    
    Args:
        codemode_plugin: The CodeModePlugin instance from the agent
        mcp_servers: List of connected MCPServer instances with populated _tools
    """
    total_tools = 0
    
    for mcp_server in mcp_servers:
        # Get the populated _tools dict from the MCPServer
        tools = getattr(mcp_server, '_tools', {})
        
        for name, tool in tools.items():
            # Create an async callable that invokes the MCP tool via the server
            async def make_tool_caller(server, tool_name):
                async def call_mcp_tool(**kwargs) -> str:
                    """Call the MCP tool via the server."""
                    return await server.call_tool(tool_name, kwargs)
                return call_mcp_tool
            
            # Register with CodeModeProxy
            codemode_plugin.proxy.register_mcp_tool(
                name=name,
                description=tool.description if hasattr(tool, 'description') else "",
                input_schema=tool.input_schema if hasattr(tool, 'input_schema') else {},
                call_fn=await make_tool_caller(mcp_server, name),
            )
            total_tools += 1
            logger.debug(f"Registered MCP tool '{name}' with CodeModeProxy")
    
    if total_tools > 0:
        logger.info(f"Registered {total_tools} MCP tools with CodeModeProxy for sandbox access")


def serve(
    agent: "Agent",
    port: int = 8000,
    host: str = "0.0.0.0",
    enable_agui: Optional[bool] = False,
    debug: Optional[bool] = None,
    spawn_livekit_worker: Optional[bool] = None,
) -> None:
    """Start server for an agent.

    Auto-mounts webhook routers for configured channels.
    When voice=VoiceConfig is active and LiveKit is configured, automatically
    spawns a LiveKit worker process to handle voice sessions.

    Args:
        agent: Agent instance to serve
        port: Server port (default: 8000)
        host: Host address (default: 0.0.0.0)
        enable_agui: Enable AG-UI protocol endpoints at /agui (default: False)
        debug: Enable DEBUG logging mode (default: uses env vars or False)
            When enabled:
            - Sets logging level to DEBUG for contextwise namespace
            - Logs HTTP request/response details (sanitized)
            - Enables detailed exception tracebacks
            - Attaches DebugLoggingPlugin to agent (if available)
        spawn_livekit_worker: Whether to spawn LiveKit worker when voice is configured.
            Default: True if voice config is present and LiveKit credentials are set.
            Set to False to disable automatic worker spawning (e.g., if running worker separately).

    Example:
        >>> from contextwise import Agent
        >>> agent = Agent("gpt-4o-mini", "You are helpful")
        >>> agent.serve(port=8000)

        # With AG-UI enabled
        >>> agent.serve(port=8000, enable_agui=True)
        
        # With DEBUG enabled
        >>> agent.serve(port=8000, debug=True)
        
        # With voice (auto-spawns LiveKit worker)
        >>> from contextwise.voice import VoiceConfig
        >>> agent = Agent("gpt-4o-mini", "Hello", voice=VoiceConfig())
        >>> agent.serve(port=8000)  # LiveKit worker starts automatically!
        
        # Disable auto worker spawn (running worker separately)
        >>> agent.serve(port=8000, spawn_livekit_worker=False)
        
        # Or via environment variable:
        # CONTEXTWISE_DEBUG=1 python my_agent.py
    """
    effective_debug = get_debug_flag(debug)
    app = create_app(agent, enable_agui=enable_agui, debug=effective_debug)
    
    # Spawn LiveKit worker if voice is configured
    worker_process = None
    if agent.voice is not None:
        # Determine if we should spawn worker
        should_spawn = spawn_livekit_worker
        if should_spawn is None:
            # Auto-detect: spawn if LiveKit is configured
            livekit_url = os.environ.get("LIVEKIT_URL", "")
            should_spawn = bool(livekit_url)
        
        if should_spawn:
            try:
                from .livekit_worker import spawn_worker_process, voice_config_to_dict
                
                voice_dict = voice_config_to_dict(agent.voice)
                
                # Merge VoiceConfig.instructions with VOICE.md content from workspace
                # get_combined_instructions() handles frontmatter stripping and graceful fallback
                if hasattr(agent.voice, 'get_combined_instructions'):
                    instructions = agent.voice.get_combined_instructions(
                        workspace=agent.workspace
                    )
                else:
                    instructions = getattr(agent.voice, "instructions", None) or ""
                
                # Fall back to agent.instructions if no voice-specific instructions
                if not instructions:
                    instructions = agent.instructions
                
                worker_process = spawn_worker_process(
                    voice_config=voice_dict,
                    instructions=instructions,
                )
                
                if worker_process:
                    logger.info(
                        f"LiveKit worker spawned (PID: {worker_process.pid}). "
                        "Voice sessions will be processed automatically."
                    )
                else:
                    logger.warning(
                        "LiveKit worker not spawned - check LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET"
                    )
            except ImportError as e:
                logger.warning(f"LiveKit worker not available: {e}")
            except Exception as e:
                logger.error(f"Failed to spawn LiveKit worker: {e}")
    
    # Configure uvicorn log level based on debug
    log_level = "debug" if effective_debug else "info"
    
    # Setup cleanup function for worker subprocess
    def cleanup_worker():
        if worker_process is None:
            return
        # For subprocess.Popen, check poll() instead of is_alive()
        if worker_process.poll() is None:  # None means still running
            logger.info("Shutting down LiveKit worker...")
            worker_process.terminate()
            try:
                worker_process.wait(timeout=5)
            except Exception:
                logger.warning("Worker didn't terminate gracefully, killing...")
                worker_process.kill()
            logger.info("LiveKit worker stopped.")
    
    # Register signal handlers to cleanup worker on exit
    import signal
    import atexit
    
    atexit.register(cleanup_worker)
    
    def signal_handler(signum, frame):
        cleanup_worker()
        # Re-raise to allow default handling
        signal.signal(signum, signal.SIG_DFL)
        os.kill(os.getpid(), signum)
    
    if worker_process:
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        uvicorn.run(app, host=host, port=port, log_level=log_level)
    finally:
        cleanup_worker()


def create_app(
    agent: "Agent", 
    enable_agui: Optional[bool] = False,
    debug: Optional[bool] = None,
) -> FastAPI:
    """Create FastAPI app for an agent.

    Args:
        agent: Agent instance
        enable_agui: Enable AG-UI protocol endpoints (optional)
        debug: Enable DEBUG logging mode (optional, resolves from env if None)

    Returns:
        FastAPI application

    Example:
        >>> from contextwise import Agent
        >>> agent = Agent("gpt-4o-mini", "You are helpful")
        >>> app = create_app(agent)
        
        # With debug enabled
        >>> app = create_app(agent, debug=True)
    """
    # Resolve effective debug flag
    effective_debug = get_debug_flag(debug)
    
    # Configure logging based on debug flag
    configure_logging(agent, effective_debug)
    
    # Initialize chat history service if configured
    chat_history_db_url = getattr(agent, 'chat_history_db_url', None)
    if chat_history_db_url:
        initialize_chat_history(chat_history_db_url)
    else:
        # Try to initialize from environment variable
        initialize_chat_history()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        """Manage MCP server lifecycle and observability.
        
        Connects MCP servers on startup and disconnects on shutdown.
        This ensures proper async context management for stdio-based MCP servers.
        Also fetches MCP tools and registers them with CodeModeProxy if enabled.
        Initializes Opik observability if available and configured.
        """
        # Initialize Opik observability on startup
        """
        if OPIK_AVAILABLE and initialize_opik:
            # Check if agent has OpikObservabilityPlugin configured
            opik_config = None
            for plugin in getattr(agent, 'plugins', []) or []:
                if hasattr(plugin, 'config') and isinstance(getattr(plugin, 'config', None), OpikConfig):
                    opik_config = plugin.config
                    break
            
            # Initialize with found config or defaults (respecting env vars)
            if opik_config is None:
                opik_config = OpikConfig()
            
            if opik_config.enabled:
                initialized = initialize_opik(opik_config)
                if initialized:
                    logger.info(f"Opik observability initialized (project={opik_config.project_name})")
                else:
                    logger.debug("Opik observability not initialized (disabled or unavailable)")
        """
        
        # Connect MCP servers on startup
        mcp_servers = getattr(agent, 'mcp', []) or []
        sdk_servers = []
        
        for mcp_server in mcp_servers:
            sdk_server = mcp_server.get_sdk_server()
            if sdk_server:
                try:
                    await sdk_server.connect()
                    sdk_servers.append(sdk_server)
                    logger.info(f"Connected MCP server: {mcp_server.name}")
                    
                    # Fetch tools from the connected SDK server
                    # This populates mcp_server._tools with MCPTool instances
                    await mcp_server.fetch_tools_from_sdk()
                    
                except Exception as e:
                    logger.error(f"Failed to connect MCP server {mcp_server.name}: {e}")
        
        # Register MCP tools with CodeModeCorePlugin after all servers are connected
        # This enables sandboxed Python code to call MCP tools via the plugin's registry
        codemode_plugin = getattr(agent, '_codemode_plugin', None)
        if codemode_plugin and mcp_servers:
            # Use the new plugin-based registration method
            if hasattr(codemode_plugin, 'register_mcp_servers'):
                await codemode_plugin.register_mcp_servers(mcp_servers)
            else:
                # Fallback for legacy CodeModePlugin
                await _register_mcp_tools_with_codemode(codemode_plugin, mcp_servers)
        
        yield  # Application runs here
        
        # Cleanup MCP servers on shutdown
        for sdk_server in sdk_servers:
            try:
                await sdk_server.cleanup()
                logger.info(f"Disconnected MCP server: {sdk_server.name}")
            except Exception as e:
                logger.warning(f"Error disconnecting MCP server: {e}")
    
    app = FastAPI(
        title=f"{agent.name} API",
        description=agent.description or f"API for {agent.name}",
        version="0.2.0",
        lifespan=lifespan,
    )

    # Register APIException handlers for structured error responses
    # Configure logging options based on debug flag
    if APIEXCEPTION_AVAILABLE and register_exception_handlers:
        if effective_debug:
            # Debug mode: verbose logging with tracebacks
            register_exception_handlers(
                app,
                response_format=ResponseFormat.RESPONSE_MODEL,
                use_fallback_middleware=True,
                log=True,
                log_level="DEBUG",
                log_traceback=True,
                log_traceback_unhandled_exception=True,
                log_request_context=True,
                log_header_keys=["x-request-id", "user-agent", "content-type"],
                extra_log_fields={
                    "agent_name": agent.name,
                    "debug": True,
                },
            )
        else:
            # Production mode: minimal logging
            register_exception_handlers(
                app,
                response_format=ResponseFormat.RESPONSE_MODEL,
                use_fallback_middleware=True,
                log=True,
                log_level="ERROR",
                log_traceback=False,
                log_traceback_unhandled_exception=True,
                extra_log_fields={
                    "agent_name": agent.name,
                },
            )
        logger.info("APIException handlers registered")
    
    # Register debug middleware if debug mode is enabled
    if effective_debug:
        debug_middleware = create_debug_middleware(agent)
        app.middleware("http")(debug_middleware)
        logger.info("Debug HTTP middleware registered")
        
        # Attach DebugLoggingPlugin to agent if not already present
        try:
            from .lib.debug_plugin import DebugLoggingPlugin
            
            # Check if plugin already exists
            has_debug_plugin = any(
                getattr(p, 'id', None) == 'debug_logging'
                for p in getattr(agent, 'plugins', [])
            )
            
            if not has_debug_plugin:
                debug_plugin = DebugLoggingPlugin()
                if hasattr(agent, 'plugins') and agent.plugins is not None:
                    agent.plugins.append(debug_plugin)
                    logger.info("DebugLoggingPlugin attached to agent")
        except ImportError:
            logger.debug("DebugLoggingPlugin not available, skipping")

    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # In production, restrict to specific origins
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Install plugin-provided middleware (e.g., burst shield, rate limiting)
    # This allows plugins to contribute server-level middleware
    for plugin in getattr(agent, 'plugins', []) or []:
        if hasattr(plugin, 'get_fastapi_middleware'):
            try:
                middleware_factories = plugin.get_fastapi_middleware()
                for middleware_factory in middleware_factories:
                    middleware_instance = middleware_factory(app)
                    app.add_middleware(type(middleware_instance))
                    logger.info(f"Installed middleware from plugin: {getattr(plugin, 'id', 'unknown')}")
            except Exception as e:
                logger.warning(f"Failed to install middleware from plugin {getattr(plugin, 'id', 'unknown')}: {e}")

    # Include agent router (includes /api endpoints and /chat, /v1/chat/completions)
    router = create_router(agent)
    app.include_router(router)

    # Mount channel routers
    for channel in agent.channels:
        # Configure channel with agent reference (needed for message handlers)
        if hasattr(channel, 'configure_agent'):
            channel.configure_agent(agent)
        
        if hasattr(channel, 'create_webhook_router'):
            webhook_router = channel.create_webhook_router()
            if webhook_router:
                # Mount with channel-specific prefix
                prefix = f"/{channel.channel_id}" if hasattr(channel, 'channel_id') else ""
                app.include_router(webhook_router, prefix=prefix)

    # Health check endpoint
    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        return {"status": "healthy", "agent": agent.name}

    if not enable_agui:
        @app.get("/status")
        async def status_check():
            return {
                "status": "running",
                "agent": agent.name,
                "version": "0.2.0",
                "features": {
                    "agui": False,
                    "streaming": True,
                },
            }

    # Mount AG-UI router if enabled
    if enable_agui:
        try:
            from .lib.agui import create_agui_router, create_agui_status_endpoint
            
            # Create AG-UI router without internal /status (we mount it at root level)
            agui_router = create_agui_router(agent, include_status=True)
            app.include_router(agui_router, prefix="/agui")
            
            # Mount standardized /status endpoint at root level for AG-UI detection
            # This allows clients to probe /status instead of /agui/status
            status_handler = create_agui_status_endpoint(agent)
            app.add_api_route("/status", status_handler, methods=["GET"], tags=["Status"])
            
            logger.info("AG-UI router mounted at /agui")
            logger.info("AG-UI status endpoint mounted at /status")
        except ImportError:
            logger.warning("AG-UI module not available, skipping")

    # Mount Acontext router if plugin is configured
    acontext_plugin = None
    for plugin in getattr(agent, 'plugins', []):
        if hasattr(plugin, 'id') and plugin.id == 'acontext':
            acontext_plugin = plugin
            break
    
    if acontext_plugin:
        try:
            from .lib.acontext import create_acontext_router
            acontext_router = create_acontext_router(acontext_plugin)
            app.include_router(acontext_router, prefix="/api/acontext")
            logger.info("Acontext router mounted at /api/acontext")
        except ImportError:
            logger.warning("Acontext router not available")

    # Install plugin-provided routers (e.g., document uploads, custom endpoints)
    # This allows plugins to contribute API endpoints
    for plugin in getattr(agent, 'plugins', []) or []:
        if hasattr(plugin, 'get_fastapi_routers'):
            try:
                routers = plugin.get_fastapi_routers()
                for plugin_router in routers:
                    # Mount plugin router (prefix is already set in router)
                    app.include_router(plugin_router)
                    logger.info(f"Installed router from plugin: {getattr(plugin, 'id', 'unknown')}")
            except Exception as e:
                logger.warning(f"Failed to install router from plugin {getattr(plugin, 'id', 'unknown')}: {e}")

    return app


def create_router(agent: "Agent") -> APIRouter:
    """Create FastAPI router for an agent.

    Args:
        agent: Agent instance

    Returns:
        FastAPI APIRouter with agent endpoints

    Example:
        >>> from contextwise import Agent
        >>> agent = Agent("gpt-4o-mini", "You are helpful")
        >>> router = create_router(agent)
    """
    router = APIRouter(tags=["agent"])

    # =========================
    # OpenAI-Compatible Endpoints (at root level)
    # =========================

    @router.post("/chat", response_model=ChatCompletionResponse)
    async def chat_completions_simple(req: ChatCompletionRequest):
        """OpenAI-compatible chat completions endpoint.

        This is the main endpoint for chat interactions, compatible with
        OpenAI's chat completion API format.

        Request body:
            {
                "messages": [{"role": "user", "content": "Hello"}],
                "model": "gpt-4o-mini",  # Optional, uses agent's model
                "user": "user_id",  # Optional
                "conversation_id": "conv_id"  # Optional, for stateful conversations
            }

        Response (OpenAI format):
            {
                "id": "chatcmpl-...",
                "object": "chat.completion",
                "created": 1234567890,
                "model": "gpt-4o-mini",
                "choices": [{
                    "index": 0,
                    "message": {"role": "assistant", "content": "..."},
                    "finish_reason": "stop"
                }],
                "usage": {...}
            }
        """
        return await _process_chat_request(agent, req)

    @router.post("/v1/chat/completions", response_model=ChatCompletionResponse)
    async def chat_completions_v1(req: ChatCompletionRequest):
        """OpenAI v1 API compatible chat completions endpoint.

        Identical to /chat but at the standard OpenAI API path.
        """
        return await _process_chat_request(agent, req)

    # =========================
    # Streaming Chat Endpoint (SSE)
    # =========================

    @router.post("/chat/stream")
    async def chat_stream_endpoint(req: ChatCompletionRequest):
        """SSE streaming chat endpoint for real-time token streaming.

        This endpoint provides true streaming using Server-Sent Events (SSE),
        yielding tokens as they are generated by the agent.

        Request body:
            {
                "messages": [{"role": "user", "content": "Hello"}],
                "model": "gpt-4o-mini",  # Optional
                "conversation_id": "conv_id"  # Optional
            }

        Response (SSE stream):
            data: {"choices": [{"delta": {"content": "Hello"}, "index": 0}]}
            data: {"choices": [{"delta": {"content": " world"}, "index": 0}]}
            data: [DONE]
        """
        return await _process_streaming_chat_request(agent, req)

    @router.options("/chat/stream")
    async def chat_stream_options():
        """OPTIONS handler for /chat/stream endpoint (CORS preflight)."""
        return JSONResponse(
            content={"status": "ok"},
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Accept",
            }
        )

    # =========================
    # Simple API Endpoints (under /api prefix)
    # =========================

    @router.post("/api/chat")
    async def api_chat_endpoint(request: Request):
        """Simple chat endpoint for sending messages to the agent.

        Request body:
            {
                "message": "User message",
                "user_id": "optional_user_id",
                "channel": "api"
            }

        Response (with apiexception):
            {
                "data": {"response": "...", "user_id": "..."},
                "status": "SUCCESS",
                "message": "OK"
            }

        Response (without apiexception):
            {
                "response": "Agent response",
                "user_id": "user_id"
            }
        """
        try:
            data = await request.json()
            message = data.get("message", "")
            user_id = data.get("user_id")
            channel = data.get("channel", "api")
            session_id = data.get("session_id")

            if not message:
                if APIEXCEPTION_AVAILABLE and APIException and ContextwiseExceptionCode:
                    raise APIException(error_code=ContextwiseExceptionCode.MISSING_MESSAGE)
                return JSONResponse(
                    status_code=400,
                    content={"error": "Message is required"}
                )

            # Call agent
            response = await agent.chat_async(
                message=message,
                user_id=user_id,
                channel=channel,
                session_id=session_id,
            )

            result = {
                "response": response,
                "user_id": user_id or agent.user_id or "default",
            }

            # Return ResponseModel envelope if apiexception available
            if APIEXCEPTION_AVAILABLE and ResponseModel:
                return ResponseModel(data=result).model_dump()
            return result

        except Exception as e:
            if APIEXCEPTION_AVAILABLE and isinstance(e, APIException):
                raise  # Let APIException handler deal with it
            logger.exception("Error in /api/chat endpoint")
            if APIEXCEPTION_AVAILABLE and APIException and ContextwiseExceptionCode:
                raise APIException(
                    error_code=ContextwiseExceptionCode.AGENT_EXECUTION_ERROR,
                    message=str(e),
                )
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    @router.get("/api/info")
    async def info_endpoint():
        """Get agent information.

        Response:
            {
                "name": "Agent name",
                "description": "Agent description",
                "model": "model_id",
                "channels": ["api", "whatsapp"],
                "features": {
                    "voice": true/false,
                    "memory": true/false,
                    "mcp": true/false
                }
            }
        """
        return {
            "name": agent.name,
            "description": agent.description,
            "model": agent._resolve_model_id() if hasattr(agent, '_resolve_model_id') else str(agent.model),
            "channels": [
                ch.channel_id if hasattr(ch, 'channel_id') else str(ch)
                for ch in agent.channels
            ],
            "features": {
                "voice": agent.voice is not None,
                "memory": agent.memory is not None,
                "mcp": len(agent.mcp) > 0 if agent.mcp else False,
                "knowledge": agent.knowledge is not None,
                "storage": agent.storage is not None,
            }
        }

    @router.post("/api/session/create")
    async def create_session_endpoint(request: Request):
        """Create a new session for a user.

        Request body:
            {
                "user_id": "user_id",
                "session_id": "optional_session_id"
            }

        Response (with apiexception):
            {
                "data": {"user_id": "...", "session_id": "...", "created": true},
                "status": "SUCCESS",
                "message": "OK"
            }
        """
        try:
            data = await request.json()
            user_id = data.get("user_id")

            if not user_id:
                if APIEXCEPTION_AVAILABLE and APIException and ContextwiseExceptionCode:
                    raise APIException(error_code=ContextwiseExceptionCode.MISSING_USER_ID)
                return JSONResponse(
                    status_code=400,
                    content={"error": "user_id is required"}
                )

            session_id = data.get("session_id")

            # Get or create session
            session = agent._get_session(user_id) if hasattr(agent, '_get_session') else None

            result = {
                "user_id": user_id,
                "session_id": session_id or agent.session_id or f"{user_id}_session",
                "created": session is not None,
            }

            if APIEXCEPTION_AVAILABLE and ResponseModel:
                return ResponseModel(data=result).model_dump()
            return result

        except Exception as e:
            if APIEXCEPTION_AVAILABLE and isinstance(e, APIException):
                raise
            logger.exception("Error in /api/session/create endpoint")
            if APIEXCEPTION_AVAILABLE and APIException and ContextwiseExceptionCode:
                raise APIException(
                    error_code=ContextwiseExceptionCode.SESSION_CREATE_ERROR,
                    message=str(e),
                )
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    # =========================
    # Agent listing endpoints (v1 API)
    # =========================

    @router.get("/v1/agents")
    async def list_agents():
        """List all available agents."""
        return [{
            "id": agent.name.lower().replace(" ", "-"),
            "name": agent.name,
            "description": agent.description,
            "model": agent._resolve_model_id() if hasattr(agent, '_resolve_model_id') else str(agent.model),
        }]

    @router.get("/v1/agents/{agent_id}/sessions")
    async def list_agent_sessions(agent_id: str):
        """List sessions for an agent."""
        sessions = []
        all_conversations = conversation_store.list_all()
        for conv_id, state in all_conversations.items():
            created_at = state.get("created_at", int(time.time()))
            history = state.get("history", [])
            title = ""
            if history:
                first_run = history[0]
                message = first_run.get("message", {})
                title = str(message.get("content", ""))[:50]
            if not title:
                title = f"Session {conv_id[:8]}"
            sessions.append({
                "session_id": conv_id,
                "title": title,
                "created_at": created_at,
            })
        return sessions

    # =========================
    # Chat History Endpoints (v1 API)
    # =========================

    @router.post("/v1/chat/sessions")
    async def create_chat_session(request: Request):
        """Create a new chat session with persistent storage.
        
        Request body:
            {
                "user_id": "user123",
                "agent_id": "agent456",  // optional
                "session_id": "custom-id",  // optional
                "provider_type": "openai"  // optional, default: openai
            }
        
        Response:
            {
                "session_id": "uuid",
                "user_id": "user123",
                "created_at": 1234567890,
                "status": "active"
            }
        """
        if not chat_history_service:
            return JSONResponse(
                status_code=503,
                content={"error": "Chat history service not available"}
            )
        
        try:
            data = await request.json()
            user_id = data.get("user_id")
            
            if not user_id:
                return JSONResponse(
                    status_code=400,
                    content={"error": "user_id is required"}
                )
            
            session_id = await chat_history_service.create_session(
                user_id=user_id,
                agent_id=data.get("agent_id") or agent.name,
                session_id=data.get("session_id"),
                provider_type=data.get("provider_type", "openai"),
            )
            
            return {
                "session_id": session_id,
                "user_id": user_id,
                "created_at": int(time.time()),
                "status": "active"
            }
            
        except Exception as e:
            logger.exception("Error creating chat session")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    @router.get("/v1/chat/sessions")
    async def list_chat_sessions(
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        status: Optional[str] = "active",
        limit: int = 50,
        offset: int = 0,
    ):
        """List chat sessions with filtering and pagination.
        
        Query params:
            user_id: Filter by user
            agent_id: Filter by agent
            status: Filter by status (active, archived, deleted)
            limit: Max results (default: 50)
            offset: Skip N results (default: 0)
        """
        if not chat_history_service:
            # Fallback to in-memory store
            sessions = []
            all_conversations = conversation_store.list_all()
            for conv_id, state in all_conversations.items():
                sessions.append({
                    "session_id": conv_id,
                    "user_id": "unknown",
                    "agent_id": agent.name,
                    "status": "active",
                    "message_count": len(state.get("history", [])),
                    "created_at": state.get("created_at", 0),
                    "last_message_at": state.get("updated_at", 0),
                    "preview": "",
                })
            return {"sessions": sessions[:limit], "total": len(sessions)}
        
        try:
            sessions = await chat_history_service.list_sessions(
                user_id=user_id,
                agent_id=agent_id or agent.name,
                status=status,
                limit=limit,
                offset=offset,
            )
            
            return {
                "sessions": [s.to_dict() for s in sessions],
                "total": len(sessions)
            }
            
        except Exception as e:
            logger.exception("Error listing chat sessions")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    @router.get("/v1/chat/sessions/{session_id}")
    async def get_chat_session(session_id: str):
        """Get detailed chat session with messages."""
        if not chat_history_service:
            # Fallback to in-memory store
            state = conversation_store.get(session_id)
            if not state:
                raise HTTPException(status_code=404, detail="Session not found")
            
            return {
                "session_id": session_id,
                "user_id": "unknown",
                "agent_id": agent.name,
                "status": "active",
                "messages": [],
                "created_at": state.get("created_at", 0),
                "updated_at": state.get("updated_at", 0),
            }
        
        try:
            session = await chat_history_service.get_session(session_id)
            if not session:
                raise HTTPException(status_code=404, detail="Session not found")
            
            return session.to_dict()
            
        except Exception as e:
            logger.exception("Error getting chat session")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    @router.get("/v1/chat/sessions/{session_id}/messages")
    async def get_chat_messages(
        session_id: str,
        limit: int = 100,
        before: Optional[int] = None,
    ):
        """Get messages for a session (paginated)."""
        if not chat_history_service:
            return JSONResponse(
                status_code=503,
                content={"error": "Chat history service not available"}
            )
        
        try:
            messages = await chat_history_service.get_messages(
                session_id=session_id,
                limit=limit,
                before_timestamp=before,
            )
            
            return {
                "messages": [m.to_dict() for m in messages],
                "session_id": session_id,
            }
            
        except Exception as e:
            logger.exception("Error getting chat messages")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    @router.get("/v1/chat/sessions/{session_id}/history")
    async def get_chat_history(session_id: str, max_messages: int = 50):
        """Get conversation history formatted for LLM context."""
        if not chat_history_service:
            return JSONResponse(
                status_code=503,
                content={"error": "Chat history service not available"}
            )
        
        try:
            history = await chat_history_service.get_conversation_history(
                session_id=session_id,
                max_messages=max_messages,
            )
            
            return {
                "history": history,
                "session_id": session_id,
            }
            
        except Exception as e:
            logger.exception("Error getting chat history")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    @router.patch("/v1/chat/sessions/{session_id}")
    async def update_chat_session(session_id: str, request: Request):
        """Update session metadata (status, etc.)."""
        if not chat_history_service:
            return JSONResponse(
                status_code=503,
                content={"error": "Chat history service not available"}
            )
        
        try:
            data = await request.json()
            status = data.get("status")
            
            if status:
                success = await chat_history_service.update_session_status(
                    session_id=session_id,
                    status=status,
                )
                
                if not success:
                    raise HTTPException(status_code=404, detail="Session not found")
            
            return {"session_id": session_id, "updated": True}
            
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Error updating chat session")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    @router.delete("/v1/chat/sessions/{session_id}")
    async def delete_chat_session(
        session_id: str,
        soft_delete: bool = True,
    ):
        """Delete a chat session."""
        if not chat_history_service:
            # Fallback to in-memory
            conversation_store.delete(session_id)
            return {"session_id": session_id, "deleted": True}
        
        try:
            success = await chat_history_service.delete_session(
                session_id=session_id,
                soft_delete=soft_delete,
            )
            
            if not success:
                raise HTTPException(status_code=404, detail="Session not found")
            
            # Also clean up in-memory store
            conversation_store.delete(session_id)
            
            return {"session_id": session_id, "deleted": True}
            
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Error deleting chat session")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )

    return router


async def _process_chat_request(agent: "Agent", req: ChatCompletionRequest) -> ChatCompletionResponse:
    """Process an OpenAI-compatible chat completion request with persistent chat history.

    Args:
        agent: Agent instance
        req: Chat completion request

    Returns:
        OpenAI-compatible chat completion response
        
    Raises:
        HTTPException: If no user message found in messages list
    """
    from fastapi import HTTPException
    
    # Extract user message from messages list
    user_message = ""
    for msg in reversed(req.messages):
        if msg.role == "user":
            user_message = msg.content
            break

    if not user_message:
        raise HTTPException(status_code=400, detail="No user message found in messages list")
    
    try:

        # Get or create conversation
        conversation_id = req.conversation_id or str(uuid.uuid4())
        user_id = req.user or conversation_id

        # Initialize chat history session if service is available
        if chat_history_service:
            try:
                existing_session = await chat_history_service.get_session(conversation_id)
                if not existing_session:
                    await chat_history_service.create_session(
                        user_id=user_id,
                        agent_id=agent.name,
                        session_id=conversation_id,
                        provider_type="openai",  # TODO: Detect from agent config
                    )
                    logger.debug(f"Created chat history session: {conversation_id}")
            except Exception as e:
                logger.warning(f"Failed to create chat history session: {e}")

        # Call agent with latency tracking
        start_time = time.time()
        response = await agent.chat_async(
            message=user_message,
            user_id=user_id,
            session_id=conversation_id,
            channel="api",
        )
        latency_ms = int((time.time() - start_time) * 1000)

        # Get model ID
        model_id = agent._resolve_model_id() if hasattr(agent, '_resolve_model_id') else str(agent.model)

        # Update conversation state
        now_ts = int(time.time())

        # Save to persistent chat history if available
        if chat_history_service:
            try:
                # Save user message
                await chat_history_service.save_message(
                    session_id=conversation_id,
                    role="user",
                    content=user_message,
                    latency_ms=0,  # User messages have no generation latency
                )
                
                # Save assistant response
                await chat_history_service.save_message(
                    session_id=conversation_id,
                    role="assistant",
                    content=response,
                    latency_ms=latency_ms,
                    token_count=len(response.split()) if response else 0,
                )
                logger.debug(f"Saved chat history for session: {conversation_id}")
            except Exception as e:
                logger.warning(f"Failed to save chat history: {e}")

        # Update conversation state (backward compatibility)
        state = conversation_store.get(conversation_id) or {
            "history": [],
            "created_at": now_ts,
        }
        state["history"].append({
            "message": {"role": "user", "content": user_message},
            "response": {"role": "assistant", "content": response},
        })
        state["updated_at"] = now_ts
        conversation_store.save(conversation_id, state)

        # Build response
        return ChatCompletionResponse(
            id=f"chatcmpl-{uuid.uuid4().hex[:24]}",
            created=now_ts,
            model=model_id,
            choices=[
                ChatCompletionChoice(
                    index=0,
                    message=ChatMessage(role="assistant", content=response),
                    finish_reason="stop",
                )
            ],
            usage=Usage(
                prompt_tokens=len(user_message.split()),
                completion_tokens=len(response.split()),
                total_tokens=len(user_message.split()) + len(response.split()),
            ),
            conversation_id=conversation_id,
        )

    except Exception as e:
        logger.exception("Error processing chat request")
        raise


async def _stream_chat_response(
    agent: "Agent",
    user_message: str,
    conversation_id: str,
    user_id: str,
) -> AsyncGenerator[str, None]:
    """Generate SSE stream for chat response with persistent chat history.
    
    Yields OpenAI-compatible SSE data chunks as the agent generates tokens.
    
    Args:
        agent: Agent instance
        user_message: User's input message
        conversation_id: Conversation ID for state tracking
        user_id: User ID
        
    Yields:
        SSE-formatted data strings
    """
    model_id = agent._resolve_model_id() if hasattr(agent, '_resolve_model_id') else str(agent.model)
    completion_id = f"chatcmpl-{uuid.uuid4().hex[:24]}"
    created = int(time.time())
    
    full_content = ""
    snapshot_style_deltas = False
    
    # Track latency
    start_time = time.time()
    
    # Initialize chat history session if service is available
    if chat_history_service:
        try:
            existing_session = await chat_history_service.get_session(conversation_id)
            if not existing_session:
                await chat_history_service.create_session(
                    user_id=user_id,
                    agent_id=agent.name,
                    session_id=conversation_id,
                    provider_type="openai",
                )
        except Exception as e:
            logger.warning(f"Failed to create chat history session: {e}")

    try:
        # Try streaming first
        async for event in agent.chat_streamed(
            message=user_message,
            user_id=user_id,
            session_id=conversation_id,
            channel="api",
        ):
            payload = getattr(event, "data", event)
            payload_type = getattr(payload, "type", None)

            content_candidate = ""
            content_delta = ""
            is_final_snapshot = False

            if isinstance(payload_type, str):
                # Only stream assistant output text deltas. Other delta events (tool args, refusal,
                # reasoning) should not be treated as chat message content.
                if payload_type == "response.output_text.delta" and isinstance(getattr(payload, "delta", None), str):
                    content_candidate = payload.delta
                # Some providers may emit a final snapshot of the output text; treat it as
                # a candidate and deduplicate against what we've already streamed.
                elif payload_type == "response.output_text.done" and isinstance(getattr(payload, "text", None), str):
                    content_candidate = payload.text
                    is_final_snapshot = True
            else:
                # Fallback for mocked/unknown stream event shapes used in tests or adapters.
                if hasattr(payload, "delta") and isinstance(payload.delta, str):
                    content_candidate = payload.delta
                elif hasattr(payload, "delta") and hasattr(payload.delta, "text"):
                    content_candidate = payload.delta.text
                elif hasattr(payload, "delta") and hasattr(payload.delta, "content"):
                    content_candidate = payload.delta.content
                elif hasattr(payload, "text"):
                    content_candidate = payload.text

            if content_candidate:
                if is_final_snapshot:
                    # response.output_text.done is a final snapshot of the full text.
                    # If we already streamed content, only emit the missing suffix.
                    if not full_content:
                        content_delta = content_candidate
                    elif (
                        content_candidate.startswith(full_content)
                        and len(content_candidate) > len(full_content)
                    ):
                        content_delta = content_candidate[len(full_content) :]
                    else:
                        content_delta = ""
                else:
                    # Most providers emit true deltas, but some emit cumulative snapshots.
                    # Only treat it as a snapshot when it grows and matches the prefix.
                    if (
                        full_content
                        and content_candidate.startswith(full_content)
                        and len(content_candidate) > len(full_content)
                    ):
                        content_delta = content_candidate[len(full_content) :]
                        snapshot_style_deltas = True
                    elif snapshot_style_deltas and full_content and content_candidate == full_content:
                        content_delta = ""
                    else:
                        content_delta = content_candidate

            if content_delta:
                full_content += content_delta
                # Yield OpenAI-compatible SSE chunk
                chunk = {
                    "id": completion_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": model_id,
                    "choices": [{
                        "index": 0,
                        "delta": {"content": content_delta},
                        "finish_reason": None,
                    }],
                }
                yield f"data: {json.dumps(chunk)}\n\n"
        
        # If no content was streamed, fall back to non-streaming
        if not full_content:
            response = await agent.chat_async(
                message=user_message,
                user_id=user_id,
                session_id=conversation_id,
                channel="api",
            )
            full_content = response or ""
            
            # Yield full content as single chunk
            chunk = {
                "id": completion_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model_id,
                "choices": [{
                    "index": 0,
                    "delta": {"content": full_content},
                    "finish_reason": None,
                }],
            }
            yield f"data: {json.dumps(chunk)}\n\n"
        
        # Final chunk with finish_reason
        final_chunk = {
            "id": completion_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model_id,
            "choices": [{
                "index": 0,
                "delta": {},
                "finish_reason": "stop",
            }],
        }
        yield f"data: {json.dumps(final_chunk)}\n\n"
        yield "data: [DONE]\n\n"
        
        # Calculate latency
        latency_ms = int((time.time() - start_time) * 1000)
        
        # Save to persistent chat history if available
        if chat_history_service:
            try:
                await chat_history_service.save_message(
                    session_id=conversation_id,
                    role="user",
                    content=user_message,
                    latency_ms=0,
                )
                await chat_history_service.save_message(
                    session_id=conversation_id,
                    role="assistant",
                    content=full_content,
                    latency_ms=latency_ms,
                    token_count=len(full_content.split()) if full_content else 0,
                )
            except Exception as e:
                logger.warning(f"Failed to save streaming chat history: {e}")
        
        # Update conversation state (backward compatibility)
        now_ts = int(time.time())
        state = conversation_store.get(conversation_id) or {
            "history": [],
            "created_at": now_ts,
        }
        state["history"].append({
            "message": {"role": "user", "content": user_message},
            "response": {"role": "assistant", "content": full_content},
        })
        state["updated_at"] = now_ts
        conversation_store.save(conversation_id, state)
        
    except Exception as e:
        logger.exception("Error during streaming chat")
        error_chunk = {
            "error": {
                "message": str(e),
                "type": "server_error",
            }
        }
        yield f"data: {json.dumps(error_chunk)}\n\n"
        yield "data: [DONE]\n\n"


async def _process_streaming_chat_request(agent: "Agent", req: ChatCompletionRequest) -> StreamingResponse:
    """Process a streaming chat completion request.
    
    Args:
        agent: Agent instance
        req: Chat completion request
        
    Returns:
        StreamingResponse with SSE content
        
    Raises:
        HTTPException: If no user message found in messages list
    """
    # Extract user message from messages list
    user_message = ""
    for msg in reversed(req.messages):
        if msg.role == "user":
            user_message = msg.content
            break
    
    if not user_message:
        raise HTTPException(status_code=400, detail="No user message found in messages list")
    
    # Get or create conversation
    conversation_id = req.conversation_id or str(uuid.uuid4())
    user_id = req.user or conversation_id
    
    return StreamingResponse(
        _stream_chat_response(agent, user_message, conversation_id, user_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


async def _process_v1_chat_request(agent: "Agent", req: V1ChatRequest) -> V1ChatResponse:
    """Process a v0.1.0 compatible chat request with full plugin support.
    
    This endpoint mirrors the original contextwise API behavior with:
    - Plugin manager before_run/after_run hooks
    - Events tracking
    - Full conversation state management
    
    Args:
        agent: Agent instance
        req: v0.1.0 chat request
        
    Returns:
        v0.1.0 compatible chat response
    """
    from .lib.base import AgentContext
    
    # Initialize or retrieve conversation state
    is_new = not req.conversation_id or conversation_store.get(req.conversation_id) is None
    
    if is_new:
        conversation_id = str(uuid.uuid4())
        now_ts = int(time.time())
        state: Dict[str, Any] = {
            "input_items": [],
            "context": {},
            "current_agent": agent.name,
            "created_at": now_ts,
            "updated_at": now_ts,
            "history": [],
        }
        
        # Handle empty message for new conversation
        if req.message.strip() == "":
            conversation_store.save(conversation_id, state)
            return V1ChatResponse(
                conversation_id=conversation_id,
                current_agent=agent.name,
                messages=[],
                events=[],
                context={},
                agents=[_build_agent_dict(agent)],
            )
    else:
        conversation_id = req.conversation_id  # type: ignore
        state = conversation_store.get(conversation_id) or {
            "input_items": [],
            "context": {},
            "current_agent": agent.name,
            "created_at": int(time.time()),
            "updated_at": int(time.time()),
            "history": [],
        }
    
    # Add user message to input items
    state["input_items"].append({"content": req.message, "role": "user"})
    
    # Create agent context
    agent_context = AgentContext(
        user_id=conversation_id,
        channel="api",
        locale=getattr(agent, "locale", "en"),
        session_id=conversation_id,
    )
    
    messages: List[MessageResponse] = []
    events: List[AgentEvent] = []
    
    try:
        # Get plugin manager if available
        plugin_manager = getattr(agent, '_plugin_manager', None)
        
        # Call before_run hook
        if plugin_manager:
            plugin_manager.before_run(agent_context, req.message)
        
        # Call agent
        response = await agent.chat_async(
            message=req.message,
            user_id=conversation_id,
            channel="api",
        )
        
        # Call after_run hook (if plugin manager supports it)
        if plugin_manager and hasattr(plugin_manager, 'after_run'):
            plugin_manager.after_run(agent_context, response)
        
        # Build message response
        messages.append(MessageResponse(
            content=response,
            agent=agent.name,
        ))
        
        # Add message event
        events.append(AgentEvent(
            id=uuid.uuid4().hex,
            type="message",
            agent=agent.name,
            content=response,
            timestamp=time.time() * 1000,
        ))
        
    except Exception as e:
        logger.exception("Error processing v1 chat request")
        error_msg = f"Error: {str(e)}"
        messages.append(MessageResponse(content=error_msg, agent=agent.name))
        events.append(AgentEvent(
            id=uuid.uuid4().hex,
            type="error",
            agent=agent.name,
            content=error_msg,
            timestamp=time.time() * 1000,
        ))
    
    # Update conversation state
    now_ts = int(time.time())
    if messages:
        state["history"].append({
            "message": {"role": "user", "content": req.message, "created_at": now_ts},
            "response": {"content": messages[-1].content, "created_at": now_ts},
        })
    state["updated_at"] = now_ts
    conversation_store.save(conversation_id, state)
    
    return V1ChatResponse(
        conversation_id=conversation_id,
        current_agent=agent.name,
        messages=messages,
        events=events,
        context=state.get("context", {}),
        agents=[_build_agent_dict(agent)],
    )


def _build_agent_dict(agent: "Agent") -> Dict[str, Any]:
    """Build agent metadata dictionary."""
    return {
        "name": agent.name,
        "description": agent.description or "",
        "handoffs": [],
        "tools": [
            getattr(t, "name", getattr(t, "__name__", str(t)))
            for t in (agent.tools or [])
        ],
        "input_guardrails": [],
    }


def create_v1_app() -> FastAPI:
    """Create a v0.1.0 compatible FastAPI app for registered agents.
    
    This creates an app that mirrors the original contextwise API behavior,
    using the global agent registry.
    
    Returns:
        FastAPI application with v0.1.0 compatible endpoints
    """
    app = FastAPI(
        title="Contextwise Agent API",
        description="v0.1.0 compatible agent API",
        version="0.2.0",
    )
    
    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    @app.post("/chat", response_model=V1ChatResponse)
    async def v1_chat_endpoint(req: V1ChatRequest):
        """v0.1.0 compatible chat endpoint."""
        if not agent_registry:
            raise HTTPException(status_code=500, detail="No agents registered")
        
        # Get default agent
        agent = get_agent(default_agent_name)
        return await _process_v1_chat_request(agent, req)
    
    @app.get("/v1/agents")
    async def list_agents():
        """List all registered agents."""
        return [_build_agent_dict(agent) for agent in agent_registry.values()]
    
    @app.get("/v1/agents/{agent_id}/sessions")
    async def list_agent_sessions(agent_id: str):
        """List sessions for an agent."""
        sessions = []
        all_conversations = conversation_store.list_all()
        for conv_id, state in all_conversations.items():
            if state.get("current_agent") != agent_id:
                continue
            created_at = int(state.get("created_at", int(time.time())))
            history = state.get("history", [])
            title = ""
            if history:
                first_run = history[0]
                message = first_run.get("message", {})
                title = str(message.get("content", ""))[:50]
            if not title:
                title = f"Session {conv_id[:8]}"
            sessions.append({
                "session_id": conv_id,
                "title": title,
                "created_at": created_at,
            })
        return sessions
    
    @app.get("/v1/agents/{agent_id}/sessions/{session_id}")
    async def get_agent_session(agent_id: str, session_id: str):
        """Get a specific session."""
        state = conversation_store.get(session_id)
        if state is None:
            raise HTTPException(status_code=404, detail="Session not found")
        
        runs = state.get("history", [])
        return {
            "session_id": session_id,
            "agent_id": agent_id,
            "user_id": None,
            "runs": runs,
            "memory": {"runs": runs, "chats": runs},
            "agent_data": {},
        }
    
    @app.delete("/v1/agents/{agent_id}/sessions/{session_id}")
    async def delete_agent_session(agent_id: str, session_id: str):
        """Delete a session."""
        state = conversation_store.get(session_id)
        if state is None:
            raise HTTPException(status_code=404, detail="Session not found")
        
        conversation_store.delete(session_id)
        return {"status": "deleted"}
    
    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        return {"status": "healthy", "agents": list(agent_registry.keys())}
    
    return app
