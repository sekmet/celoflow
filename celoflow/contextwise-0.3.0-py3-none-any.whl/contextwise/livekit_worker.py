"""LiveKit Agent Worker for Contextwise.

This module provides a LiveKit Agents worker that registers with the LiveKit server
and automatically handles voice sessions when participants join rooms.

Architecture:
    - The worker runs as a SEPARATE process from the main FastAPI server
    - It connects to the LiveKit server and registers as an agent worker
    - When a participant joins a room (e.g., via WhatsApp Go bridge), 
      LiveKit dispatches this worker to handle the voice session
    - The worker provides STT → LLM → TTS voice processing pipeline

Usage:
    # Run as a separate process:
    uv run python -m contextwise.livekit_worker start
    
    # Or from the examples directory:
    uv run python livekit_agent.py start
    
    # With config via environment:
    CONTEXTWISE_WORKER_CONFIG='{"voice_config":{"stt":"groq/whisper-large-v3-turbo"}}' \
        python -m contextwise.livekit_worker start
"""

import json
import logging
import os
from typing import Any, Optional, TYPE_CHECKING

from dotenv import load_dotenv

# Load environment variables before importing livekit
load_dotenv()

logger = logging.getLogger("contextwise.livekit_worker")

if TYPE_CHECKING:
    import subprocess

# =============================================================================
# Module-level configuration (loaded from environment or defaults)
# =============================================================================

def _load_config_from_env() -> tuple:
    """Load voice config and instructions from environment."""
    config_json = os.environ.get("CONTEXTWISE_WORKER_CONFIG", "")
    if config_json:
        try:
            config = json.loads(config_json)
            return (
                config.get("voice_config", {}),
                config.get("instructions", ""),
            )
        except json.JSONDecodeError:
            logger.warning("Failed to parse CONTEXTWISE_WORKER_CONFIG")
    return {}, ""


# Load config at module import time
_VOICE_CONFIG, _INSTRUCTIONS = _load_config_from_env()

# Apply defaults if not set
if not _VOICE_CONFIG:
    _VOICE_CONFIG = {
        "stt": "groq/whisper-large-v3-turbo",
        "stt_language": "en",
        "model": "gpt-4o-mini",
        "tts": "inworld/lupita",
    }

if not _INSTRUCTIONS:
    _INSTRUCTIONS = (
        "You are a helpful voice assistant. "
        "Be concise and conversational. "
        "Keep responses brief - under 2 sentences when possible."
    )


# =============================================================================
# Module-level LiveKit components (required for multiprocessing pickling)
# =============================================================================

# Try to import LiveKit - will fail gracefully if not installed
_LIVEKIT_AVAILABLE = False
try:
    from livekit import rtc
    from livekit.agents import (
        Agent,
        AgentServer,
        AgentSession,
        JobContext,
        JobProcess,
        cli,
        room_io,
    )
    from livekit.plugins import noise_cancellation
    _LIVEKIT_AVAILABLE = True
except ImportError:
    pass


# Module-level Agent class
if _LIVEKIT_AVAILABLE:
    class ContextwiseVoiceAgent(Agent):
        """Voice agent with configurable instructions."""
        def __init__(self):
            super().__init__(instructions=_INSTRUCTIONS)


# Module-level prewarm function
def prewarm(proc: "JobProcess"):
    """Prewarm function - load VAD and noise cancellation models once per process.
    
    The noise cancellation plugin MUST be loaded here (before any audio stream
    is created) so that its AudioFilter is registered with the LiveKit FFI layer.
    If not loaded before session.start(), the FFI will fail to find the audio
    filter module and log:
        'failed to initialize the audio filter. it will not be enabled for this session'
    """
    from livekit.plugins import silero
    proc.userdata["vad"] = silero.VAD.load()
    logger.info("VAD model prewarmed")
    
    try:
        from livekit.plugins import noise_cancellation
        if not noise_cancellation._loaded:
            noise_cancellation.load()
        logger.info("Noise cancellation plugin loaded (AudioFilter registered with FFI)")
    except Exception as e:
        logger.error(f"Failed to load noise cancellation plugin: {e}")


# Module-level noise cancellation function
def _noise_cancellation_fn(params):
    """Noise cancellation selector for audio input.
    
    Returns BVCTelephony for SIP participants (telephony-optimized model)
    and BVC (Background Voice Cancellation) for standard participants.
    
    The noise_cancellation module must already be imported at module level
    so that load() has registered the AudioFilter with the FFI layer.
    """
    if not _LIVEKIT_AVAILABLE:
        return None
    try:
        if params.participant.kind == rtc.ParticipantKind.PARTICIPANT_KIND_SIP:
            return noise_cancellation.BVCTelephony()
        return noise_cancellation.BVC()
    except Exception as e:
        logger.error(f"Failed to create noise cancellation options: {e}")
        return None


# =============================================================================
# Module-level AgentServer (created at import time if LiveKit available)
# =============================================================================

server: Optional["AgentServer"] = None

if _LIVEKIT_AVAILABLE:
    server = AgentServer()
    server.setup_fnc = prewarm
    
    @server.rtc_session()
    async def voice_session_handler(ctx: "JobContext"):
        """Handle voice sessions when participants join rooms.
        
        This function is called when a participant joins a LiveKit room.
        It creates the STT/LLM/TTS pipeline and connects the agent.
        """
        ctx.log_context_fields = {"room": ctx.room.name}
        logger.info(f"Voice session started for room: {ctx.room.name}")
        
        # Create STT
        stt = _create_stt(_VOICE_CONFIG)
        
        # Create LLM
        llm = _create_llm(_VOICE_CONFIG)
        
        # Create TTS
        tts = _create_tts(_VOICE_CONFIG)
        
        # Create agent session with voice pipeline
        session = AgentSession(
            stt=stt,
            llm=llm,
            tts=tts,
            vad=ctx.proc.userdata["vad"],
            turn_detection=_create_turn_detector(),
            preemptive_generation=True,
        )
        
        # Start the session
        await session.start(
            agent=ContextwiseVoiceAgent(),
            room=ctx.room,
            room_options=room_io.RoomOptions(
                audio_input=room_io.AudioInputOptions(
                    noise_cancellation=_noise_cancellation_fn,
                ),
            ),
        )
        
        # Connect to the room
        await ctx.connect()
        logger.info(f"Voice session connected for room: {ctx.room.name}")


def _create_stt(voice_config: dict) -> Any:
    """Create STT (Speech-to-Text) plugin."""
    stt_config = voice_config.get("stt", "groq/whisper-large-v3-turbo")
    stt_language = voice_config.get("stt_language", "en")
    
    if "/" in stt_config:
        provider, model = stt_config.split("/", 1)
    else:
        provider, model = "groq", stt_config
    
    if provider == "groq":
        from livekit.plugins import groq
        return groq.STT(model=model, language=stt_language)
    elif provider == "openai":
        from livekit.plugins import openai
        return openai.STT(model=model, language=stt_language)
    elif provider == "deepgram":
        from livekit.plugins import deepgram
        return deepgram.STT(model=model, language=stt_language)
    else:
        # Default to Groq
        from livekit.plugins import groq
        return groq.STT(model="whisper-large-v3-turbo", language=stt_language)


def _create_llm(voice_config: dict) -> Any:
    """Create LLM plugin."""
    llm_model = voice_config.get("model", "gpt-4o-mini")
    
    if "/" in llm_model:
        provider, model = llm_model.split("/", 1)
    else:
        provider, model = "openai", llm_model
    
    if provider == "groq":
        from livekit.plugins import openai
        return openai.LLM(
            model=model,
            base_url="https://api.groq.com/openai/v1",
            api_key=os.getenv("GROQ_API_KEY"),
        )
    elif provider == "google":
        from livekit.plugins import google
        return google.LLM(
            model=model,
            api_key=os.getenv("GEMINI_API_KEY"),
        )
    elif provider == "cerebras":
        from livekit.plugins import openai
        return openai.LLM.with_cerebras(
            model=model,
            api_key=os.getenv("CEREBRAS_API_KEY"),
        )
    elif provider == "openai":
        from livekit.plugins import openai
        return openai.LLM(model=model)
    else:
        from livekit.plugins import openai
        return openai.LLM(model="gpt-4o-mini")


def _create_tts(voice_config: dict) -> Any:
    """Create TTS (Text-to-Speech) plugin.

    Note on Inworld encoding: The inworld-tts-1.5-* models with OGG_OPUS encoding
    produce audio chunks that the PyAV decoder in livekit-agents<=1.3.x cannot parse,
    causing av.error.EOFError. MP3 encoding is used instead, which the decoder handles
    reliably. This can be revisited when livekit-agents is upgraded past 1.3.x.
    """
    tts_config = voice_config.get("tts", "inworld/lupita")
    tts_voice = voice_config.get("tts_voice")
    tts_model = voice_config.get("tts_model")  # None = use provider default
    tts_encoding = voice_config.get("tts_encoding", "MP3")
    tts_speaking_rate = voice_config.get("tts_speaking_rate", 1.2)
    tts_language = voice_config.get("tts_language", "en")
    tts_use_stream_adapter_raw = voice_config.get("tts_use_stream_adapter", True)
    tts_inactivity_timeout_raw = voice_config.get("tts_inactivity_timeout")

    if "/" in tts_config:
        provider, voice = tts_config.split("/", 1)
    else:
        provider, voice = "inworld", tts_config

    if tts_voice:
        voice = tts_voice

    if provider == "inworld":
        from livekit.plugins import inworld
        # Debug: Check if Inworld API key is present in subprocess
        inworld_key = os.getenv("INWORLD_API_KEY", "")
        if inworld_key:
            logger.info(
                f"Creating Inworld TTS: model={tts_model}, voice={voice}, "
                f"encoding={tts_encoding}, API key configured ({len(inworld_key)} chars)"
            )
        else:
            logger.error("INWORLD_API_KEY not set! TTS authentication will fail.")
        # Only pass model if explicitly set, otherwise Inworld uses its default
        if tts_model:
            return inworld.TTS(
                model=tts_model,
                voice=voice,
                encoding=tts_encoding,
                speaking_rate=tts_speaking_rate,
                language=tts_language,
            )
        else:
            return inworld.TTS(
                voice=voice,
                encoding=tts_encoding,
                speaking_rate=tts_speaking_rate,
                language=tts_language,
            )
    elif provider == "openai":
        from livekit.plugins import openai
        return openai.TTS(voice=voice)
    elif provider == "cartesia":
        from livekit.plugins import cartesia
        # Cartesia uses 'model' parameter (default: sonic-3-latest)
        cartesia_model = tts_model if tts_model else "sonic-3-latest"
        logger.info(
            f"Creating Cartesia TTS: model={cartesia_model}, voice={voice}"
        )
        return cartesia.TTS(
            model=cartesia_model, 
            voice=voice,
            language=tts_language,
            speed=tts_speaking_rate,
        )
    elif provider == "elevenlabs":
        from livekit.plugins import elevenlabs
        # Elevenlabs uses 'model' parameter (default: eleven_multilingual_v2)
        elevenlabs_model = tts_model if tts_model else "eleven_multilingual_v2"

        # Keep bool parsing tolerant when config comes from env/json.
        if isinstance(tts_use_stream_adapter_raw, str):
            tts_use_stream_adapter = tts_use_stream_adapter_raw.strip().lower() not in {
                "0",
                "false",
                "no",
                "off",
            }
        else:
            tts_use_stream_adapter = bool(tts_use_stream_adapter_raw)

        tts_inactivity_timeout: Optional[int] = None
        if tts_inactivity_timeout_raw is not None:
            try:
                tts_inactivity_timeout = int(tts_inactivity_timeout_raw)
            except (TypeError, ValueError):
                logger.warning(
                    "Invalid tts_inactivity_timeout=%r for ElevenLabs; using provider default",
                    tts_inactivity_timeout_raw,
                )

        elevenlabs_kwargs: dict[str, Any] = {
            "model": elevenlabs_model,
            "voice_id": voice,
            "streaming_latency": 1,
        }

        # ElevenLabs language_code is only supported for eleven_turbo_v2_5.
        if tts_language and elevenlabs_model == "eleven_turbo_v2_5":
            elevenlabs_kwargs["language"] = tts_language
        elif tts_language:
            logger.info(
                "Ignoring ElevenLabs language override for model=%s; "
                "language is only supported by eleven_turbo_v2_5",
                elevenlabs_model,
            )

        if tts_inactivity_timeout is not None:
            elevenlabs_kwargs["inactivity_timeout"] = tts_inactivity_timeout

        logger.info(
            "Creating Elevenlabs TTS: model=%s, voice=%s, stream_adapter=%s",
            elevenlabs_model,
            voice,
            tts_use_stream_adapter,
        )
        elevenlabs_tts = elevenlabs.TTS(**elevenlabs_kwargs)

        # livekit-agents 1.3.x has known retry instability on ElevenLabs websocket
        # streaming after unexpected close/timeout. StreamAdapter uses chunked
        # synthesis under the hood and is more resilient for production calls.
        if tts_use_stream_adapter:
            from livekit.agents import tts as livekit_tts

            return livekit_tts.StreamAdapter(tts=elevenlabs_tts)

        return elevenlabs_tts
    else:
        from livekit.plugins import inworld
        return inworld.TTS(
            voice=voice,
            encoding=tts_encoding,
            speaking_rate=tts_speaking_rate,
        )


def _create_turn_detector() -> Any:
    """Create turn detector.
    
    Note: MultilingualModel requires inference executor which is not available
    when running as a subprocess with 'start' mode. For now, we disable turn
    detection and use VAD-only mode which works reliably.
    
    To enable turn detection, run the worker with 'dev' mode:
        python -m contextwise.livekit_worker dev
    """
    # Disable turn detection for subprocess mode to avoid inference executor errors
    # VAD-only mode works fine for basic voice interaction
    logger.info("Using VAD-only mode for turn detection (no MultilingualModel)")
    return None


def run_worker(
    voice_config: Optional[dict] = None,
    instructions: Optional[str] = None,
):
    """Run the LiveKit agent worker.
    
    This function runs the module-level agent server, registering it with
    the LiveKit server. When participants join rooms, the server will
    dispatch this agent to handle voice sessions.
    
    Note: voice_config and instructions are ignored - config is loaded
    from CONTEXTWISE_WORKER_CONFIG environment variable at module import.
    
    Args:
        voice_config: IGNORED - use CONTEXTWISE_WORKER_CONFIG env var
        instructions: IGNORED - use CONTEXTWISE_WORKER_CONFIG env var
    """
    if not _LIVEKIT_AVAILABLE:
        raise ImportError(
            "LiveKit Agents SDK not installed. "
            "Install with: uv add livekit-agents livekit-plugins-silero"
        )
    
    if server is None:
        raise RuntimeError("LiveKit server not initialized")
    
    logger.info("Starting LiveKit agent worker...")
    logger.info(f"LIVEKIT_URL: {os.getenv('LIVEKIT_URL', 'not set')}")
    logger.info(f"Voice Config: {_VOICE_CONFIG}")
    
    # This registers with LiveKit server and waits for dispatch
    cli.run_app(server)


def spawn_worker_subprocess(
    voice_config: Optional[dict] = None,
    instructions: Optional[str] = None,
) -> Optional["subprocess.Popen"]:
    """Spawn the LiveKit worker as a subprocess.
    
    Uses subprocess.Popen to run the worker in a completely separate Python
    interpreter, avoiding pickling issues with multiprocessing.
    
    Args:
        voice_config: Voice configuration dict
        instructions: Agent instructions
        
    Returns:
        The Popen object if started successfully, None otherwise
    """
    import subprocess
    import sys
    import json
    
    # Check if LiveKit is configured
    livekit_url = os.getenv("LIVEKIT_URL", "")
    livekit_api_key = os.getenv("LIVEKIT_API_KEY", "")
    livekit_api_secret = os.getenv("LIVEKIT_API_SECRET", "")
    
    if not all([livekit_url, livekit_api_key, livekit_api_secret]):
        logger.warning(
            "LiveKit not configured. Set LIVEKIT_URL, LIVEKIT_API_KEY, and "
            "LIVEKIT_API_SECRET to enable voice processing."
        )
        return None
    
    voice_config = voice_config or DEFAULT_VOICE_CONFIG
    instructions = instructions or DEFAULT_INSTRUCTIONS
    
    logger.info("Spawning LiveKit worker subprocess...")
    logger.info(f"  LIVEKIT_URL: {livekit_url}")
    logger.info(f"  Voice Config: STT={voice_config.get('stt')}, TTS={voice_config.get('tts')}")
    
    # Debug: Check if Inworld API key is present
    inworld_key = os.getenv("INWORLD_API_KEY", "")
    if inworld_key:
        logger.info(f"  INWORLD_API_KEY: configured ({len(inworld_key)} chars)")
    else:
        logger.warning("  INWORLD_API_KEY: NOT SET - Inworld TTS will fail!")
    
    # Serialize config to JSON for passing via environment variable
    config_json = json.dumps({
        "voice_config": voice_config,
        "instructions": instructions,
    })
    
    # Get the path to this module
    module_path = os.path.dirname(os.path.abspath(__file__))
    worker_script = os.path.join(module_path, "livekit_worker.py")
    
    # Copy current environment and add config
    env = os.environ.copy()
    env["CONTEXTWISE_WORKER_CONFIG"] = config_json
    
    # Spawn the worker as a subprocess
    # Don't capture stdout/stderr so worker logs appear in main console
    process = subprocess.Popen(
        [sys.executable, worker_script, "start"],
        env=env,
    )
    
    logger.info(f"LiveKit worker subprocess started (PID: {process.pid})")
    return process


# Alias for backwards compatibility
spawn_worker_process = spawn_worker_subprocess


def voice_config_to_dict(voice_config: Any) -> dict:
    """Convert a VoiceConfig object to a dictionary.
    
    Args:
        voice_config: VoiceConfig instance or dict
        
    Returns:
        Dictionary with voice configuration
    """
    if voice_config is None:
        return {}
    
    if isinstance(voice_config, dict):
        return voice_config
    
    # Convert VoiceConfig dataclass to dict
    return {
        "instructions": getattr(voice_config, "instructions", None),
        "model": getattr(voice_config, "model", None),
        "stt": getattr(voice_config, "stt", "groq/whisper-large-v3-turbo"),
        "stt_language": getattr(voice_config, "stt_language", "en"),
        "tts": getattr(voice_config, "tts", "inworld/lupita"),
        "tts_voice": getattr(voice_config, "tts_voice", None),
        "tts_model": getattr(voice_config, "tts_model", None),  # None = provider default
        "tts_encoding": getattr(voice_config, "tts_encoding", "MP3"),
        "tts_speaking_rate": getattr(voice_config, "tts_speaking_rate", 1.2),
        "tts_language": getattr(voice_config, "tts_language", "en"),
        "tts_use_stream_adapter": getattr(voice_config, "tts_use_stream_adapter", True),
        "tts_inactivity_timeout": getattr(voice_config, "tts_inactivity_timeout", None),
    }


# Default voice configuration
DEFAULT_VOICE_CONFIG = {
    "stt": "groq/whisper-large-v3-turbo",
    "stt_language": "en",
    "model": "gpt-4o-mini",
    "tts": "inworld/Lupita",
    "tts_model": None,  # Use provider default
    "tts_encoding": "MP3",
    "tts_speaking_rate": 1.2,
    "tts_use_stream_adapter": True,
    "tts_inactivity_timeout": None,
}

DEFAULT_INSTRUCTIONS = (
    "You are a helpful voice assistant. "
    "Be concise and conversational. "
    "Keep responses brief - under 2 sentences when possible."
)


if __name__ == "__main__":
    # Config is loaded at module import time from CONTEXTWISE_WORKER_CONFIG env var
    # The module-level server is already configured with the voice pipeline
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    
    logger.info(f"Config loaded: {_VOICE_CONFIG}")
    run_worker()
